--
-- NextDR Supabase Database Schema 
-- NDR-SCHEMA-VERSION: 1.1.5
-- NDR-UPGRADE-FROM: 1.1.4
-- NDR-SCHEMA-TYPE: INCR
-- NDR-FULL-BASELINE-SCHEMA-SHA256: 914650d0b3688fc68f9283b624d8d8e8b6b8df5a2513e13d82ff9c033dd51d5e
-- NDR-FULL-UPGRADE-SCHEMA-SHA256: cff573c59fbb66c8f424eacfdb9e194e9d0357df5d9bb7b88b42f1fa82db5e5c
--

drop policy "Allow users to insert row for own user_id" on "public"."user_license";

drop policy "Enable users to view their own data only" on "public"."user_license";

drop policy "Users can update own license key" on "public"."user_license";

create table "public"."audit_events" (
    "event_id" uuid not null default gen_random_uuid(),
    "timestamp_utc" timestamp with time zone not null default now(),
    "actor" character varying default 'system'::character varying,
    "actor_type" character varying default 'system'::character varying,
    "action" character varying default ''::character varying,
    "resource_type" character varying default ''::character varying,
    "resource_id" character varying default ''::character varying,
    "resource_version" character varying,
    "severity" character varying default 'info'::character varying,
    "correlation_id" character varying,
    "execution_id" character varying,
    "incident_id" character varying,
    "before" jsonb,
    "after" jsonb,
    "metadata" jsonb default '{}'::jsonb
);


alter table "public"."audit_events" enable row level security;

create table "public"."recovery_run_reports" (
    "id" uuid not null default gen_random_uuid(),
    "run_id" text not null,
    "report_json" jsonb not null,
    "report_hash" text not null,
    "pdf_path" text not null,
    "report_version" text not null,
    "schema_version" text not null,
    "generated_at" timestamp with time zone not null,
    "immutable" boolean not null default true,
    "created_at" timestamp with time zone not null default now()
);


alter table "public"."recovery_run_reports" enable row level security;

alter table "public"."application_groups" add column "backup_region" text;

alter table "public"."application_groups" add column "backup_zone" text;

alter table "public"."recovery_step_execution" add column "target_region" text;

alter table "public"."recovery_step_execution" add column "target_zone" text;

alter table "public"."recovery_steps_new" add column "target_region" text;

alter table "public"."recovery_steps_new" add column "target_zone" text;

CREATE UNIQUE INDEX audit_events_pkey ON public.audit_events USING btree (event_id);

CREATE INDEX idx_recovery_run_reports_generated_at ON public.recovery_run_reports USING btree (generated_at DESC);

CREATE INDEX idx_recovery_run_reports_run_id ON public.recovery_run_reports USING btree (run_id);

CREATE UNIQUE INDEX recovery_run_reports_pkey ON public.recovery_run_reports USING btree (id);

CREATE UNIQUE INDEX recovery_run_reports_run_id_key ON public.recovery_run_reports USING btree (run_id);

alter table "public"."audit_events" add constraint "audit_events_pkey" PRIMARY KEY using index "audit_events_pkey";

alter table "public"."recovery_run_reports" add constraint "recovery_run_reports_pkey" PRIMARY KEY using index "recovery_run_reports_pkey";

alter table "public"."recovery_run_reports" add constraint "recovery_run_reports_run_id_key" UNIQUE using index "recovery_run_reports_run_id_key";

create policy "audit_events_delete_authenticated"
on "public"."audit_events"
as permissive
for delete
to authenticated
using (true);


create policy "audit_events_insert_authenticated"
on "public"."audit_events"
as permissive
for insert
to authenticated
with check (true);


create policy "audit_events_read_authenticated"
on "public"."audit_events"
as permissive
for select
to authenticated
using (true);


create policy "audit_events_update_authenticated"
on "public"."audit_events"
as permissive
for update
to authenticated
using (true)
with check (true);


create policy "Service role full access on recovery_run_reports"
on "public"."recovery_run_reports"
as permissive
for all
to public
using (true)
with check (true);


create policy "Authenticated users can insert licenses"
on "public"."user_license"
as permissive
for insert
to authenticated
with check (true);


create policy "Authenticated users can update licenses"
on "public"."user_license"
as permissive
for update
to authenticated
using (true)
with check (true);


create policy "Authenticated users can view all licenses"
on "public"."user_license"
as permissive
for select
to authenticated
using (true);