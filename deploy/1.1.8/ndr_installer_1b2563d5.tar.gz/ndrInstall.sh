#!/bin/bash

source "$(dirname "${BASH_SOURCE[0]}")/ndrInterface.sh"
source "$(dirname "${BASH_SOURCE[0]}")/ndrRegistry.sh"
source "$(dirname "${BASH_SOURCE[0]}")/ndrDocker.sh"
source "$(dirname "${BASH_SOURCE[0]}")/ndrSupabase.sh"

# --- CONFIGURATION ---

gLOG_FILE="/var/log/ndrInstall.log"


EXPRESS_MENU_OPTIONS="installprerequisites | installsupabase | installservice | installui | installall | removesupabase | removeservice | removeui | removeall | backupdb | restoredb | createaccount"

# ----------------------

# --- FUNCTIONS ---

# ====================================================
# Main script execution
# ====================================================

function mainInstallSupabaseApplication ()
{
  local logSectionDesc="Installing Supabase Application"
  ndr_logSecStart "$logSectionDesc"

  local regName="$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
  
  if [ "$gUPGRADE_MODE" == true ]; then
    # version check to see if module is already at current version.
    local moduleVersion=$(ndr_getModuleVersionReg "$regName")
    if [ "$moduleVersion" == "$gPRODUCT_VERSION" ]; then
      ndr_logInfo "The $gCOMPANY_NAME Supabase module is already at the current product version [$gPRODUCT_VERSION]. No upgrade required."
      return 0
    fi
  fi

  local appBuildOptions="$NDR_SUPABASE_APP_BUILD_OPTIONS_INSTALL"

  ndr_BuildSupabaseApplication "$appBuildOptions"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi
  
  if [ "$gUPGRADE_MODE" == true ]; then
    ndr_logInfo "All currently installed modules have been upgraded."
    ndr_UpdateProductVersion
  fi

  ndr_logInfo "Supabase application install completed."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainInstallClientApplication ()
{ 
  local logSectionDesc="Installing $gCOMPANY_NAME Client Application"
  ndr_logSecStart "$logSectionDesc"

  local compose_file="${gNEXTDR_HOME_DIR}/${NDR_CLIENT_APP_HOME_LOC}/${NDR_CLIENT_APP_COMPOSEFILE_FILENAME}"
  
  local dockerAppManageOptions="$NDR_DOCKER_APP_MANAGE_OPTIONS_REMOVE_ALL"
  if [ "$gNDR_USE_LOCAL_IMAGE_FOR_APP_INSTALL" == true ]; then
    ndr_logInfo "Option to use local Docker image is set, skipping Docker image cleanup."
    dockerAppManageOptions=$(( dockerAppManageOptions & ~NDR_DOCKER_APP_MANAGE_OPTIONS_IMAGE ))
  fi

  #---------------------------------------------------------
  # check that DB is already installed. There is a hard dependency on DB, bothfor operation and installation. Fail if not present.
  ndr_logInfo "Checking that prerequisite $gCOMPANY_NAME Supabase database module is installed, this is required before installing the $gCOMPANY_NAME application."
  
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
  local dbInstalled=$?
  if [[ "$dbInstalled" -ne 0 ]]; then
    ndr_logError "The prerequisite $gCOMPANY_NAME Supabase database module does not appear to be currently installed. This application has an operational dependency on that module and must be installed before this application can be installed. Please install the prerequisite module and try again."
    return 1
  fi

  #---------------------------------------------------------
  # check if module is already installed and if in upgrade mode, if not installed skip it.
  ndr_logInfo "Checking if $gCOMPANY_NAME application is already installed to determine if upgrade or overlay options should be presented."
  
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_CLIENT_NAME"
  local thisInstalled=$?

  # in upgrade mode, if package not installed skip it.
  if [[ "$gUPGRADE_MODE" == true && "$thisInstalled" -ne 0 ]]; then
    ndr_logInfo "The $gCOMPANY_NAME application does not appear to be currently installed. Skipping installation in upgrade mode."
    return 0
  fi

  #----------------------------------------------------------
  # overlay/reinstall mode check, only if not in express mode and not in upgrade mode. In both overlay and upgrade mode, we want to give the user the option to proceed if the application is already installed, but in upgrade mode we do not want to give the option to proceed if the application is not already installed.
  if [[ "$gEXPRESS_MODE" == false && "$gUPGRADE_MODE" == false ]]; then
    # already installed/upgrade/overlay check
    if [[ "$thisInstalled" -eq 0 ]]; then
      read -p "The $gCOMPANY_NAME application is already installed. Would you like to upgrade or overlay the existing installation? (Y|n)" -n 1 -r
      echo    # Move to a new line
      if [[ $REPLY =~ ^[Nn]$ ]]; then
        ndr_logInfo "Operation cancelled, returning to main menu."
        return 1
      fi
      ndr_logInfo "Proceeding with installation."
    fi
  fi

  #----------------------------------------------------------
  # remove container/images and application files from previous installation if they exist. If local image is enabled, skip image cleanup internally.
  if [[ "$thisInstalled" -ne 0 ]]; then
    ndr_logInfo "Previous installation of $gCOMPANY_NAME application is detected, attempting cleanup before installation."
  
    # cleanup at the application/compose level.
    ndr_cleanupDockerApplications "$compose_file" "$dockerAppManageOptions"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "$gCOMPANY_NAME application cleanup failed."
      return 1
    fi
    ndr_logInfo "$gCOMPANY_NAME application cleanup success."
  fi

  #---------------------------------------------------------
  # query/create install home dir (should already be installed from DB installation, but check just in case)
  ndr_logInfo "Checking application install home directory is present and has correct permissions for install operations."
  
  ndr_InstallHomeCheck
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Install home directory check failed."
    return 1
  fi

  # create folder
  local appHomeDir="${gNEXTDR_HOME_DIR}/${NDR_CLIENT_APP_HOME_LOC}"
  
  ndr_CreateApplicationFolders
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create application folders."
    return 1
  fi
  
  #---------------------------------------------------------
  # copy files - compose, caddy, env template
  ndr_logInfo "Copying application files to install location."

  ndr_CopyClientModuleFiles
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Copy module files failed."
    return 1
  fi

  #---------------------------------------------------------
  # Create top level registry entry for application. This is a high level entry to track the overall application status, vs individual module status. 
  ndr_logInfo "Creating base registry entry for $gCOMPANY_NAME application install status."
  
  ndr_RegistryCreateV2 "$gPRODUCT_VERSION" "$gNEXTDR_HOME_DIR" "$gREGISTRY_ENTRY_MODULE_STATUS_CLIENT_NAME"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create application registry."
    return 1
  fi
  
  #---------------------------------------------------------
  # Parse and enumerate compose services - this allows us to go into per-service processing mode to handle per service customization functions. 
  # We could shift some things like pull and compose to top compose level, but then we would not have a hook into per-service customiztion steps along the way--looping through is a better approach.
  ndr_logInfo "Parsing compose file to enumerate services and service details for installation processing."
  
  ndr_ParseComposeFileServicesV2 "$compose_file" ndr_client_container_services ndr_client_container_service_container_names ndr_client_container_service_image_names ndr_client_container_service_image_tags
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to parse compose file [$compose_file] for service details."
    return 1
  fi

  if [[ ${#ndr_client_container_services[@]} -eq 0 ]]; then
    ndr_logWarn "No services found in the compose file '$compose_file'."
    return 0
  fi
  
  #---------------------------------------------------------
  # For each service, read service details: image, container, etc:
  ndr_logInfo "Performing per-service processing and customization."
  
  for service in "${ndr_client_container_services[@]}"; do
    local dockerContainerName="${ndr_client_container_service_container_names[$service]}"
    local dockerFullImageName="${ndr_client_container_service_image_names[$service]}"
    local dockerImageTag="${ndr_client_container_service_image_tags[$service]}"

    local dockerRepoAccount=""
    local dockerRepoName=""
    local dockerImageBaseName=""
    local dockerImageVersionTag=""

    local dockerImageVersionCleanup=$gINSTALLED_VERSION
    #local dockerImageName="$dockerFullImageName"
    
    local containerFolder="$NDR_CLIENT_APP_HOME_LOC"
    local containerHomeDir="${gNEXTDR_HOME_DIR}/${containerFolder}"
    
    local dockerContainerPort=""

    ndr_logInfo "Begin processing for service [$service] with image [$dockerFullImageName] and container name [$dockerContainerName]."

    # Need to distinguish between NDR services and 3rd party services here, as we want to do additional checks and prompts for NDR services around image tags, 
    # but for 3rd party services we just want to pull the image specified in the compose file without prompting.
    ndr_logInfo "Check if service [$service] is a $gCOMPANY_NAME owned service or a 3rd party service to determine if additional checks and prompts for image tag details are needed." 
    local isNDRService="false"
    ndr_IsDockerServiceNextDROwned "$compose_file" "$service" isNDRService
    return_code=$?
    if [[ $return_code -ne 0 || -z "$isNDRService" ]]; then
      ndr_logError "Failed to determine if service [$service] is owned by $gCOMPANY_NAME."
      return 1
    fi

    if [[ "$isNDRService" == "true" ]]; then
      ndr_logInfo "Service [$service] is identified as a $gCOMPANY_NAME owned service. Performing additional checks and prompts for image tag details."
    else
      ndr_logInfo "Service [$service] is identified as a 3rd party service. Skipping additional checks and prompts for image tag details."
    fi

    # For NDR modules, we start with the inital base image tag version in the compose file, but we want to check if there is an updated version of that image in the repo (and optionally give the user the option to use the updated image tag for install). 
    # In advanced mode, we also want to give the user the option to specify a different image tag in the repo to use for install. 
    # For 3rd party modules, we just use the image tag specified in the compose file without prompting.
    # but if any tag is updated, we want to update our local variables and for use with pulling the image and for labeling the container, etc.
    # we also need to update the compose file with the new image tag to ensure the correct image is pulled and used for container construction.
    if [[ "$isNDRService" == "true" ]]; then
      ndr_logInfo "Performing additional image processing for $gCOMPANY_NAME service [$service]."
      
      # The NDR compose file is a template, albeit supplied as complete and up to date as possible.
      # The intial value for the images should map to an actual release value in the repo, but, despite that, the latest image tags will very likley be out of date as images are updated in the official repos. 
      # The version portion is tied to this install version and the latest commit and timestamp will ultimately need to be pulled from the repo image tag.
      
      local imageTagNDRVersion=""
      ndr_ParseImageTagVersionV2 "$dockerFullImageName" imageTagNDRVersion
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Failed to parse image tag version from full image name [$dockerFullImageName] for service [$service]."
        return 1
      fi

      if [[ "$imageTagNDRVersion" != "$gPRODUCT_VERSION" ]]; then        
        ndr_logWarn "Image tag version [$imageTagNDRVersion] does not match install version [$gPRODUCT_VERSION] after parsing from full image name [$dockerFullImageName] for service [$service]. Reforming image tag with install version for further image search and processing."
        ndr_UpdateImageTagVersionValue dockerFullImageName "$gPRODUCT_VERSION"
        return_code=$?
        if [ $return_code -ne 0 ]; then
          ndr_logError "Failed to update image tag version value to install version [$gPRODUCT_VERSION] in full image name [$dockerFullImageName] for service [$service]."
          return 1
        fi
      fi

      # query for latest image tag details.
      # this is applicable to NDR services, but not 3rd party.
      if [[ "$gNDR_ADVANCED_MODE" == true && "$gEXPRESS_MODE" == false ]]; then
        ndr_PromptRemoteImageTagV2 "$dockerFullImageName" dockerFullImageName
      else
        ndr_QueryLatestMatchingRemoteImageTagV2 "$dockerFullImageName" dockerFullImageName
      fi
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Failed to query remote repo for image tag details."
        return 1
      fi

     # We assume that the full image name being used is always different than the default value in the compose file for any number of reasons (updated image query, user selection, etc).
      # Due to this, we always update compose file with the latest image details for this service.
      ndr_UpdateComposeFileServiceImage "$compose_file" "$service" "$dockerFullImageName"
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Failed to update compose file [$compose_file] with new image tag [$dockerFullImageName] for service [$service]."
        return 1
      fi
      ndr_logInfo "Compose file [$compose_file] updated with new image tag [$dockerFullImageName] for service [$service]."

      # also update the global GIT commit and timestamp registry values with the values from the image tag.
      # this will be used for tracking and display purposes in the registry and in the UI about what image version is actually running for this product.
      ndr_UpdateProductVersionDetails "$dockerFullImageName"
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Failed to update product version details with image tag details from full image name [$dockerFullImageName] for service [$service]."
        return 1
      fi    
    fi
    
    # With all the image selection and preprocessing complete, parse final selected full image name into components.
    if [[ "$isNDRService" == "true" ]]; then
      ndr_ParseNDRFullImageName "$dockerFullImageName" dockerRepoAccount dockerRepoName dockerImageBaseName dockerImageVersionTag
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Failed to parse full image name [$dockerFullImageName] for $gCOMPANY_NAME service [$service]."
        return 1
      fi
    else
      ndr_ParseFullImageName "$dockerFullImageName" dockerRepoAccount dockerRepoName dockerImageBaseName dockerImageVersionTag
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Failed to parse full image name [$dockerFullImageName] for 3rd party service [$service]."
        return 1
      fi
    fi
    
    # pull image (with verify) -- doing individually lets us reuse our atomic code functions and point check along the way.
    # compose container (with verify) -- doing individually lets us reuse our atomic code functions and point check along the way.
    # Eliminate systemd service entry--using restart: unless-stopped mechanism in compose instead.
      # must ensure docker service itself is set to restart at reboot (systemctl is-enabled docker)
    # add module specific reg entry - may need to change the level of detail we track for modules.
    # service loop complete
    if [ "$gEXPRESS_MODE" == false ]; then
      # check if the a previously built Docker image exists
      ndr_verifyDockerImageExists "$dockerFullImageName"
      return_code=$?
      #2-error, 1-not found, 0-found
      if [ "$return_code" -eq 0 ]; then
        ndr_logInfo "Docker image [$dockerFullImageName] already present on host. Prompting user for use as source image for install."

        read -p "A local Docker image [$dockerFullImageName] matching this application is already present on this host. Would you like to use this local image to construct the application container? Choose Yes to use local image or No to use remote image. (Y|n)" -n 1 -r
        echo    # Move to a new line
        if [[ $REPLY =~ ^[Nn]$ ]]; then
          ndr_logInfo "Local Docker image [$dockerFullImageName] refused, continuing installation with remote repo Docker image."
        else
          ndr_logInfo "Local Docker image [$dockerFullImageName] accepted, continuing installation with local Docker image."
          gNDR_USE_LOCAL_IMAGE_FOR_APP_INSTALL=true
        fi
      fi
    fi

    # if local images is enabled, attempt to use whats there.
    if [[ "$gNDR_USE_LOCAL_IMAGE_FOR_APP_INSTALL" == true ]]; then
      ndr_logInfo "Using preexisting, verified local docker image for container construction."
    else
      # pull image from repo
      ndr_DownloadDockerImageV2 "$dockerFullImageName" "$gNDR_DOCKER_ARCHITECTURE_CURRENT" "$NDR_DOCKER_REPO_TYPE_CURRENT"
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Docker image download failed for [$dockerFullImageName]."
        return 1
      fi
      ndr_logInfo "Docker image download succeeded for [$dockerFullImageName]."
    fi

    ndr_logInfo "Service [$service] individual processing and customization completed."
  done

  if [[ "$NDR_CADDY_ENABLED" == true ]]; then
    ndr_ConfigureCaddyProxy
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to configure caddy proxy."
      return 1
    fi
    ndr_logInfo "Caddy proxy successfully configured for this installation."
  fi

  # pull and compose at the full application level after all service level processing is complete.
  ndr_ComposeDockerApplicationContainers "$appHomeDir" "$compose_file"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to build Docker application containers for compose file [$compose_file]."
    return 1
  fi
  ndr_logInfo "Docker application containers for compose file [$compose_file] successfully built."
  
  ndr_RegistryCreateV2 "$gPRODUCT_VERSION" "$gNEXTDR_HOME_DIR" "$gREGISTRY_ENTRY_MODULE_STATUS_CLIENT_NAME" "$NDR_GIT_REPO_COMMIT_HASH_SHORT" "$NDR_GIT_REPO_COMMIT_TIMESTAMP"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create application registry."
    return 1
  fi

  ndr_CopyInstallHomeFiles
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to copy install home files"
    return 1
  fi

  ndr_InstallationReportAddEntry "The $gCOMPANY_NAME $NDR_CLIENT_APPLICATION_NAME has been installed successfully."
  ndr_InstallationReportAddEntry "Version: $gPRODUCT_VERSION | Commit: $NDR_GIT_REPO_COMMIT_HASH_SHORT | Built: $NDR_GIT_REPO_COMMIT_TIMESTAMP"
  for service in "${ndr_client_container_services[@]}"; do
    local dockerContainerName="${ndr_client_container_service_container_names[$service]}"
    #local dockerFullImageName="${ndr_client_container_service_image_names[$service]}"
    local dockerImageTag="${ndr_client_container_service_image_tags[$service]}"
    ndr_InstallationReportAddEntry "Docker Image: $dockerImageTag | Container: $dockerContainerName"
  done

  if [ "$gUPGRADE_MODE" == true ]; then
    ndr_logInfo "All currently installed modules have been upgraded."
    ndr_UpdateProductVersion
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainInstallAllApplications ()
{
  local logSectionDesc="Installing all applications"
  ndr_logSecStart "$logSectionDesc"

  mainInstallSupabaseApplication
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi
  
  mainInstallClientApplication
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi  
  
  if [ "$gUPGRADE_MODE" == false ]; then
    ndr_PrintInstallationReport
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_CheckandInstallUpdatesV2 ()
{
  local logSectionDesc="Product Update Check V2"
  ndr_logSecStart "$logSectionDesc"

  local updateAvailable=false
  local updateReport="  ${NDR_CLIENT_APPLICATION_NAME}:"

  if ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_CLIENT_NAME" 2>/dev/null; then
  
    local moduleHash=$(ndr_getModuleCommitHash "$gREGISTRY_ENTRY_MODULE_STATUS_CLIENT_NAME")
    local moduleTimestampUTC=$(ndr_getModuleCommitTimestamp "$gREGISTRY_ENTRY_MODULE_STATUS_CLIENT_NAME")
    local moduleTimestampHR=$(date -u -d @"$moduleTimestampUTC" +"%Y-%m-%d")
    
    local containers=("$NDR_SERVICE_CONTAINER_NAME" "$NDR_UI_CONTAINER_NAME")
    for container in "${containers[@]}"; do
      # For this installed container name, get its full image name and hash.
      local localImageName=$(ndr_QueryContainerImageName "$container")
      local localTimestamp
      ndr_ParseImageTagTimestampV2 "$localImageName" localTimestamp
      local localTimestampHR=$(date -u -d @"$localTimestamp" +"%Y-%m-%d")
      local localCommitHash
      ndr_ParseImageTagCommitHashV2 "$localImageName" localCommitHash

      # then get the latest image matching this one and parse its timestamp.
      local latestImageName=""
      ndr_QueryLatestMatchingRemoteImageTagV2 "$localImageName" latestImageName
      local latestTimestamp
      ndr_ParseImageTagTimestampV2 "$latestImageName" latestTimestamp
      local latestTimestampHR=$(date -u -d @"$latestTimestamp" +"%Y-%m-%d")
      local latestCommitHash
      ndr_ParseImageTagCommitHashV2 "$latestImageName" latestCommitHash

      # if any physical module image needs update, add to report and break.
      if [[ -n "$localTimestamp" && -n "$latestTimestamp" && "$latestTimestamp" -gt "$localTimestamp" ]]; then
        updateReport="${updateReport} Currently installed version [$localCommitHash, $localTimestampHR], Update version available [$latestCommitHash, $latestTimestampHR]"
        updateAvailable=true
        break
      fi
    done

    if [[ "$updateAvailable" == false ]]; then
      updateReport="${updateReport} Currently installed version [$moduleHash, $moduleTimestampHR] is up to date."
    fi
  else
    updateReport="${updateReport} Not currently installed."
  fi

  local reportHeader="======[ Application Update Report ]=============================="
  local reportFooter="================================================================="

  # check for no updates
  if [[ "$updateAvailable" == false ]]; then
    ndr_logInfo "No updates found for the installed modules."
    ndr_logInfo "\n${reportHeader}\n${updateReport}\n${reportFooter}"
    echo -n "Press any key to return without updating..."
    read -n 1 -s
    echo    # move to a new line after key press

    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # some updates are available. Display, prompt and execute.
  ndr_logInfo "Some updates found for the installed modules."
  ndr_logInfo "\n${reportHeader}\n${updateReport}\n${reportFooter}"
  read -p "Do you wish to proceed with updating these modules? (Y|n)" -n 1 -r
  echo    # Move to a new line
  if [[ $REPLY =~ ^[Nn]$ ]]; then
    ndr_logInfo "Update cancelled."
    return 0
  fi
  ndr_logInfo "Proceeding with module update."
  gUPDATE_MODE=true

  if [ "$updateAvailable" == true ]; then
    mainInstallClientApplication
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to update application."
      return 1
    fi
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainCheckandInstallUpdates ()
{
  local logSectionDesc="Checking and Installing Product Updates"
  ndr_logSecStart "$logSectionDesc"

  if [ "$gNDR_SKIP_REMOTE_IMAGE_REPO_UPDATE_CHECK" == true ]; then
    ndr_logWarn "Warning, remote image update check is disabled via command line option, update is not possible in this mode."
    ndr_logInfo "Please exit the installer and re-launch without the update check disabled."
    return 1
  fi

  ndr_CheckandInstallUpdatesV2
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to check and install application updates."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainRemoveSupabaseApplication ()
{
  local logSectionDesc="Removing Supabase Application"
  ndr_logSecStart "$logSectionDesc"

  local regName="$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
  ndr_isModuleInstalledReg "$regName"
  local dbInstalled=$?
  if [[ dbInstalled -ne 0 ]]; then
    if [ "$gEXPRESS_MODE" == false ]; then
      read -p "This product does not currently appear to be installed. Would you like to force remove any partial or existing installation? (Y|n)" -n 1 -r
      echo    # Move to a new line
      if [[ $REPLY =~ ^[Nn]$ ]]; then
        ndr_logInfo "Operation cancelled, returning to main menu."
        return 1
      fi
      ndr_logInfo "Proceeding with forced removal."
    fi
  fi

  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SERVICE_NAME"
  local svcInstalled=$?
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_UI_NAME"
  local uiInstalled=$?
  if [[ "$svcInstalled" -eq 0 || "$uiInstalled" -eq 0 ]]; then
    read -p "Some dependent $gCOMPANY_NAME product modules appear to be currently installed. Removing this module may adversely affect the operation of these dependencies. Would you like continue removing this module? (Y|n)" -n 1 -r
    echo    # Move to a new line
    if [[ $REPLY =~ ^[Nn]$ ]]; then
      ndr_logInfo "Operation cancelled, returning to main menu."
      return 1
    else
      ndr_logInfo "Proceeding with removal."
    fi
  fi

  # If upgrade mode is enabled (some modules still needing upgrade) and uninstall triggered from express mode, 
  # disable upgrade mode and allow uninstall to complete without all the skips ebedded in upgrade mode.
  if [[ "$gEXPRESS_MODE" == true && "$gUPGRADE_MODE" == true ]]; then
    ndr_logInfo "Uninstall running in express mode and upgrade mode detected. Disabling upgrade mode to allow uninstall."
    gUPGRADE_MODE=false
  fi

  ndr_SupabaseContainerCleanup
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  ndr_RegistryAddKey "$regName" "$gREGISTRY_ENTRY_MODULE_STATUS_NOT_INSTALLED"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to update registry entry [$regName -> $gREGISTRY_ENTRY_MODULE_STATUS_NOT_INSTALLED]."
    #return 1
  fi

  ndr_RegistryRemoveServiceEntries
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to remove Supabase registry services."
    #return 1
  fi

  ndr_RegistryUninstallV2
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  ndr_CleanupApplicationFolders "$gSUPABASE_NEXTDR_SUB"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainRemoveClientApplication ()
{
  local logSectionDesc="Removing Client Application"
  ndr_logSecStart "$logSectionDesc"

  local compose_file="${gNEXTDR_HOME_DIR}/${NDR_CLIENT_APP_HOME_LOC}/${NDR_CLIENT_APP_COMPOSEFILE_FILENAME}"
  
  local dockerAppManageOptions="$NDR_DOCKER_APP_MANAGE_OPTIONS_REMOVE_ALL"
  
  local regName="$gREGISTRY_ENTRY_MODULE_STATUS_CLIENT_NAME"
  ndr_isModuleInstalledReg "$regName"
  return_code=$?
  if [[ return_code -ne 0 ]]; then
    if [ "$gEXPRESS_MODE" == false ]; then
      read -p "This product does not currently appear to be installed. Would you like to force remove any partial or existing installation? (Y|n)" -n 1 -r
      echo    # Move to a new line
      if [[ $REPLY =~ ^[Nn]$ ]]; then
        ndr_logInfo "Operation cancelled, returning to main menu."
        return 1
      fi
      ndr_logInfo "Proceeding with forced removal."
    fi
  fi
  
  # If upgrade mode is enabled (some modules still needing upgrade) and uninstall triggered from express mode, 
  # disable upgrade mode and allow uninstall to complete without all the skips ebedded in upgrade mode.
  if [[ "$gEXPRESS_MODE" == true && "$gUPGRADE_MODE" == true ]]; then
    ndr_logInfo "Uninstall running in express mode and upgrade mode detected. Disabling upgrade mode to allow uninstall."
    gUPGRADE_MODE=false
  fi

  # cleanup at the application/compose level.
  ndr_cleanupDockerApplications "$compose_file" "$dockerAppManageOptions"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "$gCOMPANY_NAME application cleanup failed."
    return 1
  fi
  ndr_logInfo "$gCOMPANY_NAME application cleanup success."

  ndr_RegistryAddKey "$regName" "$gREGISTRY_ENTRY_MODULE_STATUS_NOT_INSTALLED"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to update registry entry [$regName -> $gREGISTRY_ENTRY_MODULE_STATUS_NOT_INSTALLED]."
    #return 1
  fi
  ndr_RegistryDeleteKey "$gREGISTRY_ENTRY_MODULE_STATUS_CLIENT_COMMIT_HASH"
  ndr_RegistryDeleteKey "$gREGISTRY_ENTRY_MODULE_STATUS_CLIENT_COMMIT_TIMESTAMP"

  ndr_RegistryUninstallV2
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  if [[ "$NDR_CADDY_ENABLED" == true ]]; then
    ndr_CleanupApplicationFolders "$NDR_CADDY_HOME_LOC"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      return 1
    fi
  fi

  ndr_CleanupApplicationFolders "$NDR_CLIENT_APP_HOME_LOC"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainRemoveAllApplications ()
{
  local logSectionDesc="Removing all applications"
  ndr_logSecStart "$logSectionDesc"

  mainBackupApplication
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  mainRemoveClientApplication
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi  
  
  mainRemoveSupabaseApplication
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainBackupSupabaseDB ()
{
  local logSectionDesc="Backup Supabase Database"
  ndr_logSecStart "$logSectionDesc"

  ndr_BackupApplication "$gNDR_APP_BACKUP_RESTORE_OPTIONS_DB"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainRestoreSupabaseDB ()
{
  local logSectionDesc="Restore Supabase Database"
  ndr_logSecStart "$logSectionDesc"

  ndr_RestoreApplication "$gNDR_APP_BACKUP_RESTORE_OPTIONS_DB"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainBackupApplication ()
{
  local logSectionDesc="Backup $gPRODUCT_NAME Application"
  ndr_logSecStart "$logSectionDesc"

  ndr_BackupApplication "$gNDR_APP_BACKUP_RESTORE_OPTIONS_ALL_MODULES"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainRestoreApplication ()
{
  local logSectionDesc="Restore $gPRODUCT_NAME Application"
  ndr_logSecStart "$logSectionDesc"

  ndr_RestoreApplication "$gNDR_APP_BACKUP_RESTORE_OPTIONS_ALL_MODULES"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainUpgradeSupabaseDB ()
{
  local logSectionDesc="Upgrade Supabase Database"
  ndr_logSecStart "$logSectionDesc"

  ndr_RestorePostgresDB "upgrade"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainCreateNDRConsoleAdminAccount ()
{
  local logSectionDesc="Creating $gPRODUCT_NAME Console Admin Account"
  ndr_logSecStart "$logSectionDesc"

  ndr_CreateNDRConsoleAdminAccount
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# ====================================================
# command line parsing
# ====================================================
function mainParseCommandLineArgs ()
{
  local logSectionDesc="Parsing command line arguments"
  ndr_logSecStartDebug "$logSectionDesc"

  # Default values
  
  ndr_parseCommandLineArgs "$@"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to parse common command line args."
    return 1
  fi

  # Parse arguments
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --dest|-d)
        if [[ -n "$2" && "$2" != --* ]]; then
          gNEXTDR_HOME_DIR="$2"
          ndr_logInfo "Home directory set to [$gNEXTDR_HOME_DIR]"
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --forceregeneratediff|--regendiff)
        gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY="$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY_DYNAMIC"
        ndr_logInfo "Option to ignore the upgrade diff schema file packaged with installer and force regenerate the diff is enabled."
        shift
        ;;
      --noupdatecheck|--noupdate)
        gNDR_SKIP_REMOTE_IMAGE_REPO_UPDATE_CHECK=true
        ndr_logInfo "Skip remote image repo update check option enabled."
        shift
        ;;
      --uselocalimage|--localimage)
        gNDR_USE_LOCAL_IMAGE_FOR_APP_INSTALL=true
        ndr_logInfo "Use local Docker images for application containers option enabled."
        shift
        ;;
      --nobuildlocalimage|--nobuild)
        gNDR_BUILD_LOCAL_IMAGE_FOR_APP_INSTALL=false
        ndr_logInfo "Option to NOT BUILD local Docker images when installing application modules is set."
        shift
        ;;
      --allowdbupdatetag)
        ndr_logInfo "Option to allow Supabase tag update to latest is enabled."
        gNDR_SUPABASE_GIT_VERSION_ALLOW_TAG_UPDATE=true
        shift
      ;;
      --allowdbupdatecommit)
        ndr_logInfo "Option to allow Supabase commit hash update for current tag to latest is enabled."
        gNDR_SUPABASE_GIT_VERSION_ALLOW_COMMIT_HASH_UPDATE=true
        shift
      ;;
      --help|-h)
        ndr_logWarn "Usage: $0 --express <$EXPRESS_MENU_OPTIONS> [--debug]."
        return 1
        ;;
      *)
        #ndr_logError "Unknown option: $1"
        shift
        ;;
    esac
  done

  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

# ====================================================
# Express install mode
# ====================================================
function mainExpressInstallMode ()
{
  local logSectionDesc="Executing express install mode"
  ndr_logSecStart "$logSectionDesc"

  # Check if express mode is enabled and an option is provided
  if [ "$gEXPRESS_MODE" == false ]; then
    ndr_logError "Express mode is not enabled. Use --express to enable."
    return 1
  fi
  if [ -z "$gExpressOption" ]; then
    ndr_logError "No express option provided. Use --express <option>."
    return 1
  fi

  if [[ "$gUPGRADE_MODE" == true && "$gNDR_ADVANCED_MODE" == false ]]; then
    ndr_logInfo "Upgrade mode is enabled, all installed applications will be upgraded at once."
    gExpressOption="installall"
  fi

  case "$gExpressOption" in
    installprerequisites|installprereq)
      ndr_checkAndInstallPrerequisites
      ;;
    installsupabase|installdb)
      mainInstallSupabaseApplication
      ;;
    installclient)
      mainInstallClientApplication
      ;;
    installall|upgradeall|upgrade)
      mainInstallAllApplications
      ;;
    removesupabaseapp|removesupabase|removedb|uninstalldb)
      mainRemoveSupabaseApplication
      ;;
    removeclient|uninstallclient)
      mainRemoveClientApplication
      ;;
    removeall|uninstallall)
      mainRemoveAllApplications
      ;;
    backupdb)
      mainBackupSupabaseDB
      ;;
    restoredb)
      mainRestoreSupabaseDB
      ;;
    backupapp)
      mainBackupApplication
      ;;
    restoreapp)
      mainRestoreApplication
      ;;
    upgradedb)
      mainUpgradeSupabaseDB
      ;;
    update|checkupdates)
      mainCheckandInstallUpdates
      ;;
    createadminaccount|createaccount)
      mainCreateNDRConsoleAdminAccount
      ;;
    test)
      ndr_Test
      ;;
    *)
      # print usage and exit
      ndr_logWarn "Invalid option. Please use one of the following options: $EXPRESS_MENU_OPTIONS."
      return 1
      ;;
  esac
  
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to execute selection."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# basic menu option constants
NDR_INSTALL_MENU_OPTION_IDX_NONE=0
NDR_INSTALL_MENU_OPTION_IDX_CHECK_PREREQUISITES=1
NDR_INSTALL_MENU_OPTION_DESC_CHECK_PREREQUISITES="Check and install software package prerequisites"
NDR_INSTALL_MENU_OPTION_IDX_INSTALL_ALL=2
NDR_INSTALL_MENU_OPTION_DESC_INSTALL_ALL="Install $gCOMPANY_NAME application suite"
NDR_INSTALL_MENU_OPTION_IDX_CHECK_UPDATES=3
NDR_INSTALL_MENU_OPTION_DESC_CHECK_UPDATES="Check for updates for all currently installed applications"
NDR_INSTALL_MENU_OPTION_IDX_REMOVE_ALL=4
NDR_INSTALL_MENU_OPTION_DESC_REMOVE_ALL="Remove $gCOMPANY_NAME application suite"

# advanced menu option constants
NDR_INSTALL_MENU_OPTION_IDX_INSTALL_SUPABASE=5
NDR_INSTALL_MENU_OPTION_DESC_INSTALL_SUPABASE="Advanced Option: Install the $gCOMPANY_NAME Supabase database application in a local Docker container"
NDR_INSTALL_MENU_OPTION_IDX_INSTALL_CLIENT_APPLICATION=6
NDR_INSTALL_MENU_OPTION_DESC_INSTALL_CLIENT_APPLICATION="Advanced Option: Install the $gCOMPANY_NAME Client application in a local Docker container"
NDR_INSTALL_MENU_OPTION_IDX_REMOVE_SUPABASE=7
NDR_INSTALL_MENU_OPTION_DESC_REMOVE_SUPABASE="Advanced Option: Remove existing $gCOMPANY_NAME Supabase Docker application"
NDR_INSTALL_MENU_OPTION_IDX_REMOVE_CLIENT_APPLICATION=8
NDR_INSTALL_MENU_OPTION_DESC_REMOVE_CLIENT_APPLICATION="Advanced Option: Remove existing $gCOMPANY_NAME Client Docker application"

# ====================================================
# Interactive menu mode
# ====================================================
function mainInteractiveMenuMode ()
{
  local logSectionDesc="Executing interactive menu mode"
  ndr_logSecStartDebug "$logSectionDesc"
  
  declare -a menuItem=() # primary array to hold menu item indices and actions
  declare -A menuItemDesc=() # associative array to hold menu item descriptions

  # add basic menu items
  local idx=1
  menuItem[$idx]="$NDR_INSTALL_MENU_OPTION_IDX_CHECK_PREREQUISITES"
  menuItemDesc[$idx]="$NDR_INSTALL_MENU_OPTION_DESC_CHECK_PREREQUISITES"
  idx=$((idx+1))
  menuItem[$idx]="$NDR_INSTALL_MENU_OPTION_IDX_INSTALL_ALL"
  menuItemDesc[$idx]="$NDR_INSTALL_MENU_OPTION_DESC_INSTALL_ALL"
  idx=$((idx+1))
  menuItem[$idx]="$NDR_INSTALL_MENU_OPTION_IDX_CHECK_UPDATES"
  menuItemDesc[$idx]="$NDR_INSTALL_MENU_OPTION_DESC_CHECK_UPDATES"
  idx=$((idx+1))
  menuItem[$idx]="$NDR_INSTALL_MENU_OPTION_IDX_REMOVE_ALL"
  menuItemDesc[$idx]="$NDR_INSTALL_MENU_OPTION_DESC_REMOVE_ALL"

  # add advanced menu items if advanced mode is enabled
  if [[ "$gNDR_ADVANCED_MODE" == true ]]; then
    idx=$((idx+1))
    menuItem[$idx]="$NDR_INSTALL_MENU_OPTION_IDX_INSTALL_SUPABASE"
    menuItemDesc[$idx]="$NDR_INSTALL_MENU_OPTION_DESC_INSTALL_SUPABASE"
    idx=$((idx+1))
    menuItem[$idx]="$NDR_INSTALL_MENU_OPTION_IDX_REMOVE_SUPABASE"
    menuItemDesc[$idx]="$NDR_INSTALL_MENU_OPTION_DESC_REMOVE_SUPABASE"
    
    idx=$((idx+1))
    menuItem[$idx]="$NDR_INSTALL_MENU_OPTION_IDX_INSTALL_CLIENT_APPLICATION"
    menuItemDesc[$idx]="$NDR_INSTALL_MENU_OPTION_DESC_INSTALL_CLIENT_APPLICATION"
    idx=$((idx+1))
    menuItem[$idx]="$NDR_INSTALL_MENU_OPTION_IDX_REMOVE_CLIENT_APPLICATION"
    menuItemDesc[$idx]="$NDR_INSTALL_MENU_OPTION_DESC_REMOVE_CLIENT_APPLICATION"
  fi
  
  local refreshModuleStatus=true
  
  local installActionWarning=""
  if [ "$gUPGRADE_MODE" == true ]; then
    installActionWarning="Attention, this will upgrade the existing instance and install the updated package. This action cannot be undone!"  
  else
    installActionWarning="Attention, this will overwrite any existing instance and install a clean copy. This action cannot be undone!"
  fi  
  local removeActionWarning="Attention, this will completely remove any existing instance. This action cannot be undone!"

  while true; do
    if [[ "$refreshModuleStatus" == true ]]; then
      ndr_UpgradeModeCheck
      ndr_UpdateModuleInstallStatus
    fi
  
    echo "===================================================================="
    echo "$gCOMPANY_NAME $gPRODUCT_VERSION Software Installation and Package Management Menu"
    ndr_DisplayModuleInstallStatus
    echo "===================================================================="

    local choice=""
    if [ "$gUPGRADE_MODE" == true ]; then
      echo "  ------ VERSION [$gPRODUCT_VERSION] UPGRADE MODE ENABLED ------"
      echo "  Install has detected that a previous version of one or more applications is currently installed."
      echo "  Upgrade of all of currently installed applications to version [$gPRODUCT_VERSION] will be performed."
      echo -e "  ${YELLOW}NOTE:${RESET} To Add/Remove applications for installed version [${YELLOW}$gINSTALLED_VERSION${RESET}] instead,"
      echo -e "  please exit and run the install package from the install home directory [${YELLOW}$gNEXTDR_HOME_DIR${RESET}]."
      read -p "  Are you sure you want to proceed? (Y|n) " -n 1 -r
        echo    # Move to a new line
        echo "===================================================================="
        # default YES logic
        if [[ $REPLY =~ ^[Nn]$ ]]; then
          ndr_logInfo "Operation cancelled, aborting."
          break
        fi
        choice="2"
        echo "Proceeding with upgrade of all currently installed applications."
    else
      echo "Please select an option:"
      echo ""
      for idx in "${!menuItem[@]}"; do
        echo "$idx. ${menuItemDesc[$idx]}"
      done
      echo "q. Exit"
      echo ""
      read -p "Enter your choice [1-n]: " choice
    fi

    refreshModuleStatus=false

    # check for non-numerical choice (exit, test, etc)
    if ! [[ "$choice" =~ ^[0-9]+$ ]]; then
      if [[ "$choice" == "q" || "$choice" == "Q" ]]; then
        ndr_logInfo "Exiting installer."
        break
      elif  [[ "$choice" == "t" || "$choice" == "T" ]]; then
        # unit test - remove for production
        ndr_Test
        continue
      fi
    fi
        
    # translate numerical choice index to menu item index
    local action="${menuItem[$choice]}"
    local actionDesc="${menuItemDesc[$choice]}"
    ndr_logDebug "User selected menu choice [$choice] -> action [$action] : [$actionDesc]"
    if [[ "$action" -eq "$NDR_INSTALL_MENU_OPTION_IDX_NONE" ]]; then
      ndr_logWarn "Invalid selection [$choice], please try again."
      continue
    fi

    case $action in
      "$NDR_INSTALL_MENU_OPTION_IDX_CHECK_PREREQUISITES")
        echo "$actionDesc. This will check for NPM/NPX, GIT, Docker, etc and prompt for interactive install."
        read -p "Are you sure you want to proceed? (Y|n) " -n 1 -r
        echo    # Move to a new line
        # default YES logic
        if [[ $REPLY =~ ^[Nn]$ ]]; then
          ndr_logInfo "Operation cancelled, returning to main menu."
          continue
        else
          ndr_checkAndInstallPrerequisites
        fi
        ;;
      "$NDR_INSTALL_MENU_OPTION_IDX_INSTALL_SUPABASE")
        echo "$actionDesc. $installActionWarning"
        read -p "Are you sure you want to proceed? (Y|n) " -n 1 -r
        echo    # Move to a new line
        if [[ $REPLY =~ ^[Nn]$ ]]; then
          ndr_logInfo "Operation cancelled, returning to main menu."
          continue
        else
          mainInstallSupabaseApplication
        fi
        ;;
      "$NDR_INSTALL_MENU_OPTION_IDX_INSTALL_CLIENT_APPLICATION")
        echo "$actionDesc. $installActionWarning"
        read -p "Are you sure you want to proceed? (Y|n) " -n 1 -r
        echo    # Move to a new line
        if [[ $REPLY =~ ^[Nn]$ ]]; then
          ndr_logInfo "Operation cancelled, returning to main menu."
          continue
        else
          mainInstallClientApplication
        fi
        ;;
      "$NDR_INSTALL_MENU_OPTION_IDX_INSTALL_ALL")
        echo "$actionDesc. $installActionWarning"
        read -p "Are you sure you want to proceed? (Y|n) " -n 1 -r
        echo    # Move to a new line
        if [[ $REPLY =~ ^[Nn]$ ]]; then
          ndr_logInfo "Operation cancelled, returning to main menu."
          continue
        else
          mainInstallAllApplications
        fi
        ;;
      "$NDR_INSTALL_MENU_OPTION_IDX_CHECK_UPDATES")
        echo "$actionDesc. $installActionWarning"
        read -p "Are you sure you want to proceed? (Y|n) " -n 1 -r
        echo    # Move to a new line
        if [[ $REPLY =~ ^[Nn]$ ]]; then
          ndr_logInfo "Operation cancelled, returning to main menu."
          continue
        else
          mainCheckandInstallUpdates
        fi
        ;;
      "$NDR_INSTALL_MENU_OPTION_IDX_REMOVE_SUPABASE")
        echo "$actionDesc. $removeActionWarning"
        read -p "Are you sure you want to proceed? (y|N) " -n 1 -r
        echo    # Move to a new line
        # default NO logic
        if [[ $REPLY =~ ^[Yy]$ ]]; then
          mainRemoveSupabaseApplication
        else
          ndr_logInfo "Operation cancelled, returning to main menu."
          continue
        fi
        ;;
      "$NDR_INSTALL_MENU_OPTION_IDX_REMOVE_CLIENT_APPLICATION")
        echo "$actionDesc. $removeActionWarning"
        read -p "Are you sure you want to proceed? (y|N) " -n 1 -r
        echo    # Move to a new line
        # default NO logic
        if [[ $REPLY =~ ^[Yy]$ ]]; then
          mainRemoveClientApplication
        else
          ndr_logInfo "Operation cancelled, returning to main menu."
          continue
        fi
        ;;
      "$NDR_INSTALL_MENU_OPTION_IDX_REMOVE_ALL")
        echo "$actionDesc. $removeActionWarning"
        read -p "Are you sure you want to proceed? (y|N) " -n 1 -r
        echo    # Move to a new line
        # default NO logic
        if [[ $REPLY =~ ^[Yy]$ ]]; then
          mainRemoveAllApplications
        else
          ndr_logInfo "Operation cancelled, returning to main menu."
          continue
        fi
        ;;
      *)
        echo "Invalid option. Please try again."
        continue
        ;;
    esac

    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to execute selection."
      return 1
    fi

    echo ""

    refreshModuleStatus=true
  done

  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

function mainPreInstallChecks ()
{
  local logSectionDesc="Running Install Pre-Checks"
  ndr_logSecStartDebug "$logSectionDesc"

  ndr_osTypeCheck

  ndr_UpgradeModeCheck
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Error during upgrade mode checks."
    return 1
  fi

  if [[ "$NDR_DOCKER_REPO_TYPE_CURRENT" == "$NDR_DOCKER_REPO_TYPE_GCP_REGISTRY" ]]; then
    ndr_GCPDockerRegistryVerifyAccess "$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT"
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Failed to verify access to repo root: $gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT"
      return 1
    fi
  fi

  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

function main ()
{
  echo "🕓 Started at $(date)"
  
  gNDR_INSTALL_MODE=true
  ndr_SetLogPolicy $NDR_LOG_POLICY_MODE_NORMAL
  
  mainParseCommandLineArgs "$@"
  return_code=$?
  if [ $return_code != 0 ]; then
    return 1
  fi

  mainPreInstallChecks
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Error during install pre-checks."
    return 1
  fi

  local operation_return_code=0

  if [[ "$gEXPRESS_MODE" == true  && -n "$gExpressOption" ]]; then
    ndr_logInfo "Express install option selected. Skipping all prompts and running with supplied values."
    mainExpressInstallMode
    operation_return_code=$?
    echo "🕓 Finished at $(date)"
    return $operation_return_code
  fi

  mainInteractiveMenuMode
  operation_return_code=$?

  echo "🕓 Finished at $(date)"

  return $operation_return_code
}

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  main "$@"
  return_code=$?
  exit $return_code
fi
