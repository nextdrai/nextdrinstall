#!/bin/bash
# ndrInterface.sh - A Bash module providing UI/menu definitions and functions

#source "$(dirname "${BASH_SOURCE[0]}")/ndrCommon.sh"
source "$(dirname "${BASH_SOURCE[0]}")/ndrSupabase.sh"
source "$(dirname "${BASH_SOURCE[0]}")/ndrRegistry.sh"

# docker container and image module menu status definitions
export gCLI_MENU_IMAGE_STATUS_NOT_PRESENT="No image"
export gCLI_MENU_IMAGE_STATUS_PRESENT="Present"

export gCLI_MENU_CONTAINER_STATUS_NOT_PRESENT="No container"
export gCLI_MENU_CONTAINER_STATUS_PRESENT="Present"
export gCLI_MENU_CONTAINER_STATUS_RUNNING="Running"
export gCLI_MENU_CONTAINER_STATUS_STOPPED="Stopped"

export gCLI_GIT_REPO_STATUS_NOT_FOUND="Repo not available"

# git repo revision details
export gCLI_GIT_REPO_STATUS="$gCLI_GIT_REPO_STATUS_NOT_FOUND"
export gCLI_GIT_REPO_COMMIT_HASH_LONG=""
export gCLI_GIT_REPO_COMMIT_HASH_SHORT=""
export gCLI_GIT_REPO_COMMIT_TIMESTAMP=""

# docker module status
export gCLI_MODULE_DOCKER_IMAGE_STATUS_DB="$gCLI_MENU_IMAGE_STATUS_NOT_PRESENT"
export gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC="$gCLI_MENU_IMAGE_STATUS_NOT_PRESENT"
export gCLI_MODULE_DOCKER_IMAGE_STATUS_UI="$gCLI_MENU_IMAGE_STATUS_NOT_PRESENT"

export gCLI_MODULE_DOCKER_CONTAINER_STATUS_DB="$gCLI_MENU_CONTAINER_STATUS_NOT_PRESENT"
export gCLI_MODULE_DOCKER_CONTAINER_STATUS_SVC="$gCLI_MENU_CONTAINER_STATUS_NOT_PRESENT"
export gCLI_MODULE_DOCKER_CONTAINER_STATUS_UI="$gCLI_MENU_CONTAINER_STATUS_NOT_PRESENT"

# installed module menu status defintions
export gCLI_MENU_INSTALL_STATUS_INSTALLED="Installed"
export gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED="Not Installed"

# installed module status
export gCLI_MODULE_INSTALL_STATUS_DB="$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED"
export gCLI_MODULE_INSTALL_STATUS_CLIENT="$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED"
export gCLI_MODULE_INSTALL_STATUS_SVC="$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED" # +++ to be deprecated?
export gCLI_MODULE_INSTALL_STATUS_UI="$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED" # +++ to be deprecated?

# misc status items
export gCLI_NDR_INSTALLED_VERSION="$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED"
export gCLI_NDR_HOST_ADDRESS="$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED"

# update/upgrade mode items
export gCLI_UPDATE_MODE_CHECK_COMPLETED=false
export gCLI_UPDATES_AVAILABLE=false


# updates the status of any module updates/upgrades
function ndr_UpdateModuleUpgradeStatus ()
{
  local logSectionDesc="Updating Module Update Status"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ "$gNDR_SKIP_REMOTE_IMAGE_REPO_UPDATE_CHECK" == true || "$gNDR_INSTALL_MODE" != true || "$gCLI_UPDATE_MODE_CHECK_COMPLETED" == true ]]; then
    ndr_logDebug "Skipping update status check"
    # no update check for these modes/conditions.
    return 0
  fi

  local dbInstalled=ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME" >/dev/null
  local svcInstalled=ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SERVICE_NAME" >/dev/null
  local uiInstalled=ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_UI_NAME" >/dev/null
  if [[ "$dbInstalled" -ne 0 && "$svcInstalled" -ne 0 && "$uiInstalled" -ne 0 ]]; then
    # no modules installed
    ndr_logDebug "No modules currently installed"
    return 0
  fi

  local updates_available=false;

  # query for latest remote repo image tag details.
  if [[ "$svcInstalled" -eq 0 && "$updates_available" == false ]]; then
    local svcImageVersionTag=$(ndr_QueryContainerImageVersionTag "$NDR_SERVICE_CONTAINER_NAME")
    #local svcImageVersionTag="$NDR_SERVICE_IMAGE_VERSION_TAG"
    ndr_QueryLatestMatchingRemoteImageTags "$NDR_SERVICE_IMAGE_NAME"
    if [[ -n "$svcImageVersionTag" && -n "$NDR_SERVICE_IMAGE_VERSION_TAG" && "$svcImageVersionTag" != "$NDR_SERVICE_IMAGE_VERSION_TAG" ]]; then
      ndr_logDebug "Update may be available for module [$svcImageVersionTag -> $NDR_SERVICE_IMAGE_VERSION_TAG]"
      updates_available=true;
    fi
  fi

  if [[ "$uiInstalled" -eq 0 && "$updates_available" == false ]]; then
    local uiImageVersionTag=$(ndr_QueryContainerImageVersionTag "$NDR_UI_CONTAINER_NAME")
    #local uiImageVersionTag="$NDR_UI_IMAGE_VERSION_TAG"
    ndr_QueryLatestMatchingRemoteImageTags "$NDR_UI_IMAGE_NAME"
    if [[ -n "$uiImageVersionTag" && -n "$NDR_UI_IMAGE_VERSION_TAG" && "$uiImageVersionTag" != "$NDR_UI_IMAGE_VERSION_TAG" ]]; then
      ndr_logDebug "Update may be available for module [$uiImageVersionTag -> $NDR_UI_IMAGE_VERSION_TAG]"
      updates_available=true;
    fi
  fi

  if [ "$updates_available" == true ]; then
    gCLI_UPDATES_AVAILABLE=true;
  fi

  gCLI_UPDATE_MODE_CHECK_COMPLETED=true;

  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

# updates the status of all docker modules
function ndr_UpdateModuleDockerStatus ()
{
  local logSectionDesc="Updating Module Docker Status"
  ndr_logSecStartDebug "$logSectionDesc"

  local imageName=""
  
  # Git Repo ------------------------------
  ndr_PopulateLocalGitRepoDetails

  # Supabase ------------------------------
  #gCLI_MODULE_DOCKER_IMAGE_STATUS_DB=$(if ndr_verifyDockerImageExists "$NDR_SUPABASE_APP_SERVICE_NAME_DB_IMAGE_NAME" >/dev/null; then echo "$gCLI_MENU_IMAGE_STATUS_PRESENT"; fi)
  gCLI_MODULE_DOCKER_IMAGE_STATUS_DB="$gCLI_MENU_IMAGE_STATUS_NOT_PRESENT"
  if ndr_verifyDockerImageExists "$NDR_SUPABASE_APP_SERVICE_NAME_DB_IMAGE_NAME" >/dev/null; then gCLI_MODULE_DOCKER_IMAGE_STATUS_DB="$NDR_SUPABASE_APP_SERVICE_NAME_DB_IMAGE_NAME | $gCLI_MENU_IMAGE_STATUS_PRESENT"; fi

  #gCLI_MODULE_DOCKER_CONTAINER_STATUS_DB=$(if ndr_verifyDockerContainerExists "$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME" >/dev/null; then echo "$gCLI_MENU_CONTAINER_STATUS_PRESENT"; fi)
  if ndr_verifyDockerContainerExists "$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME" >/dev/null; then
    # build container status
    gCLI_MODULE_DOCKER_CONTAINER_STATUS_DB="$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME"
    #local supabaseContainerRunning=$(if ndr_verifyDockerContainerRunning "$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME" >/dev/null; then echo "$gCLI_MENU_CONTAINER_STATUS_RUNNING"; fi)
    if ndr_verifyDockerContainerRunning "$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME" >/dev/null; then gCLI_MODULE_DOCKER_CONTAINER_STATUS_DB="$gCLI_MODULE_DOCKER_CONTAINER_STATUS_DB | $gCLI_MENU_CONTAINER_STATUS_RUNNING"; else gCLI_MODULE_DOCKER_CONTAINER_STATUS_DB="$gCLI_MODULE_DOCKER_CONTAINER_STATUS_DB | $gCLI_MENU_CONTAINER_STATUS_STOPPED"; fi
  fi
  
  # Service -------------------------------
  # query image details first. init image name with local repo tag.
  gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC="$gCLI_MENU_IMAGE_STATUS_NOT_PRESENT"
  if imageName=$(ndr_verifyDockerImageExists "$NDR_SERVICE_IMAGE_NAME" 2>/dev/null); then gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC="$imageName"; fi

  # query container details second, if container exists, override image name with actual image name used by container.
  gCLI_MODULE_DOCKER_CONTAINER_STATUS_SVC="$gCLI_MENU_CONTAINER_STATUS_NOT_PRESENT"
  if ndr_verifyDockerContainerExists "$NDR_SERVICE_CONTAINER_NAME" >/dev/null; then
    # build container status
    gCLI_MODULE_DOCKER_CONTAINER_STATUS_SVC="$NDR_SERVICE_CONTAINER_NAME | $gCLI_MENU_CONTAINER_STATUS_PRESENT"
    if ndr_verifyDockerContainerRunning "$NDR_SERVICE_CONTAINER_NAME" "$NDR_SERVICE_CONTAINER_PORT" >/dev/null; then 
      gCLI_MODULE_DOCKER_CONTAINER_STATUS_SVC="$gCLI_MODULE_DOCKER_CONTAINER_STATUS_SVC | $gCLI_MENU_CONTAINER_STATUS_RUNNING"; 
    else 
      gCLI_MODULE_DOCKER_CONTAINER_STATUS_SVC="$gCLI_MODULE_DOCKER_CONTAINER_STATUS_SVC | $gCLI_MENU_CONTAINER_STATUS_STOPPED"; 
    fi
    
    # rebuild image status
    gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC=$(ndr_QueryContainerImageName "$NDR_SERVICE_CONTAINER_NAME")
    local commitHash=$(ndr_QueryContainerImageCommitHash "$NDR_SERVICE_CONTAINER_NAME")
    if [[ -n "$commitHash" ]]; then gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC="$gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC | Commit: $commitHash"; fi
    local timestampUTC=$(ndr_QueryContainerImageTimestampHumanReadable "$NDR_SERVICE_CONTAINER_NAME")
    if [[ -n "$timestampUTC" ]]; then gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC="$gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC | Built: $timestampUTC"; fi
  fi
  
  # UI -----------------------------------
  # query image details first. init image name with local repo tag.
  gCLI_MODULE_DOCKER_IMAGE_STATUS_UI="$gCLI_MENU_IMAGE_STATUS_NOT_PRESENT"
  if imageName=$(ndr_verifyDockerImageExists "$NDR_UI_IMAGE_NAME" 2>/dev/null); then gCLI_MODULE_DOCKER_IMAGE_STATUS_UI="$imageName"; fi
  
  # query container details second, if container exists, override image name with actual image name used by container.
  gCLI_MODULE_DOCKER_CONTAINER_STATUS_UI="$gCLI_MENU_CONTAINER_STATUS_NOT_PRESENT"
  if ndr_verifyDockerContainerExists "$NDR_UI_CONTAINER_NAME" >/dev/null; then
    # build container status
    gCLI_MODULE_DOCKER_CONTAINER_STATUS_UI="$NDR_UI_CONTAINER_NAME | $gCLI_MENU_CONTAINER_STATUS_PRESENT"
    if ndr_verifyDockerContainerRunning "$NDR_UI_CONTAINER_NAME" "$NDR_UI_CONTAINER_PORT" >/dev/null; then 
      gCLI_MODULE_DOCKER_CONTAINER_STATUS_UI="$gCLI_MODULE_DOCKER_CONTAINER_STATUS_UI | $gCLI_MENU_CONTAINER_STATUS_RUNNING"; 
    else
      gCLI_MODULE_DOCKER_CONTAINER_STATUS_UI="$gCLI_MODULE_DOCKER_CONTAINER_STATUS_UI | $gCLI_MENU_CONTAINER_STATUS_STOPPED"; 
    fi
    
    # rebuild image status
    gCLI_MODULE_DOCKER_IMAGE_STATUS_UI=$(ndr_QueryContainerImageName "$NDR_UI_CONTAINER_NAME")
    local commitHash=$(ndr_QueryContainerImageCommitHash "$NDR_UI_CONTAINER_NAME")
    if [[ -n "$commitHash" ]]; then gCLI_MODULE_DOCKER_IMAGE_STATUS_UI="$gCLI_MODULE_DOCKER_IMAGE_STATUS_UI | Commit: $commitHash"; fi
    local timestampUTC=$(ndr_QueryContainerImageTimestampHumanReadable "$NDR_UI_CONTAINER_NAME")
    if [[ -n "$timestampUTC" ]]; then gCLI_MODULE_DOCKER_IMAGE_STATUS_UI="$gCLI_MODULE_DOCKER_IMAGE_STATUS_UI | Built: $timestampUTC"; fi
  fi

  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

function ndr_DisplayModuleDockerStatus ()
{
  echo "Current Docker image/container module status:"
  if [[ "$gCLI_GIT_REPO_STATUS" != "$gCLI_GIT_REPO_STATUS_NOT_FOUND" ]]; then
    echo "  Local git repo revision [ $gCLI_GIT_REPO_STATUS ]"
  fi
  echo "  Supabase DB module [ Image: $gCLI_MODULE_DOCKER_IMAGE_STATUS_DB ], [ Container: $gCLI_MODULE_DOCKER_CONTAINER_STATUS_DB ]"
  echo "  Service module [ Image: $gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC ], [ Container: $gCLI_MODULE_DOCKER_CONTAINER_STATUS_SVC ]"
  echo "  UI module [ Image: $gCLI_MODULE_DOCKER_IMAGE_STATUS_UI ], [ Container: $gCLI_MODULE_DOCKER_CONTAINER_STATUS_UI ]"

  return 0
}

# updates the status of all installed modules
function ndr_UpdateModuleInstallStatus ()
{
  local logSectionDesc="Updating Module Install Status"
  ndr_logSecStartDebug "$logSectionDesc"

  gCLI_UPDATES_AVAILABLE=false

  gCLI_MODULE_INSTALL_STATUS_DB="$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED"
  gCLI_MODULE_INSTALL_STATUS_CLIENT="$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED"
  gCLI_MODULE_INSTALL_STATUS_SVC="$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED"
  gCLI_MODULE_INSTALL_STATUS_UI="$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED"
  
  # only check these reg vars if something is installed and registry exists or else error messages will get printed.
  ndr_RegistryExists
  return_code=$?
  if [ $return_code -eq 1 ]; then
    return 0
  fi

  # DB
  if ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME" 2>/dev/null; then
    gCLI_MODULE_INSTALL_STATUS_DB="$gCLI_MENU_INSTALL_STATUS_INSTALLED"
    local version=$(ndr_getModuleVersionReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME")
    if [[ -n "$version" ]]; then gCLI_MODULE_INSTALL_STATUS_DB="$gCLI_MODULE_INSTALL_STATUS_DB | Version: $version"; fi
  fi
  
  # CLIENT
  if ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_CLIENT_NAME" 2>/dev/null; then
    # build the general client status with the registry values...
    gCLI_MODULE_INSTALL_STATUS_CLIENT="$gCLI_MENU_INSTALL_STATUS_INSTALLED"
    local imageVersion=$(ndr_getModuleVersionReg "$gREGISTRY_ENTRY_MODULE_STATUS_CLIENT_NAME")
    if [[ -n "$imageVersion" ]]; then gCLI_MODULE_INSTALL_STATUS_CLIENT="$gCLI_MODULE_INSTALL_STATUS_CLIENT | Version: $imageVersion"; fi
    local commitHash=$(ndr_getModuleCommitHash "$gREGISTRY_ENTRY_MODULE_STATUS_CLIENT_NAME")
    if [[ -n "$commitHash" ]]; then gCLI_MODULE_INSTALL_STATUS_CLIENT="$gCLI_MODULE_INSTALL_STATUS_CLIENT | Commit: $commitHash"; fi
    local timestampUTC=$(ndr_getModuleCommitTimestamp "$gREGISTRY_ENTRY_MODULE_STATUS_CLIENT_NAME")
    local timestampHR=$(date -u -d @"$timestampUTC" +"%Y-%m-%d")
    if [[ -n "$timestampUTC" ]]; then gCLI_MODULE_INSTALL_STATUS_CLIENT="$gCLI_MODULE_INSTALL_STATUS_CLIENT | Built: $timestampHR"; fi

    # ...but check each physical image for potential updates.
    # For the unified logical client, there is no image so we check our actual individual container images for a potential update.
    local containers=("$NDR_SERVICE_CONTAINER_NAME" "$NDR_UI_CONTAINER_NAME")
    for container in "${containers[@]}"; do
      if ! ndr_verifyDockerContainerExists "$container" >/dev/null; then
        # container not present
        ndr_logWarn "Docker container [$container] required for $gCOMPANY_NAME Client application not found."
        continue
      fi

      # For this installed container name, get its full image name and hash.
      local dockerFullImageName=$(ndr_QueryContainerImageName "$container")
      local imageCommitHash
      ndr_ParseImageTagCommitHashV2 "$dockerFullImageName" imageCommitHash
      
      # then get the latest image matching this one and parse its hash.
      local latestImageName=""
      ndr_QueryLatestMatchingRemoteImageTagV2 "$dockerFullImageName" latestImageName
      local latestCommitHash
      ndr_ParseImageTagCommitHashV2 "$latestImageName" latestCommitHash
      
      #ndr_logDebug "Installed hash: $imageCommitHash, latest hash: $latestCommitHash"
      # now compare the local installed image hash to the latest remote
      if [[ -n "$imageCommitHash" && -n "$latestCommitHash" && "$imageCommitHash" != "$latestCommitHash" ]]; then
        local latestTimestamp
        ndr_ParseImageTagTimestampV2 "$latestImageName" latestTimestamp
        local timestampHR=$(date -u -d @"$latestTimestamp" +"%Y-%m-%d")
        gCLI_MODULE_INSTALL_STATUS_CLIENT="$gCLI_MODULE_INSTALL_STATUS_CLIENT | ${YELLOW}Update available: $latestCommitHash ($timestampHR)${RESET}"
        gCLI_UPDATES_AVAILABLE=true;
      fi
    done
  fi
  
  # Service +++ to be DEPRECATED
  if ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SERVICE_NAME" 2>/dev/null; then
    gCLI_MODULE_INSTALL_STATUS_SVC="$gCLI_MENU_INSTALL_STATUS_INSTALLED"
    local imageVersion=$(ndr_QueryContainerImageVersion "$NDR_SERVICE_CONTAINER_NAME")
    if [[ -n "$imageVersion" ]]; then gCLI_MODULE_INSTALL_STATUS_SVC="$gCLI_MODULE_INSTALL_STATUS_SVC | Version: $imageVersion"; fi
    local commitHash=$(ndr_QueryContainerImageCommitHash "$NDR_SERVICE_CONTAINER_NAME")
    if [[ -n "$commitHash" ]]; then gCLI_MODULE_INSTALL_STATUS_SVC="$gCLI_MODULE_INSTALL_STATUS_SVC | Commit: $commitHash"; fi
    local timestampUTC=$(ndr_QueryContainerImageTimestampHumanReadable "$NDR_SERVICE_CONTAINER_NAME")
    if [[ -n "$timestampUTC" ]]; then gCLI_MODULE_INSTALL_STATUS_SVC="$gCLI_MODULE_INSTALL_STATUS_SVC | Built: $timestampUTC"; fi

    # image update check
    ndr_QueryLatestMatchingRemoteImageTags "$NDR_SERVICE_IMAGE_NAME"
    if [[ -n "$commitHash" && -n "$NDR_SERVICE_IMAGE_COMMIT_HASH_SHORT" && "$commitHash" != "$NDR_SERVICE_IMAGE_COMMIT_HASH_SHORT" ]]; then
      local timestampHR=$(date -u -d @"$NDR_SERVICE_IMAGE_COMMIT_TIMESTAMP_UTC" +"%Y-%m-%d")
      gCLI_MODULE_INSTALL_STATUS_SVC="$gCLI_MODULE_INSTALL_STATUS_SVC | ${YELLOW}Update available: $NDR_SERVICE_IMAGE_COMMIT_HASH_SHORT ($timestampHR)${RESET}"
      gCLI_UPDATES_AVAILABLE=true;
    fi
  fi

  # UI +++ to be DEPRECATED
  if ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_UI_NAME" 2>/dev/null; then
    gCLI_MODULE_INSTALL_STATUS_UI="$gCLI_MENU_INSTALL_STATUS_INSTALLED"
    local imageVersion=$(ndr_QueryContainerImageVersion "$NDR_UI_CONTAINER_NAME")
    if [[ -n "$imageVersion" ]]; then gCLI_MODULE_INSTALL_STATUS_UI="$gCLI_MODULE_INSTALL_STATUS_UI | Version: $imageVersion"; fi
    local commitHash=$(ndr_QueryContainerImageCommitHash "$NDR_UI_CONTAINER_NAME")
    if [[ -n "$commitHash" ]]; then gCLI_MODULE_INSTALL_STATUS_UI="$gCLI_MODULE_INSTALL_STATUS_UI | Commit: $commitHash"; fi
    local timestampUTC=$(ndr_QueryContainerImageTimestampHumanReadable "$NDR_UI_CONTAINER_NAME")
    if [[ -n "$timestampUTC" ]]; then gCLI_MODULE_INSTALL_STATUS_UI="$gCLI_MODULE_INSTALL_STATUS_UI | Built: $timestampUTC"; fi

    # image update check
    ndr_QueryLatestMatchingRemoteImageTags "$NDR_UI_IMAGE_NAME"
    if [[ -n "$commitHash" && -n "$NDR_UI_IMAGE_COMMIT_HASH_SHORT" && "$commitHash" != "$NDR_UI_IMAGE_COMMIT_HASH_SHORT" ]]; then
    local timestampHR=$(date -u -d @"$NDR_UI_IMAGE_COMMIT_TIMESTAMP_UTC" +"%Y-%m-%d")
      gCLI_MODULE_INSTALL_STATUS_UI="$gCLI_MODULE_INSTALL_STATUS_UI |${YELLOW} Update available: $NDR_UI_IMAGE_COMMIT_HASH_SHORT ($timestampHR)${RESET}"
      gCLI_UPDATES_AVAILABLE=true;
    fi
  fi
  
  gCLI_NDR_INSTALLED_VERSION=$(ndr_getVersionReg)
  gCLI_NDR_HOST_ADDRESS=$(ndr_getHostAddressReg)

  #ndr_UpdateModuleUpgradeStatus

  ndr_logSecEndDebug "$logSectionDesc" 

  return 0
}

function ndr_DisplayModuleInstallStatus ()
{
  if [[ "$gCLI_UPDATES_AVAILABLE" == true ]]; then
    echo -e "${YELLOW}Attention! Updates may be available for installed modules.${RESET}"
  fi
  echo -e "Current module installation status:"
  echo -e "  Supabase application [ $gCLI_MODULE_INSTALL_STATUS_DB ]"
  if [[ "$gNDR_INSTALL_ENG_VER" == "$gNDR_INSTALL_ENG_VERSION_V2" ]]; then
    echo -e "  Client application [ $gCLI_MODULE_INSTALL_STATUS_CLIENT ]" # not supported yet
  else
    echo -e "  Service application [ $gCLI_MODULE_INSTALL_STATUS_SVC ]"
    echo -e "  UI application [ $gCLI_MODULE_INSTALL_STATUS_UI ]"
  fi
  return 0
}

function ndr_PopulateLocalGitRepoDetails ()
{
  local logSectionDesc="Populating Local Git Repo Details"
  ndr_logSecStartDebug "$logSectionDesc"

  local commit_hash=$(git rev-parse HEAD 2>/dev/null)
  return_code=$?
  if [[ $return_code -ne 0 || -z "$commit_hash" ]]; then
    ndr_logWarn "Unable to retrieve git commit hash."
    return 1
  fi
  
  if [[ -n "$gCLI_GIT_REPO_COMMIT_HASH_LONG" && "$commit_hash" == "$gCLI_GIT_REPO_COMMIT_HASH_LONG" ]];then
    # already up to date
    ndr_logDebug "Local git repo details up to date."
    ndr_logSecEndDebug "$logSectionDesc"
    return 0
  fi

  gCLI_GIT_REPO_COMMIT_HASH_LONG="$commit_hash"

  gCLI_GIT_REPO_COMMIT_HASH_SHORT=$(echo "$gCLI_GIT_REPO_COMMIT_HASH_LONG" | cut -c1-7)
  
  gCLI_GIT_REPO_COMMIT_TIMESTAMP=$(git show -s --format=%ct 2>/dev/null)
  return_code=$?
  if [[ $return_code -ne 0 || -z "$gCLI_GIT_REPO_COMMIT_TIMESTAMP" ]]; then
    ndr_logWarn "Unable to retrieve git commit timestamp."
    return 1
  fi

  local tsHR=$(date -u -d @"$gCLI_GIT_REPO_COMMIT_TIMESTAMP" +"%Y-%m-%d")

  gCLI_GIT_REPO_STATUS="Commit: $gCLI_GIT_REPO_COMMIT_HASH_LONG ($gCLI_GIT_REPO_COMMIT_HASH_SHORT) | Timestamp: $tsHR ($gCLI_GIT_REPO_COMMIT_TIMESTAMP)"
  
  ndr_logDebug "Built full repo details [$gCLI_GIT_REPO_STATUS]"

  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ndr_logWarn "This is a bash module--there is no direct execution capabilities in this file."
  exit 0
fi
