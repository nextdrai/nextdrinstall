#!/bin/bash
# ndrDocker.sh - A Bash module providing common Docker related functions

source "$(dirname "${BASH_SOURCE[0]}")/ndrCommon.sh"

export NDR_DOCKER_REMOTE_REPO_AUTHENTICATED=false
export NDR_DOCKER_REMOTE_REPO_QUERIED=false

# --- FUNCTIONS ---

function ndr_removeDockerPackages ()
{
  local logSectionDesc="Cleaning up packages"
  ndr_logSecStart "$logSectionDesc"

  # Loop through each package and remove it
  for pkg in "${dockerRemovePkgs[@]}"; do
    if dpkg -l | grep -q "$pkg"; then
      ndr_logInfo "🗑️ Removing $pkg..."
      sudo apt-get remove --assume-yes "$pkg"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "$pkg package not removed, please manually remove package before proceeding."
        return 1
      fi
    else
      ndr_logInfo "$pkg is not installed, skipping."
    fi
  done

  # Loop through each package and remove it
  for pkg in "${dockerInstallPackages[@]}"; do
    if dpkg -l | grep -q "$pkg"; then
      ndr_logInfo "🗑️ Removing $pkg..."
      sudo apt-get remove --assume-yes "$pkg"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "$pkg package not removed, please manually remove package before proceeding."
        return 1
      fi
    else
      ndr_logInfo "$pkg is not installed, skipping."
    fi
  done

  sudo apt-get autoremove --assume-yes
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to autoremove unused packages."
    #return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# returns 2 for usage or general error
# returns 1 for image not found
# returns 0 for image found
# usage: function <image:tag>
function ndr_verifyDockerImageExists () 
{
  local logSectionDesc="Verifying Docker Image Exists"
  ndr_logSecStartDebug "$logSectionDesc"

  local retVal=0

  if [[ $# -lt 1 ]]; then
    ndr_logWarn "Usage: ndr_verifyDockerImageExists <image:tag>"
    return 2
  fi

  local image_name="$1"
  if [[ -z "$image_name" ]]; then
    ndr_logWarn "Usage: ndr_verifyDockerImageExists <image:tag>"
    return 2
  fi

  # check for existance of optional image tag.
  tagPresent=false

  if [[ "$image_name" == *:* ]]; then
    tagPresent=true
  fi

  # Run command and capture both output and return status
  while true; do
    
    local output
    if [[ "$tagPresent" == true ]]; then
      output=$(docker images --format "{{.Repository}}:{{.Tag}}" 2>/dev/null)
    else
      output=$(docker images --format "{{.Repository}}" 2>/dev/null)
    fi
    return_code=$?

    # Check if docker failed
    if [[ $return_code != 0 ]]; then
      ndr_logError "Failed to query for Docker images."
      retVal=2
      break
    fi

    # check if output is empty (no images at all present)
    if [[ -z "$output" ]]; then
      ndr_logInfo "No Docker images found."
      retVal=1
      break
    fi

    #if [[ -n "$output" ]]; then
    #  ndr_logInfo "✅ Docker image '${image_name}' exists."
    #  retVal=0
    #else
    #  ndr_logWarn "No matching image output returned for '${image_name}'."
    #  retVal=1
    #fi

    # there is output, check for target item.
    echo "$output" | grep -Fxq "$image_name"
    return_code=$?
    if [[ $return_code -eq 0 ]]; then
      ndr_logInfo "✅ Docker image '${image_name}' exists."
      retVal=0
    else
      ndr_logWarn "No matching image output returned for '${image_name}'."
      retVal=1
    fi
    
    break
  done
  
  ndr_logSecEndDebug "$logSectionDesc"

  return $retVal
}

# returns 2 for usage or general error
# returns 1 for container not found
# returns 0 for container found
# usage: function <container_name>
function ndr_verifyDockerContainerExists () 
{
  local logSectionDesc="Verifying Docker Container Exists"
  ndr_logSecStartDebug "$logSectionDesc"

  local retVal=0

  if [[ $# -lt 1 ]]; then
    ndr_logWarn "Usage: ndr_verifyDockerContainerExists <container_name>"
    return 2
  fi

  local container_name="$1"
  if [[ -z "$container_name" ]]; then
    echo "❌ Usage: ndr_verifyDockerContainerExists <container_name>"
    return 2
  fi

  # Capture the output and return code separately
  while true; do
    
    local output
    output=$(docker ps -a --format '{{.Names}}' 2>/dev/null)
    local status=$?

    # Check if docker failed
    if [[ $status -ne 0 ]]; then
      ndr_logError "Failed to query for Docker containers."
      retVal=2
      break
    fi

    # check if output is empty (no containers at all present)
    if [[ -z "$output" ]]; then
      ndr_logInfo "No Docker containers found."
      retVal=1
      break
    fi

    # there is output, check for target item.
    echo "$output" | grep -Fxq "$container_name"
    return_code=$?
    if [[ $return_code -eq 0 ]]; then
      ndr_logDebug "✅ Docker container '${container_name}' exists."
      retVal=0
    else
      ndr_logWarn "No matching container output returned for '${container_name}'."
      retVal=1
      break
    fi

    break
  done

  ndr_logSecEndDebug "$logSectionDesc"

  return $retVal
}

# usage: function <container_name> [container_port]
function ndr_verifyDockerContainerRunning () 
{
  local logSectionDesc="Verifying Docker Container is Running"
  ndr_logSecStartDebug "$logSectionDesc"

  local dockerContainerName="$1"
  local dockerContainerPort="${2:-}"
  
  # Validate argument count
  if [[ $# -lt 1 ]]; then
    ndr_logError "Usage: function <container_name> [container_port]"
    return 1
  fi

  # check if the container is running
  docker ps -a | grep "$dockerContainerName" | grep "Up"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Docker container [$dockerContainerName] is not running."
    return 1
  fi
  ndr_logInfo "Docker container [$dockerContainerName] is running."

  if [[ -z "$dockerContainerPort" ]]; then
    ndr_logInfo "Port not supplied for container [$dockerContainerName], skipping optional port and curl check."
  else
    local dockerContainerURL="http://localhost:$dockerContainerPort"

    # check if the container is running on specified container port
    docker ps -a | grep "$dockerContainerName" | grep "$dockerContainerPort"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logWarn "Docker container [$dockerContainerName] is NOT running on port $dockerContainerPort."
      return 1
    fi
    ndr_logInfo "Docker container [$dockerContainerName] is running on port $dockerContainerPort."
    
    # execute curl command to check if the container is running
    curl -s -o /dev/null -w "%{http_code}" "$dockerContainerURL"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logWarn "Failed to access the container at $dockerContainerURL"
      #todo, restore this once service can respond to curl return 1
    fi
    ndr_logInfo "Successfully accessed the container at $dockerContainerURL"
 fi

  ndr_logSecEndDebug "$logSectionDesc"

  return $retVal
}

# usage: function <image_name> [build_mode_options]
function ndr_cleanupDockerImage() 
{
  local logSectionDesc="Cleaning up Docker Image"
  ndr_logSecStart "$logSectionDesc"

  # Validate argument count
  if [[ $# -lt 1 ]]; then
    ndr_logError "Usage: function <image_name> [build_mode_options]"
    return 1
  fi

  local search_image_name="$1"
  if [[ -z "$search_image_name" ]]; then
    ndr_logWarn "Usage: function <image_name> [build_mode_options]"
    return 2
  fi
  
  local dockerAppManageOptions="${2:-$NDR_DOCKER_APP_MANAGE_OPTIONS_DEFAULT}"

  if [[ "$gNDR_RETAIN_DOCKER_IMAGES" == true ]]; then
    ndr_logInfo "Global flag to retain Docker images is set, skipping delete of [$search_image_name]"
    return 0
  fi

  local retVal=0
  
  # query for all images matching the name. Useful for older style image tags without embedded commit hash or datetime and for cleaning out all images with same base name.
  mapfile -t images < <(docker images --format "{{.Repository}}:{{.Tag}}" | grep "$search_image_name")

  ndr_logInfo "Found ${#images[@]} matching image [$search_image_name]"

  for image_name in "${images[@]}"; do
    ndr_logInfo "Removing image [$image_name]..."

    ndr_verifyDockerImageExists "$image_name"
    return_code=$?
    #2-error, 1-not found, 0-found
    if [[ $return_code != 0 ]]; then
      # skip if not found
      ndr_logInfo "Docker image '${image_name}' not found, no cleanup needed."
      #retVal=0
      #break
      continue
    fi
    
    # if option to remove without prompting is present, skip interactive prompt and remove.
    ndr_checkFlag "$dockerAppManageOptions" "$NDR_DOCKER_APP_MANAGE_OPTIONS_REMOVE_NO_PROMPT"
    return_code=$?
    if [[ $return_code != 0 ]]; then
      ndr_logInfo "Existing Docker image '${image_name}' found. Removing it will erase it permanently."
      read -p "Are you sure you want to proceed? [Y|n] " -n 1 -r
      echo    # Move to a new line
      if [[ $REPLY =~ ^[Nn]$ ]]; then
        ndr_logInfo "Skipping docker image removal."
        #retVal=0
        #break
        continue
      fi
    fi

    ndr_logInfo "🧹 Forcing removal of image '${image_name}'..."
    docker image rm -f "$image_name"
    return_code=$?
    if [[ $return_code != 0 ]]; then
      ndr_logError "Failed to remove image '${image_name}'."
      retVal=1
      #break
      continue
    fi
    ndr_logInfo "Docker image '${image_name}' removal command succeeded."

    docker buildx prune -f
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logWarn "Failed to prune docker build cache entries."
    fi
    ndr_logInfo "Successfully pruned docker build cache entries."

    ndr_verifyDockerImageExists "$image_name"
    return_code=$?
    #2-error, 1-not found, 0-found
    if [[ $return_code -eq 0 ]]; then
      # image still exists after removal attempt
      ndr_logError "Error, image still present after removal '${image_name}'."
      retVal=1
      #break
      continue
    fi

    ndr_logInfo "✅ Image '${image_name}' successfully removed and verified."

  done

  if [ "$retVal" -ne 0 ]; then
    ndr_logError "One or more errors encountered during image cleanup."
  fi

  ndr_logSecEnd "$logSectionDesc"

  #return 0
  return "$retVal"
}

# usage: function  <image_name> [build_mode_options]
function ndr_cleanupDockerContainer ()
{
  local logSectionDesc="Cleaning up Docker Container"
  ndr_logSecStart "$logSectionDesc"

  local retVal=0

  while true; do
    local container_name="$1"
    
    if [[ -z "$container_name" ]]; then
      ndr_logWarn "Usage: ndr_cleanupDockerContainer <container_name> [build_mode_options]"
      retVal=2
      break
    fi

    local dockerAppManageOptions="${2:-$NDR_DOCKER_APP_MANAGE_OPTIONS_DEFAULT}"

    ndr_verifyDockerContainerExists "$container_name"
    return_code=$?
    #2-error, 1-not found, 0-found
    if [[ $return_code != 0 ]]; then
      # skip if not found
      ndr_logInfo "Docker container '${container_name}' not found, nothing to remove."
      retVal=0
      break
    fi

     # if option to remove without prompting is present, skip interactive prompt and remove.
    ndr_checkFlag "$dockerAppManageOptions" "$NDR_DOCKER_APP_MANAGE_OPTIONS_REMOVE_NO_PROMPT"
    return_code=$?
    if [[ $return_code != 0 ]]; then
      ndr_logInfo "Existing Docker container '${container_name}' found. Removing it will erase it permanently."
      read -p "Are you sure you want to proceed? [Y|n] " -n 1 -r
      echo    # Move to a new line
      if [[ $REPLY =~ ^[Nn]$ ]]; then
        ndr_logInfo "Skipping docker container removal."
        retVal=0
        break
      fi
    fi

    ndr_logInfo "🛑 Stopping container '${container_name}'..."

    docker stop "$container_name"
    return_code=$?
    if [[ $return_code != 0 ]]; then
      ndr_logWarn "Failed to stop Docker container '${container_name}'."
      #retVal=1
      #break
    fi

    ndr_logInfo "🧹 Removing container '${container_name}'..."
    
    docker container rm -f "$container_name"
    return_code=$?
    if [[ $return_code != 0 ]]; then
      ndr_logError "Failed to remove Docker container '${container_name}'."
      retVal=1
      break
    fi
    ndr_logInfo "Docker container removal command succeeded."

    ndr_verifyDockerContainerExists "$container_name"
    return_code=$?
    #2-error, 1-not found, 0-found
    if [[ $return_code -eq 0 ]]; then
      ndr_logError "Error, container still present after removal '${container_name}'."
      retVal=1
      break
    fi

    ndr_logInfo "✅ Container '${container_name}' successfully removed and verified."

    break
  done
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function <folder> <image_name> <image_version> <container_name> [build_mode_options]
function ndr_cleanupDockerApplication ()
{
  local logSectionDesc="Cleanup Docker Application"
  ndr_logSecStart "$logSectionDesc"

  local containerFolder="$1"
  local dockerImageBaseName="$2"
  local dockerImageVersion="$3"
  local dockerImageName="$dockerImageBaseName:$dockerImageVersion"
  local dockerContainerName="$4"
  
  local dockerAppManageOptions="${5:-$NDR_DOCKER_APP_MANAGE_OPTIONS_DEFAULT}"

  # Validate argument count
  if [[ $# -lt 4 ]]; then
    ndr_logError "Usage: ndr_cleanupDockerApplication <folder> <image_name> <image_version> <container_name> [build_mode_options]"
    return 1
  fi

  if [[ ! -d "$containerFolder" ]]; then
    ndr_logWarn "Container path [$containerFolder] does not exist."
    return 0
  fi

  # move from the install directory to the container/module directory
  cd "$containerFolder" || { ndr_logError "Failed to cd into $containerFolder"; return 1; }

  # query for full image tag in use by container
  dockerImageName=$(ndr_QueryContainerImageVersionTag "$dockerContainerName")
  return_code=$?
  if [[ "$return_code" -ne 0 || -z "$dockerImageName" ]]; then
    ndr_logWarn "Failed to query for image tag in use by container [$dockerContainerName], image may not be present and/or image cleanup may not succeed."
    dockerImageName="$dockerImageBaseName:$dockerImageVersion"
  fi

  if (( dockerAppManageOptions & NDR_DOCKER_APP_MANAGE_OPTIONS_CONTAINER )); then
    # remove any existing Docker container with the same name
    ndr_cleanupDockerContainer "$dockerContainerName" "$dockerAppManageOptions"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to remove existing Docker container."
      return 1
    fi
  fi

  if (( dockerAppManageOptions & NDR_DOCKER_APP_MANAGE_OPTIONS_IMAGE )); then
    # remove any existing image with the same name
    ndr_cleanupDockerImage "$dockerImageName" "$dockerAppManageOptions"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to remove existing Docker image."
      return 1
    fi
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# prepares the container for running by performing whatever steps needed to prepare and configure before running.
# usage: function <folder> <image_name> <image_version> <container_name> [build_mode_options]
function ndr_prepareDockerApplicationContainer ()
{
  local logSectionDesc="Preparing Docker Application Container"
  ndr_logSecStart "$logSectionDesc"

  local containerFolder="$1"
  local dockerImageBaseName="$2"
  local dockerImageVersion="$3"
  local dockerImageVersionCleanup=$gINSTALLED_VERSION
  local dockerImageName="$dockerImageBaseName:$dockerImageVersion"
  local dockerContainerName=$4
  
  local dockerAppManageOptions="${5:-$NDR_DOCKER_APP_MANAGE_OPTIONS_NONE}"

  # Validate argument count
  if [[ $# -lt 4 ]]; then
    ndr_logError "Usage: function <folder> <image_name> <image_version> <container_name> [build_mode_options]"
    return 1
  fi

  # move from the install directory to the container/module directory
  #cd "$containerFolder" || { ndr_logError "Failed to cd into $containerFolder"; return 1; }
  
  dockerAppManageOptions=$(( dockerAppManageOptions | NDR_DOCKER_APP_MANAGE_OPTIONS_CONTAINER | NDR_DOCKER_APP_MANAGE_OPTIONS_REMOVE_NO_PROMPT ))

  # remove any existing Docker container with the same name
  ndr_cleanupDockerApplication "$containerFolder" "$dockerImageBaseName" "$dockerImageVersionCleanup" "$dockerContainerName" "$dockerAppManageOptions"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to remove existing Docker application container."
    return 1
  fi

  # populate host address before env file construction.
  ndr_PopulateHostAddress
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to populate host address."
    return 1
  fi

  # construct env file
  ndr_BuildModuleEnvFileV2 "$containerFolder"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to build module env file for [$containerFolder]."
    return 1
  fi

  # construct the compose file
  ndr_BuildModuleComposeFile "$containerFolder" "$dockerImageBaseName"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to customize module compose file for [$containerFolder]."
    return 1
  fi
  
  # create the bridge network if it does not exist
  ndr_createDockerBridgeNetwork
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to create Docker bridge network."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# runs a fully prep'd container, or restarts one already created.
# usage: function <folder> <image_name> <image_version> <container_name> <container_port> [build_mode_options]
function ndr_runDockerApplicationContainer ()
{
  local logSectionDesc="Running Docker Application Container"
  ndr_logSecStart "$logSectionDesc"

  local containerFolder="$1"
  local dockerImageBaseName="$2"
  local dockerImageVersion="$3"
  local dockerImageName="$dockerImageBaseName:$dockerImageVersion"
  local dockerContainerName=$4
  local dockerContainerPort=$5
  local dockerContainerURL="http://localhost:$dockerContainerPort"

  local dockerAppManageOptions="${6:-$NDR_DOCKER_APP_MANAGE_OPTIONS_NONE}"

  # Validate argument count
  if [[ $# -lt 5 ]]; then
    ndr_logError "Usage: function <folder> <image_name> <image_version> <container_name> <container_port> [build_mode_options]"
    return 1
  fi

  # move from the install directory to the container/module directory
  cd "$containerFolder" || { ndr_logError "Failed to cd into $containerFolder"; return 1; }
  
  dockerAppManageOptions=$(( dockerAppManageOptions | NDR_DOCKER_APP_MANAGE_OPTIONS_CONTAINER | NDR_DOCKER_APP_MANAGE_OPTIONS_REMOVE_NO_PROMPT ))

  # Check if the .env file exists. 
  # env file is needed for both container start modes to either be an explicit input (run mode) or implicitly linked to compose file (compose mode).
  local envFile="${containerFolder}/${gNDR_ENV_TARGET_FILENAME}"
  if [[ ! -f "$envFile" ]]; then
    ndr_logError "env file '$envFile' not found."
    return 1
  fi
    
  # Check if the compose file exists
  local composeFile="${containerFolder}/${NDR_STANDARD_DOCKER_COMPOSEFILE_FILENAME}"
  if [[ ! -f "$composeFile" ]]; then
    ndr_logError "Compose file '$composeFile' not found."
    return 1
  fi

  docker compose up -d 
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to run Docker container [$dockerContainerName]."
    return 1
  fi

  # check if the newly built Docker container exists
  ndr_verifyDockerContainerExists "$dockerContainerName"
  return_code=$?
  #2-error, 1-not found, 0-found
  if [ $return_code -ne 0 ]; then
    ndr_logError "Docker container verification failed."
    return 1
  fi

  # check if the container is running
  ndr_verifyDockerContainerRunning "$dockerContainerName" "$dockerContainerPort"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Docker container [$dockerContainerName] is not running."
    return 1
  fi
  
  ndr_logInfo "Docker container [$dockerContainerName] is running and accessible at [$dockerContainerURL]"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_postExecDockerApplicationContainer ()
{
  local logSectionDesc="Post exec Docker Application Container"
  ndr_logSecStart "$logSectionDesc"

  # clean up image env file
  #ndr_CleanupModuleEnvFile "$containerFolder"
  #return_code=$?
  #if [ $return_code != 0 ]; then
  #  ndr_logWarn "Failed to clean up module env file for [$containerFolder]."
  #fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function <folder> <image_name> <image_version> <container_name> <container_port> [build_mode_options]
function ndr_ComposeDockerApplicationContainer ()
{
  local logSectionDesc="Composing Docker Application Container"
  ndr_logSecStart "$logSectionDesc"

  local containerFolder="$1"
  local dockerImageBaseName="$2"
  local dockerImageVersion="$3"
  local dockerImageName="$dockerImageBaseName:$dockerImageVersion"
  local dockerContainerName=$4
  local dockerContainerPort=$5
  local dockerContainerURL="http://localhost:$dockerContainerPort"

  local dockerAppManageOptions="${6:-$NDR_DOCKER_APP_MANAGE_OPTIONS_NONE}"

  # Validate argument count
  if [[ $# -lt 5 ]]; then
    ndr_logError "Usage: function <folder> <image_name> <image_version> <container_name> <container_port> [build_mode_options]"
    return 1
  fi

  # prepare container for running
  ndr_prepareDockerApplicationContainer "$containerFolder" "$dockerImageBaseName" "$dockerImageVersion" "$dockerContainerName"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to prepare Docker container [$dockerContainerName]."
    return 1
  fi

  # run container
  ndr_runDockerApplicationContainer "$containerFolder" "$dockerImageBaseName" "$dockerImageVersion" "$dockerContainerName" "$dockerContainerPort"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to run Docker container [$dockerContainerName]."
    return 1
  fi

  # post exec cleanup
  ndr_postExecDockerApplicationContainer
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to run post exec on Docker container [$dockerContainerName]."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_scrubAllDockerResources ()
{
  local logSectionDesc="Force Removing All Local Docker Resources"
  ndr_logSecStart "$logSectionDesc"  

  if [ "$gExpressMode" -ne 1 ]; then
    ndr_logInfo "ALL existing local Docker resources will be removed, both active and inactive. Warning, this action cannot be undone!"
    read -p "Are you sure you want to proceed? [y|N] " -n 1 -r
    echo    # Move to a new line
    if [[ $REPLY =~ ^[Yy]$ ]]; then
      ndr_logInfo "Proceeding with all local Docker resource removal."
    else
      ndr_logInfo "Operation cancelled, returning to main menu."
      return 0
    fi
  fi

  # docker cleanup
  # https://stackoverflow.com/questions/45357771/stop-and-remove-all-docker-containers

  #Stop all the containers
  docker stop $(docker ps -a -q)
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Error encountered with docker stop."
  fi

  #Remove all the containers
  docker rm -f $(docker ps -a -q)
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Error encountered with docker rm."
  fi

  #Deleting no longer needed containers (stopped)
  docker container prune -f
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Error encountered with docker container prune."
  fi

  #Deleting no longer needed images which means, that it only deletes images, which are not tagged and are not pointed on by "latest" - so no real images you can regularly use are deleted
  if [ "$gNDR_RETAIN_DOCKER_IMAGES" == false ]; then
    docker image prune -a -f
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logWarn "Error encountered with docker image prune."
    fi
  else
    ndr_logInfo "Skipping Docker image prune due to global retain image option being enabled."
  fi

  #Delete all volumes, which are not used by any existing container ( even stopped containers do claim volumes ). 
  # This usually cleans up dangling anon-volumes of containers have been deleted long time ago. 
  # It should never delete named volumes since the containers of those should exists / be running. 
  # Be careful, ensure your stack at least is running before going with this one
  docker volume prune -f
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Error encountered with docker volume prune."
  fi

  #Same for unused networks
  docker network prune -f
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Error encountered with docker network prune."
  fi

  #And finally, if you want to get rid if all the trash - to ensure nothing happens to your production, be sure all stacks are running and then run
  docker system prune -f
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Error encountered with docker system prune."
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# Function to parse details of a given service
function ndr_ParseComposeFileServiceDetails () 
{
  if [[ $# -ne 2 ]]; then
    ndr_logWarn "Usage: ndr_ParseComposeFileServiceDetails <compose_file_path> <service_name>"
    return 1
  fi

  local compose_file=$1
  local service=$2

  # Extract container_name, image full string (name:tag)
  local container_name image_full image_name image_tag

  container_name=$(yq eval ".services.\"$service\".container_name // \"\"" "$compose_file")
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to parse container_name for service '$service'"
    return 1
  fi

  image_full=$(yq eval ".services.\"$service\".image // \"\"" "$compose_file")
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to parse image for service '$service'" >&2
    return 1
  fi

  # If no image defined, leave blank
  if [[ -z "$image_full" ]]; then
    image_name=""
    image_tag=""
  else
    # Split image_full into name and tag by ':'
    if [[ "$image_full" == *:* ]]; then
      image_name="${image_full%%:*}"
      image_tag="${image_full##*:}"
    else
      image_name="$image_full"
      image_tag="latest"
    fi
  fi

  # Save to global associative arrays keyed by service name
  ndr_supabase_container_service_container_names["$service"]="$container_name"
  ndr_supabase_container_service_image_names["$service"]="$image_name"
  ndr_supabase_container_service_image_tags["$service"]="$image_tag"

  return 0
}

# Function to parse top-level services and call detail parser
# Usage: ndr_ParseComposeFileServiceDetails <compose_file_path>"
function ndr_ParseComposeFileServices () 
{
  local logSectionDesc="Parsing Compose File Services"
  ndr_logSecStart "$logSectionDesc"  

  if [[ $# -ne 1 ]]; then
    ndr_logWarn "Usage: ndr_ParseComposeFileServiceDetails <compose_file_path>"
    return 1
  fi

  local compose_file=$1
  if [[ ! -f "$compose_file" ]]; then
    ndr_logError "Compose file not found: $compose_file"
    return 1
  fi

  # Clear previous contents
  ndr_supabase_container_services=()
  ndr_supabase_container_service_container_names=()
  ndr_supabase_container_service_image_names=()
  ndr_supabase_container_service_image_tags=()

  # Extract service names using yq (expects yq v4+)
  mapfile -t ndr_supabase_container_services < <(yq eval '.services | keys | .[]' "$compose_file")
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to parse services from $compose_file"
    return 1
  fi

  ndr_logInfo "Found ${#ndr_supabase_container_services[@]} services in the compose file '$compose_file'."

  # For each service, call details parser
  for svc in "${ndr_supabase_container_services[@]}"; do
    ndr_ParseComposeFileServiceDetails "$compose_file" "$svc"
    return_code=$?
    if [[ $return_code != 0 ]]; then
      ndr_logError "Failed to parse service details for '$svc' in $compose_file"
      return 1
    fi
  done

  if  [[ ${#ndr_supabase_container_services[@]} -ne 0 ]]; then  
    echo "-----------------------------------------------------------------------------------------"
    echo "Parsed Docker Compose Services in [$compose_file]:"
    echo "-----------------------------------------------------------------------------------------"

    for svc in "${ndr_supabase_container_services[@]}"; do
      # Output
      echo "Service: $svc"
      echo "  Container Name: ${ndr_supabase_container_service_container_names[$svc]}"
      echo "  Image Name    : ${ndr_supabase_container_service_image_names[$svc]}"
      echo "  Image Tag     : ${ndr_supabase_container_service_image_tags[$svc]}"
      echo
    done

    echo "-----------------------------------------------------------------------------------------"
  fi

  ndr_logInfo "Successfully parsed Docker compose file [$compose_file] service entries."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function [build_mode_options]
function ndr_mainCleanupServiceApplication ()
{
  local logSectionDesc="Cleanup Service Application"
  ndr_logSecStart "$logSectionDesc"

  local containerFolder=$NDR_SERVICE_HOME_LOC
  local dockerImageName=$NDR_SERVICE_IMAGE_NAME
  local dockerImageVersion=$NDR_SERVICE_IMAGE_VERSION
  local dockerContainerName=$NDR_SERVICE_CONTAINER_NAME
  
  local dockerAppManageOptions="${1:-$NDR_DOCKER_APP_MANAGE_OPTIONS_REMOVE_ALL}"

  local applicationHomeDir
  if [[ "$gNDR_DEVOPS_MODE" == true ]]; then
    applicationHomeDir="${gSCRIPT_HOME_DIR}/../${containerFolder}"
  else
    applicationHomeDir="${gNEXTDR_HOME_DIR}/${containerFolder}"
  fi

  ndr_cleanupDockerApplication "$applicationHomeDir" "$dockerImageName" "$dockerImageVersion" "$dockerContainerName" "$dockerAppManageOptions"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to remove existing Docker application [$dockerContainerName]."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function [build_mode_options]
function ndr_mainCleanupUIApplication ()
{
  local logSectionDesc="Cleanup UI Application"
  ndr_logSecStart "$logSectionDesc"

  local containerFolder=$NDR_UI_HOME_LOC
  local dockerImageName=$NDR_UI_IMAGE_NAME
  local dockerImageVersion=$NDR_UI_IMAGE_VERSION
  local dockerContainerName=$NDR_UI_CONTAINER_NAME
  
  local dockerAppManageOptions="${1:-$NDR_DOCKER_APP_MANAGE_OPTIONS_REMOVE_ALL}"

  local applicationHomeDir
  if [[ "$gNDR_DEVOPS_MODE" == true ]]; then
    applicationHomeDir="${gSCRIPT_HOME_DIR}/../${containerFolder}"
  else
    applicationHomeDir="${gNEXTDR_HOME_DIR}/${containerFolder}"
  fi

  ndr_cleanupDockerApplication "$applicationHomeDir" "$dockerImageName" "$dockerImageVersion" "$dockerContainerName" "$dockerAppManageOptions"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to remove existing Docker application [$dockerContainerName]."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_createDockerBridgeNetwork ()
{
  local logSectionDesc="Create Docker Bridge Network"
  ndr_logSecStart "$logSectionDesc"

  if ! docker network ls --format '{{.Name}}' | grep -q "^${NDR_DOCKER_BRIDGE_NETWORK_NAME}$"; then
    ndr_logInfo "Creating Docker network: ${NDR_DOCKER_BRIDGE_NETWORK_NAME}"
    docker network create "${NDR_DOCKER_BRIDGE_NETWORK_NAME}"
    return_code=$?
    if [[ $return_code != 0 ]]; then
      ndr_logError "Failed to create Docker network '${NDR_DOCKER_BRIDGE_NETWORK_NAME}'. Please check your Docker installation and permissions."
      return 1
    fi
  else
    ndr_logInfo "Docker network '${NDR_DOCKER_BRIDGE_NETWORK_NAME}' already exists"
  fi

  ndr_logInfo "Docker bridge network created."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function <image_name> <image_version> <repo_name>
function ndr_DownloadDockerImage ()
{
  local logSectionDesc="Downloading Docker Image"
  ndr_logSecStart "$logSectionDesc"

  local dockerImageBaseName="$1"
  local dockerImageVersion="$2"
  local dockerImageName="${dockerImageBaseName}:${dockerImageVersion}"
  local imageRepoName="$3"
  
  # Validate argument count
  if [[ $# -lt 3 ]]; then
    ndr_logError "Usage: ndr_DownloadDockerImage <image_name> <image_version> <repo_name>"
    return 1
  fi
  
  if [[ "$NDR_DOCKER_REPO_TYPE_CURRENT" == "$NDR_DOCKER_REPO_TYPE_PRIVATE" ]]; then
    ndr_logInfo "Docker repo type is private, performing authentication first."
  
    # decrypt and populate secrets.
    ndr_DecryptPopulateSecrets || { echo "Error: failed to populate secrets"; return 1; }

    if [[ -z "$NDR_DOCKER_REPO_ACCOUNT" || -z "$NDR_DOCKER_REPO_ACCESS_TOKEN" ]]; then
      ndr_logError "Docker repo account and/or token empty."
      return 1
    fi

    docker login -u "$NDR_DOCKER_REPO_ACCOUNT" -p "$NDR_DOCKER_REPO_ACCESS_TOKEN"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Docker login failed for [$NDR_DOCKER_REPO_ACCOUNT]."
      return 1
    fi
    ndr_logInfo "Docker login success for account [$NDR_DOCKER_REPO_ACCOUNT]"
  else
    ndr_logInfo "Docker repo type is public, proceeding without authentication."
  fi

  # raw image base name: supabase/studio, encoded base name: supabase_NDR_DELIM_studio
  #local encodedDockerImageBaseName=$(echo "$dockerImageBaseName" | sed "s|${NDR_DOCKER_MODULE_NAME_DELIMITER_RAW}|${NDR_DOCKER_MODULE_NAME_DELIMITER_MONIKER}|g")
  # repo tag format: <account>/<repo_name>:<{image_base_name}_{image_version}>
  #local repoImageTag="$NDR_DOCKER_REPO_ACCOUNT/$imageRepoName:${encodedDockerImageBaseName}_${dockerImageVersion}"
  # transform local to remote image format
  local repoImageTag
  repoImageTag=$(ndr_LocalToRemoteRepoImageName "$dockerImageBaseName" "$dockerImageVersion" "$imageRepoName")
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to convert image name [$dockerImageName]."
    return 1
  fi

  # pull image from repo
  docker pull "$repoImageTag"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Docker pull failed for [$repoImageTag]."
    return 1
  fi
  ndr_logInfo "Docker pull success for [$repoImageTag]."

  # check if the newly pulled Docker image is present
  ndr_verifyDockerImageExists "$repoImageTag"
  return_code=$?
  #2-error, 1-not found, 0-found
  if [ $return_code -ne 0 ]; then
    ndr_logError "Docker image verification failed for local copy of remote tag [$repoImageTag]."
    return 1
  fi
  ndr_logInfo "Docker remote repo image tag found [$repoImageTag]."

  # re tag it from remote format to local.
  docker tag "$repoImageTag" "$dockerImageName"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Docker tag failed for [$repoImageTag]."
    return 1
  fi
  ndr_logInfo "Docker tag success for [$repoImageTag] to [$dockerImageName]."
  
  # cleanup remote repo tag reference to local image.
  ndr_logInfo "Removing remote repo tag [$repoImageTag] from local image [$dockerImageName]"
  docker rmi "$repoImageTag"
  if [ $return_code -ne 0 ]; then
    ndr_logError "Docker rmi failed for [$repoImageTag]."
    #return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# Converts from raw image base name values: <image_base_name>, <version>, <repo_name> to encoded base name. eg: <repo_account>/<repo_name>:<moniker_image_base_name>_<version>
# Will also convert and image base name with delim to moniker format. eg. raw: supabase/studio to moniker: supabase_NDR_DELIM_studio
# usage: function <image_name> <image_version> <repo_name>
# outputs converted image name to stdout
function ndr_LocalToRemoteRepoImageName ()
{
  local dockerImageBaseName="$1"
  local dockerImageVersion="$2"
  local dockerImageName="${dockerImageBaseName}:${dockerImageVersion}"
  local imageRepoName="$3"
  
  # Validate argument count
  if [[ $# -lt 3 ]]; then
    ndr_logError "Usage: ndr_LocalToRemoteRepoImageName <image_name> <image_version> <repo_name>"
    return 1
  fi

  # raw image base name: supabase/studio, encoded base name: supabase_NDR_DELIM_studio
  local encodedDockerImageBaseName=$(echo "$dockerImageBaseName" | sed "s|${NDR_DOCKER_MODULE_NAME_DELIMITER_RAW}|${NDR_DOCKER_MODULE_NAME_DELIMITER_MONIKER}|g")

  # repo tag format: <account>/<repo_name>:<{image_base_name}_{image_version}>
  local repoImageTag="$NDR_DOCKER_REPO_ACCOUNT/$imageRepoName:${encodedDockerImageBaseName}_${dockerImageVersion}"

  echo "$repoImageTag"

  return 0
}

function ndr_RemoteRepoImageExists ()
{
  local logSectionDesc="Remote Repo Image Check"
  ndr_logSecStart "$logSectionDesc"

  local dockerImageBaseName="$1"
  local dockerImageVersion="$2"
  local dockerImageName="${dockerImageBaseName}:${dockerImageVersion}"
  local imageRepoName="$3"
  
  # Validate argument count
  if [[ $# -lt 3 ]]; then
    ndr_logError "Usage: ndr_RemoteRepoImageExists <image_name> <image_version> <repo_name>"
    return 1
  fi

  # transform local to remote image format
  local remoteRepoImageName
  remoteRepoImageName=$(ndr_LocalToRemoteRepoImageName "$dockerImageBaseName" "$dockerImageVersion" "$imageRepoName")
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to convert image name [$dockerImageName]."
    return 1
  fi

  if [[ "$NDR_DOCKER_REPO_TYPE_CURRENT" == "$NDR_DOCKER_REPO_TYPE_PRIVATE" ]]; then
    ndr_logInfo "Docker repo type is private, performing authentication first."
  
    if [[ -z "$NDR_DOCKER_REPO_ACCOUNT" || -z "$NDR_DOCKER_REPO_ACCESS_TOKEN" ]]; then
      ndr_logError "Docker repo account and/or token empty."
      return 1
    fi

    docker login -u "$NDR_DOCKER_REPO_ACCOUNT" -p "$NDR_DOCKER_REPO_ACCESS_TOKEN"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Docker login failed for [$NDR_DOCKER_REPO_ACCOUNT]."
      return 1
    fi
    ndr_logInfo "Docker login success for account [$NDR_DOCKER_REPO_ACCOUNT]"
  else
    ndr_logInfo "Docker repo type is public, proceeding without authentication."
  fi

  docker manifest inspect "$remoteRepoImageName" >/dev/null 2>&1
  local exists=$?
  if [[ $exists -eq 0 ]]; then
    ndr_logInfo "Image [$remoteRepoImageName] exists"
  else
    ndr_logInfo "Image [$remoteRepoImageName] does not exist"
  fi

  ndr_logSecEnd "$logSectionDesc"

  return $exists
}

function ndr_CheckContainerHealth() 
{
  local logSectionDesc="Container Health Check"
  ndr_logSecStart "$logSectionDesc"

  local container_name="$1"

  if [[ -z "$container_name" ]]; then
    ndr_logWarn "Usage: ndr_CheckContainerHealth <container_name>"
    return 1
  fi

  if ! docker inspect "$container_name" &>/dev/null; then
    ndr_logError "Container '$container_name' not found."
    return 1
  fi

  local status health overallhealth=4
  local start_time
  local current_time
  local elapsed_time
  local timeout=60  # 1 minute timeout

  start_time=$(date +%s)

  while true; do
    # Check if we've exceeded the timeout
    current_time=$(date +%s)
    elapsed_time=$((current_time - start_time))
    
    if [ $elapsed_time -ge $timeout ]; then
      ndr_logWarn "Health check timed out after ${timeout} seconds for container '$container_name'"
      overallhealth=4  # unknown state due to timeout
      break
    fi

    status=$(docker inspect --format '{{.State.Status}}' "$container_name" 2>/dev/null)
    health=$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}no healthcheck{{end}}' "$container_name" 2>/dev/null)

    ndr_logInfo "$container_name: $status - $health"

    case "$status" in
      running)
        if [[ "$health" == "healthy" || "$health" == "no healthcheck" ]]; then
          overallhealth=0  # success
          break
        elif [[ "$health" == "unhealthy" ]]; then
          overallhealth=2  # unhealthy
          # continue polling as it might become healthy
        fi
        ;;
      exited|dead)
        overallhealth=3  # container not running
        break
        ;;
      *)
        # For intermediate states, continue polling
        overallhealth=4  # unknown or intermediate state
        ;;
    esac

    sleep 5  # Wait n seconds before next check
  done

  if [ $overallhealth -eq 0 ]; then
    ndr_logInfo "Container '$container_name' is healthy and running"
  elif [ $overallhealth -eq 2 ]; then
    ndr_logWarn "Container '$container_name' is running but unhealthy"
  elif [ $overallhealth -eq 3 ]; then
    ndr_logError "Container '$container_name' is not running"
  else
    ndr_logWarn "Container '$container_name' status is unknown or in transition"
  fi

  ndr_logSecEnd "$logSectionDesc"

  return $overallhealth
}

function ndr_DockerRemoteRepoLogin ()
{
  local logSectionDesc="Docker Remote Repo Login"
  ndr_logSecStart "$logSectionDesc"

  if [ "$NDR_DOCKER_REMOTE_REPO_AUTHENTICATED" == true ]; then
    ndr_logInfo "Already authenticated to remote Docker repo."
    return 0
  fi

  # decrypt and populate secrets.
  ndr_DecryptPopulateSecrets || { echo "Error: failed to populate secrets"; return 1; }

  if [[ -z "$NDR_DOCKER_REPO_ACCOUNT" || -z "$NDR_DOCKER_REPO_ACCESS_TOKEN" ]]; then
    ndr_logError "Docker repo account and/or token empty."
    return 1
  fi

  docker login -u "$NDR_DOCKER_REPO_ACCOUNT" -p "$NDR_DOCKER_REPO_ACCESS_TOKEN"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Docker login failed for [$NDR_DOCKER_REPO_ACCOUNT]."
    return 1
  fi
  ndr_logInfo "Docker login success for account [$NDR_DOCKER_REPO_ACCOUNT]"

  NDR_DOCKER_REMOTE_REPO_AUTHENTICATED=true
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# takes a version tag (e.g. v1.0.0) and appends short git commit hash and timestamp to create a full version string
# usage: function <version_tag>
# outputs full version string to stdout
function ndr_ConstructLocalGitRepoImageVersionString ()
{
  local logSectionDesc="Constructing Image Version String"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <version_tag>"
    return 1
  fi

  local versionTag="$1"
  local fullVersionName=""
  local updateinfo=false
  # query for local git hash and timestamp values and update if newer
  
  local timestamp=$(git show -s --format=%ct 2>/dev/null)
  return_code=$?
  if [[ $return_code -ne 0 || -z "$timestamp" ]]; then
    ndr_logWarn "Unable to retrieve git commit timestamp."
    return 1
  fi

  if [[ "$timestamp" -gt "$NDR_GIT_REPO_COMMIT_TIMESTAMP" ]]; then
    ndr_logInfo "Found git local commit timestamp [$timestamp] newer than script version [$NDR_GIT_REPO_COMMIT_TIMESTAMP], updating."
    NDR_GIT_REPO_COMMIT_TIMESTAMP="$timestamp"
    updateinfo=true
  elif [[ "$timestamp" -eq "$NDR_GIT_REPO_COMMIT_TIMESTAMP" ]]; then
    ndr_logInfo "Found git local commit timestamp [$timestamp] same as script version [$NDR_GIT_REPO_COMMIT_TIMESTAMP]"
  fi
  
  local commit_hash=$(git rev-parse HEAD 2>/dev/null)
  return_code=$?
  if [[ $return_code -ne 0 || -z "$commit_hash" ]]; then
    ndr_logWarn "Unable to retrieve git commit hash."
    return 1
  fi
  
  if [ "$updateinfo" == true ]; then
    ndr_logInfo "Updating git commit hash [$NDR_GIT_REPO_COMMIT_HASH] to latest [$commit_hash]"
    NDR_GIT_REPO_COMMIT_HASH="$commit_hash"
    NDR_GIT_REPO_COMMIT_HASH_SHORT=$(echo "$NDR_GIT_REPO_COMMIT_HASH" | cut -c1-7)
  fi

  if [[ -z "$NDR_GIT_REPO_COMMIT_HASH" || -z "$NDR_GIT_REPO_COMMIT_HASH_SHORT" || -z "$NDR_GIT_REPO_COMMIT_TIMESTAMP" ]]; then
    ndr_logWarn "Invalid git commit hashes."
    return 1
  fi

  fullVersionName="${versionTag}-${NDR_GIT_REPO_COMMIT_HASH_SHORT}-${NDR_GIT_REPO_COMMIT_TIMESTAMP}"
  ndr_logDebug "Built full image name [$fullVersionName]"

  ndr_logSecEndDebug "$logSectionDesc"

  echo "$fullVersionName"
  return 0
}

# Given a running container name, performs a docker query to retrieve the image name it was started from
# usage: function <container_name>
# returns image name to stdout, eg "nextdr-ui-img:1.0.0-e373a98-1757443381"
function ndr_QueryContainerImageName ()
{
  local logSectionDesc="Querying Container Image Name"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <container_name>"
    return 1
  fi

  local dockerContainerName="$1"

  ndr_verifyDockerContainerExists "$dockerContainerName"
  return_code=$?
  # 2-error, 1-not found, 0-found
  if [[ $return_code -ne 0 ]]; then
    ndr_logWarn "Docker container [$dockerContainerName] does not exist."
    return 1
  fi

  local dockerImageName=$(docker inspect --format '{{.Config.Image}}' "$dockerContainerName" 2>/dev/null)
  return_code=$?
  if [[ $return_code -ne 0 || -z "$dockerImageName" ]]; then
    ndr_logError "Failed to retrieve image name for container [$dockerContainerName]."
    return 1
  fi

  ndr_logDebug "Found image name [$dockerImageName] for container [$dockerContainerName]"

  ndr_logSecEndDebug "$logSectionDesc"

  echo "$dockerImageName"
  return 0
}

# Given a running container name, performs a docker query to retrieve the image version tag of the full image name it was started from
# usage: function <container_name>
# returns image name to stdout, eg "1.0.0-e373a98-1757443381"
function ndr_QueryContainerImageVersionTag ()
{
  local logSectionDesc="Querying Container Image Version Tag"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <container_name>"
    return 1
  fi

  local dockerContainerName="$1"

  local dockerImageName=$(ndr_QueryContainerImageName "$dockerContainerName")
  return_code=$?
  if [[ $return_code -ne 0 || -z "$dockerImageName" ]]; then
    ndr_logError "Failed to retrieve image name for container [$dockerContainerName]."
    return 1
  fi
  
  local dockerImageTag="${dockerImageName#*:}"  # remove everything up to and including ':'
  if [[ -z "$dockerImageTag" ]]; then
    ndr_logError "Failed to parse image tag from image name [$dockerImageName]."
    return 1
  fi

  ndr_logDebug "Found image tag [$dockerImageTag] from image name [$dockerImageName] for container [$dockerContainerName]"

  ndr_logSecEndDebug "$logSectionDesc"

  echo "$dockerImageTag"
  return 0
}

# usage: function <image_tag>
# returns version tag to stdout
function ndr_ParseImageTagVersion ()
{
  local logSectionDesc="Parsing Image Tag Version"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <image_tag>"
    return 1
  fi

  local imageTag="$1"

  # full format is: <version>-<git_hash>-<timestamp>
  # example: 1.2.0-e373a98-1757443381
  local imageVersion="${imageTag%%-*}"   # remove everything after the first '-'
  if [[ -z "$imageVersion" ]]; then
    ndr_logError "Failed to parse version from image tag [$imageTag]."
    return 1
  fi

  ndr_logDebug "Found version [$imageVersion] from image tag [$imageTag]"

  ndr_logSecEndDebug "$logSectionDesc"

  echo "$imageVersion"
  return 0
}

# usage: function <container_name>
# returns version to stdout
function ndr_QueryContainerImageVersion ()
{
  local logSectionDesc="Querying Container Image Version"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <container_name>"
    return 1
  fi

  local dockerContainerName="$1"

  ndr_verifyDockerContainerExists "$dockerContainerName"
  return_code=$?
  #2-error, 1-not found, 0-found
  if [[ $return_code -ne 0 ]]; then
    ndr_logWarn "Docker container [$dockerContainerName] does not exist."
    return 1
  fi

  local dockerImageTag=$(ndr_QueryContainerImageVersionTag "$dockerContainerName")
  return_code=$?
  if [[ $return_code -ne 0 || -z "$dockerImageTag" ]]; then
    ndr_logError "Failed to retrieve image name for container [$dockerContainerName]."
    return 1
  fi

  local imageVersion=$(ndr_ParseImageTagVersion "$dockerImageTag")
  if [[ -z "$imageVersion" ]]; then
    ndr_logError "Failed to parse version from image tag [$dockerImageTag]."
    return 1
  fi

  ndr_logDebug "Found version [$imageVersion] from image name [$dockerImageTag] for container [$dockerContainerName]"

  ndr_logSecEndDebug "$logSectionDesc"

  echo "$imageVersion"
}

# usage: function <image_tag>
# returns commit hash to stdout
function ndr_ParseImageTagCommitHash ()
{
  local logSectionDesc="Parsing Image Tag Commit Hash"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <image_tag>"
    return 1
  fi

  local imageTag="$1"

  # full format is: <version>-<git_hash>-<timestamp>
  # example: 1.2.0-e373a98-1757443381
  local imageCommitHash=$(echo "$imageTag" | awk -F '[-:]' '{print $(NF-1)}')
  if [[ -z "$imageCommitHash" ]]; then
    ndr_logError "Failed to parse commit hash from image tag [$imageTag]."
    return 1
  fi

  # Ensure the parsed commit hash is exactly 7 characters (short git SHA)
  if [[ ${#imageCommitHash} -ne 7 ]]; then
    ndr_logError "Parsed commit hash [$imageCommitHash] is not 7 characters long from image tag [$imageTag]."
    return 1
  fi

  ndr_logDebug "Found commit hash [$imageCommitHash] from image tag [$imageTag]"

  ndr_logSecEndDebug "$logSectionDesc"

  echo "$imageCommitHash"
  return 0
}

# Given a running container name, performs a docker query to retrieve the image name it was started from, parses out the git commit hash portion of the image tag
# usage: function <container_name>
# returns commit hash to stdout
function ndr_QueryContainerImageCommitHash ()
{
  local logSectionDesc="Querying Container Image Commit Hash"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <image_name>"
    return 1
  fi

  local dockerContainerName="$1"

  ndr_verifyDockerContainerExists "$dockerContainerName"
  return_code=$?
  #2-error, 1-not found, 0-found
  if [[ $return_code -ne 0 ]]; then
    ndr_logWarn "Docker container [$dockerContainerName] does not exist."
    return 1
  fi

  local dockerImageTag=$(ndr_QueryContainerImageVersionTag "$dockerContainerName")
  return_code=$?
  if [[ $return_code -ne 0 || -z "$dockerImageTag" ]]; then
    ndr_logError "Failed to retrieve image name for container [$dockerContainerName]."
    return 1
  fi

  local imageCommitHash=$(ndr_ParseImageTagCommitHash "$dockerImageTag")
  if [[ -z "$imageCommitHash" ]]; then
    ndr_logError "Failed to parse commit hash from image name [$dockerImageTag]."
    return 1
  fi

  # Ensure the parsed commit hash is exactly 7 characters (short git SHA)
  if [[ ${#imageCommitHash} -ne 7 ]]; then
    ndr_logError "Parsed commit hash [$imageCommitHash] is not 7 characters long from image name [$dockerImageTag]."
    return 1
  fi

  ndr_logDebug "Found commit hash [$imageCommitHash] from image name [$dockerImageTag] for container [$dockerContainerName]"

  ndr_logSecEndDebug "$logSectionDesc"

  echo "$imageCommitHash"
  return 0
}

function ndr_ParseImageTagTimestamp ()
{
  local logSectionDesc="Parsing Image Tag Timestamp"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <image_tag>"
    return 1
  fi

  local imageTag="$1"

  # full format is: <version>-<git_hash>-<timestamp>
  # example: 1.2.0-e373a98-1757443381
  local imageTimestamp=$(echo "$imageTag" | awk -F '[-:]' '{print $NF}')
  if [[ -z "$imageTimestamp" ]]; then
    ndr_logError "Failed to parse timestamp from image tag [$imageTag]."
    return 1
  fi

  # Ensure the parsed timestamp looks like an epoch time (10 digits = seconds, 13 digits = milliseconds)
  if ! [[ "$imageTimestamp" =~ ^[0-9]{10}$ || "$imageTimestamp" =~ ^[0-9]{13}$ ]]; then
    ndr_logError "Parsed timestamp [$imageTimestamp] is not a valid epoch time (expected 10 or 13 digit numeric) from image tag [$imageTag]."
    return 1
  fi

  ndr_logDebug "Found timestamp [$imageTimestamp] from image tag [$imageTag]"

  ndr_logSecEndDebug "$logSectionDesc"

  echo "$imageTimestamp"
  return 0
}

# given a running container name, performs a docker query to retrieve the image name it was started from, parses out the timestamp portion of the image tag
# usage: function <container_name> 
# returns timestamp to stdout
function ndr_QueryContainerImageTimestampUTC ()
{
  local logSectionDesc="Querying Container Image Timestamp UTC"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <image_name>"
    return 1
  fi

  local dockerContainerName="$1"

  ndr_verifyDockerContainerExists "$dockerContainerName"
  return_code=$?
  #2-error, 1-not found, 0-found
  if [[ $return_code -ne 0 ]]; then
    ndr_logWarn "Docker container [$dockerContainerName] does not exist."
    return 1
  fi

  local dockerImageTag=$(ndr_QueryContainerImageVersionTag "$dockerContainerName")
  return_code=$?
  if [[ $return_code -ne 0 || -z "$dockerImageTag" ]]; then
    ndr_logError "Failed to retrieve image tag for container [$dockerContainerName]."
    return 1
  fi

  local imageTimestamp=$(ndr_ParseImageTagTimestamp "$dockerImageTag")
  if [[ -z "$imageTimestamp" ]]; then
    ndr_logError "Failed to parse timestamp from image tag [$dockerImageTag]."
    return 1
  fi

  ndr_logDebug "Found timestamp [$imageTimestamp] from image tag [$dockerImageTag] for container [$dockerContainerName]"

  ndr_logSecEndDebug "$logSectionDesc"

  echo "$imageTimestamp"
  return 0
}

# given a running container name, performs a docker query to retrieve the image name it was started from, parses out the timestamp portion of the image tag, converts to human readable format
# usage: function <container_name>
# returns human readable timestamp to stdout
function ndr_QueryContainerImageTimestampHumanReadable ()
{
  local logSectionDesc="Querying Container Image Timestamp Human Readable"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <image_name>"
    return 1
  fi

  local dockerContainerName="$1"

  ndr_verifyDockerContainerExists "$dockerContainerName"
  return_code=$?
  #2-error, 1-not found, 0-found
  if [[ $return_code -ne 0 ]]; then
    ndr_logWarn "Docker container [$dockerContainerName] does not exist."
    return 1
  fi

  local imageTimestampUTC
  imageTimestampUTC=$(ndr_QueryContainerImageTimestampUTC "$dockerContainerName")
  return_code=$?
  if [[ $return_code -ne 0 || -z "$imageTimestampUTC" ]]; then
    ndr_logError "Failed to retrieve image timestamp for container [$dockerContainerName]."
    return 1
  fi

  local imageTimestampHuman
  #imageTimestampHuman=$(date -u -d @"$imageTimestampUTC" +"%Y-%m-%d %H:%M:%S UTC")
  imageTimestampHuman=$(date -u -d @"$imageTimestampUTC" +"%Y-%m-%d")
  return_code=$?
  if [[ $return_code -ne 0 || -z "$imageTimestampHuman" ]]; then
    ndr_logError "Failed to convert timestamp [$imageTimestampUTC] to human readable format."
    return 1
  fi

  ndr_logDebug "Converted timestamp [$imageTimestampUTC] to human readable format [$imageTimestampHuman] for container [$dockerContainerName]"

  ndr_logSecEndDebug "$logSectionDesc"

  echo "$imageTimestampHuman"
  return 0
}

function ndr_QueryLatestMatchingLocalImage ()
{
  local logSectionDesc="Querying Latest Matching Image"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <image_name_pattern>"
    return 1
  fi

  local imageNamePattern="$1"

  ndr_logInfo "Searching for images matching pattern [$imageNamePattern]"
  
  mapfile -t matchingImages < <(docker images --format "{{.Repository}}:{{.Tag}}" | grep "$imageNamePattern")

  ndr_logInfo "Found ${#matchingImages[@]} matching image [$imageNamePattern]"

  if [[ ${#matchingImages[@]} -eq 0 ]]; then
    ndr_logWarn "No images found matching pattern [$imageNamePattern]"
    return 0
  fi

  # loop through each image, parse out the timestamp and determine the latest
  local latestImage=""
  local latestTimestamp=0
  for image_name in "${matchingImages[@]}"; do
    ndr_logInfo "Parsing image [$image_name]..."
    
    local imgTimestamp=$(ndr_ParseImageTagTimestamp "$image_name" 2>/dev/null)
    if [[ -z "$imgTimestamp" ]]; then
      ndr_logWarn "Failed to parse timestamp from image name [$image_name], skipping."
      continue
    fi

    # Compare timestamps and update latestImage if this one is newer
    if (( imgTimestamp > latestTimestamp )); then
      latestImage="$image_name"
      latestTimestamp="$imgTimestamp"
    fi
  done

  ndr_logInfo "Latest image matching pattern [$imageNamePattern] is [$latestImage] with timestamp [$latestTimestamp]"

  ndr_logSecEnd "$logSectionDesc"

  echo "$latestImage"
  return 0
}

function ndr_QueryFullImageString ()
{
  local logSectionDesc="Querying Full Image String"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -ne 2 ]]; then
    ndr_logError "Usage: function <image_name> <image_version>"
    return 1
  fi

  local dockerImageBaseName="$1"
  local dockerImageVersion="$2"
  local dockerImageName="${dockerImageBaseName}:${dockerImageVersion}"
  #+++ incomplete
  ndr_logInfo "Full image string is [$dockerImageName]"

  ndr_logSecEnd "$logSectionDesc"

  echo "$dockerImageName"
  return 0
}

# Queries for the latest remote image tags from a specified repo matching an optional image name and updates the associated globals for those images.
# If no image name supplied, queries all image repos.
# usage: function <image_base_name>
function ndr_QueryLatestMatchingRemoteImageTags ()
{
  local logSectionDesc="Querying Latest Matching Remote Image Tags"

  ndr_logSecStart "$logSectionDesc"

  local search_image_name="${1:-}"
  local user_or_org="$NDR_DOCKER_REPO_ACCOUNT"
  local repo=""
  local image_version="$gPRODUCT_VERSION"

  if [ "$gNDR_SKIP_REMOTE_IMAGE_REPO_UPDATE_CHECK" == true ]; then
    ndr_logInfo "Skipping remote Docker repo image tag check per override."
    return 0
  fi

  if [ "$NDR_DOCKER_REMOTE_REPO_QUERIED" == true ]; then
    ndr_logInfo "Already queried remote Docker repo for latest image tags."
    return 0
  fi

  local svcRepo="$NDR_DOCKER_SERVICE_PUBLIC_REPO_NAME"
  local uiRepo="$NDR_DOCKER_UI_PUBLIC_REPO_NAME"
  if [[ "$NDR_DOCKER_REPO_TYPE_CURRENT" == "$NDR_DOCKER_REPO_TYPE_PRIVATE" ]]; then  
    svcRepo="$NDR_DOCKER_SERVICE_PRIVATE_REPO_NAME"
    uiRepo="$NDR_DOCKER_UI_PRIVATE_REPO_NAME"
  fi

  declare -A mapImagesAndRepos=()
  if [ -n "$search_image_name" ]; then
    if [[ "$search_image_name" == "$NDR_SERVICE_IMAGE_NAME" ]]; then
      mapImagesAndRepos["$NDR_SERVICE_IMAGE_NAME"]="$svcRepo"
    elif [[ "$search_image_name" == "$NDR_UI_IMAGE_NAME" ]]; then
      mapImagesAndRepos["$NDR_UI_IMAGE_NAME"]="$uiRepo"
    else
      ndr_logWarn "Invalid image name [$search_image_name]"
    fi
  else
    mapImagesAndRepos["$NDR_SERVICE_IMAGE_NAME"]="$svcRepo"
    mapImagesAndRepos["$NDR_UI_IMAGE_NAME"]="$uiRepo"
  fi

  local retVal=0
  for image_name in "${!mapImagesAndRepos[@]}"; do
    repo="${mapImagesAndRepos[$image_name]}"
    #image_version="${NDR_VERSION_MAJOR}.${NDR_VERSION_MINOR}.${NDR_VERSION_PATCH}"
    ndr_logInfo "Searching for latest remote image for [$image_name:$image_version] in repo [$user_or_org/$repo]"
    
    local latest_tag=$(ndr_QueryLatestMatchingRemoteImageTag "$user_or_org" "$repo" "$image_name" "$image_version")
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logWarn "No matching remote image found for [$image_name:$image_version] in repo [$user_or_org/$repo]"
      retVal=1
      continue
    fi

    ndr_logDebug "Latest remote image for [$image_name:$image_version] is [$user_or_org/$repo:$latest_tag]"

    # parse out the git commit hash from the tag
    local commit_hash=$(ndr_ParseImageTagCommitHash "$latest_tag")
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logWarn "Failed to parse commit hash from tag [$latest_tag] for image [$image_name]"
      retVal=1
      continue
    fi

    # parse out the timestamp from the tag
    local timestamp=$(ndr_ParseImageTagTimestamp "$latest_tag")
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logWarn "Failed to parse timestamp from tag [$latest_tag] for image [$image_name]"
      retVal=1
      continue
    fi

    ndr_logDebug "Latest remote image for [$image_name:$image_version] has commit hash [$commit_hash] and timestamp [$timestamp]"

    # populate global variables
    local version_tag="${latest_tag#*_}"
    if [[ "$image_name" == "$NDR_SERVICE_IMAGE_NAME" ]]; then
      # To update globals, image version must match expected product version and timestamp must be newer than current
      if [[ "$image_version" == "$NDR_SERVICE_IMAGE_VERSION" && "$timestamp" -le "$NDR_SERVICE_IMAGE_COMMIT_TIMESTAMP_UTC" ]]; then
        ndr_logInfo "Service image tag reference version/timestamp [$NDR_SERVICE_IMAGE_VERSION_TAG] newer or equal to latest remote repo [$version_tag], skipping update."
        continue
      fi

      NDR_SERVICE_IMAGE_VERSION="$image_version"
      NDR_SERVICE_IMAGE_VERSION_TAG="$version_tag"
      NDR_SERVICE_IMAGE_COMMIT_HASH_SHORT="$commit_hash"
      NDR_SERVICE_IMAGE_COMMIT_TIMESTAMP_UTC="$timestamp"

      ndr_logInfo "Updated service image version to [$NDR_SERVICE_IMAGE_VERSION], tag to [$NDR_SERVICE_IMAGE_VERSION_TAG], commit hash to [$NDR_SERVICE_IMAGE_COMMIT_HASH_SHORT], timestamp to [$NDR_SERVICE_IMAGE_COMMIT_TIMESTAMP_UTC]"
    elif [[ "$image_name" == "$NDR_UI_IMAGE_NAME" ]]; then
      # To update globals, image version must match expected product version and timestamp must be newer than current
      if [[ "$image_version" == "$NDR_UI_IMAGE_VERSION" && "$timestamp" -le "$NDR_UI_IMAGE_COMMIT_TIMESTAMP_UTC" ]]; then
        ndr_logInfo "UI image tag reference version/timestamp [$NDR_UI_IMAGE_VERSION_TAG] newer or equal to latest remote repo [$version_tag], skipping update."
        continue
      fi

      NDR_UI_IMAGE_VERSION="$image_version"
      NDR_UI_IMAGE_VERSION_TAG="$version_tag"
      NDR_UI_IMAGE_COMMIT_HASH_SHORT="$commit_hash"
      NDR_UI_IMAGE_COMMIT_TIMESTAMP_UTC="$timestamp"

      ndr_logInfo "Updated UI image version to [$NDR_UI_IMAGE_VERSION], tag to [$NDR_UI_IMAGE_VERSION_TAG], commit hash to [$NDR_UI_IMAGE_COMMIT_HASH_SHORT], timestamp to [$NDR_UI_IMAGE_COMMIT_TIMESTAMP_UTC]"
    else
      ndr_logWarn "Invalid image name [$image_name]"
      continue
    fi

  done

  if [ $retVal -ne 0 ]; then
    ndr_logWarn "One or more images not found in repo."
  else
    ndr_logInfo "All images found in repo."
    # upldate the repo queried flag ONLY if we queried all repo's (not specific single repo)
    if [ -z "$search_image_name" ]; then
      NDR_DOCKER_REMOTE_REPO_QUERIED=true
      ndr_logInfo "All repo's queried, marking queried flag true."
    fi
  fi

  ndr_logSecEnd "$logSectionDesc"

  return "$retVal"
}

# for a given user/org, repo, image name and version prefix, queries the remote docker repo for tags matching the pattern <image_name>_<image_version>-<git_hash>-<timestamp>
function ndr_QueryLatestMatchingRemoteImageTag ()
{
  local logSectionDesc="Querying Latest Matching Remote Image Tag"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -ne 4 ]]; then
    ndr_logError "Usage: function <user> <repo_name> <image_name> <image_version>"
    return 1
  fi

  local user_or_org="$1"
  local repo="$2"
  local image_name="$3"
  local image_version="$4"

  ndr_logInfo "Searching for remote images matching pattern [$image_name:$image_version] in repo [$user_or_org/$repo]"

  local config_token=""
  local auth_header=""
  local token=""
  local response=""
  
  if [[ "$NDR_DOCKER_REPO_TYPE_CURRENT" == "$NDR_DOCKER_REPO_TYPE_PRIVATE" ]]; then  
    # docker remote repo login
    ndr_DockerRemoteRepoLogin
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Docker login failed for [$NDR_DOCKER_REPO_ACCOUNT]."
      return 1
    fi

    # Try to read Docker login token (for private repos)
    if [ -f "$HOME/.docker/config.json" ]; then
      config_token=$(jq -r '.auths["https://index.docker.io/v1/"].auth' "$HOME/.docker/config.json" 2>/dev/null)
      if [ "$config_token" != "null" ] && [ -n "$config_token" ]; then
        local creds user pass
        creds=$(echo "$config_token" | base64 --decode)
        user="${creds%%:*}"
        pass="${creds#*:}"
        token=$(curl -s -H "Content-Type: application/json" -X POST \
          -d "{\"username\":\"${user}\",\"password\":\"${pass}\"}" \
          https://hub.docker.com/v2/users/login/ | jq -r .token)
        if [ "$token" != "null" ] && [ -n "$token" ]; then
          auth_header="Authorization: JWT ${token}"
        fi
      fi
    fi
  fi

  # Fetch tags (no pagination)
  response=$(curl -s ${auth_header:+-H "$auth_header"} \
    "https://hub.docker.com/v2/repositories/${user_or_org}/${repo}/tags/")

  #ndr_logDebug "Response: $response"
  
  mapfile -t tags < <(jq -r '.results[].name' <<< "$response")
  ndr_logInfo "Found ${#tags[@]} unfiltered tags in repo ${user_or_org}/${repo}"

  # Parse and find latest timestamp
  local search_tag="${image_name}_${image_version}"
  declare -A tag_ts_map
  for tag in "${tags[@]}"; do
    if [[ "$tag" =~ ^${search_tag}-[[:alnum:]]+-([0-9]+)$ ]]; then
      ts="${BASH_REMATCH[1]}"
      tag_ts_map["$tag"]="$ts"
      ndr_logDebug "Matched tag: $tag with timestamp: $ts"
    fi
  done

  local latest_tag=""
  local latest_ts=0
  for tag in "${!tag_ts_map[@]}"; do
    ts="${tag_ts_map[$tag]}"
    if (( ts > latest_ts )); then
      latest_ts=$ts
      latest_tag="$tag"
    fi
  done

  local retVal=0
  if [ -n "$latest_tag" ]; then
    ndr_logInfo "Found latest tag: ${user_or_org}/${repo}:${latest_tag}"
  else
    ndr_logError "No matching tags found for version prefix '$search_tag'"
    retVal=1
  fi

  ndr_logSecEnd "$logSectionDesc"

  if [ $retVal -eq 0 ]; then
    echo "$latest_tag"
  fi
  return "$retVal"
}

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ndr_logWarn "This is a bash module--there is no direct execution capabilities in this file."
  exit 0
fi
