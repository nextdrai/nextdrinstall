#!/bin/bash
# ndrInterface.sh - A Bash module providing UI/menu definitions and functions

#source "$(dirname "${BASH_SOURCE[0]}")/ndrCommon.sh"
source "$(dirname "${BASH_SOURCE[0]}")/ndrSupabase.sh"
source "$(dirname "${BASH_SOURCE[0]}")/ndrRegistry.sh"

# docker container and image module menu status definitions
export gCLI_MENU_IMAGE_STATUS_NOT_PRESENT="No image"
export gCLI_MENU_IMAGE_STATUS_PRESENT="Present"

export gCLI_MENU_CONTAINER_STATUS_NOT_PRESENT="No container"
export gCLI_MENU_CONTAINER_STATUS_PRESENT="Present"
export gCLI_MENU_CONTAINER_STATUS_RUNNING="Running"
export gCLI_MENU_CONTAINER_STATUS_STOPPED="Stopped"

# docker module status
export gCLI_MODULE_DOCKER_IMAGE_STATUS_DB="$gCLI_MENU_IMAGE_STATUS_NOT_PRESENT"
export  gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC="$gCLI_MENU_IMAGE_STATUS_NOT_PRESENT"
export  gCLI_MODULE_DOCKER_IMAGE_STATUS_UI="$gCLI_MENU_IMAGE_STATUS_NOT_PRESENT"

export  gCLI_MODULE_DOCKER_CONTAINER_STATUS_DB="$gCLI_MENU_CONTAINER_STATUS_NOT_PRESENT"
export  gCLI_MODULE_DOCKER_CONTAINER_STATUS_SVC="$gCLI_MENU_CONTAINER_STATUS_NOT_PRESENT"
export  gCLI_MODULE_DOCKER_CONTAINER_STATUS_UI="$gCLI_MENU_CONTAINER_STATUS_NOT_PRESENT"

# installed module menu status defintions
export gCLI_MENU_INSTALL_STATUS_INSTALLED="Installed"
export gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED="Not Installed"

# installed module status
export gCLI_MODULE_INSTALL_STATUS_DB="$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED"
export gCLI_MODULE_INSTALL_STATUS_SVC="$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED"
export gCLI_MODULE_INSTALL_STATUS_UI="$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED"

# misc status items
export gCLI_NDR_INSTALLED_VERSION="$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED"
export gCLI_NDR_HOST_ADDRESS="$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED"

# updates the status of all docker modules
function ndr_UpdateModuleDockerStatus ()
{
  # Supabase ------------------------------
  #gCLI_MODULE_DOCKER_IMAGE_STATUS_DB=$(if ndr_verifyDockerImageExists "$NDR_SUPABASE_APP_SERVICE_NAME_DB_IMAGE_NAME" >/dev/null; then echo "$gCLI_MENU_IMAGE_STATUS_PRESENT"; fi)
  gCLI_MODULE_DOCKER_IMAGE_STATUS_DB="$gCLI_MENU_IMAGE_STATUS_NOT_PRESENT"
  if ndr_verifyDockerImageExists "$NDR_SUPABASE_APP_SERVICE_NAME_DB_IMAGE_NAME" >/dev/null; then gCLI_MODULE_DOCKER_IMAGE_STATUS_DB="$NDR_SUPABASE_APP_SERVICE_NAME_DB_IMAGE_NAME | $gCLI_MENU_IMAGE_STATUS_PRESENT"; fi

  #gCLI_MODULE_DOCKER_CONTAINER_STATUS_DB=$(if ndr_verifyDockerContainerExists "$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME" >/dev/null; then echo "$gCLI_MENU_CONTAINER_STATUS_PRESENT"; fi)
  if ndr_verifyDockerContainerExists "$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME" >/dev/null; then
    # build container status
    gCLI_MODULE_DOCKER_CONTAINER_STATUS_DB="$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME"
    #local supabaseContainerRunning=$(if ndr_verifyDockerContainerRunning "$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME" >/dev/null; then echo "$gCLI_MENU_CONTAINER_STATUS_RUNNING"; fi)
    if ndr_verifyDockerContainerRunning "$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME" >/dev/null; then gCLI_MODULE_DOCKER_CONTAINER_STATUS_DB="$gCLI_MODULE_DOCKER_CONTAINER_STATUS_DB | $gCLI_MENU_CONTAINER_STATUS_RUNNING"; else gCLI_MODULE_DOCKER_CONTAINER_STATUS_DB="$gCLI_MODULE_DOCKER_CONTAINER_STATUS_DB | $gCLI_MENU_CONTAINER_STATUS_STOPPED"; fi
  fi
  
  # Service -------------------------------
  # query image details first. init image name with local repo tag.
  #gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC="$gCLI_MENU_IMAGE_STATUS_NOT_PRESENT"
  local imageVersionTag=$(ndr_ConstructLocalGitRepoImageVersionString "$NDR_SERVICE_IMAGE_VERSION")
  local imageName="$NDR_SERVICE_IMAGE_NAME:$imageVersionTag"
  if ndr_verifyDockerImageExists "$imageName" >/dev/null; then gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC="$imageName"; fi

  # query container details second, if container exists, override image name with actual image name used by container.
  #gCLI_MODULE_DOCKER_CONTAINER_STATUS_SVC="$NDR_CONTAINER_STATUS_NOT_PRESENT"
  if ndr_verifyDockerContainerExists "$NDR_SERVICE_CONTAINER_NAME" >/dev/null; then
    # build container status
    gCLI_MODULE_DOCKER_CONTAINER_STATUS_SVC="$NDR_SERVICE_CONTAINER_NAME | $gCLI_MENU_CONTAINER_STATUS_PRESENT"
    if ndr_verifyDockerContainerRunning "$NDR_SERVICE_CONTAINER_NAME" "$NDR_SERVICE_CONTAINER_PORT" >/dev/null; then 
      gCLI_MODULE_DOCKER_CONTAINER_STATUS_SVC="$gCLI_MODULE_DOCKER_CONTAINER_STATUS_SVC | $gCLI_MENU_CONTAINER_STATUS_RUNNING"; 
    else 
      gCLI_MODULE_DOCKER_CONTAINER_STATUS_SVC="$gCLI_MODULE_DOCKER_CONTAINER_STATUS_SVC | $gCLI_MENU_CONTAINER_STATUS_STOPPED"; 
    fi
    
    # rebuild image status
    gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC=$(ndr_QueryContainerImageName "$NDR_SERVICE_CONTAINER_NAME")
    local commitHash=$(ndr_QueryContainerImageCommitHash "$NDR_SERVICE_CONTAINER_NAME")
    if [[ -n "$commitHash" ]]; then gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC="$gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC | Commit: $commitHash"; fi
    local timestampUTC=$(ndr_QueryContainerImageTimestampHumanReadable "$NDR_SERVICE_CONTAINER_NAME")
    if [[ -n "$timestampUTC" ]]; then gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC="$gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC | Built: $timestampUTC"; fi
  fi
  
  # UI -----------------------------------
  # query image details first. init image name with local repo tag.
  #local gCLI_MODULE_DOCKER_IMAGE_STATUS_UI="$gCLI_MENU_IMAGE_STATUS_NOT_PRESENT"
  imageVersionTag=$(ndr_ConstructLocalGitRepoImageVersionString "$NDR_UI_IMAGE_VERSION")
  imageName="$NDR_UI_IMAGE_NAME:$imageVersionTag"
  if ndr_verifyDockerImageExists "$imageName" >/dev/null; then gCLI_MODULE_DOCKER_IMAGE_STATUS_UI="$imageName"; fi
  
  # query container details second, if container exists, override image name with actual image name used by container.
  local gCLI_MODULE_DOCKER_CONTAINER_STATUS_UI="$NDR_CONTAINER_STATUS_NOT_PRESENT"
  if ndr_verifyDockerContainerExists "$NDR_UI_CONTAINER_NAME" >/dev/null; then
    # build container status
    gCLI_MODULE_DOCKER_CONTAINER_STATUS_UI="$NDR_UI_CONTAINER_NAME | $gCLI_MENU_CONTAINER_STATUS_PRESENT"
    if ndr_verifyDockerContainerRunning "$NDR_UI_CONTAINER_NAME" "$NDR_UI_CONTAINER_PORT" >/dev/null; then 
      gCLI_MODULE_DOCKER_CONTAINER_STATUS_UI="$gCLI_MODULE_DOCKER_CONTAINER_STATUS_UI | $gCLI_MENU_CONTAINER_STATUS_RUNNING"; 
    else
      gCLI_MODULE_DOCKER_CONTAINER_STATUS_UI="$gCLI_MODULE_DOCKER_CONTAINER_STATUS_UI | $gCLI_MENU_CONTAINER_STATUS_STOPPED"; 
    fi
    
    # rebuild image status
    gCLI_MODULE_DOCKER_IMAGE_STATUS_UI=$(ndr_QueryContainerImageName "$NDR_UI_CONTAINER_NAME")
    local commitHash=$(ndr_QueryContainerImageCommitHash "$NDR_UI_CONTAINER_NAME")
    if [[ -n "$commitHash" ]]; then gCLI_MODULE_DOCKER_IMAGE_STATUS_UI="$gCLI_MODULE_DOCKER_IMAGE_STATUS_UI | Commit: $commitHash"; fi
    local timestampUTC=$(ndr_QueryContainerImageTimestampHumanReadable "$NDR_UI_CONTAINER_NAME")
    if [[ -n "$timestampUTC" ]]; then gCLI_MODULE_DOCKER_IMAGE_STATUS_UI="$gCLI_MODULE_DOCKER_IMAGE_STATUS_UI | Built: $timestampUTC"; fi
  fi

  return 0
}

function ndr_DisplayModuleDockerStatus ()
{
  echo "Current Docker image/container module status:"
  echo "  Supabase DB module [ Image: $gCLI_MODULE_DOCKER_IMAGE_STATUS_DB ], [ Container: $gCLI_MODULE_DOCKER_CONTAINER_STATUS_DB ]"
  echo "  Service module [ Image: $gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC ], [ Container: $gCLI_MODULE_DOCKER_CONTAINER_STATUS_SVC ]"
  echo "  UI module [ Image: $gCLI_MODULE_DOCKER_IMAGE_STATUS_UI ], [ Container: $gCLI_MODULE_DOCKER_CONTAINER_STATUS_UI ]"

  return 0
}

# updates the status of all installed modules
function ndr_UpdateModuleInstallStatus ()
{
  # only check these reg vars if something is installed and registry exists or else error messages will get printed.
  ndr_RegistryExists
  return_code=$?
  if [ $return_code -eq 1 ]; then
    return 0
  fi
  
  gCLI_MODULE_INSTALL_STATUS_DB=$(version=$(ndr_getModuleVersionReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME") && echo "$gCLI_MENU_INSTALL_STATUS_INSTALLED" || echo "$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED")
  if [ "$gCLI_MODULE_INSTALL_STATUS_DB" == "$gCLI_MENU_INSTALL_STATUS_INSTALLED" ]; then
    local version=$(ndr_getModuleVersionReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME")
    if [[ -n "$version" ]]; then gCLI_MODULE_INSTALL_STATUS_DB="$gCLI_MODULE_INSTALL_STATUS_DB | Version: $version"; fi
  fi
  
  gCLI_MODULE_INSTALL_STATUS_SVC=$(if version=$(ndr_getModuleVersionReg "$gREGISTRY_ENTRY_MODULE_STATUS_SERVICE_NAME"); then echo "$gCLI_MENU_INSTALL_STATUS_INSTALLED"; else echo "$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED"; fi)
  if [ "$gCLI_MODULE_INSTALL_STATUS_SVC" == "$gCLI_MENU_INSTALL_STATUS_INSTALLED" ]; then
    local imageVersion=$(ndr_QueryContainerImageVersion "$NDR_SERVICE_CONTAINER_NAME")
    if [[ -n "$imageVersion" ]]; then gCLI_MODULE_INSTALL_STATUS_SVC="$gCLI_MODULE_INSTALL_STATUS_SVC | Version: $imageVersion"; fi
    local commitHash=$(ndr_QueryContainerImageCommitHash "$NDR_SERVICE_CONTAINER_NAME")
    if [[ -n "$commitHash" ]]; then gCLI_MODULE_INSTALL_STATUS_SVC="$gCLI_MODULE_INSTALL_STATUS_SVC | Commit: $commitHash"; fi
    local timestampUTC=$(ndr_QueryContainerImageTimestampHumanReadable "$NDR_SERVICE_CONTAINER_NAME")
    if [[ -n "$timestampUTC" ]]; then gCLI_MODULE_INSTALL_STATUS_SVC="$gCLI_MODULE_INSTALL_STATUS_SVC | Built: $timestampUTC"; fi
  fi

  gCLI_MODULE_INSTALL_STATUS_UI=$(if version=$(ndr_getModuleVersionReg "$gREGISTRY_ENTRY_MODULE_STATUS_UI_NAME"); then echo "$gCLI_MENU_INSTALL_STATUS_INSTALLED"; else echo "$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED"; fi)
  if [ "$gCLI_MODULE_INSTALL_STATUS_UI" == "$gCLI_MENU_INSTALL_STATUS_INSTALLED" ]; then
    local imageVersion=$(ndr_QueryContainerImageVersion "$NDR_UI_CONTAINER_NAME")
    if [[ -n "$imageVersion" ]]; then gCLI_MODULE_INSTALL_STATUS_UI="$gCLI_MODULE_INSTALL_STATUS_UI | Version: $imageVersion"; fi
    local commitHash=$(ndr_QueryContainerImageCommitHash "$NDR_UI_CONTAINER_NAME")
    if [[ -n "$commitHash" ]]; then gCLI_MODULE_INSTALL_STATUS_UI="$gCLI_MODULE_INSTALL_STATUS_UI | Commit: $commitHash"; fi
    local timestampUTC=$(ndr_QueryContainerImageTimestampHumanReadable "$NDR_UI_CONTAINER_NAME")
    if [[ -n "$timestampUTC" ]]; then gCLI_MODULE_INSTALL_STATUS_UI="$gCLI_MODULE_INSTALL_STATUS_UI | Built: $timestampUTC"; fi
  fi
  
  gCLI_NDR_INSTALLED_VERSION=$(ndr_getVersionReg)
  gCLI_NDR_HOST_ADDRESS=$(ndr_getHostAddressReg)
  
  return 0
}

function ndr_DisplayModuleInstallStatus ()
{
  echo "Current module installation status:"
  echo "  Supabase application [ $gCLI_MODULE_INSTALL_STATUS_DB ]"
  echo "  Service application [ $gCLI_MODULE_INSTALL_STATUS_SVC ]"
  echo "  UI application [ $gCLI_MODULE_INSTALL_STATUS_UI ]"
  #echo "  Installed Product Version [ $gCLI_NDR_INSTALLED_VERSION ]"
  echo "  Host Address [ $gCLI_NDR_HOST_ADDRESS ]"
  return 0
}

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ndr_logWarn "This is a bash module--there is no direct execution capabilities in this file."
  exit 0
fi
