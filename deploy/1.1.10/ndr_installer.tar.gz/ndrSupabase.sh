#!/bin/bash
# shellcheck shell=bash
# ndrSupabase.sh - A Bash module providing common Supabase related functions

source "$(dirname "${BASH_SOURCE[0]}")/ndrDocker.sh"

# global variables
export gMIGRATION_TIMESTAMP=""
export gSUPABASE_MIGRATION_DIR="./supabase/migrations"
export gNDR_REFERENCE_SQL_SCHEMA_FILENAME="NDR-schema.sql"
export gNDR_SUPABASE_DOCKER_PROJECT_NAME="ndr-supabase"
export gNDR_SUPABASE_REMOTE_HOST_URL="aws-0-us-west-1.pooler.supabase.com"

# schema files and options
export gACTIVE_NDR_SQL_SCHEMA_FILE="" # the active schema file to use for installs and upgrades.
export gNDR_SUPABASE_DB_SCHEMA_FILE="" # a user supplied schema file for db restores via --sf argument
export gNDR_SUPABASE_DB_BACKUP_FILE="" # PD_DUMP schema file produced during backup
export gNDR_POSTGRES_EXPORT_SCHEMA_ONLY=false # PG_DUMP option to export only the schema without data
export gNDR_ALLOW_SCHEMA_ERRORS=false # PSQL option to allow schema errors during playback

export gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL="" # the full schema file that represents the currently installed DB schema (typically kept in the install/home folder)
export gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL="" # the full schema file we are upgrading to
export gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF="" # the diff schema file computed from the prod schema and the upgrade schema (or explicitly provided via cmdline option)
export gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF_FILENAME="NDR-schema-diff_v${gPRODUCT_VERSION}_${NDR_GIT_REPO_COMMIT_HASH_SHORT}_$$.sql" # output diff file name
export gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF_FILENAME_SHORT="NDR-schema-diff.sql" # undecorated diff file name to be bundled in the installer archive.
export gNDR_SUPABASE_UPGRADE_SCHEMA_REPLAY_WORK_DIR="" # temp workspace used when downloading replay diff files from the install package manifest.
export gNDR_INSTALL_PACKAGE_MANIFEST_REMOTE_URL="https://raw.githubusercontent.com/nextdrai/nextdrinstall/main/deploy/${gNDR_INSTALL_PACKAGE_MANIFEST_FILENAME}" # public manifest used to resolve incremental schema upgrade paths.
export gNDR_INSTALL_PACKAGE_RELEASES_REMOTE_BASE_URL="https://raw.githubusercontent.com/nextdrai/nextdrinstall/main/deploy" # base url for downloading version-specific schema diff files.
export gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY="" # selected diff upgrade strategy for the current upgrade run.
export gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY_REPLAY="REPLAY" # apply one or more incremental diff files in sequence.
export gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY_DYNAMIC="DYNAMIC" # generate a replacement diff on the fly, then apply it.
declare -ag gNDR_SUPABASE_UPGRADE_DIFF_VERSION_CHAIN=() # ordered schema upgrade hops in the form from|to|release_dir|diff_schema_file.
declare -ag gNDR_SUPABASE_UPGRADE_DIFF_FILE_CHAIN=() # ordered local diff files to apply, index-linked to the version chain.

# supabase versions
export gNDR_SUPABASE_GIT_REPO="supabase/supabase"
export gNDR_SUPABASE_GIT_VERSION_TAG="v1.26.05" # default version tag to use for new installs from https://github.com/supabase/supabase/tags
export gNDR_SUPABASE_GIT_VERSION_TAG_NEXT="" # next version tag after target version tag, used for querying latest commit between the two tags.
export gNDR_SUPABASE_GIT_VERSION_COMMIT_HASH_FULL="484a264a41abf97577f9b984704b4b7ea63492ea"  # commit hash for the target version tag, used for checking out specific version of the repo.
export gNDR_SUPABASE_GIT_VERSION_COMMIT_HASH_SHORT="484a264" # short, 7 char version of the commit hash (commonly used in github and easier to embed in image names and tags)
export gNDR_SUPABASE_GIT_VERSION_ALLOW_COMMIT_HASH_UPDATE=false # option to allow install to query for commits *after* the sealed version tag (but not exceeding the next tag) and use the latest commit available for checkout/install/upgrade.
export gNDR_SUPABASE_GIT_VERSION_ALLOW_TAG_UPDATE=false # option to allow install to query for latest tag after teh sealed version tag and use this for checkout/install/upgrade.
export gNDR_SUPABASE_GIT_VERSION_TAG_UPGRADE=false # flag to indicate if we are upgrading the supabase version (as well as the product version) during this installation. used to conditionally enable or disable certain steps in the upgrade process.

# supabase service upgrade
declare -A gNDR_SUPABASE_SERVICE_UPGRADE=() # associative array to track which services are being upgraded in this run, key is the service name, value is true/false for whether this service is being upgraded or not. this is used to conditionally enable or disable certain steps in the upgrade process for specific services.

# postgres specific service version upgrade options
export gNDR_SUPABASE_POSTGRES_MINOR_VERSION_UPGRADE=false # flag to indicate if the installed postgres minor version is older than the target postgres minor version. eg 15.1 -> 15.3
export gNDR_SUPABASE_POSTGRES_MAJOR_VERSION_UPGRADE=false # flag to indicate if the installed postgres major version is older than the target postgres major version. eg 15.x -> 16.x
export gNDR_SUPABASE_ALLOW_POSTGRES_MAJOR_VERSION_UPGRADE=false # flag to control whether the overall upgrade process will support postgres major upgrades, which typically require more involved upgrade processes. if false, then the installer will block any upgrade that involves a postgres major version upgrade
export gNDR_SUPABASE_USE_LATEST_POSTGRES_IMAGE=false # flag to enable whether we use the postgres image in the default supabase docker compose (eg. docker-compose.yml) or we use a helper compose (docker-compose-pg17.yml) with an updated, alternate image version.

# supabase command variables
export gSUPABASE_CLI_CMD="sudo npx supabase"
export gSUPABASE_NEXTDR_SUB="supabase"
export gSUPABASE_NEXTDR_HOME=""
export gSUPABASE_TEMPLATE_SUB="supabase_template"
export gSUPABASE_TEMPLATE_HOME=""
export gSUPABASE_REMOTE_TOKEN="" #SECRETS
export gSUPABASE_REMOTE_PROJECT_REFERENCE="" #SECRETS
export gSUPABASE_REMOTE_PASSWORD="" #SECRETS

# supabase env var entries
declare -A gSUPABASE_ENV_VARS=()

# Access to Dashboard
export gSUPABASE_ENV_KEY_DASHBOARD_USERNAME="DASHBOARD_USERNAME"
export gSUPABASE_ENV_VAL_DASHBOARD_USERNAME="supabase"

export gSUPABASE_ENV_KEY_DASHBOARD_PASSWORD="DASHBOARD_PASSWORD"
export gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD="nextdr12345" # default dashboard password, will be randomized during install or upgrade for new installs or if the user opts to reset the dashboard password during upgrade.
export gSUPABASE_DASHBOARD_PASSWORD_LENGTH=16

# Legacy symmetric HS256 key
export gSUPABASE_ENV_KEY_JWT_SECRET="JWT_SECRET"
export gSUPABASE_ENV_VAL_JWT_SECRET=""

# Legacy API keys (HS256-signed JWTs)
export gSUPABASE_ENV_KEY_ANON_KEY="ANON_KEY"
export gSUPABASE_ENV_VAL_ANON_KEY=""

export gSUPABASE_ENV_KEY_SERVICE_ROLE_KEY="SERVICE_ROLE_KEY"
export gSUPABASE_ENV_VAL_SERVICE_ROLE_KEY=""

# Used by Supavisor
export gSUPABASE_ENV_KEY_VAULT_ENC_KEY="VAULT_ENC_KEY"
export gSUPABASE_ENV_VAL_VAULT_ENC_KEY=""

export gSUPABASE_ENV_KEY_POOLER_TENANT_ID="POOLER_TENANT_ID"
export gSUPABASE_ENV_VAL_POOLER_TENANT_ID="ndr-tenant-id-1"

# Used by Realtime and Supavisor
export gSUPABASE_ENV_KEY_SECRET_KEY_BASE="SECRET_KEY_BASE"
export gSUPABASE_ENV_VAL_SECRET_KEY_BASE=""

export gSUPABASE_ENV_KEY_POSTGRES_USER="POSTGRES_USER"
export gSUPABASE_ENV_VAL_POSTGRES_USER=""

export gSUPABASE_ENV_KEY_POSTGRES_PASSWORD="POSTGRES_PASSWORD"
export gSUPABASE_ENV_VAL_POSTGRES_PASSWORD=""

export gSUPABASE_ENV_KEY_POSTGRES_DB="POSTGRES_DB"
export gSUPABASE_ENV_VAL_POSTGRES_DB=""

# Used by Studio to access Postgres via postgres-meta
export gSUPABASE_ENV_KEY_PG_META_CRYPTO_KEY="PG_META_CRYPTO_KEY"
export gSUPABASE_ENV_VAL_PG_META_CRYPTO_KEY=""

# Analytics - API tokens for log ingestion/querying, and for management
export gSUPABASE_ENV_KEY_LOGFLARE_PUBLIC_ACCESS_TOKEN="LOGFLARE_PUBLIC_ACCESS_TOKEN"
export gSUPABASE_ENV_VAL_LOGFLARE_PUBLIC_ACCESS_TOKEN=""

export gSUPABASE_ENV_KEY_LOGFLARE_PRIVATE_ACCESS_TOKEN="LOGFLARE_PRIVATE_ACCESS_TOKEN"
export gSUPABASE_ENV_VAL_LOGFLARE_PRIVATE_ACCESS_TOKEN=""

# Access to Storage via S3 protocol endpoint
export gSUPABASE_ENV_KEY_S3_PROTOCOL_ACCESS_KEY_ID="S3_PROTOCOL_ACCESS_KEY_ID"
export gSUPABASE_ENV_VAL_S3_PROTOCOL_ACCESS_KEY_ID=""

export gSUPABASE_ENV_KEY_S3_PROTOCOL_ACCESS_KEY_SECRET="S3_PROTOCOL_ACCESS_KEY_SECRET"
export gSUPABASE_ENV_VAL_S3_PROTOCOL_ACCESS_KEY_SECRET=""

# Used by MinIO
export gSUPABASE_ENV_KEY_MINIO_ROOT_PASSWORD="MINIO_ROOT_PASSWORD"
export gSUPABASE_ENV_VAL_MINIO_ROOT_PASSWORD=""

# supabase service, image and container names (ideally read these from yml for most up to date values)
export NDR_SUPABASE_APP_SERVICE_NAME_STUDIO="studio"
export NDR_SUPABASE_APP_SERVICE_NAME_STUDIO_IMAGE_NAME="supabase/studio"
export NDR_SUPABASE_APP_SERVICE_NAME_STUDIO_CONTAINER_NAME="supabase-studio"

export NDR_SUPABASE_APP_SERVICE_NAME_KONG="kong"
export NDR_SUPABASE_APP_SERVICE_NAME_KONG_IMAGE_NAME="kong"
export NDR_SUPABASE_APP_SERVICE_NAME_KONG_CONTAINER_NAME="supabase-kong"

export NDR_SUPABASE_APP_SERVICE_NAME_AUTH="auth"
export NDR_SUPABASE_APP_SERVICE_NAME_AUTH_IMAGE_NAME="supabase/gotrue"
export NDR_SUPABASE_APP_SERVICE_NAME_AUTH_CONTAINER_NAME="supabase-auth"

export NDR_SUPABASE_APP_SERVICE_NAME_REST="rest"
export NDR_SUPABASE_APP_SERVICE_NAME_REST_IMAGE_NAME="postgrest/postgrest"
export NDR_SUPABASE_APP_SERVICE_NAME_REST_CONTAINER_NAME="supabase-rest"

export NDR_SUPABASE_APP_SERVICE_NAME_REALTIME="realtime"
export NDR_SUPABASE_APP_SERVICE_NAME_REALTIME_IMAGE_NAME="supabase/realtime"
export NDR_SUPABASE_APP_SERVICE_NAME_REALTIME_CONTAINER_NAME="realtime-dev.supabase-realtime"

export NDR_SUPABASE_APP_SERVICE_NAME_STORAGE="storage"
export NDR_SUPABASE_APP_SERVICE_NAME_STORAGE_IMAGE_NAME="supabase/storage-api"
export NDR_SUPABASE_APP_SERVICE_NAME_STORAGE_CONTAINER_NAME="supabase-storage"

export NDR_SUPABASE_APP_SERVICE_NAME_IMGPROXY="imgproxy"
export NDR_SUPABASE_APP_SERVICE_NAME_IMGPROXY_IMAGE_NAME="darthsim/imgproxy"
export NDR_SUPABASE_APP_SERVICE_NAME_IMGPROXY_CONTAINER_NAME="supabase-imgproxy"

export NDR_SUPABASE_APP_SERVICE_NAME_META="meta"
export NDR_SUPABASE_APP_SERVICE_NAME_META_IMAGE_NAME="supabase/postgres-meta"
export NDR_SUPABASE_APP_SERVICE_NAME_META_CONTAINER_NAME="supabase-meta"

export NDR_SUPABASE_APP_SERVICE_NAME_FUNCTIONS="functions"
export NDR_SUPABASE_APP_SERVICE_NAME_FUNCTIONS_IMAGE_NAME="supabase/edge-runtime"
export NDR_SUPABASE_APP_SERVICE_NAME_FUNCTIONS_CONTAINER_NAME="supabase-edge-functions"

export NDR_SUPABASE_APP_SERVICE_NAME_ANALYTICS="analytics"
export NDR_SUPABASE_APP_SERVICE_NAME_ANALYTICS_IMAGE_NAME="supabase/logflare"
export NDR_SUPABASE_APP_SERVICE_NAME_ANALYTICS_CONTAINER_NAME="supabase-analytics"

export NDR_SUPABASE_APP_SERVICE_NAME_DB="db"
export NDR_SUPABASE_APP_SERVICE_NAME_DB_IMAGE_NAME="supabase/postgres"
export NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME="supabase-db"

export NDR_SUPABASE_APP_SERVICE_NAME_VECTOR="vector"
export NDR_SUPABASE_APP_SERVICE_NAME_VECTOR_IMAGE_NAME="timberio/vector"
export NDR_SUPABASE_APP_SERVICE_NAME_VECTOR_CONTAINER_NAME="supabase-vector"

export NDR_SUPABASE_APP_SERVICE_NAME_SUPAVISOR="supavisor"
export NDR_SUPABASE_APP_SERVICE_NAME_SUPAVISOR_IMAGE_NAME="supabase/supavisor"
export NDR_SUPABASE_APP_SERVICE_NAME_SUPAVISOR_CONTAINER_NAME="supabase-pooler"

declare -a NDR_SUPABASE_APP_OPTIONAL_SERVICES=(
  #"NDR_SUPABASE_APP_SERVICE_NAME_STUDIO"
  "$NDR_SUPABASE_APP_SERVICE_NAME_IMGPROXY"
  "$NDR_SUPABASE_APP_SERVICE_NAME_ANALYTICS"
  #"$NDR_SUPABASE_APP_SERVICE_NAME_REALTIME"
  "$NDR_SUPABASE_APP_SERVICE_NAME_FUNCTIONS"
  "$NDR_SUPABASE_APP_SERVICE_NAME_VECTOR"
)

# supabase cleanup mode options
export NDR_SUPABASE_CLEANUP_OPTION_STRICT=0x1 # fail on any error, default behavior for standard uninstalls.
export NDR_SUPABASE_CLEANUP_OPTION_BEST_EFFORT=0x2 # in prepare phase, we do a best effort cleanup and dont fail on errors.
export NDR_SUPABASE_CLEANUP_OPTION_DEFAULT=$(( NDR_SUPABASE_CLEANUP_OPTION_STRICT ))

# schema headers
export gNDR_SUPABASE_SCHEMA_FILE_HEADER_DESC="-- NextDR Supabase Database Schema"
export gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION="-- NDR-SCHEMA-VERSION:" # product version of the current schema file (what will be installed or upgraded TO)
export gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL="$gPRODUCT_VERSION"
export gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM="-- NDR-UPGRADE-FROM:" # product version this schema file supports upgrading FROM
export gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL="$gINSTALLED_VERSION"

# Found in the DIFF schema file, these are the sha256 checksums of the FULL schema files that this DIFF was generated from.
# These checksums are used to validate and ensure the the DIFF file is the acutal one generated from the FULL schema files being used for the upgrade.
# if this hash matches the computed hash of the FULL baseline schema file found in the install/home folder AND the full upgrade schema supplied in the installtion package, 
# then we can confidently use this DIFF file for this upgrade and save time.
# if the hashes do not match, then the DIFF file is invalid for the FULL schema files and we must generate a new diff on the fly.
export gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH="-- NDR-FULL-BASELINE-SCHEMA-SHA256:" 
export gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH_VAL=""
export gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH="-- NDR-FULL-UPGRADE-SCHEMA-SHA256:" 
export gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL=""

export gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_FULL="FULL"
export gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_INCR="INCR"
export gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE="-- NDR-SCHEMA-TYPE:"
export gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_VAL="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_FULL"
  
# supabase db upgrade schema diff options
export NDR_SCHEMA_DIFF_WORK_DIR="/tmp/diff"
export NDR_SCHEMA_DIFF_SUPABASE_DIR="${NDR_SCHEMA_DIFF_WORK_DIR}/supabase-diff"
export NDR_SCHEMA_DIFF_SUPABASE_BASELINE_DIR="${NDR_SCHEMA_DIFF_WORK_DIR}/supabase-base"
export NDR_SCHEMA_DIFF_SUPABASE_DOCKER_SUB_DIR="docker"
export NDR_SCHEMA_DIFF_SUPABASE_PROJECT_NAME_BASELINE="ndr-supabase-base"
export NDR_SCHEMA_DIFF_SUPABASE_PROJECT_NAME_DIFF="ndr-supabase-diff"

export NDR_SCHEMA_DIFF_PYTHON_SCRIPT_FILE="ndrSchemaDiffUtil.py"

declare -a NDR_SCHEMA_DIFF_DOCKER_SERVICES=($NDR_SUPABASE_APP_SERVICE_NAME_DB $NDR_SUPABASE_APP_SERVICE_NAME_AUTH $NDR_SUPABASE_APP_SERVICE_NAME_REALTIME $NDR_SUPABASE_APP_SERVICE_NAME_STORAGE) # master list of service names required for diff db
declare -A NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_TEMP=() # list of linked temp diff container names
declare -A NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_BASE=() # OPTIONAL list of linked temp baseline container names
declare -A NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_PROD=() # list of linked original container names
declare -A NDR_SCHEMA_DIFF_DOCKER_SERVICE_IMAGES_TEMP=() # list of linked temp diff container images
declare -A NDR_SCHEMA_DIFF_DOCKER_SERVICE_IMAGES_BASE=() # OPTIONAL list of linked temp baseline container images
declare -A NDR_SCHEMA_DIFF_DOCKER_SERVICE_IMAGES_PROD=() # list of linked original container images

# Supabase merge
export gNDR_SUPABASE_DB_MERGE_TEMP_PROD_DB="" # temporary DB to contain copy of production DB for diff comparison and merging.

export gNDR_SUPABASE_DB_OPS_POSTGRES_ADMIN_USER="postgres"
export gNDR_SUPABASE_DB_OPS_SUPABASE_ADMIN_USER="supabase_admin"
export gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT="$gNDR_SUPABASE_DB_OPS_POSTGRES_ADMIN_USER"
export gNDR_SUPABASE_DB_OPS_PRODUCTION_DB="postgres"

# Supabase test DB build options
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_PREPARE_FOLDERS=0x1
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CLONE_REPO=0x2
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_COPY_ENV_FILE=0x4
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODIFY_ENV_PORTS=0x8
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CONFIGURE_COMPOSE_SERVICES=0x10
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_PULL_IMAGES=0x20
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_COMPOSE_CONTAINERS=0x40
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CONTAINER_VERIFY=0x80
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_BRIDGE_NETWORKS=0x100
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_QUERY_PROD_DB_ENV=0x200
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_QUERY_BUILD_DB_ENV=0x400
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_INJECT_SCHEMA=0x800
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_VALIDATE_SCHEMA=0x1000
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_VALIDATE_BUILD_TABLES=0x2000
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_INSTALL_DIFF_UTILS=0x4000
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CLEANUP_SERVICES=0x8000
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CLEANUP_FOLDERS=0x10000

# Test DB construct mode
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_BASELINE=0x1000000000
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_UPGRADE=0x2000000000

# Baseline db build options (devops mode)
baselineDBOpts=$NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_BASELINE
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_PREPARE_FOLDERS ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CLONE_REPO ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_COPY_ENV_FILE ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODIFY_ENV_PORTS ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CONFIGURE_COMPOSE_SERVICES ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_PULL_IMAGES ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_COMPOSE_CONTAINERS ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CONTAINER_VERIFY ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_BRIDGE_NETWORKS ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_QUERY_PROD_DB_ENV ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_QUERY_BUILD_DB_ENV ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_INJECT_SCHEMA ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_VALIDATE_SCHEMA ))
#baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_VALIDATE_BUILD_TABLES ))
#baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_INSTALL_DIFF_UTILS ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CLEANUP_SERVICES ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CLEANUP_FOLDERS ))
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_BASELINE=$baselineDBOpts

# Upgrade test db build options
upgradeDBOpts=$NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_UPGRADE
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_PREPARE_FOLDERS ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CLONE_REPO ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_COPY_ENV_FILE ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODIFY_ENV_PORTS ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CONFIGURE_COMPOSE_SERVICES ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_PULL_IMAGES ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_COMPOSE_CONTAINERS ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CONTAINER_VERIFY ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_BRIDGE_NETWORKS ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_QUERY_PROD_DB_ENV ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_QUERY_BUILD_DB_ENV ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_INJECT_SCHEMA ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_VALIDATE_SCHEMA ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_VALIDATE_BUILD_TABLES ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_INSTALL_DIFF_UTILS ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CLEANUP_SERVICES ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CLEANUP_FOLDERS ))
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_UPGRADE=$upgradeDBOpts

# supabase application build enum
export NDR_SUPABASE_APP_BUILD_OPTIONS_NONE=0x0

# prepare phase individual options
export NDR_SUPABASE_APP_BUILD_OPTIONS_INSTALL_PREREQUISITES=0x1 # install and devops
export NDR_SUPABASE_APP_BUILD_OPTIONS_HOME_DIR_CHECK=0x2        # (install only, devops will always use the current working directory since all will be cleaned up at the end)
export NDR_SUPABASE_APP_BUILD_OPTIONS_PREUPGRADE=0x4  # install only, performs various pre-upgrade specific tasks.
export NDR_SUPABASE_APP_BUILD_OPTIONS_INSTALL_PROMPTS=0x8  # devops and install
export NDR_SUPABASE_APP_BUILD_OPTIONS_CLEANUP_EXISTING_APP=0x10  # devops and install

# configure phase individual options
export NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_SUPABASE_DIRS=0x100     # devops and install
export NDR_SUPABASE_APP_BUILD_OPTIONS_GIT_CLONE_TEMPLATE=0x200       # devops and install
export NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_TEMPLATE_FILES=0x400       # devops and install, template files only.
export NDR_SUPABASE_APP_BUILD_OPTIONS_CUSTOMIZE_COMPOSE_FILE=0x800   # devops and install, note- Install will later copy precustomized file from installer archive.
export NDR_SUPABASE_APP_BUILD_OPTIONS_QUERY_COMPOSE_SERVICES=0x1000  # install and devops

# build/install phase individual options
export NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_SUPABASE_APP_REGISTRY=0x10000 # install only
export NDR_SUPABASE_APP_BUILD_OPTIONS_SCHEMA_FILE_CHECK=0x20000            # devops, note- install will pull the necessary image with schema baked in
export NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_SCHEMA_FILE=0x40000              # devops, note- install will pull the necessary image with schema baked in
export NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_ENV_FILE=0x80000                # devops and install, note- install will package the env file with the installer archive
export NDR_SUPABASE_APP_BUILD_OPTIONS_PULL_SUPABASE_BASE_IMAGES=0x100000   # devops and install
export NDR_SUPABASE_APP_BUILD_OPTIONS_BACKUP_SCHEMA=0x200000               # install
export NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_BRIDGE_NETWORK=0x400000       # devops and install, note- not required by devops build, but docker compose command will fail since the entry is in the compose file.
export NDR_SUPABASE_APP_BUILD_OPTIONS_START_CONTAINERS=0x800000            # devops and install
export NDR_SUPABASE_APP_BUILD_OPTIONS_VERIFY_CONTAINERS=0x1000000          # devops and install
export NDR_SUPABASE_APP_BUILD_OPTIONS_APP_INSTALL_COMPLETE_NOTIFY=0x2000000 # install only
export NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_SYSTEMD=0x8000000             # install only
export NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_ADMIN_ACCOUNT=0x10000000       # devops and install
export NDR_SUPABASE_APP_BUILD_OPTIONS_APPLY_SCHEMA=0x20000000              # devops and install
export NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_INSTALL_FILES=0x40000000        # install only
export NDR_SUPABASE_APP_BUILD_OPTIONS_POPULATE_HOST_ADDRESS=0x80000000     # devops and install
export NDR_SUPABASE_APP_BUILD_OPTIONS_CUSTOMIZE_ENV_FILE=0x100000000        # devops and install
export NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_DASHBOARD_ACCOUNT=0x200000000 # devops and install

# Post install phase individual options
export NDR_SUPABASE_APP_BUILD_OPTIONS_CLEANUP_SUPABASE_DIRS=0x1000000000       # devops and install, note- devops removes all folders, install only removes the template folder, note2- install mode essentially ends here

# install and devops option amalgamations.
installOpts=0
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_INSTALL_PREREQUISITES ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_HOME_DIR_CHECK ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_PREUPGRADE ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_BACKUP_SCHEMA ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_INSTALL_PROMPTS ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_SCHEMA_FILE_CHECK ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CLEANUP_EXISTING_APP ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_SUPABASE_DIRS ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_GIT_CLONE_TEMPLATE ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_TEMPLATE_FILES ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CUSTOMIZE_COMPOSE_FILE ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_QUERY_COMPOSE_SERVICES ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_SUPABASE_APP_REGISTRY ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_SCHEMA_FILE ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_ENV_FILE ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_DASHBOARD_ACCOUNT ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CUSTOMIZE_ENV_FILE ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_PULL_SUPABASE_BASE_IMAGES ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_BRIDGE_NETWORK ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_START_CONTAINERS ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_VERIFY_CONTAINERS ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_INSTALL_FILES ))
#installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_SYSTEMD )) # not explicitly needed since supabase compose uses restart sections for each service
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_APPLY_SCHEMA ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_ADMIN_ACCOUNT ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_APP_INSTALL_COMPLETE_NOTIFY ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CLEANUP_SUPABASE_DIRS ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_POPULATE_HOST_ADDRESS ))
export NDR_SUPABASE_APP_BUILD_OPTIONS_INSTALL=$installOpts


# --- FUNCTIONS ---

ndr_version_ge() {
  # returns 0 if $1 >= $2
  # otherwise returns 1
  local v1 v2
  local version_a="${1#v}"
  local version_b="${2#v}"
  version_a="${version_a#V}"
  version_b="${version_b#V}"

  # split by dot and pad to 3 fields
  IFS='.' read -r -a v1 <<< "$version_a"
  IFS='.' read -r -a v2 <<< "$version_b"

  # compare major, then minor, then patch
  for i in 0 1 2; do
      local a="${v1[i]:-0}"
      local b="${v2[i]:-0}"

      if (( 10#$a > 10#$b )); then return 0; fi
      if (( 10#$a < 10#$b )); then return 1; fi
  done

  return 0  # equal
}

# 1st checks if app is installed and reads registry.
# 2nd looks for compose yml and reads from file.
# 3rd will populate from hard coded defines.
function ndr_PopulateSupabaseServiceMap ()
{
  local logSectionDesc="Populating Supabase service map"
  ndr_logSecStart "$logSectionDesc"

  local serviceListFound=false

  # 1st checks if app is installed and reads registry.
  while [ "$serviceListFound" = false ]; do
    ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
    local dbInstalled=$?
    if [[ "$dbInstalled" -ne 0 ]]; then
      break
    fi

    ndr_RegistryReadServiceEntries
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logWarn "Could not read service entries from registry."
      break
    fi
    
    if [ ${#ndr_supabase_container_services[@]} -eq 0 ]; then
      ndr_logWarn "No service entries found in list."
      break
    fi

    ndr_logInfo "Read ${#ndr_supabase_container_services[@]} service entries from the registry."

    serviceListFound=true
  done

  while [ "$serviceListFound" = false ]; do
    local COMPOSE_FILE="${gSUPABASE_NEXTDR_HOME}/docker-compose.yml"

    if [[ ! -f $COMPOSE_FILE ]]; then
      ndr_logError "Docker compose file [$COMPOSE_FILE] not found."
      break
    fi

    # Get list of services
    mapfile -t services < <(yq eval '.services | keys | .[]' "$COMPOSE_FILE")
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to retrieve services from compose file [$COMPOSE_FILE]."
      break
    fi

    if [[ ${#services[@]} -eq 0 ]]; then
      echo "No services found in compose file."
      break
    fi

    ndr_logInfo "Read ${#services[@]} service entries from the compose file."

    # clear the arrays
    ndr_supabase_container_services=()
    ndr_supabase_container_service_container_names=()
    ndr_supabase_container_service_image_names=()
    ndr_supabase_container_service_image_tags=()

    for service_name in "${services[@]}"; do
      local container_name=$(yq eval ".services.$service_name.container_name" "$COMPOSE_FILE")
      local image=$(yq eval ".services.$service_name.image" "$COMPOSE_FILE")

      if [[ -z "$container_name" || -z "$image" ]]; then
        ndr_logError "Failed to retrieve service [$service_name] details from compose file [$COMPOSE_FILE]."
        break
      fi
    
      local image_base_name=$image
      local image_version

      if [[ "$image" == *:* ]]; then
        image_base_name="${image%%:*}"
        image_version="${image##*:}"
      fi

      ndr_AddSupabaseServiceMapEntry $service_name $container_name $image_base_name $image_version

    done

    ndr_logInfo "Added ${#ndr_supabase_container_services[@]} service entries from the compose file."

    serviceListFound=true
  done

  while [ "$serviceListFound" = false ]; do
    
    # clear the arrays
    ndr_supabase_container_services=()
    ndr_supabase_container_service_container_names=()
    ndr_supabase_container_service_image_names=()
    ndr_supabase_container_service_image_tags=()

    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_STUDIO $NDR_SUPABASE_APP_SERVICE_NAME_STUDIO_CONTAINER_NAME $NDR_SUPABASE_APP_SERVICE_NAME_STUDIO_IMAGE_NAME
    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_KONG $NDR_SUPABASE_APP_SERVICE_NAME_KONG_IMAGE_NAME $NDR_SUPABASE_APP_SERVICE_NAME_KONG_CONTAINER_NAME
    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_AUTH $NDR_SUPABASE_APP_SERVICE_NAME_AUTH_IMAGE_NAME $NDR_SUPABASE_APP_SERVICE_NAME_AUTH_CONTAINER_NAME
    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_REST $NDR_SUPABASE_APP_SERVICE_NAME_REST_IMAGE_NAME $NDR_SUPABASE_APP_SERVICE_NAME_REST_CONTAINER_NAME
    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_REALTIME $NDR_SUPABASE_APP_SERVICE_NAME_REALTIME_IMAGE_NAME $NDR_SUPABASE_APP_SERVICE_NAME_REALTIME_CONTAINER_NAME
    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_STORAGE $NDR_SUPABASE_APP_SERVICE_NAME_STORAGE_IMAGE_NAME $NDR_SUPABASE_APP_SERVICE_NAME_STORAGE_CONTAINER_NAME
    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_IMGPROXY $NDR_SUPABASE_APP_SERVICE_NAME_IMGPROXY_IMAGE_NAME $NDR_SUPABASE_APP_SERVICE_NAME_IMGPROXY_CONTAINER_NAME
    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_META $NDR_SUPABASE_APP_SERVICE_NAME_META_IMAGE_NAME $NDR_SUPABASE_APP_SERVICE_NAME_META_CONTAINER_NAME
    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_FUNCTIONS $NDR_SUPABASE_APP_SERVICE_NAME_FUNCTIONS_IMAGE_NAME $NDR_SUPABASE_APP_SERVICE_NAME_FUNCTIONS_CONTAINER_NAME
    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_ANALYTICS $NDR_SUPABASE_APP_SERVICE_NAME_ANALYTICS_IMAGE_NAME $NDR_SUPABASE_APP_SERVICE_NAME_ANALYTICS_CONTAINER_NAME
    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_DB $NDR_SUPABASE_APP_SERVICE_NAME_DB_IMAGE_NAME $NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME
    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_VECTOR $NDR_SUPABASE_APP_SERVICE_NAME_VECTOR_IMAGE_NAME $NDR_SUPABASE_APP_SERVICE_NAME_VECTOR_CONTAINER_NAME
    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_SUPAVISOR $NDR_SUPABASE_APP_SERVICE_NAME_SUPAVISOR_IMAGE_NAME $NDR_SUPABASE_APP_SERVICE_NAME_SUPAVISOR_CONTAINER_NAME
    
    serviceListFound=true
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function <service_name> <container_name> <image_name> <image_tag (OPTIONAL)> 
function ndr_AddSupabaseServiceMapEntry () 
{
  # Argument validation
  if [[ $# -lt 3 ]]; then
    ndr_logError "Usage: function <service_name> <container_name> <image_name> <image_tag [OPTIONAL]>"
    return 1
  fi
  
  local serviceName="$1"
  local containerName="$2"
  local imageName="$3"
  local imageTag="${4:-}"
  
  # Append to the ordered service array
  ndr_supabase_container_services+=("$serviceName")

  # Map service to its container, image and tag name
  ndr_supabase_container_service_container_names["$serviceName"]="$containerName"
  ndr_supabase_container_service_image_names["$serviceName"]="$imageName"
  ndr_supabase_container_service_image_tags["$serviceName"]="$imageTag"

  return 0
}

function ndr_SupabasePullDatabaseReferenceSchemaFileV2 ()
{
  local logSectionDesc="Executing supabase DB pull"
  ndr_logSecStart "$logSectionDesc"

  # decrypt and populate secrets.
  ndr_DecryptPopulateSecrets || { echo "Error: failed to populate secrets"; return 1; }

  local destMigrationFileName=$gNDR_REFERENCE_SQL_SCHEMA_FILENAME
  local destMigrationFileTmp="${gSCRIPT_HOME_DIR}/tmp_${destMigrationFileName}"

  # build command
  # this connects directly to the postgres db in the cloud supabase project using the IPV4 session pooler style parameter syntax.
  # it requires the remote pwd, remote proj reference and remote host url (found in the connection options for session pooler)

  cmd="env PGPASSWORD='$gSUPABASE_REMOTE_PASSWORD' pg_dump -h \"$gNDR_SUPABASE_REMOTE_HOST_URL\" -U \"postgres.$gSUPABASE_REMOTE_PROJECT_REFERENCE\" -d postgres -p 5432 --no-owner -f \"$destMigrationFileTmp\" --schema-only --schema=auth --schema=public"
  eval $cmd
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "[$cmd] failure with code [$return_code]"
    return 1
  fi

  ndr_logInfo "Successfully generated $gCOMPANY_NAME SQL schema file [$destMigrationFileTmp]"

  # check for existing migration refrence file in root project folder.
  # if one exists, backup/rename with timestamp appended.
  if [[ -f "$destMigrationFileName" ]]; then
    # Get the UNIX timestamp (modification time) of the file
    timestamp=$(stat -c %Y "$destMigrationFileName")

    # Convert timestamp to readable format: YYYYMMDD_HHMMSS
    readable_time=$(date -d @"$timestamp" +"%Y%m%d_%H%M%S")
    
    # Build the new filename with timestamp appended
    filename_base="${destMigrationFileName%.*}"
    filename_ext="${destMigrationFileName##*.}"

    if [[ "$filename_base" == "$destMigrationFileName" ]]; then
      # No extension case
      backup_filename="${filename_base}_${readable_time}"
    else
      backup_filename="${filename_base}_${readable_time}.${filename_ext}"
    fi

    # Move the file to the new filename
    mv -f "$destMigrationFileName" "$backup_filename"

    ndr_logInfo "Backing up preexisting $gCOMPANY_NAME SQL schema file [$destMigrationFileName] to [$backup_filename]"
  fi

  # move tmp file to root project folder
  local destMigrationFile="${gSCRIPT_HOME_DIR}/${destMigrationFileName}"
  mv -f $destMigrationFileTmp $destMigrationFile
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to move temp schema file [$destMigrationFileTmp] to [$destMigrationFile]"
    return 1
  fi
  ndr_logInfo "Moved migration file [$destMigrationFileTmp] to [$destMigrationFile]"

  # cache copied migration file name for potential later use
  gACTIVE_NDR_SQL_SCHEMA_FILE=$destMigrationFile
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabasePullDatabaseReferenceSchemaFile ()
{
  local logSectionDesc="Executing supabase DB pull"
  ndr_logSecStart "$logSectionDesc"

  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }

  # pre check for any existing migrations. If any exist, the DB pull may fail.
  # If this is the first time running this script, there should be no migrations present.
  # If there are migrations present, the user will need to run the migration repair command to remove the entry from the remote migration history table.
  # Set the directory to query
  
  
  # Check if the directory exists. Directory will not exist for fresh installs so skip check if not present.
  if [ ! -d "$gSUPABASE_MIGRATION_DIR" ]; then
    ndr_logInfo "Directory $gSUPABASE_MIGRATION_DIR does not exist, skipping precheck. "
    #return 1
  fi

  # Get list of regular files (excluding directories) in the directory
  FILES=("$gSUPABASE_MIGRATION_DIR"/*)
  COUNT=0
  
  # Count only regular files (skip directories and others)
  for FILE in "${FILES[@]}"; do
    if [ -f "$FILE" ]; then
      ndr_logInfo "Removing existing migration file: [$FILE]"
      # delete original migration file from migrations folder
      rm "$FILE"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logWarn "Failed to remove preexisting migration file [$FILE]. Please remove manually."
        #return 1
      fi
      
      # Extract just the filename portion (strip path)
      BASENAME=$(basename "$FILE")

      # Check if filename contains an underscore
      if [[ "$BASENAME" != *_* ]]; then
        ndr_logWarn "Invalid filename format. No underscore found in [$BASENAME], skipping."
        continue
      fi

      # Extract the timestamp value before the first underscore
      gMIGRATION_TIMESTAMP=$(echo "$BASENAME" | cut -d'_' -f1)

      if [ -z "$gMIGRATION_TIMESTAMP" ]; then
        ndr_logWarn "Failed to extract migration timestamp from filename [$BASENAME], skipping. "
        continue
      fi

      ndr_logInfo "Using migration timestamp: [$gMIGRATION_TIMESTAMP]"

      # run migration entry reset against remote db with the timestamp
      # this will remove the entry from the remote migration history table
      cmd="$gSUPABASE_CLI_CMD migration repair --status reverted $gMIGRATION_TIMESTAMP"
      if [ -n "$gSUPABASE_REMOTE_PASSWORD" ]; then
        cmd="$cmd --password '$gSUPABASE_REMOTE_PASSWORD'"
      fi    
      if [[ "$gDEBUG_MODE" == true ]]; then
        cmd="$cmd --debug"
      fi
      
      max_retries=3
      attempt=1

      while true; do
        eval "$cmd"
        
        return_code=$?

        if [[ $return_code -eq 0 ]]; then
          # success
          break
        fi

        if [[ $attempt -ge $max_retries ]]; then
          ndr_logError "Max supabase command retries reached. Exiting. "
          return 1
        fi

        ndr_logWarn "Supabase command attempt $attempt failed, retrying."
        
        
        attempt=$((attempt + 1))
        sleep 1  # Optional: wait before retrying
      done

      if [ $return_code != 0 ]; then
        ndr_logWarn "Failed to remove migration entry [$gMIGRATION_TIMESTAMP] from remote DB. Please run command to remove manually [$gSUPABASE_CLI_CMD migration repair --status reverted $gMIGRATION_TIMESTAMP]"
        #return 1
      fi

      ndr_logInfo "Removing remote migration entry for timestamp: [$gMIGRATION_TIMESTAMP]"
      
      ((COUNT++))
    fi
  done

  # Check count and respond accordingly
  if [ "$COUNT" -eq 0 ]; then
    ndr_logInfo "No preexisting migration files found in directory. Proceeding with db pull."
  else
    ndr_logInfo "Removed [$COUNT] migration files from dir [$gSUPABASE_MIGRATION_DIR]"
  fi

  # The auth and storage schemas are excluded by default. Run supabase db pull --schema auth,storage again to diff them.
  max_retries=3
  attempt=1

  cmd="$gSUPABASE_CLI_CMD db pull --linked --schema auth,public"
  if [ -n "$gSUPABASE_REMOTE_PASSWORD" ]; then
    cmd="$cmd --password '$gSUPABASE_REMOTE_PASSWORD'"
  fi
  if [[ "$gDEBUG_MODE" == true ]]; then
    cmd="$cmd --debug"
  fi
  
  while true; do
    eval "$cmd" <<< "n"
    
    return_code=$?

    if [[ $return_code -eq 0 ]]; then
      # success
      break
    fi

    if [[ $attempt -ge $max_retries ]]; then
      ndr_logError "Max supabase command retries reached. Exiting. "
      return 1
    fi

    ndr_logWarn "Supabase command attempt $attempt failed, retrying."
    
    
    attempt=$((attempt + 1))
    sleep 1  # Optional: wait before retrying
  done

  if [ $return_code != 0 ]; then
    ndr_logError "Supabase db pull failed."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# To install supabase CLI:
# https://supabase.com/docs/guides/local-development
function ndr_SupabaseCLIInstall ()
{
  local logSectionDesc="Installing supabase CLI"
  ndr_logSecStart "$logSectionDesc"

  cd "$gNEXTDR_HOME_DIR"  || { ndr_logError "Failed to cd into home dir"; return 1; }
  
  # check if supabase cli is already installed
  $gSUPABASE_CLI_CMD -v
  return_code=$?
  if [ $return_code -eq 0 ]; then
    ndr_logInfo "Supabase CLI already installed"
    return 0
  fi

  npm install supabase --save-dev
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to install supabase CLI."
    return 1
  fi
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# To begin linking to the remote instance
# eg. supabase link --project-ref <project-id> -password <password>
# You can get <project-id> from your project's dashboard URL: https://supabase.com/dashboard/project/<project-id>
# Alternatively, omitting the project ID will cause supabase to show all available remote db's to choose from.
# password is the master project password (not the supabase email account login)

function ndr_SupabaseLinkRemote ()
{
  local logSectionDesc="Executing supabase remote login"
  ndr_logSecStart "$logSectionDesc"

  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }

  # perform a remote logout in case the user is already logged in.
  ndr_SupabaseLogoutRemote

  cmd="$gSUPABASE_CLI_CMD login --token $gSUPABASE_REMOTE_TOKEN"
  if [[ "$gDEBUG_MODE" == true ]]; then
    cmd="$cmd --debug"
  fi
  $cmd
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Supabase login with token failed."
    return 1
  fi
  ndr_logSecEnd "$logSectionDesc"

  local logSectionDesc="Executing supabase init"
  ndr_logSecStart "$logSectionDesc"

  cmd="$gSUPABASE_CLI_CMD init --force"
  $cmd <<< "n"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Supabase init failed."
    return 1
  fi
  ndr_logSecEnd "$logSectionDesc"

  local logSectionDesc="Linking local supabase project to remote master"
  ndr_logSecStart "$logSectionDesc"

  # There seems to be a bug in the supbase CLI where the link command (And others) still prompts for password even when the initial login with token was successful.
  # This results in several redundant prompts for password from a number of CLI commands.
  # As a workaround, lets prompt for the password interactively here and then pass it to the link command. If link command fails, the password was incorrect and retry the prompt up to 3 times.

  cmd="$gSUPABASE_CLI_CMD link --project-ref $gSUPABASE_REMOTE_PROJECT_REFERENCE"
  if [ -n "$gSUPABASE_REMOTE_PASSWORD" ]; then
    cmd="$cmd --password '$gSUPABASE_REMOTE_PASSWORD'"
  fi
  if [[ "$gDEBUG_MODE" == true ]]; then
    cmd="$cmd --debug"
  fi
  
  max_retries=3
  attempt=1

  while true; do

    if [[ -z "$gSUPABASE_REMOTE_PASSWORD" ]]; then
      read -s -p "Enter the Supabase remote project password: " gSUPABASE_REMOTE_PASSWORD
      echo  # Print a newline after the password input
      
      if [[ -z "$gSUPABASE_REMOTE_PASSWORD" ]]; then
        ndr_logError "Supabase remote project password is required."
        continue
      else 
        cmd="$cmd --password '$gSUPABASE_REMOTE_PASSWORD'"
      fi
    fi

    eval "$cmd"
    
    return_code=$?

    if [[ $return_code -eq 0 ]]; then
      # success
      break
    fi

    if [[ $attempt -ge $max_retries ]]; then
      ndr_logError "Max supabase command retries reached. Exiting. "
      return 1
    fi

    ndr_logWarn "Supabase command attempt $attempt failed, retrying."
    
    # command failure could be due to an incoorect password so clear that to trigger a re-prompt.
    gSUPABASE_REMOTE_PASSWORD=""
    
    attempt=$((attempt + 1))
    sleep 1  # Optional: wait before retrying
  done

  if [ $return_code != 0 ]; then
    ndr_logError "Supabase link failed."
    # immediately run a supabase unlink command to remove the local link and clean up.
    $gSUPABASE_CLI_CMD unlink
    return 1
  fi
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# Capture any changes that you have made to your remote database before you went through in the process of pulling the schema.
# may prompt to update remote migration history table. select default.
# this process is lengthy and can take several minutes.

# If successful, Will output schema sql file to a folder stated in CLI output.
# supabase/migrations is now populated with a migration in <timestamp>_remote_schema.sql.
# eg. "Schema written to supabase\migrations\20250421192748_remote_schema.sql"

# query the output folder for the generated sql file. This will be under supabase/migrations.
# copy this file to the root project folder and delete the original from the migrations folder.
# parse the timestamp from the file name.
# Run the migration entry reset against the remote db with the timestamp. This will remove the entry from the remote migration history table.
# eg.  npx supabase migration repair --status reverted 20250422185759
function ndr_SupabaseProcessRemoteMigration ()
{
  local logSectionDesc="Processing supabase remote migration file"
  ndr_logSecStart "$logSectionDesc"

  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }

  # Set the directory to query
  DIR="$gSUPABASE_MIGRATION_DIR"
  
  # Check if the directory exists
  if [ ! -d "$DIR" ]; then
    ndr_logError "Directory $DIR does not exist. "
    return 1
  fi

  # Get list of regular files (excluding directories) in the directory
  FILES=("$DIR"/*)
  COUNT=0
  MIGRATION_FILENAME=""

  # Count only regular files (skip directories and others)
  for FILE in "${FILES[@]}"; do
    if [ -f "$FILE" ]; then
      ((COUNT++))
      MIGRATION_FILENAME="$FILE"
    fi
  done

  # Check count and respond accordingly
  if [ "$COUNT" -eq 0 ]; then
    ndr_logError "No migration files found in directory. "
    return 1
  elif [ "$COUNT" -gt 1 ]; then
    ndr_logError "Too many files migration found in directory. "
    return 1
  else
    ndr_logInfo "Found migration file: [$MIGRATION_FILENAME]"
    # You can now use $MIGRATION_FILENAME as needed
  fi

  # Extract just the filename portion (strip path)
  BASENAME=$(basename "$MIGRATION_FILENAME")

  # Extract the timestamp value before the first underscore
  gMIGRATION_TIMESTAMP=$(echo "$BASENAME" | cut -d'_' -f1)

  ndr_logInfo "Using migration timestamp: [$gMIGRATION_TIMESTAMP]"

  destMigrationFileName=$gNDR_REFERENCE_SQL_SCHEMA_FILENAME
  # check for existing migration refrence file in root project folder.
  # if one exists, backup/rename with timestamp appended.
  if [[ -f "$destMigrationFileName" ]]; then
    # Get the UNIX timestamp (modification time) of the file
    timestamp=$(stat -c %Y "$destMigrationFileName")

    # Convert timestamp to readable format: YYYYMMDD_HHMMSS
    readable_time=$(date -d @"$timestamp" +"%Y%m%d_%H%M%S")
    
    # Build the new filename with timestamp appended
    filename_base="${destMigrationFileName%.*}"
    filename_ext="${destMigrationFileName##*.}"

    if [[ "$filename_base" == "$destMigrationFileName" ]]; then
      # No extension case
      backup_filename="${filename_base}_${readable_time}"
    else
      backup_filename="${filename_base}_${readable_time}.${filename_ext}"
    fi

    # Move the file to the new filename
    mv -f "$destMigrationFileName" "$backup_filename"

    ndr_logInfo "Backing up preexisting $gCOMPANY_NAME SQL schema file [$destMigrationFileName] to [$backup_filename]"
  fi

  # copy migration file to root project folder
  local destMigrationFile="${gSCRIPT_HOME_DIR}/${destMigrationFileName}"
  cp -f $MIGRATION_FILENAME $destMigrationFile
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to copy migration file [$MIGRATION_FILENAME] to [$destMigrationFile]"
    return 1
  fi
  ndr_logInfo "Copied migration file [$MIGRATION_FILENAME] to [$destMigrationFile]"

  # cache copied migration file name for later use in docker container construction
  gACTIVE_NDR_SQL_SCHEMA_FILE=$destMigrationFile
  ndr_logInfo "Successfully generated $gCOMPANY_NAME SQL schema file [$destMigrationFileName]"

  # delete original migration file from migrations folder
  rm "$MIGRATION_FILENAME"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Failed to remove original migration file [$MIGRATION_FILENAME]. Please remove manually."
    #return 1
  fi

  # run migration entry reset against remote db with the timestamp
  # this will remove the entry from the remote migration history table
  cmd="$gSUPABASE_CLI_CMD migration repair --status reverted $gMIGRATION_TIMESTAMP"
  if [ -n "$gSUPABASE_REMOTE_PASSWORD" ]; then
    cmd="$cmd --password '$gSUPABASE_REMOTE_PASSWORD'"
  fi    
  if [[ "$gDEBUG_MODE" == true ]]; then
    cmd="$cmd --debug"
  fi
  
  max_retries=3
  attempt=1

  while true; do
    eval "$cmd"
    
    return_code=$?

    if [[ $return_code -eq 0 ]]; then
      # success
      break
    fi

    if [[ $attempt -ge $max_retries ]]; then
      ndr_logError "Max supabase command retries reached. Exiting. "
      return 1
    fi

    ndr_logWarn "Supabase command attempt $attempt failed, retrying."
    
    
    attempt=$((attempt + 1))
    sleep 1  # Optional: wait before retrying
  done

  if [ $return_code != 0 ]; then
    ndr_logWarn "Failed to remove migration entry [$gMIGRATION_TIMESTAMP] from remote DB. Please run command to remove manually [$gSUPABASE_CLI_CMD migration repair --status reverted $gMIGRATION_TIMESTAMP]"
    #return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseLogoutRemote ()
{
  local logSectionDesc="Unlinking local supabase project"
  ndr_logSecStart "$logSectionDesc"

  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }

  cmd="$gSUPABASE_CLI_CMD unlink"
  if [[ "$gDEBUG_MODE" == true ]]; then
    cmd="$cmd --debug"
  fi
  $cmd
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Supabase unlink failed."
    #return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  
  local logSectionDesc="Executing supabase remote logout"
  ndr_logSecStart "$logSectionDesc"

  cmd="$gSUPABASE_CLI_CMD logout"
  if [[ "$gDEBUG_MODE" == true ]]; then
    cmd="$cmd --debug"
  fi
  $cmd <<< "y"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Supabase logout failed."
    #return 1
  fi
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# there are 2 types of objects that need to be removed:
# 1. the supabase container and its data. This can be done with the docker file and compose commands if present. Otherwise we can remove images and containers by name.
# 2. the supabase template and project directories and files.
function ndr_SupabaseContainerCleanup ()
{
  # Cleanup code snippet taken from "projectDir/reset.sh"
  local logSectionDesc="Cleaning up Supabase Containers"
  ndr_logSecStart "$logSectionDesc"
  
  if [[ "$gUPGRADE_MODE" == true && "$gNDR_SUPABASE_GIT_VERSION_TAG_UPGRADE" == false ]]; then
    ndr_logDebug "Supabase tag upgrade not enabled, skipping section."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  local cleanupOptions="${1:-$NDR_SUPABASE_CLEANUP_OPTION_DEFAULT}"
  
  if [[ -z "$gNEXTDR_HOME_DIR" ]]; then
    # read from registry if package already present.
    local homeDir=""
    homeDir=$(ndr_getHomeDirReg)
    return_code=$?
    if [[ $return_code -eq 0 && -n "$homeDir" ]]; then
      ndr_logInfo "Found existing directory [$homeDir] in registry."
      gNEXTDR_HOME_DIR="$homeDir"
    fi
  fi
  
  if [[ -n "$gNEXTDR_HOME_DIR" ]]; then
    gSUPABASE_NEXTDR_HOME="${gNEXTDR_HOME_DIR}/${gSUPABASE_NEXTDR_SUB}"
    gSUPABASE_TEMPLATE_HOME="${gNEXTDR_HOME_DIR}/${gSUPABASE_TEMPLATE_SUB}"
  fi

  if [[ -z "$gNEXTDR_HOME_DIR" || -z "$gSUPABASE_NEXTDR_HOME" ]]; then
    ndr_logError "Invalid home or project directory."
    return 1
  fi

  if [[ ! -d "$gSUPABASE_NEXTDR_HOME" ]]; then
    ndr_logInfo "Supabase project directory [$gSUPABASE_NEXTDR_HOME] does not exist. Nothing to clean up."
    return 0
  fi

  local dockerComposeFile="$gSUPABASE_NEXTDR_HOME/docker-compose.yml"
  local dockerComposeDevFile="$gSUPABASE_NEXTDR_HOME/dev/docker-compose.dev.yml"
  
  # step 1: stop and remove the supabase docker containers and images
  ndr_logInfo "Stopping and removing Supabase Docker containers..."

  # if the home dir and compose file exists, we can query it for the service list and execute the compose down command.
  if [[ -f "$dockerComposeFile" ]]; then

    cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into supabase project dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }

    if [[ "$gUPGRADE_MODE" == true && "$gNDR_SUPABASE_GIT_VERSION_TAG_UPGRADE" == true ]]; then
      ndr_logInfo "Supabase tag upgrade mode detected, processing containers individually."

      for service in "${ndr_supabase_container_services[@]}"; do
        local image_update="${ndr_supabase_container_service_image_update[$service]}"
        if [[ -z "$image_update" ]]; then
          ndr_logError "Image update status not found for service [$service]."
          return 1
        fi

        if [[ "$image_update" == false ]]; then
          ndr_logDebug "Image for service [$service] is not updated in new version, issuing stop command."
        
          docker compose stop "$service"
          return_code=$?
          if [ $return_code -ne 0 ]; then
            ndr_logWarn "Failed to stop service [$service]."
            if (( cleanupOptions & NDR_SUPABASE_CLEANUP_OPTION_DEFAULT )); then
              return 1
            fi
          fi
          
          ndr_logInfo "Stopped service [$service]."
        else
          ndr_logDebug "Image for service [$service] is updated in new version, issuing compose down command to remove container."

          docker compose -p "$gNDR_SUPABASE_DOCKER_PROJECT_NAME" -f "$dockerComposeFile" down "$service"
          return_code=$?
          if [ $return_code -ne 0 ]; then
            ndr_logWarn "Failed to stop and remove Supabase Docker service [$service]."
            if (( cleanupOptions & NDR_SUPABASE_CLEANUP_OPTION_DEFAULT )); then
              return 1
            fi
          fi
          
          ndr_logInfo "Stopped and removed Supabase Docker service [$service]"
        fi
      done
      
      ndr_logInfo "Stopped and/or removed Supabase Docker containers for upgrade. Containers with updated images were removed, containers with unchanged images were stopped but not removed to preserve data and state for containers to be restarted."
    else
      #docker compose -p "$gNDR_SUPABASE_DOCKER_PROJECT_NAME" -f "$dockerComposeFile" -f "$dockerComposeDevFile" down -v --remove-orphans
      docker compose -p "$gNDR_SUPABASE_DOCKER_PROJECT_NAME" -f "$dockerComposeFile" down -v
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logWarn "Failed to stop and remove Supabase Docker container"
        if (( cleanupOptions & NDR_SUPABASE_CLEANUP_OPTION_DEFAULT )); then
          return 1
        fi
      fi
      ndr_logInfo "Stopped and removed Supabase Docker container"
    fi

  else
    ndr_logWarn "Docker compose file [$dockerComposeFile] not found, skipping compose down command."
  fi
  
  if [ ${#ndr_supabase_container_services[@]} -eq 0 ]; then
    ndr_RegistryReadServiceEntries
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Failed to read service entries from registry."
      #return 1
    fi
  fi  

  if [ ${#ndr_supabase_container_services[@]} -eq 0 ]; then
    ndr_logWarn "No service entries found in compose or registry to act on."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # After constainer removal and before image cleanup, we may need to execute a permissions correction command on the db container for the pgsodium key.
  if [[ "$gNDR_SUPABASE_GIT_VERSION_TAG_UPGRADE" == true && "$gNDR_SUPABASE_USE_LATEST_POSTGRES_IMAGE" == false ]]; then
    local service="$NDR_SUPABASE_APP_SERVICE_NAME_DB"
    local db_image_update="${ndr_supabase_container_service_image_update[$service]}"
    if [[ -n "$db_image_update" && "$db_image_update" == true ]]; then
    
      ndr_logInfo "Executing permissions correction command on DB container for pgsodium key as part of upgrade process."
      
      #correction_cmd="docker compose -p \"$gNDR_SUPABASE_DOCKER_PROJECT_NAME\" -f \"$dockerComposeFile\" exec -T \"$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME\" chown postgres:postgres /var/lib/postgresql/pgsodium/pgsodium.key"
      local correction_cmd="docker compose run --rm --no-deps \"$NDR_SUPABASE_APP_SERVICE_NAME_DB\" \
          chown postgres:postgres /etc/postgresql-custom/pgsodium_root.key && \
          docker compose run --rm --no-deps \"$NDR_SUPABASE_APP_SERVICE_NAME_DB\" \
          chmod 600 /etc/postgresql-custom/pgsodium_root.key"
      
      eval "$correction_cmd"
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Failed to execute permissions correction command on DB container for pgsodium key. Command: [$correction_cmd]"
        # Not critical enough to fail the entire process, so just log a warning and continue.
        return 1
      else
        ndr_logInfo "Successfully executed permissions correction command on DB container for pgsodium key."
      fi
    fi
  fi

  # perform image cleanup.
  imageFailed=0

  for service in "${ndr_supabase_container_services[@]}"; do
    if [[ "$gNDR_RETAIN_DOCKER_IMAGES" == true ]]; then
      ndr_logInfo "Global flag to retain Docker images is set, skipping delete of [$service]"
      continue
    fi

    # if the service image is not updated in the new version, skip image cleanup to preserve for reuse in case of upgrade.
    if [[ "$gNDR_SUPABASE_GIT_VERSION_TAG_UPGRADE" == true ]]; then
      local db_image_update="${ndr_supabase_container_service_image_update[$service]}"
      if [[ -n "$db_image_update" && "$db_image_update" == false ]]; then
        ndr_logInfo "Image for service [$service] is not updated in new version, skipping image cleanup to preserve for reuse."
        continue
      fi
    fi

    local dockerAppManageOptions="$NDR_DOCKER_APP_MANAGE_OPTIONS_REMOVE_NO_PROMPT"
    local dockerImage="${ndr_supabase_container_service_image_tags[$service]}"

    ndr_cleanupDockerImage "$dockerImage" "$dockerAppManageOptions"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to remove Docker image [$dockerImage]."
      imageFailed=1
      continue
    fi
  done

  if [ $imageFailed -eq 1 ]; then
    ndr_logError "One or more Supabase Docker images were not removed. Please check the logs for details."
    #return 1
  else
    ndr_logInfo "All Supabase Docker images removed."
  fi
  
  # for upgrades, we do not need to remove the network or bind mounted volumes as these will be reused by the new containers. For fresh installs, we want to remove all existing artifacts to ensure a clean state.
  if [[ "$gUPGRADE_MODE" == true ]]; then
    ndr_logInfo "Upgrade mode detected, skipping removal of Docker network and folders to preserve data and state for new containers."
  else
    # remove bridge network
    if ! docker network ls --format '{{.Name}}' | grep -q "^${NDR_DOCKER_BRIDGE_NETWORK_NAME}$"; then
      ndr_logInfo "Docker network not found [$NDR_DOCKER_BRIDGE_NETWORK_NAME]."
    else
      output=$(docker network rm "$NDR_DOCKER_BRIDGE_NETWORK_NAME" 2>&1)
      return_code=$?
      if [ $return_code != 0 ]; then
        if echo "$output" | grep -q "network .* is in use"; then
          ndr_logWarn "Cannot remove Docker network '$NDR_DOCKER_BRIDGE_NETWORK_NAME': It is currently in use by one or more containers."
        else
          ndr_logWarn "Failed to remove Docker network [$NDR_DOCKER_BRIDGE_NETWORK_NAME]."
        fi
      else
        ndr_logInfo "Removed Docker network [$NDR_DOCKER_BRIDGE_NETWORK_NAME]."
      fi
    fi

    # step 2: remove all directories and files related to the supabase project
    ndr_logInfo "Removing Supabase project directories and files..."

    ndr_logInfo "Cleaning up bind-mounted directories."
    BIND_MOUNTS=(
      "$gSUPABASE_NEXTDR_HOME/volumes/db/data"
    )

    for DIR in "${BIND_MOUNTS[@]}"; do
      if [ -d "$DIR" ]; then
        ndr_logInfo "Deleting $DIR..."
        rm -rf "$DIR"
      else
        ndr_logInfo "Directory $DIR does not exist. Skipping bind mount deletion."
      fi
    done

    ndr_logInfo "Removing Supabase project directory [$gSUPABASE_NEXTDR_HOME] and template directory [$gSUPABASE_TEMPLATE_HOME]..."
    if [ -d "$gSUPABASE_NEXTDR_HOME" ]; then
      rm -rf "$gSUPABASE_NEXTDR_HOME"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "Failed to remove Supabase project directory [$gSUPABASE_NEXTDR_HOME]. Please check permissions and try again."
        #return 1
      fi
    else
      ndr_logInfo "Supabase project directory [$gSUPABASE_NEXTDR_HOME] does not exist."
    fi

    if [ -d "$gSUPABASE_TEMPLATE_HOME" ]; then
      rm -rf "$gSUPABASE_TEMPLATE_HOME"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "Failed to remove Supabase template directory [$gSUPABASE_TEMPLATE_HOME]. Please check permissions and try again."
        #return 1
      fi
    else
      ndr_logInfo "Supabase template directory [$gSUPABASE_TEMPLATE_HOME] does not exist."
    fi
  fi
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseLocalSchemaFileCheck ()
{
  local logSectionDesc="Local $gCOMPANY_NAME schema file check"
  ndr_logSecStart "$logSectionDesc"
  
  #if [ "$gEXPRESS_MODE" == true ]; then
  #  ndr_logInfo "Skipping local $gCOMPANY_NAME schema file check in express mode."
  #  return 0
  #fi

  # check for local NDR schema file. 
  # first check if the file is present in the home directory.
  # If not in the home folder, check if the file is present in the same folder as the script.

  # If not present, prompt user to exit and run the supabase db pull command to generate the file.
  if [ -z "$gACTIVE_NDR_SQL_SCHEMA_FILE" ]; then
    # active schema file variable not populated. populate and recheck
    if [ -f "${gNEXTDR_HOME_DIR}/${gNDR_REFERENCE_SQL_SCHEMA_FILENAME}" ]; then
      gACTIVE_NDR_SQL_SCHEMA_FILE="${gNEXTDR_HOME_DIR}/${gNDR_REFERENCE_SQL_SCHEMA_FILENAME}"
      ndr_logInfo "Found local $gCOMPANY_NAME schema file in home directory [$gACTIVE_NDR_SQL_SCHEMA_FILE]"
    elif [ -f "${PWD}/${gNDR_REFERENCE_SQL_SCHEMA_FILENAME}" ]; then
      gACTIVE_NDR_SQL_SCHEMA_FILE="$PWD/$gNDR_REFERENCE_SQL_SCHEMA_FILENAME"
      ndr_logInfo "Found local $gCOMPANY_NAME schema file in script folder [$gACTIVE_NDR_SQL_SCHEMA_FILE]"
    else
      ndr_logError "Local $gCOMPANY_NAME schema file not found in home directory or script folder."
    fi
  fi
  
  if [ ! -f "$gACTIVE_NDR_SQL_SCHEMA_FILE" ]; then
    ndr_logWarn "WARNING: Local copy of $gCOMPANY_NAME schema file [$gNDR_REFERENCE_SQL_SCHEMA_FILENAME] not found."
    ndr_logInfo "This file is required to seed the Supabase Docker container with the $gCOMPANY_NAME schema upon startup and, without it, the database would be empty and require manual injection of the SQL schema after installation."
    return 1
  fi

  # check for a schema DIFF file for upgrade scenarios.
  # deprecated in favor of dynamic diff generation strategy, but leaving code in place for now in case we want to refer back.
  if false; then
  if [ "$gUPGRADE_MODE" == true ]; then
    while true; do
      # Always check for and assign installed schema filename to baseline schema file var for later checksum operations.
      if [[ -z "$gNEXTDR_HOME_DIR" ]]; then
        gNEXTDR_HOME_DIR=$(ndr_getHomeDirReg)
        return_code=$?
        if [[ $return_code -ne 0 || -z "$gNEXTDR_HOME_DIR" ]]; then
          ndr_logError "Failed to retrieve home dir from registry."
          # turn on dynamic diff generation strategy.
          gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY="$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY_DYNAMIC"
          break
        fi
      fi
      gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL="$gNEXTDR_HOME_DIR/$gSUPABASE_NEXTDR_SUB/$gNDR_REFERENCE_SQL_SCHEMA_FILENAME"
      if [[ ! -f "$gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL" ]]; then
        ndr_logError "Installed schema file not found at expected location [$gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL]. Schema diff will be regenerated on the fly."
        # turn on dynamic diff generation strategy since the packaged diff is not found.
        gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY="$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY_DYNAMIC"
        break
      fi
      ndr_logInfo "Using installed schema file for baseline: $gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL"
      
      gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL="$gACTIVE_NDR_SQL_SCHEMA_FILE"

      # If cmdline option was explicitly given to ignore packaged diff file and dynamically regen the diff, skip all further diff file validation steps below.
      if [[ "$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY" == "$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY_DYNAMIC" ]]; then
        ndr_logInfo "Schema diff file generation is enabled, skipping schema validation."
        gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF=""
        break
      fi

      # check for diff schema in package
      local diffSchemaFile="${gSCRIPT_HOME_DIR}/${gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF_FILENAME_SHORT}"
      if [ ! -f "$diffSchemaFile" ]; then
        ndr_logInfo "No local $gCOMPANY_NAME schema DIFF file found for upgrade. Schema diff will be regenerated on the fly."
        # turn on dynamic diff generation strategy since the packaged diff is not found.
        gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY="$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY_DYNAMIC"
        break
      fi
      ndr_logInfo "Found local $gCOMPANY_NAME schema DIFF file [$diffSchemaFile] for upgrades."
      
      # read checksum of FULL schema file from the DIFF schema header.
      ndr_logInfo "Checking schema diff for compatibility..."
      ndr_SupabaseSchemaDiffHeaderVerify "$diffSchemaFile"
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logWarn "Failed to validate schema diff. Schema diff will be regenerated on the fly."
        # turn on dynamic diff generation strategy since the packaged diff is invalid.
        gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY="$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY_DYNAMIC"
        break
      fi
      
      # Diff schema is good to go, preserve values
      gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF="$diffSchemaFile"
      gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY="$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY_REPLAY"

      break
    done
  fi
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_customizeSupabaseDockerComposeFile () 
{
  local logSectionDesc="Customizing $gCOMPANY_NAME supabase docker compose file"
  ndr_logSecStart "$logSectionDesc"

  local appBuildOptions="${1:-$NDR_SUPABASE_APP_BUILD_OPTIONS_NONE}"
  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_NONE )); then
    ndr_logInfo "No build options specified."
    return 1
  fi

  if [[ "$gUPGRADE_MODE" == true && "$gNDR_SUPABASE_GIT_VERSION_TAG_UPGRADE" == false ]]; then
    ndr_logDebug "Supabase tag upgrade not enabled, skipping section."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  ndr_customizeSupabaseDockerComposeFileAddProjectName
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to customize supabase docker compose file to add project name."
    return 1
  fi
  ndr_logInfo "Successfully customized $gCOMPANY_NAME supabase docker compose file to add project name."

  ndr_customizeSupabaseDockerComposeFileUpdatePostgres
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to customize supabase docker compose file to update postgres service."
    return 1
  fi
  ndr_logInfo "Successfully customized $gCOMPANY_NAME supabase docker compose file to update postgres service."

  ndr_customizeSupabaseDockerComposeFileSimplifyServices
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to customize supabase docker compose file to simplify service list."
    return 1
  fi
  ndr_logInfo "Successfully customized $gCOMPANY_NAME supabase docker compose file service list"
  
  # customize the docker compose file to add the bridge network
  ndr_customizeSupabaseDockerComposeFileAddBridgeNetwork
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to customize supabase docker compose file to add bridge network."
    return 1
  fi
  ndr_logInfo "Successfully customized $gCOMPANY_NAME supabase docker compose file to add bridge network."
  
  # when using caddy, we need to disable certain ports in the compose file to not conflict with what caddy is listening in on.
  if [[ "$NDR_CADDY_ENABLED" == true ]]; then
    ndr_customizeSupabaseDockerComposeFileDisablePorts
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to customize supabase docker compose file to disable ports."
      return 1
    fi
    ndr_logInfo "Successfully customized $gCOMPANY_NAME supabase docker compose file to disable ports to support Caddy proxy."
  fi
  #read -n 1 -s -r -p "Press any key to continue..." ; echo
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_customizeSupabaseDockerComposeFileAddBridgeNetwork () 
{
  local logSectionDesc="Customizing $gCOMPANY_NAME supabase docker compose file to add bridge network"
  ndr_logSecStart "$logSectionDesc"

  local COMPOSE_FILE="${gSUPABASE_NEXTDR_HOME}/docker-compose.yml"
  
  ndr_CustomizeDockerComposeFileAddBridgeNetwork "$COMPOSE_FILE"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to add bridge network to compose file [$COMPOSE_FILE]."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_customizeSupabaseDockerComposeFileSimplifyServices () 
{
  local logSectionDesc="Customizing $gCOMPANY_NAME supabase docker compose file to simplify services"
  ndr_logSecStart "$logSectionDesc"

  if [[ "$gNDR_FULL_SUPABASE_SERVICES_MODE" == true ]]; then
    ndr_logInfo "Full Supabase services mode is enabled, skipping compose file service list simplification."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  local COMPOSE_FILE="${gSUPABASE_NEXTDR_HOME}/docker-compose.yml"
  local return_code=0
  local result=""
  local service_name=""
  local remaining_service=""
  local dependency_exists=""
  local depends_on_type=""
  local depends_on_length=0
  
  local -a remaining_services=()
  
  if [[ ! -f $COMPOSE_FILE ]]; then
    ndr_logError "Docker compose file [$COMPOSE_FILE] not found."
    return 1
  fi

  for service_name in "${NDR_SUPABASE_APP_OPTIONAL_SERVICES[@]}"; do
    result=$(yq eval ".services | has(\"$service_name\")" "$COMPOSE_FILE")
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to determine whether service [$service_name] exists in compose file [$COMPOSE_FILE]."
      return 1
    fi

    if [[ "$result" != "true" ]]; then
      ndr_logInfo "Service [$service_name] not present in compose file. Skipping removal."
      continue
    fi

    yq eval -i "del(.services.\"$service_name\")" "$COMPOSE_FILE"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to remove service [$service_name] from compose file [$COMPOSE_FILE]."
      return 1
    fi

    ndr_logInfo "Removed service [$service_name] from compose file."
  done

  mapfile -t remaining_services < <(yq eval '.services | keys | .[]' "$COMPOSE_FILE")
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to retrieve remaining services from compose file [$COMPOSE_FILE]."
    return 1
  fi

  for remaining_service in "${remaining_services[@]}"; do
    result=$(yq eval ".services.\"$remaining_service\" | has(\"depends_on\")" "$COMPOSE_FILE")
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to determine whether service [$remaining_service] has dependencies in compose file [$COMPOSE_FILE]."
      return 1
    fi

    if [[ "$result" != "true" ]]; then
      continue
    fi

    depends_on_type=$(yq eval ".services.\"$remaining_service\".depends_on | type" "$COMPOSE_FILE")
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to read dependency type for service [$remaining_service] in compose file [$COMPOSE_FILE]."
      return 1
    fi

    for service_name in "${NDR_SUPABASE_APP_OPTIONAL_SERVICES[@]}"; do
      dependency_exists="false"

      if [[ "$depends_on_type" == "!!seq" ]]; then
        dependency_exists=$(yq eval ".services.\"$remaining_service\".depends_on[] | select(. == \"$service_name\")" "$COMPOSE_FILE" 2>/dev/null)
        return_code=$?
        if [[ $return_code -ne 0 && $return_code -ne 1 ]]; then
          ndr_logError "Failed checking dependency [$service_name] on service [$remaining_service] in compose file [$COMPOSE_FILE]."
          return 1
        fi

        if [[ "$dependency_exists" == "$service_name" ]]; then
          yq eval -i "del(.services.\"$remaining_service\".depends_on[] | select(. == \"$service_name\"))" "$COMPOSE_FILE"
          return_code=$?
          if [ $return_code -ne 0 ]; then
            ndr_logError "Failed to remove dependency [$service_name] from service [$remaining_service] in compose file [$COMPOSE_FILE]."
            return 1
          fi

          ndr_logInfo "Removed dependency [$service_name] from service [$remaining_service]."
        fi
      elif [[ "$depends_on_type" == "!!map" ]]; then
        dependency_exists=$(yq eval ".services.\"$remaining_service\".depends_on | has(\"$service_name\")" "$COMPOSE_FILE")
        return_code=$?
        if [ $return_code -ne 0 ]; then
          ndr_logError "Failed checking mapped dependency [$service_name] on service [$remaining_service] in compose file [$COMPOSE_FILE]."
          return 1
        fi

        if [[ "$dependency_exists" == "true" ]]; then
          yq eval -i "del(.services.\"$remaining_service\".depends_on.\"$service_name\")" "$COMPOSE_FILE"
          return_code=$?
          if [ $return_code -ne 0 ]; then
            ndr_logError "Failed to remove mapped dependency [$service_name] from service [$remaining_service] in compose file [$COMPOSE_FILE]."
            return 1
          fi

          ndr_logInfo "Removed dependency [$service_name] from service [$remaining_service]."
        fi
      fi
    done

    result=$(yq eval ".services.\"$remaining_service\" | has(\"depends_on\")" "$COMPOSE_FILE")
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to verify dependencies after cleanup for service [$remaining_service] in compose file [$COMPOSE_FILE]."
      return 1
    fi

    if [[ "$result" == "true" ]]; then
      depends_on_length=$(yq eval ".services.\"$remaining_service\".depends_on | length" "$COMPOSE_FILE")
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Failed to determine dependency count for service [$remaining_service] in compose file [$COMPOSE_FILE]."
        return 1
      fi

      if [[ "$depends_on_length" == "0" ]]; then
        yq eval -i "del(.services.\"$remaining_service\".depends_on)" "$COMPOSE_FILE"
        return_code=$?
        if [ $return_code -ne 0 ]; then
          ndr_logError "Failed to remove empty depends_on block from service [$remaining_service] in compose file [$COMPOSE_FILE]."
          return 1
        fi

        ndr_logInfo "Removed empty depends_on block from service [$remaining_service]."
      fi
    fi
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_customizeSupabaseDockerComposeFileUpdatePostgres ()
{
  local logSectionDesc="Customizing $gCOMPANY_NAME supabase docker compose file to update postgres service"
  ndr_logSecStart "$logSectionDesc"
  
  # +++ this check is primarily for fresh installs until supabase makes the new version default. 
  # on upgrades, we want to carry forward the same logic as fresh and whether we even get here is validated during the upgrade checks.
  if [[ "$gNDR_SUPABASE_USE_LATEST_POSTGRES_IMAGE" != true ]]; then
    ndr_logInfo "Postgres major version upgrade not enabled, skipping section."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  ndr_version_ge "$gNDR_SUPABASE_GIT_VERSION_TAG" "1.26.04"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logInfo "Supabase version [$gNDR_SUPABASE_GIT_VERSION_TAG] is below 1.26.04, skipping Postgres image update."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  local COMPOSE_FILE="${gSUPABASE_NEXTDR_HOME}/docker-compose.yml"
  local PG17_COMPOSE_FILE="${gSUPABASE_NEXTDR_HOME}/docker-compose.pg17.yml"

  if [[ ! -f "$COMPOSE_FILE" ]]; then
    ndr_logError "Docker compose file [$COMPOSE_FILE] not found."
    return 1
  fi

  local current_db_image
  current_db_image=$(yq eval ".services.\"$NDR_SUPABASE_APP_SERVICE_NAME_DB\".image" "$COMPOSE_FILE")
  return_code=$?
  if [[ $return_code -ne 0 || -z "$current_db_image" || "$current_db_image" == "null" ]]; then
    ndr_logError "Failed to read existing Postgres image from compose file [$COMPOSE_FILE]."
    return 1
  fi

  # eg: supabase/postgres:17.6.1.084
  local current_db_tag="${current_db_image##*:}"
  current_db_tag="${current_db_tag%%@*}"
  local current_db_major="${current_db_tag%%.*}"
  if [[ "$current_db_major" =~ ^[0-9]+$ && $current_db_major -ge 17 ]]; then
    ndr_logInfo "Postgres image in compose file is already version 17 or higher [$current_db_image], skipping update."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  if [[ ! -f "$PG17_COMPOSE_FILE" ]]; then
    ndr_logError "Postgres 17 helper compose file [$PG17_COMPOSE_FILE] not found."
    return 1
  fi

  local db_image
  db_image=$(yq eval ".services.\"$NDR_SUPABASE_APP_SERVICE_NAME_DB\".image" "$PG17_COMPOSE_FILE")
  return_code=$?
  if [[ $return_code -ne 0 || -z "$db_image" || "$db_image" == "null" ]]; then
    ndr_logError "Failed to read Postgres image from helper compose file [$PG17_COMPOSE_FILE]."
    return 1
  fi

  yq eval -i ".services.\"$NDR_SUPABASE_APP_SERVICE_NAME_DB\".image = \"$db_image\"" "$COMPOSE_FILE"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to update Postgres image in compose file [$COMPOSE_FILE]."
    return 1
  fi

  ndr_logInfo "Updated Postgres image in compose file from [$current_db_image] to [$db_image]."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_customizeSupabaseDockerComposeFileAddProjectName () 
{
  local logSectionDesc="Customizing $gCOMPANY_NAME supabase docker compose file to add project name"
  ndr_logSecStart "$logSectionDesc"
  
  local COMPOSE_FILE="${gSUPABASE_NEXTDR_HOME}/docker-compose.yml"
  
  if [[ ! -f $COMPOSE_FILE ]]; then
    ndr_logError "Docker compose file [$COMPOSE_FILE] not found."
    return 1
  fi

  ndr_logInfo "Customizing $gCOMPANY_NAME project Docker compose file [$COMPOSE_FILE]."

  # Replace first occurrence of 'name: supabase' with 'name: ndr-supabase'
  yq eval -i ".name = \"${gNDR_SUPABASE_DOCKER_PROJECT_NAME}\"" "$COMPOSE_FILE"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Failed to change top level container stack entry to \"$gNDR_SUPABASE_DOCKER_PROJECT_NAME\" in compose file."
    #return 1
  fi
  ndr_logInfo "Changed top level container stack entry to \"$gNDR_SUPABASE_DOCKER_PROJECT_NAME\" in compose file."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_customizeSupabaseDockerComposeFileDisablePorts () 
{
  local logSectionDesc="Customizing $gCOMPANY_NAME supabase docker compose file to disable ports"
  ndr_logSecStart "$logSectionDesc"
  
  local COMPOSE_FILE="${gSUPABASE_NEXTDR_HOME}/docker-compose.yml"
  
  if [[ ! -f $COMPOSE_FILE ]]; then
    ndr_logError "Docker compose file [$COMPOSE_FILE] not found."
    return 1
  fi

  ndr_logInfo "Customizing $gCOMPANY_NAME project Docker compose file [$COMPOSE_FILE]."

  # Remove only the https port entry under kong service
  local service_name="$NDR_SUPABASE_APP_SERVICE_NAME_KONG"
  local ports_exist
  ports_exist=$(yq eval ".services.\"$service_name\" | has(\"ports\")" "$COMPOSE_FILE")
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Failed to determine whether ports section exists for service [$service_name] in compose file."
  fi

  if [ "$ports_exist" == "true" ]; then
    local https_port="8443"
    mapfile -t port_entries < <(yq eval ".services.\"$service_name\".ports[]" "$COMPOSE_FILE")
    local https_removed=false

    for port_entry in "${port_entries[@]}"; do
      if [[ "$port_entry" == *":$https_port"* || "$port_entry" == "$https_port"* ]]; then
        yq eval -i "del(.services.\"$service_name\".ports[] | select(. == \"$port_entry\"))" "$COMPOSE_FILE"
        return_code=$?
        if [ $return_code != 0 ]; then
          ndr_logWarn "Failed to remove HTTPS port entry [$port_entry] for service [$service_name] in compose file."
          return 1
        fi
        ndr_logInfo "Removed HTTPS port entry [$port_entry] for service [$service_name] in compose file."
        https_removed=true
      fi
    done

    if [ "$https_removed" == false ]; then
      ndr_logInfo "No HTTPS port entry found for service [$service_name] in compose file. Skipping removal."
    fi
  else
    ndr_logInfo "Ports section not present for service [$service_name] in compose file. Skipping removal."
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_verifySupabaseContainersExist ()
{
  local logSectionDesc="Verifying Supabase containers exist"
  ndr_logSecStart "$logSectionDesc"

  if [[ -z "$gNEXTDR_HOME_DIR" || -z "$gSUPABASE_NEXTDR_HOME" ]]; then
    ndr_logError "Invalid home or project directory."
    return 1
  fi

  if [ ${#ndr_supabase_container_services[@]} -eq 0 ]; then
    ndr_RegistryReadServiceEntries
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to read Supabase Docker service entries from registry."
      return 1
    fi
  fi

  if [ ${#ndr_supabase_container_services[@]} -eq 0 ]; then
    ndr_logInfo "No Supabase service array entries found."
    return 1
  fi

  ndr_logInfo "Verifying ${#ndr_supabase_container_services[@]} Supabase service entries."

  local containerFailed=0

  for service in "${ndr_supabase_container_services[@]}"; do
    local container_name="${ndr_supabase_container_service_container_names[$service]}"
    local image_name="${ndr_supabase_container_service_image_names[$service]}"
    local image_tag="${ndr_supabase_container_service_image_tags[$service]}"

    # check if the supabase container exists
    local containerCheck="$container_name" #"$image_name:$image_tag"
    ndr_verifyDockerContainerExists "$containerCheck"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Supabase Docker container [$containerCheck] does not exist."
      containerFailed=1
      continue
    fi

    ndr_CheckContainerHealth "$container_name"
    return_code=$?
    if [[ $return_code -eq 0 ]]; then
      ndr_logInfo "Docker container returned healthy status [$container_name]."
      #retVal=0
    else
      ndr_logWarn "Docker container returned non-healthy status [$container_name]."
      local logs_output=$(docker logs --tail 50 "$container_name" 2>&1)
      if [[ -n "$logs_output" ]]; then
        ndr_logWarn "$logs_output"
      fi
      #retVal=1
    fi
  done

  if [ $containerFailed -eq 0 ]; then
    ndr_logInfo "All Supabase Docker containers exist."
  else
    ndr_logError "One or more Supabase Docker containers do not exist. Please check the logs for details."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

check_url() {
  curl -Is --max-time 3 "$1" >/dev/null 2>&1
}

function ndr_SupabaseInstallCompletePopulateReport ()
{
  # Populate installation report with Supabase info
  ndr_logInfo "Populating installation report with Supabase info."

  local remoteURL="http://$gNDR_SERVER_HOST_ADDRESS:8000"
  local localURL="http://localhost:8000"

  ndr_InstallationReportAddEntry "The $gCOMPANY_NAME $gPRODUCT_VERSION application suite installation has been installed successfully at [$gNEXTDR_HOME_DIR]."
  ndr_InstallationReportAddEntry "You can access the Supabase Studio through the API gateway on port 8000."
  ndr_InstallationReportAddEntry "$remoteURL, or $localURL if you are accessing Docker locally."
  if [[ -n "$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME" && -n "$gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD" ]]; then
    ndr_InstallationReportAddEntry "The Supabase Dashboard user account is: \"$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME\" password: \"$gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD\""
  fi
  if [[ -n "$gNDR_CONSOLE_ADMIN_ACCOUNT_USER" && -n "$gNDR_CONSOLE_ADMIN_ACCOUNT_PASSWORD" ]]; then
    ndr_InstallationReportAddEntry "The $gCOMPANY_NAME Admin Console user account is: \"$gNDR_CONSOLE_ADMIN_ACCOUNT_USER\" password: \"$gNDR_CONSOLE_ADMIN_ACCOUNT_PASSWORD\""
  fi
  ndr_InstallationReportAddEntry "Please check the .env file in the folder [$gSUPABASE_NEXTDR_HOME] for full dashboard configuration."
  
  return 0
}

function ndr_SupabaseInstallCompleteNotify ()
{
  # Accessing Supabase Studio
  # You can access Supabase Studio through the API gateway on port 8000. For example: http://<your-ip>:8000, or localhost:8000 if you are running Docker locally.

  # You will be prompted for a username and password. By default, the credentials are:

  # Username: supabase
  # Password: this_password_is_insecure_and_should_be_updated

  # Need to change credentials and secrets to secure values
  # Update the ./docker/.env file with your own secrets. In particular, these are required:

  # POSTGRES_PASSWORD: the password for the postgres role.
  # JWT_SECRET: used by PostgREST and GoTrue, among others.

  # Dashboard authentication
  # The Dashboard is protected with basic authentication. The default user and password MUST be updated before using Supabase in production.
  # Update the following values in the ./docker/.env file:

  # DASHBOARD_PASSWORD: The default password for the Dashboard

  local remoteURL="http://$gNDR_SERVER_HOST_ADDRESS:8000"
  local localURL="http://localhost:8000"

  ndr_PrintInstallationReport

  return 0
}

function ndr_CreateSupabaseFolders ()
{
  # Create your desired working directory:
  # Tree should look like this
  # .
  # ├── supabase-template
  # └── supabase
  
  local logSectionDesc="Cleaning and creating new application folders"
  ndr_logSecStart "$logSectionDesc"
  
  if [[ -z "$gNEXTDR_HOME_DIR" || -z "$gSUPABASE_NEXTDR_HOME" ]]; then
    ndr_logError "Invalid home or project directory."
    return 1
  fi

  # template section -- this is a temporary folder and can always be cleaned up.
  local folder="$gSUPABASE_TEMPLATE_HOME"
  ndr_logInfo "Cleaning up existing supabase template directory [$folder] if it exists."
  rm -rf "$folder"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to clean up existing supabase template directory [$folder]."
    #return 1
  fi

  ndr_logInfo "Creating supabase template directory at [$folder]."
  mkdir "$folder"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create directory [$folder]. Please check permissions and try again."
    return 1
  fi
  
  # supabase home section. This should never be cleaned up for upgrades--we either re-use as-is for simple, non-tag upgrades or we merge in changes from the new template for tag upgrades.
  if [[ "$gUPGRADE_MODE" == false ]]; then
    folder="$gSUPABASE_NEXTDR_HOME"
    # cleanup only for new installs or or upgrades where the supabase tag is being updated.
    ndr_logInfo "Cleaning up existing supabase home directory [$folder] if it exists."
    rm -rf "$folder"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to clean up existing supabase home directory [$folder]."
      #return 1
    fi
    
    ndr_logInfo "Creating supabase home directory at [$folder]."
    mkdir "$folder"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to create directory [$folder]. Please check permissions and try again."
      return 1
    fi
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_PullSupabaseGitTemplate ()
{
  # To pull supabase docker code from GIT
  # This is a very lengthy process and will take several minutes or more depending on connectivity speed.
  local logSectionDesc="Cloning a local supabase template from GIT"
  ndr_logSecStart "$logSectionDesc"

  if [[ "$gUPGRADE_MODE" == true && "$gNDR_SUPABASE_GIT_VERSION_TAG_UPGRADE" == false ]]; then
    ndr_logDebug "Supabase tag upgrade not enabled, skipping section."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  cd "$gSUPABASE_TEMPLATE_HOME" || { ndr_logError "Failed to cd into supabase template dir [$gSUPABASE_TEMPLATE_HOME]"; return 1; }

  local checkoutTag="$gNDR_SUPABASE_GIT_VERSION_TAG"

  # first check if we can update to a more recent tag.
  if [ "$gNDR_SUPABASE_GIT_VERSION_ALLOW_TAG_UPDATE" == true ]; then
    ndr_logInfo "Option to query for latest release tag is enabled."
    ndr_SupabaseQueryLatestTag
    return_code=$?
    if [[ $return_code != 0 ]]; then
      ndr_logWarn "Failed to query latest release tag from GitHub. Will checkout base tag [$checkoutTag]"
      #return 0
    else
      checkoutTag="$gNDR_SUPABASE_GIT_VERSION_COMMIT_HASH_FULL"
    fi
  fi

  # then check if we can update to the latest commit hash for our given tag.
  if [ "$gNDR_SUPABASE_GIT_VERSION_ALLOW_COMMIT_HASH_UPDATE" == true ]; then
    ndr_logInfo "Option to query for latest granular commit after [$gNDR_SUPABASE_GIT_VERSION_TAG] is enabled."
    ndr_SupabaseQueryLatestCommit
    return_code=$?
    if [[ $return_code != 0 ]]; then
      ndr_logWarn "Failed to query latest commit hash from GitHub. Will checkout base tag [$checkoutTag]"
      #return 0
    else
      checkoutTag="$gNDR_SUPABASE_GIT_VERSION_COMMIT_HASH_FULL"
    fi
  fi

  ndr_logInfo "Cloning the Supabase template repository tag [$checkoutTag] from GitHub to [$gSUPABASE_TEMPLATE_HOME]"
  
  # advanced clone command
  git clone --filter=blob:none --no-checkout https://github.com/supabase/supabase "$gSUPABASE_TEMPLATE_HOME"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Git clone failed."
    return 1
  fi
  ndr_logInfo "Git clone for Supabase completed."

  git sparse-checkout set --cone docker
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "GIT sparse checkout for docker only folder failed."
    return 1
  fi
  ndr_logInfo "Git sparse checkout for Supabase completed."

  git checkout "$checkoutTag"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "GIT checkout for [$checkoutTag] failed."
    return 1
  fi
  ndr_logInfo "Git checkout for [$checkoutTag] completed."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_PreserveSupabaseConfigFiles ()
{
  # For upgrades where the supabase git tag is not being updated, we want to preserve the existing compose files and .env file in the project rather than copying over the template versions which would overwrite any customizations and potentially cause issues with the upgrade. 
  # For new installs or upgrades where the supabase git tag is being updated, we will copy over the template compose files and .env file since there are likely important updates to those files in the new tag that we want to make sure are included in the project.
  
  local logSectionDesc="Preserving existing compose and env files for Supabase upgrades"
  ndr_logSecStart "$logSectionDesc"

  # no need to preserve files on fresh installed or simple supabase no-tag upgrades.
  if [[ "$gUPGRADE_MODE" == true && "$gNDR_SUPABASE_GIT_VERSION_TAG_UPGRADE" == false ]]; then
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # create a new _tmp folder under the ndr home to store the backup copies of the compose and env files.
  local backupDir="$gNEXTDR_HOME_DIR/_tmp"
  mkdir -p "$backupDir"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create temporary backup directory [$backupDir] for compose and env file copies during upgrade."
    return 1
  fi

  ndr_logInfo "Tag upgrade mode enabled, creating backup copies of critical files before copying template files."
  cp -f "$gSUPABASE_NEXTDR_HOME/$NDR_STANDARD_DOCKER_COMPOSEFILE_FILENAME" "$backupDir/$NDR_STANDARD_DOCKER_COMPOSEFILE_FILENAME.bkp"
  if [ $? -ne 0 ]; then
    ndr_logError "Failed to backup existing $NDR_STANDARD_DOCKER_COMPOSEFILE_FILENAME file."
    return 1
  else
    ndr_logInfo "Backup of existing $NDR_STANDARD_DOCKER_COMPOSEFILE_FILENAME file created at [$backupDir/$NDR_STANDARD_DOCKER_COMPOSEFILE_FILENAME.bkp]."
  fi

  cp -f "$gSUPABASE_NEXTDR_HOME/${gNDR_ENV_TARGET_FILENAME}" "$backupDir/${gNDR_ENV_BACKUP_FILENAME}"
  if [ $? -ne 0 ]; then
    ndr_logError "Failed to backup existing .env file."
    return 1
  else
    ndr_logInfo "Backup of existing .env file created at [$backupDir/${gNDR_ENV_BACKUP_FILENAME}]."
  fi
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}
function ndr_CopySupabaseTemplateFiles ()
{
  # Copy the template compose files over to your project
  local logSectionDesc="Copying the template files to project"
  ndr_logSecStart "$logSectionDesc"

  if [[ "$gUPGRADE_MODE" == true && "$gNDR_SUPABASE_GIT_VERSION_TAG_UPGRADE" == false ]]; then
    ndr_logDebug "Supabase tag upgrade not enabled, skipping section."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # always need to copy the template files because there a number of files and folders other than the main yml needed here.
  cd "$gSCRIPT_HOME_DIR" || { ndr_logError "Failed to cd into install dir"; return 1; }
    
  # during tag upgrades, we want to be selective about which files we copy over from the template vs which ones we preserve in the project to avoid overwrite. 
  # For example, its critical we not overwrite the DB in /volumes/db.
  # For tag upgrades, we will compile an exclude list of files/folders to exclude from the copy and then use rsync with the exclude list to copy the files rather than a simple cp command. 
  # For new installs where the exlude list is empty, we can just do a normal copy of all the files.
  declare -a exclude_list=()

  if [[ "$gUPGRADE_MODE" == true && "$gNDR_SUPABASE_GIT_VERSION_TAG_UPGRADE" == true ]]; then
    exclude_list+=("/volumes/db/data")
  fi

  local src="$gSUPABASE_TEMPLATE_HOME/docker/*"
  local dest="$gSUPABASE_NEXTDR_HOME"

  if [[ ${#exclude_list[@]} -gt 0 ]]; then
    ndr_logInfo "Upgrade mode with tag upgrade enabled, using rsync with exclude list to copy template files while preserving critical existing files in project."
    local rsync_exclude_args=()
    for exclude_item in "${exclude_list[@]}"; do
      rsync_exclude_args+=(--exclude="$exclude_item")
    done

    src="$gSUPABASE_TEMPLATE_HOME/docker/"
    dest="$gSUPABASE_NEXTDR_HOME/"

    rsync -av "${rsync_exclude_args[@]}" "$src" "$dest"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to copy Base template files from [$src] to [$dest] using rsync with exclude list."
      return 1
    fi
    ndr_logInfo "Base template files copied from [$src] to [$dest] using rsync with exclude list while preserving existing files in project."
  else
    cp -rf $src $dest # note: DO NOT quote the args for cp command, otherwise it will not copy the files correctly with a stat failure.
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to copy Base template files [$src] to [$dest]"
      return 1
    fi
  fi
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_CopySupabaseSchemaFile ()
{
  local logSectionDesc="Copying the $gCOMPANY_NAME schema file to project"
  ndr_logSecStart "$logSectionDesc"
  
  # Copy the NDR schema file to the project.
  # we copy the schema to the ndr supabase home loc to store as a reference for the currently installed schema. This dir already exists so no need to create.
  
  local schemaDestLocation="${gSUPABASE_NEXTDR_HOME}"
  
  local schemaSrcFile="${gACTIVE_NDR_SQL_SCHEMA_FILE}"
  if [ -z "$schemaSrcFile" ] || [ ! -f "$schemaSrcFile" ]; then
    schemaSrcFile="${gSCRIPT_HOME_DIR}/${gNDR_REFERENCE_SQL_SCHEMA_FILENAME}"
  fi

  if [ -z "$schemaSrcFile" ] || [ ! -f "$schemaSrcFile" ]; then
    ndr_logError "No active Supabase schema file [$gACTIVE_NDR_SQL_SCHEMA_FILE] found."
    return 1
  fi

  local schemaDestFile="${schemaDestLocation}/${gNDR_REFERENCE_SQL_SCHEMA_FILENAME}"

  cp -f $schemaSrcFile $schemaDestFile
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to copy Supabase schema file [$schemaSrcFile] to [$schemaDestFile]"
    return 1
  fi
  ndr_logInfo "Successfully copied Supabase schema file [$schemaSrcFile] to [$schemaDestFile]"

  gACTIVE_NDR_SQL_SCHEMA_FILE="$schemaDestFile"
  ndr_logInfo "Updating active Supabase schema file as [$gACTIVE_NDR_SQL_SCHEMA_FILE]."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_CopySupabaseEnvFile ()
{
  local logSectionDesc="Copying the Supabase template env file to project"
  ndr_logSecStart "$logSectionDesc"
  
  # for upgrades, we still need to take the new env file for any new keys introduced but we also need to preserve any customized values from the previous env file.
  # To do this we want to merge the old env file values into the new template env file rather than just skipping the copy of the new template env file entirely.
  if [[ "$gUPGRADE_MODE" == true && "$gNDR_SUPABASE_GIT_VERSION_TAG_UPGRADE" == false ]]; then
    ndr_logDebug "Supabase tag upgrade not enabled, skipping section."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # Copy the supplied template env var file to the project.
  # its important to use the supplied template file because it is maintained by supabase and 
  # contains all essential vars pertinent to the image versions it is accompanied with.
  local envSrcFile="${gSUPABASE_TEMPLATE_HOME}/docker/${gNDR_SUPABASE_ENV_TEMPLATE_VAR_FILENAME}"
  local envDestFile="${gSUPABASE_NEXTDR_HOME}/${gNDR_SUPABASE_ENV_TEMPLATE_VAR_FILENAME}"
  cp -f "$envSrcFile" "$envDestFile"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to copy the Supabase template env file [$envSrcFile] to [$envDestFile]"
    return 1
  fi
  ndr_logInfo "Supabase template env file [$envSrcFile] copied to [$envDestFile]"

  # The parent install path under /opt is world-readable, so explicitly remove
  # all "other" permissions from the env file while preserving user/group bits.
  chmod o-rwx "$envDestFile"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to remove world permissions from Supabase env file [$envDestFile]"
    return 1
  fi
  ndr_logInfo "Removed world permissions from Supabase env file [$envDestFile]"
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_GenerateJWT () 
{
  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: <role> <jwt_secret>"
    return 1
  fi

  local role=$1
  local jwt_secret=$2
  local iat=$(date +%s)                   # current time
  local exp=1911700800                    # far future expiration (2030+)
  
  local header=$(printf '{"alg":"HS256","typ":"JWT"}' \
    | openssl base64 -e -A | tr '+/' '-_' | tr -d '=')
  local payload=$(printf '{"role":"%s","iss":"supabase","iat":%s,"exp":%s}' \
    "$role" "$iat" "$exp" \
    | openssl base64 -e -A | tr '+/' '-_' | tr -d '=')
  local signature=$(printf '%s.%s' "$header" "$payload" \
    | openssl dgst -binary -sha256 -hmac "$jwt_secret" \
    | openssl base64 -e -A | tr '+/' '-_' | tr -d '=')
  
  echo "${header}.${payload}.${signature}"

  return 0
}

function ndr_CustomizeSupabaseEnvFile ()
{
  local logSectionDesc="Customizing the Supabase env file"
  ndr_logSecStart "$logSectionDesc"

  local envSrcFile="${gSCRIPT_HOME_DIR}/${gNDR_SUPABASE_ENV_SOURCE_VAR_FILENAME}"
  local envDestFile="${gSUPABASE_NEXTDR_HOME}/${gNDR_ENV_TARGET_FILENAME}"
  local envDestFileTmp="${envDestFile}.tmp"  # Temporary output file

  # --- Check that files exist ---
  if [ ! -f "$envSrcFile" ]; then
    ndr_logError "Source file missing [$envSrcFile]"
    return 1
  fi
  if [ ! -f "$envDestFile" ]; then
    ndr_logError "Dest file missing [$envDestFile]"
    return 1
  fi
  if [[ -z "$gNDR_SERVER_HOST_ADDRESS" || "$gNDR_SERVER_HOST_ADDRESS" == "localhost" ]]; then
    ndr_logError "Target server host address not specified."
    return 1
  fi

  # --- customize secrets and keys ---
  # Generate a secure random JWT secret (hex string)
  gSUPABASE_ENV_VAL_JWT_SECRET=$(openssl rand -base64 30)
  if [[ $? -ne 0 || -z "$gSUPABASE_ENV_VAL_JWT_SECRET" ]]; then
    ndr_logError "OpenSSL failed to generate JWT secret"
    return 1
  fi
  
  # Generate anon and service role keys
  gSUPABASE_ENV_VAL_ANON_KEY=$(ndr_GenerateJWT "anon" "$gSUPABASE_ENV_VAL_JWT_SECRET")
  if [[ $? -ne 0 || -z "$gSUPABASE_ENV_VAL_ANON_KEY" ]]; then
    ndr_logError "Failed to generate anon key"
    return 1
  fi
  
  gSUPABASE_ENV_VAL_SERVICE_ROLE_KEY=$(ndr_GenerateJWT "service_role" "$gSUPABASE_ENV_VAL_JWT_SECRET")
  if [[ $? -ne 0 || -z "$gSUPABASE_ENV_VAL_SERVICE_ROLE_KEY" ]]; then
    ndr_logError "Failed to generate service role key"
    return 1
  fi

  gSUPABASE_ENV_VAL_PG_META_CRYPTO_KEY=$(openssl rand -base64 24)
  if [[ $? -ne 0 || -z "$gSUPABASE_ENV_VAL_PG_META_CRYPTO_KEY" ]]; then
    ndr_logError "OpenSSL failed to generate Postgres meta crypto key"
    return 1
  fi

  gSUPABASE_ENV_VAL_VAULT_ENC_KEY=$(openssl rand -hex 16)
  if [[ $? -ne 0 || -z "$gSUPABASE_ENV_VAL_VAULT_ENC_KEY" ]]; then
    ndr_logError "OpenSSL failed to generate Vault encryption key"
    return 1
  fi

  gSUPABASE_ENV_VAL_SECRET_KEY_BASE=$(openssl rand -base64 48)
  if [[ $? -ne 0 || -z "$gSUPABASE_ENV_VAL_SECRET_KEY_BASE" ]]; then
    ndr_logError "OpenSSL failed to generate secret key base"
    return 1
  fi

  gSUPABASE_ENV_VAL_LOGFLARE_PUBLIC_ACCESS_TOKEN=$(openssl rand -base64 24)
  if [[ $? -ne 0 || -z "$gSUPABASE_ENV_VAL_LOGFLARE_PUBLIC_ACCESS_TOKEN" ]]; then
    ndr_logError "OpenSSL failed to generate Logflare public access token"
    return 1
  fi
  gSUPABASE_ENV_VAL_LOGFLARE_PRIVATE_ACCESS_TOKEN=$(openssl rand -base64 24)
  if [[ $? -ne 0 || -z "$gSUPABASE_ENV_VAL_LOGFLARE_PRIVATE_ACCESS_TOKEN" ]]; then
    ndr_logError "OpenSSL failed to generate Logflare private access token"
    return 1
  fi

  gSUPABASE_ENV_VAL_S3_PROTOCOL_ACCESS_KEY_ID=$(openssl rand -hex 16)
  if [[ $? -ne 0 || -z "$gSUPABASE_ENV_VAL_S3_PROTOCOL_ACCESS_KEY_ID" ]]; then
    ndr_logError "OpenSSL failed to generate S3 protocol access key ID"
    return 1
  fi
  gSUPABASE_ENV_VAL_S3_PROTOCOL_ACCESS_KEY_SECRET=$(openssl rand -hex 32)
  if [[ $? -ne 0 || -z "$gSUPABASE_ENV_VAL_S3_PROTOCOL_ACCESS_KEY_SECRET" ]]; then
    ndr_logError "OpenSSL failed to generate S3 protocol access key secret"
    return 1
  fi

  gSUPABASE_ENV_VAL_MINIO_ROOT_PASSWORD=$(openssl rand -hex 16)
  if [[ $? -ne 0 || -z "$gSUPABASE_ENV_VAL_MINIO_ROOT_PASSWORD" ]]; then
    ndr_logError "OpenSSL failed to generate MinIO root password"
    return 1
  fi

  # global vars that will override any template env values
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_JWT_SECRET"]="$gSUPABASE_ENV_VAL_JWT_SECRET"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_ANON_KEY"]="$gSUPABASE_ENV_VAL_ANON_KEY"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_SERVICE_ROLE_KEY"]="$gSUPABASE_ENV_VAL_SERVICE_ROLE_KEY"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_DASHBOARD_USERNAME"]="$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_DASHBOARD_PASSWORD"]="$gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_PG_META_CRYPTO_KEY"]="$gSUPABASE_ENV_VAL_PG_META_CRYPTO_KEY"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_VAULT_ENC_KEY"]="$gSUPABASE_ENV_VAL_VAULT_ENC_KEY"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_POOLER_TENANT_ID"]="$gSUPABASE_ENV_VAL_POOLER_TENANT_ID"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_SECRET_KEY_BASE"]="$gSUPABASE_ENV_VAL_SECRET_KEY_BASE"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_LOGFLARE_PUBLIC_ACCESS_TOKEN"]="$gSUPABASE_ENV_VAL_LOGFLARE_PUBLIC_ACCESS_TOKEN"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_LOGFLARE_PRIVATE_ACCESS_TOKEN"]="$gSUPABASE_ENV_VAL_LOGFLARE_PRIVATE_ACCESS_TOKEN"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_S3_PROTOCOL_ACCESS_KEY_ID"]="$gSUPABASE_ENV_VAL_S3_PROTOCOL_ACCESS_KEY_ID"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_S3_PROTOCOL_ACCESS_KEY_SECRET"]="$gSUPABASE_ENV_VAL_S3_PROTOCOL_ACCESS_KEY_SECRET"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_MINIO_ROOT_PASSWORD"]="$gSUPABASE_ENV_VAL_MINIO_ROOT_PASSWORD"

  # --- Load custom supabase overrides into associative array ---
  declare -A src_map=()
  while IFS='=' read -r key value; do
    [[ -z "$key" || "$key" == \#* ]] && continue
    src_map["$key"]="$value"
  done < "$envSrcFile"

  ndr_logInfo "Read [${#src_map[@]}] custom values from source file [$envSrcFile] to update in target file [$envDestFile]."

  # --- Read template into array ---
  mapfile -t lines < "$envDestFile"
  if [[ $? -ne 0 ]]; then
    ndr_logError "Failed to read $envDestFile"
    return 1
  fi

  local new_lines=()
  declare -A seen_keys=()  # Tracks keys that already exist in dest

  local linesUpdated=0

  # --- Process template lines ---
  for line in "${lines[@]}"; do
    if [[ "$line" =~ ^([A-Za-z_][A-Za-z0-9_]*)=(.*)$ ]]; then
      key="${BASH_REMATCH[1]}"
      value="${BASH_REMATCH[2]}"
      seen_keys["$key"]=1

      if [[ -n "${src_map[$key]+_}" ]]; then
        value="${src_map[$key]}"
        ndr_logInfo "Overriding $key with custom value from source"
        linesUpdated=$((linesUpdated += 1))
      fi

      if [[ "$value" == *"localhost"* ]]; then
        value="${value//localhost/$gNDR_SERVER_HOST_ADDRESS}"
        ndr_logInfo "Updating host address key with actual value [$key=$value]"
        linesUpdated=$((linesUpdated += 1))
      fi

      new_lines+=("$key=$value")
    else
      new_lines+=("$line")
    fi
  done

  # --- Append any source keys not in the template ---
  for key in "${!src_map[@]}"; do
    if [[ -z "${seen_keys[$key]+_}" ]]; then
      ndr_logInfo "Adding missing key from source: $key"
      value="${src_map[$key]}"
      if [[ "$value" == *"localhost"* ]]; then
        value="${value//localhost/$gNDR_SERVER_HOST_ADDRESS}"
        ndr_logInfo "Updating host address key with actual value [$key=$value]"
      fi
      linesUpdated=$((linesUpdated += 1))
      new_lines+=("$key=$value")
    fi
  done

  # --- Override any template or source keys from global vars ---
  # Loop through global gSUPABASE_ENV_VARS and update/add in new_lines
  for key in "${!gSUPABASE_ENV_VARS[@]}"; do
    local found=0
    local value="${gSUPABASE_ENV_VARS[$key]}"
    # if the value is empty, skip immediately.
    if [ -z "$value" ]; then
      ndr_logWarn "Key [$key] had empty value, skipping..."
      continue
    fi
    for ii in "${!new_lines[@]}"; do
      local line="${new_lines[$ii]}"
      
      [[ -z "$line" || "$line" == \#* ]] && continue
      
      local line_key="${line%%=*}"
      if [[ "$line_key" == "$key" ]]; then
        new_lines[$ii]="$key=$value"
        found=1
        ndr_logInfo "Updating key [$key] with new value from env var map."
        break
      fi
    done
    if [[ $found -eq 0 ]]; then
      new_lines+=("$key=$value")
      ndr_logInfo "Adding new key [$key] from env var map."
    fi
  done
  
  # --- Open temp file for writing ---
  exec 3> "$envDestFileTmp" || {
    ndr_logError "Failed to open $envDestFileTmp for writing"
    return 1
  }

  # --- Write updated lines to temp file with error checking ---
  for l in "${new_lines[@]}"; do
    if ! printf '%s\n' "$l" >&3; then
      ndr_logError "Failed to write line to $envDestFileTmp: $l"
      exec 3>&-
      return 1
    fi
  done

  # --- Close temp file descriptor ---
  exec 3>&-

  # --- Move temp file into place ---
  if ! mv "$envDestFileTmp" "$envDestFile"; then
    ndr_logError "Failed to replace $envDestFile with updated content"
    return 1
  fi

  # make optional secure caddy changes to env file urls
  if [[ "$NDR_CADDY_ENABLED" == true ]]; then
    ndr_CustomizeSupabaseEnvFileCaddy "$envDestFile"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to customize the Supabase env file for secure caddy mode [$envDestFile]"
      return 1
    fi
    ndr_logInfo "Supabase env file successfully configured for secure caddy mode [$envDestFile]"
  fi

  ndr_logInfo "Environment file [$envDestFile] successfully updated with [$linesUpdated] values"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_CustomizeSupabaseEnvFileV2 ()
{
  local logSectionDesc="Customizing the Supabase env file"
  ndr_logSecStart "$logSectionDesc"

  local templateEnvFile="${gSUPABASE_NEXTDR_HOME}/${gNDR_SUPABASE_ENV_TEMPLATE_VAR_FILENAME}"
  local backupEnvFile="${gNEXTDR_HOME_DIR}/_tmp/${gNDR_ENV_BACKUP_FILENAME}"
  local customizedEnvFile="${gSUPABASE_NEXTDR_HOME}/${gNDR_ENV_TARGET_FILENAME}"
  local customizedEnvFileTmp="${customizedEnvFile}.tmp"  # Temporary output file

  # --- Check that files exist ---
  if [ ! -f "$templateEnvFile" ]; then
    ndr_logError "Template env file missing [$templateEnvFile]"
    return 1
  fi
  if [[ -z "$gNDR_SERVER_HOST_ADDRESS" || "$gNDR_SERVER_HOST_ADDRESS" == "localhost" ]]; then
    ndr_logError "Target server host address not specified."
    return 1
  fi

  declare -A backup_env_map=()
  if [[ "$gUPGRADE_MODE" == true && "$gNDR_SUPABASE_GIT_VERSION_TAG_UPGRADE" == true ]]; then
    if [ ! -f "$backupEnvFile" ]; then
      ndr_logError "Backup env file missing [$backupEnvFile]"
      return 1
    fi

    while IFS='=' read -r key value; do
      [[ -z "$key" || "$key" == \#* ]] && continue
      backup_env_map["$key"]="$value"
    done < "$backupEnvFile"

    ndr_logInfo "Read [${#backup_env_map[@]}] values from backup env file [$backupEnvFile]."
  fi

  # --- customize secrets and keys ---
  # Generate a secure random JWT secret (hex string)
  gSUPABASE_ENV_VAL_JWT_SECRET=$(openssl rand -base64 30)
  if [[ $? -ne 0 || -z "$gSUPABASE_ENV_VAL_JWT_SECRET" ]]; then
    ndr_logError "OpenSSL failed to generate JWT secret"
    return 1
  fi
  
  # Generate anon and service role keys
  gSUPABASE_ENV_VAL_ANON_KEY=$(ndr_GenerateJWT "anon" "$gSUPABASE_ENV_VAL_JWT_SECRET")
  if [[ $? -ne 0 || -z "$gSUPABASE_ENV_VAL_ANON_KEY" ]]; then
    ndr_logError "Failed to generate anon key"
    return 1
  fi
  
  gSUPABASE_ENV_VAL_SERVICE_ROLE_KEY=$(ndr_GenerateJWT "service_role" "$gSUPABASE_ENV_VAL_JWT_SECRET")
  if [[ $? -ne 0 || -z "$gSUPABASE_ENV_VAL_SERVICE_ROLE_KEY" ]]; then
    ndr_logError "Failed to generate service role key"
    return 1
  fi

  gSUPABASE_ENV_VAL_PG_META_CRYPTO_KEY=$(openssl rand -base64 24)
  if [[ $? -ne 0 || -z "$gSUPABASE_ENV_VAL_PG_META_CRYPTO_KEY" ]]; then
    ndr_logError "OpenSSL failed to generate Postgres meta crypto key"
    return 1
  fi

  gSUPABASE_ENV_VAL_VAULT_ENC_KEY=$(openssl rand -hex 16)
  if [[ $? -ne 0 || -z "$gSUPABASE_ENV_VAL_VAULT_ENC_KEY" ]]; then
    ndr_logError "OpenSSL failed to generate Vault encryption key"
    return 1
  fi

  gSUPABASE_ENV_VAL_SECRET_KEY_BASE=$(openssl rand -base64 48)
  if [[ $? -ne 0 || -z "$gSUPABASE_ENV_VAL_SECRET_KEY_BASE" ]]; then
    ndr_logError "OpenSSL failed to generate secret key base"
    return 1
  fi

  gSUPABASE_ENV_VAL_LOGFLARE_PUBLIC_ACCESS_TOKEN=$(openssl rand -base64 24)
  if [[ $? -ne 0 || -z "$gSUPABASE_ENV_VAL_LOGFLARE_PUBLIC_ACCESS_TOKEN" ]]; then
    ndr_logError "OpenSSL failed to generate Logflare public access token"
    return 1
  fi
  gSUPABASE_ENV_VAL_LOGFLARE_PRIVATE_ACCESS_TOKEN=$(openssl rand -base64 24)
  if [[ $? -ne 0 || -z "$gSUPABASE_ENV_VAL_LOGFLARE_PRIVATE_ACCESS_TOKEN" ]]; then
    ndr_logError "OpenSSL failed to generate Logflare private access token"
    return 1
  fi

  gSUPABASE_ENV_VAL_S3_PROTOCOL_ACCESS_KEY_ID=$(openssl rand -hex 16)
  if [[ $? -ne 0 || -z "$gSUPABASE_ENV_VAL_S3_PROTOCOL_ACCESS_KEY_ID" ]]; then
    ndr_logError "OpenSSL failed to generate S3 protocol access key ID"
    return 1
  fi
  gSUPABASE_ENV_VAL_S3_PROTOCOL_ACCESS_KEY_SECRET=$(openssl rand -hex 32)
  if [[ $? -ne 0 || -z "$gSUPABASE_ENV_VAL_S3_PROTOCOL_ACCESS_KEY_SECRET" ]]; then
    ndr_logError "OpenSSL failed to generate S3 protocol access key secret"
    return 1
  fi

  gSUPABASE_ENV_VAL_MINIO_ROOT_PASSWORD=$(openssl rand -hex 16)
  if [[ $? -ne 0 || -z "$gSUPABASE_ENV_VAL_MINIO_ROOT_PASSWORD" ]]; then
    ndr_logError "OpenSSL failed to generate MinIO root password"
    return 1
  fi

  # global vars that will override any template env values
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_JWT_SECRET"]="$gSUPABASE_ENV_VAL_JWT_SECRET"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_ANON_KEY"]="$gSUPABASE_ENV_VAL_ANON_KEY"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_SERVICE_ROLE_KEY"]="$gSUPABASE_ENV_VAL_SERVICE_ROLE_KEY"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_DASHBOARD_USERNAME"]="$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_DASHBOARD_PASSWORD"]="$gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_PG_META_CRYPTO_KEY"]="$gSUPABASE_ENV_VAL_PG_META_CRYPTO_KEY"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_VAULT_ENC_KEY"]="$gSUPABASE_ENV_VAL_VAULT_ENC_KEY"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_POOLER_TENANT_ID"]="$gSUPABASE_ENV_VAL_POOLER_TENANT_ID"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_SECRET_KEY_BASE"]="$gSUPABASE_ENV_VAL_SECRET_KEY_BASE"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_LOGFLARE_PUBLIC_ACCESS_TOKEN"]="$gSUPABASE_ENV_VAL_LOGFLARE_PUBLIC_ACCESS_TOKEN"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_LOGFLARE_PRIVATE_ACCESS_TOKEN"]="$gSUPABASE_ENV_VAL_LOGFLARE_PRIVATE_ACCESS_TOKEN"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_S3_PROTOCOL_ACCESS_KEY_ID"]="$gSUPABASE_ENV_VAL_S3_PROTOCOL_ACCESS_KEY_ID"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_S3_PROTOCOL_ACCESS_KEY_SECRET"]="$gSUPABASE_ENV_VAL_S3_PROTOCOL_ACCESS_KEY_SECRET"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_MINIO_ROOT_PASSWORD"]="$gSUPABASE_ENV_VAL_MINIO_ROOT_PASSWORD"

  # --- Read template into array ---
  mapfile -t default_lines < "$templateEnvFile"
  return_code=$?
  if [[ $return_code -ne 0 || -z "$default_lines" ]]; then
    ndr_logError "Failed to read $templateEnvFile"
    return 1
  fi

  local custom_lines=()

  local linesUpdated=0

  # --- Process template lines ---
  for default_line in "${default_lines[@]}"; do
    # Preserve comments, blank lines, and any template lines that are not simple KEY=value pairs.
    if [[ "$default_line" =~ ^([A-Za-z_][A-Za-z0-9_]*)=(.*)$ ]]; then
      key="${BASH_REMATCH[1]}"
      value="${BASH_REMATCH[2]}"

      # gSUPABASE_ENV_VARS is the allowlist of keys this installer owns. Leave
      # all other Supabase template defaults untouched so new release defaults flow in.
      if [[ -n "${gSUPABASE_ENV_VARS[$key]+_}" ]]; then
        local custom_value="${gSUPABASE_ENV_VARS[$key]}"

        # During tag upgrades, carry forward the previous customized value for
        # owned keys that still exist in the new Supabase template.
        if [[ -n "${backup_env_map[$key]+_}" && -n "${backup_env_map[$key]}" ]]; then
          value="${backup_env_map[$key]}"
          ndr_logInfo "Preserving key [$key] with value from backup env file."
          linesUpdated=$((linesUpdated += 1))
        elif [[ -n "$custom_value" ]]; then
          value="$custom_value"
          ndr_logInfo "Updating key [$key] with new value from env var map."
          linesUpdated=$((linesUpdated += 1))
        else
          ndr_logDebug "Key [$key] had empty value, skipping..."
        fi
      fi

      # Host values are resolved after selecting the final key value so both
      # preserved and generated values get the same address handling.
      if [[ "$value" == *"localhost"* ]]; then
        value="${value//localhost/$gNDR_SERVER_HOST_ADDRESS}"
        ndr_logInfo "Updating host address key with actual value [$key=$value]"
        linesUpdated=$((linesUpdated += 1))
      fi

      custom_lines+=("$key=$value")
    else
      custom_lines+=("$default_line")
    fi
  done

  # --- Open temp file for writing ---
  exec 3> "$customizedEnvFileTmp" || {
    ndr_logError "Failed to open $customizedEnvFileTmp for writing"
    return 1
  }

  # --- Write updated lines to temp file with error checking ---
  for l in "${custom_lines[@]}"; do
    if ! printf '%s\n' "$l" >&3; then
      ndr_logError "Failed to write line to $customizedEnvFileTmp: $l"
      exec 3>&-
      return 1
    fi
  done

  # --- Close temp file descriptor ---
  exec 3>&-

  # --- Move temp file into place ---
  if ! mv "$customizedEnvFileTmp" "$customizedEnvFile"; then
    ndr_logError "Failed to replace $customizedEnvFile with updated content"
    return 1
  fi

  # make optional secure caddy changes to env file urls (skip on upgrades since we would have already made these changes to the existing env file and we do not want to accidentally overwrite any customized values in the existing env file with new generated values from the template env file during an upgrade.)
  if [[ "$NDR_CADDY_ENABLED" == true ]]; then
    ndr_CustomizeSupabaseEnvFileCaddy "$customizedEnvFile"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to customize the Supabase env file for secure caddy mode [$customizedEnvFile]"
      return 1
    fi
    ndr_logInfo "Supabase env file successfully configured for secure caddy mode [$customizedEnvFile]"
  fi

  ndr_logInfo "Environment file [$customizedEnvFile] successfully updated with [$linesUpdated] values"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function <env_file>
function ndr_CustomizeSupabaseEnvFileCaddy ()
{
  local logSectionDesc="Customizing the Supabase env File for Caddy"
  ndr_logSecStart "$logSectionDesc"
  
  if [[ $# -lt 1 ]]; then
    ndr_logError "Usage: function <env_file>"
    return 1
  fi

  local env_file="$1"
  
  # --- Check that files exist ---
  if [ ! -f "$env_file" ]; then
    ndr_logError "Env file not found [$env_file]"
    return 1
  fi

  # Update URL settings from http to https in env file
  local url_vars=("SITE_URL" "API_EXTERNAL_URL")
  local var_name
  for var_name in "${url_vars[@]}"; do
    ndr_ConvertEnvVarHTTPToHTTPS "$env_file" "$var_name"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to update $var_name in env file [$env_file]."
      return 1
    fi
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_PullSupabaseBaseDockerImagesV2 ()
{
  local logSectionDesc="Pulling base Supabase Docker images"
  ndr_logSecStart "$logSectionDesc"
  
  if [[ "$gUPGRADE_MODE" == true && "$gNDR_SUPABASE_GIT_VERSION_TAG_UPGRADE" == false ]]; then
    ndr_logDebug "Supabase tag upgrade not enabled, skipping section."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # Go to the docker folder
  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into supabase project dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }
  
  # Pull all the images
  if [ ${#ndr_supabase_container_services[@]} -eq 0 ]; then
    ndr_logError "Supabase Docker image list is empty, cannot pull images."
    return 1
  fi
  
  # by default, we pull supabase from dockerhub, but if local registry option is set, we pull from the local registry instead. 
  # This allows for flexibility in airgapped environments where docker images may need to be pre-pulled and stored in a local registry.
  local repoType="$NDR_DOCKER_REPO_TYPE_PUBLIC_ALL"
  if [[ "$NDR_DOCKER_REPO_TYPE_CURRENT" == "$NDR_DOCKER_REPO_TYPE_LOCAL_REGISTRY" ]]; then
    repoType="$NDR_DOCKER_REPO_TYPE_LOCAL_REGISTRY"
  elif [[ "$NDR_DOCKER_REPO_TYPE_CURRENT" == "$NDR_DOCKER_REPO_TYPE_GCP_REGISTRY" ]]; then
    repoType="$NDR_DOCKER_REPO_TYPE_GCP_REGISTRY"
  fi

  ndr_logInfo "Pulling Supabase images individually from repo type [$repoType]"

  for service in "${ndr_supabase_container_services[@]}"; do
    # after moving to parsecomposeV2, we have the full image name with version tag in the imagename array so we dont need to piece it back together here, we can just use the value directly to pull the image. We keep the old code here commented out in case we need to revert back to the old parsecompose method for any reason, but ideally we should not need to do that and we can remove all the old code in the future once we are confident in the new method.
    if false; then
    local dockerImageBaseName="${ndr_supabase_container_service_image_names[$service]}"
    local dockerImageVersion="${ndr_supabase_container_service_image_tags[$service]}"
    local dockerImageName="$dockerImageBaseName:$dockerImageVersion"
    
    local dockerRepoAccount="" #"$NDR_DOCKER_MODULE_NAME_EMPTY_VALUE" #"docker.io/library"
    local dockerRepoName=""
    
    if [[ "$dockerImageBaseName" == */* ]]; then
      dockerRepoAccount="${dockerImageBaseName%/*}/"
      dockerRepoName="${dockerImageBaseName##*/}"
    else
      dockerRepoName="$dockerImageBaseName"
    fi

    # Some images need to be "adjusted" like kong that lacks the repo account field. Images like that cause problems when pulling from GCP. All other repos can leave it blank.
    if [[ -z "$dockerRepoAccount" && "$NDR_DOCKER_REPO_TYPE_CURRENT" == "$NDR_DOCKER_REPO_TYPE_GCP_REGISTRY" ]]; then
      dockerRepoAccount="library/"
    fi

    local dockerImageName="${dockerRepoAccount}${dockerRepoName}:${dockerImageVersion}"
    fi
    local dockerImageName="${ndr_supabase_container_service_image_names[$service]}"

    ndr_logInfo "Pulling Supabase image [$dockerImageName]"

    ndr_DownloadDockerImageV2 "$dockerImageName" "$gNDR_DOCKER_ARCHITECTURE_CURRENT" "$repoType"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Docker image download failed for [$dockerImageName]."
      return 1
    fi
    ndr_logInfo "Docker image download succeeded for [$dockerImageName]."
  done
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_PullSupabaseBaseDockerImages ()
{
  local logSectionDesc="Pulling base Supabase Docker images"
  ndr_logSecStart "$logSectionDesc"
  
  # Go to the docker folder
  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into supabase project dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }
  
  # Pull all the images
  if [ ${#ndr_supabase_container_services[@]} -eq 0 ]; then
    ndr_logError "Supabase Docker image list is empty, cannot pull images."
    return 1
  fi
  
  ndr_logInfo "Pulling Supabase images individually."
  for service in "${ndr_supabase_container_services[@]}"; do
    local dockerImageBaseName="${ndr_supabase_container_service_image_names[$service]}"
    local dockerImageVersion="${ndr_supabase_container_service_image_tags[$service]}"
    local dockerImageName="$dockerImageBaseName:$dockerImageVersion"
    
    ndr_logInfo "Pulling Supabase image [$dockerImageName]."
    docker pull "$dockerImageName"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Docker pull failed for image [$dockerImageName]"
      return 1
    fi
  done
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

export NDR_START_SUPABASE_DOCKER_CONTAINER_OPTION_NO_RECREATE="no_recreate"

# shellcheck disable=SC2120
function ndr_ComposeSupabaseDockerContainers ()
{
  # Start the container services (in detached mode)
  local logSectionDesc="Starting Supabase Docker Container services"
  ndr_logSecStart "$logSectionDesc"
  
  local opt_no_recreate="${1:-}"

  # Go to the docker folder
  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into supabase project dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }

  dockerProjectName="$gNDR_SUPABASE_DOCKER_PROJECT_NAME"

  # we add the --remove-orphans flag to ensure that any optional containers that are not defined in the current compose file get removed.
  local cmd=(docker compose -p "$dockerProjectName" up -d --remove-orphans)

  if [ "$opt_no_recreate" == "$NDR_START_SUPABASE_DOCKER_CONTAINER_OPTION_NO_RECREATE" ]; then
    cmd+=(--no-recreate)
  fi
    
  "${cmd[@]}"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Docker compose up failed"

    for service in "${ndr_supabase_container_services[@]}"; do
      local container_name="${ndr_supabase_container_service_container_names[$service]}"
      
      ndr_CheckContainerHealth "$container_name"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logWarn "Docker container returned non-healthy status [$container_name]."
        local logs_output=$(docker logs --tail 50 "$container_name" 2>&1)
        if [[ -n "$logs_output" ]]; then
          ndr_logWarn "$logs_output"
        fi
      else
        ndr_logInfo "Docker container returned healthy status [$container_name]."
      fi
    done

    return 1
  fi
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_CleanupSupabaseProjectDirs ()
{
  local logSectionDesc="Cleaning up Supabase Docker folders"
  ndr_logSecStart "$logSectionDesc"

  # clean up supabase folders
  if [[ -n "$gSUPABASE_TEMPLATE_HOME" && -d "$gSUPABASE_TEMPLATE_HOME" ]]; then
    ndr_logInfo "Removing Supabase template folder [$gSUPABASE_TEMPLATE_HOME]"
    rm -rf "$gSUPABASE_TEMPLATE_HOME"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to remove Supabase folder [$gSUPABASE_TEMPLATE_HOME]"
      #return 1
    fi
  fi

  # cleanup the home/_tmp folder if it exists
  local tempDir="$gNEXTDR_HOME_DIR/_tmp"
  if [[ -d "$tempDir" ]]; then
    ndr_logInfo "Removing home temp folder [$tempDir]"
    rm -rf "$tempDir"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to remove home temp folder [$tempDir]"
      #return 1
    fi
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_StartSupabaseDockerServices ()
{
  # bring the containers down.
  local logSectionDesc="Starting Supabase Docker Service Containers"
  ndr_logSecStart "$logSectionDesc"
  
  local options="${1:-$gNDR_DOCKER_SERVICE_CONTROL_START}"

  retCode=0

  # if db not installed, then skip
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
  local dbInstalled=$?
  if [ $dbInstalled -ne 0 ]; then
    ndr_logInfo "Supabase module is not installed, skipping start of supabase Docker services."
  fi

  if [[ -z "$gSUPABASE_NEXTDR_HOME" || ! -d "$gSUPABASE_NEXTDR_HOME" ]]; then
    ndr_logError "Supabase project directory not found [$gSUPABASE_NEXTDR_HOME]"
    return 1
  fi
  
  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into supabase project dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }
  
  # ensure we have the service map populated
  if [ ${#ndr_supabase_container_services[@]} -eq 0 ]; then
    ndr_PopulateSupabaseServiceMap
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Failed to populate Supabase service map."
      return 1
    fi
    
    if [ ${#ndr_supabase_container_services[@]} -eq 0 ]; then
      ndr_logError "No service entries found in compose or registry to act on."
      return 1
    fi
  fi

  if (( options & gNDR_DOCKER_SERVICE_CONTROL_PULL )); then
    docker compose pull --quiet
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logInfo "Failed to start Docker Container services"
      return 1
    fi
    ndr_logInfo "Pulled Docker images for Docker Container services successfully."
  fi

  if (( options & gNDR_DOCKER_SERVICE_CONTROL_COMPOSE )); then
    docker compose up -d
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logInfo "Failed to compose Docker Container services"
      return 1
    fi
    ndr_logInfo "Composed Docker container services successfully."
  fi
  
  if (( options & gNDR_DOCKER_SERVICE_CONTROL_START )); then
    docker compose start
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logInfo "Failed to start Docker Container services"
      return 1
    fi
  fi

  # if options specified compose or start, then check health. Do not check if option is pull only.
  if (( options & (gNDR_DOCKER_SERVICE_CONTROL_COMPOSE | gNDR_DOCKER_SERVICE_CONTROL_START) )); then
    for service in "${ndr_supabase_container_services[@]}"; do
      local container_name="${ndr_supabase_container_service_container_names[$service]}"
        
      ndr_CheckContainerHealth "$container_name"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logWarn "Docker container returned non-healthy status [$container_name]."
        local logs_output=$(docker logs --tail 50 "$container_name" 2>&1)
        if [[ -n "$logs_output" ]]; then
          ndr_logWarn "$logs_output"
        fi
        retCode=1
        continue
      fi
      
      ndr_logInfo "Docker container returned healthy status [$container_name]."
    done
  fi

  if [ $retCode -ne 0 ]; then
    ndr_logError "One or more Supabase Docker services failed to start or returned non-healthy status."
  else
    ndr_logInfo "Started Supabase Docker container services successfully."
  fi

  ndr_logSecEnd "$logSectionDesc"

  return $retCode
}

# usage: function [options]
function ndr_StopSupabaseDockerServices ()
{
  # bring the containers down.
  local logSectionDesc="Stopping Supabase Docker Service Containers"
  ndr_logSecStart "$logSectionDesc"

  local options="${1:-$gNDR_DOCKER_SERVICE_CONTROL_STOP}"

  # if db not installed, then skip
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
  local dbInstalled=$?
  if [ $dbInstalled -ne 0 ]; then
    ndr_logInfo "Supabase module is not installed, skipping stop of supabase Docker services."
  fi

  if [[ -z "$gSUPABASE_NEXTDR_HOME" || ! -d "$gSUPABASE_NEXTDR_HOME" ]]; then
    ndr_logError "Supabase project directory not found [$gSUPABASE_NEXTDR_HOME]"
    return 1
  fi
  
  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into supabase project dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }
  
  if (( options & gNDR_DOCKER_SERVICE_CONTROL_STOP )); then
    docker compose stop
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logInfo "Failed to stop Supabase Docker services"
      return 1
    fi

    ndr_logInfo "Stopped Docker container services successfully."
  fi
  
  if (( options & gNDR_DOCKER_SERVICE_CONTROL_REMOVE )); then
    ndr_logInfo "Option specified to remove Docker images and containers."

    if [[ "$gNDR_RETAIN_DOCKER_IMAGES" == true ]]; then
      ndr_logInfo "Global flag to retain Docker images is set, skipping image removal."
      docker compose down
    else
      docker compose down -v --rmi all --remove-orphans
    fi
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logInfo "Failed to remove Docker Containers and images"
      return 1
    fi
    ndr_logInfo "Removed Docker containers and images successfully."
  fi

  ndr_logInfo "Stopped Supabase Docker services successfully."
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseSchemaDiffPrepare ()
{
  local logSectionDesc="Preparing Supabase Schema Diff Environment"
  ndr_logSecStart "$logSectionDesc"

  if [[ "$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY" != "$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY_DYNAMIC" ]]; then
    ndr_logInfo "Schema diff file generation disabled. Skipping operation."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  ndr_SupabaseBuildTempDatabase "$NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_UPGRADE" "$NDR_SCHEMA_DIFF_SUPABASE_DIR" "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to build Supabase temp upgrade database for schema diff."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseBuildTempDatabase ()
{
  local logSectionDesc="Building Supabase Temp Database Environment"
  ndr_logSecStart "$logSectionDesc"
  
  # Argument validation
  if [[ $# -lt 3 ]]; then
    ndr_logError "Usage: function <db_build_options> <db_build_folder> <schema_file>"
    return 1
  fi

  local buildOptions=${1:-}
  local buildDBFolder=${2:-}
  local schemaFile=${3:-}
  
  # -----------------------------
  # Configuration
  # -----------------------------
  local PROD_DB_CONTAINER="$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME"
  local checkoutTag="$gNDR_SUPABASE_GIT_VERSION_TAG"
  local DB_SERVICE="$NDR_SUPABASE_APP_SERVICE_NAME_DB"
  local supabaseDockerDir="${buildDBFolder}/${NDR_SCHEMA_DIFF_SUPABASE_DOCKER_SUB_DIR}"
  local COMPOSE_FILE="${supabaseDockerDir}/$NDR_STANDARD_DOCKER_COMPOSEFILE_FILENAME"
  local project_name="$NDR_SCHEMA_DIFF_SUPABASE_PROJECT_NAME_DIFF"
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_BASELINE )); then
    project_name="$NDR_SCHEMA_DIFF_SUPABASE_PROJECT_NAME_BASELINE"
  fi

  # -----------------------------
  # Prepare temp folders
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_PREPARE_FOLDERS )); then
    if [ ! -d "$NDR_SCHEMA_DIFF_WORK_DIR" ]; then
      ndr_logInfo "Creating schema diff work dir [$NDR_SCHEMA_DIFF_WORK_DIR]"
      sudo mkdir -p "$NDR_SCHEMA_DIFF_WORK_DIR"  
      sudo chown "$(whoami)":"$(whoami)" "$NDR_SCHEMA_DIFF_WORK_DIR"
    fi
    
    if [ ! -d "$buildDBFolder" ]; then
      ndr_logInfo "Creating supabase diff container dir [$buildDBFolder]"
      sudo mkdir -p "$buildDBFolder"  
      sudo chown "$(whoami)":"$(whoami)" "$buildDBFolder"
    fi
  fi

  # -----------------------------
  # checkout supabase repo
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CLONE_REPO )); then
    ndr_logInfo "Cloning Supabase repository into [$buildDBFolder]"

    cd "$buildDBFolder" || { ndr_logError "Failed to cd into dir [$buildDBFolder]"; return 1; }

    git clone --filter=blob:none --no-checkout https://github.com/supabase/supabase "$buildDBFolder"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Git clone failed."
      return 1
    fi
    ndr_logInfo "Git clone for Supabase completed."

    git sparse-checkout set --cone docker
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "GIT sparse checkout for docker only folder failed."
      return 1
    fi
    ndr_logInfo "Git sparse checkout for Supabase completed."

    ndr_logInfo "Checking out Supabase repository tag [$checkoutTag]"
    git checkout "$checkoutTag"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "GIT checkout for [$checkoutTag] failed."
      return 1
    fi
    ndr_logInfo "Git checkout for [$checkoutTag] completed."
  fi

  # -----------------------------
  # copy template env file
  # -----------------------------
  local envDestFile=""
  
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_COPY_ENV_FILE )); then
    local envSrcFile="${supabaseDockerDir}/${gNDR_SUPABASE_ENV_TEMPLATE_VAR_FILENAME}"
    envDestFile="${supabaseDockerDir}/${gNDR_ENV_TARGET_FILENAME}"
    cp -f $envSrcFile $envDestFile
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to copy the Supabase template env file [$envSrcFile] to [$envDestFile]"
      return 1
    fi
    ndr_logInfo "Supabase template env file [$envSrcFile] copied to [$envDestFile]"
  fi

  # -----------------------------
  # modify postgres port in env file to 5433
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODIFY_ENV_PORTS )); then
    local port="5433"
    if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_BASELINE )); then
      port="5434"
    fi
    
    sed -i "s/^POSTGRES_PORT=.*/POSTGRES_PORT=$port/" "$envDestFile"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to modify POSTGRES_PORT in env file [$envDestFile]"
      return 1
    fi
    ndr_logInfo "Modified POSTGRES_PORT to $port in env file [$envDestFile]"
  fi

  # -----------------------------
  # configure compose services
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CONFIGURE_COMPOSE_SERVICES )); then
    # -----------------------------
    # customize project name
    # -----------------------------
    # Replace first occurrence of 'name: supabase' with 'name: supabase-<suffix>'
    yq eval -i ".name = \"${project_name}\"" "$COMPOSE_FILE"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logWarn "Failed to change compose file project name to \"$project_name\"."
      return 1
    fi
    ndr_logInfo "Changed compose file project name to \"$project_name\"."
      
    for service in "${NDR_SCHEMA_DIFF_DOCKER_SERVICES[@]}"; do
      # -----------------------------
      # read the image name for the services in the compose file
      # -----------------------------
      local image_section=".services.$service.image"
      local temp_image_name=$(yq eval "$image_section" "$COMPOSE_FILE")
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "Failed to read $image_section from compose file."
        return 1
      fi
      ndr_logInfo "Read $image_section as [$temp_image_name] from compose file."

      # -----------------------------
      # read the container name for the services in the compose file
      # -----------------------------
      local container_name_section=".services.$service.container_name"
      local prod_container_name=$(yq eval "$container_name_section" "$COMPOSE_FILE")
      return_code=$?
      if [[ $return_code != 0 || -z "$prod_container_name" ]]; then
        ndr_logError "Failed to read $container_name_section from compose file."
        return 1
      fi

      # -----------------------------
      # get the image name of the production db container
      # -----------------------------
      local prod_image_name=$(ndr_QueryContainerImageName "$prod_container_name")
      return_code=$?
      if [[ $return_code -ne 0 || -z "$prod_image_name" ]]; then
        ndr_logWarn "Failed to retrieve image name for container [$prod_container_name]. Using image name [$temp_image_name] from compose file."
        prod_image_name="$temp_image_name"
        gNDR_RETAIN_DOCKER_IMAGES=true
      fi
      ndr_logInfo "Image name for container [$prod_container_name]: $prod_image_name"
      
      # -----------------------------
      # modify compose file container_name value to append suffix
      # -----------------------------
      local temp_container_name=""
      local temp_container_suffix="-diff"
      if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_BASELINE )); then
        temp_container_suffix="-base"
      fi
      temp_container_name="${prod_container_name}${temp_container_suffix}"
      yq eval -i "$container_name_section = \"$temp_container_name\"" "$COMPOSE_FILE"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logWarn "Failed to change $container_name_section to '$temp_container_name' in compose file."
        return 1
      fi
      ndr_logInfo "Changed $container_name_section to '$temp_container_name' in compose file."

      # -----------------------------
      # preserve values
      # -----------------------------
      NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_PROD["$service"]="$prod_container_name"
      NDR_SCHEMA_DIFF_DOCKER_SERVICE_IMAGES_PROD["$service"]="$prod_image_name"

      if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_UPGRADE )); then
        NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_TEMP["$service"]="$temp_container_name"
        NDR_SCHEMA_DIFF_DOCKER_SERVICE_IMAGES_TEMP["$service"]="$temp_image_name"
      fi
      if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_BASELINE )); then
        NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_BASE["$service"]="$temp_container_name"
        NDR_SCHEMA_DIFF_DOCKER_SERVICE_IMAGES_BASE["$service"]="$temp_image_name"
      fi
    done
  fi

  # -----------------------------
  # pull images
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_PULL_IMAGES )); then
    cd "$supabaseDockerDir" || { ndr_logError "Failed to cd into dir [$supabaseDockerDir]"; return 1; }

    for service in "${NDR_SCHEMA_DIFF_DOCKER_SERVICES[@]}"; do
      docker compose pull --quiet "$service"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "Docker compose pull failed for service [$service]"
        return 1
      fi
      ndr_logInfo "Docker compose pull completed for service [$service]"
    done
  fi

  # -----------------------------
  # compose containers
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_COMPOSE_CONTAINERS )); then
    cd "$supabaseDockerDir" || { ndr_logError "Failed to cd into dir [$supabaseDockerDir]"; return 1; }

    for service in "${NDR_SCHEMA_DIFF_DOCKER_SERVICES[@]}"; do
      docker compose -p "$project_name" -f "$COMPOSE_FILE" up -d --no-deps --force-recreate "$service"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "Docker compose up failed for service [$service]"
        return 1
      fi
      ndr_logInfo "Docker compose up completed for service [$service]"
    done

  fi

  # -----------------------------
  # wait for containers to be running/healthy
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CONTAINER_VERIFY )); then
    for service in "${NDR_SCHEMA_DIFF_DOCKER_SERVICES[@]}"; do
      local max_retries=3
      local attempt=1
      local container_name=""
      if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_UPGRADE )); then
        container_name="${NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_TEMP[$service]}"
      else
        container_name="${NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_BASE[$service]}"
      fi
        
      while true; do
        sleep 3

        ndr_verifyDockerContainerRunning "$container_name" >/dev/null
        return_code=$?
        if [ $return_code -eq 0 ]; then
          ndr_logInfo "Container is running [$container_name]"
          break
        fi
        
        if [[ $attempt -ge $max_retries ]]; then
          ndr_logError "Max container running checks reached for [$container_name]. Exiting."

          local logs_output=$(docker logs --tail 50 "$container_name" 2>&1)
          if [[ -n "$logs_output" ]]; then
            ndr_logWarn "$logs_output"
          fi

          return 1
        fi

        attempt=$((attempt + 1))
      done

      # -----------------------------
      # wait for DB container to be healthy
      # -----------------------------
      attempt=1
      
      while true; do

        sleep 3

        ndr_CheckContainerHealth "$container_name"
        return_code=$?
        if [[ $return_code -eq 0 ]]; then
          ndr_logInfo "Docker container returned healthy status [$container_name]."
          break
        fi
          
        if [[ $attempt -ge $max_retries ]]; then
          ndr_logError "Max container health checks reached for [$container_name]. Exiting."

          ndr_logWarn "Docker container returned non-healthy status [$container_name]."
          local logs_output=$(docker logs --tail 50 "$container_name" 2>&1)
          if [[ -n "$logs_output" ]]; then
            ndr_logWarn "$logs_output"
          fi

          return 1
        fi

        attempt=$((attempt + 1))
      done
    done
  fi

  # -----------------------------
  # connect new containers to existing ndr bridge network
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_BRIDGE_NETWORKS )); then
    # create or verify the bridge network exists
    ndr_createDockerBridgeNetwork
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to create or verify docker bridge network [$NDR_DOCKER_BRIDGE_NETWORK_NAME]"
      return 1
    fi

    for service in "${NDR_SCHEMA_DIFF_DOCKER_SERVICES[@]}"; do
      local container_name=""
      if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_UPGRADE )); then
        container_name="${NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_TEMP[$service]}"
      else
        container_name="${NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_BASE[$service]}"
      fi

      docker network connect "$NDR_DOCKER_BRIDGE_NETWORK_NAME" "$container_name"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "Docker network [$NDR_DOCKER_BRIDGE_NETWORK_NAME] connect failed for [$container_name]"
        return 1
      fi
      ndr_logInfo "Docker network [$NDR_DOCKER_BRIDGE_NETWORK_NAME] connect completed for [$container_name]"
    done
  fi

  # -----------------------------
  # Detect Postgres credentials inside container
  # -----------------------------
  local PROD_POSTGRES_ENV=""
  local PROD_POSTGRES_USER=""
  local PROD_POSTGRES_PASSWORD=""
  local PROD_POSTGRES_DB=""

  local TEMP_DB_CONTAINER=""
  local TEMP_POSTGRES_ENV=""
  local TEMP_POSTGRES_USER=""
  local TEMP_POSTGRES_PASSWORD=""
  local TEMP_POSTGRES_DB=""

  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_QUERY_PROD_DB_ENV )); then
    PROD_POSTGRES_ENV=$(docker exec -i "$PROD_DB_CONTAINER" env | grep POSTGRES_)
    PROD_POSTGRES_USER=$(echo "$PROD_POSTGRES_ENV" | grep POSTGRES_USER | cut -d '=' -f2 | tr -d '\r\n')
    PROD_POSTGRES_PASSWORD=$(echo "$PROD_POSTGRES_ENV" | grep POSTGRES_PASSWORD | cut -d '=' -f2 | tr -d '\r\n')
    PROD_POSTGRES_DB=$(echo "$PROD_POSTGRES_ENV" | grep POSTGRES_DB | cut -d '=' -f2 | tr -d '\r\n')
    #local PROD_POSTGRES_PORT=$(echo "$PROD_POSTGRES_ENV" | grep POSTGRES_PORT | cut -d '=' -f2 | tr -d '\r\n')
    
    if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_UPGRADE )); then
      TEMP_DB_CONTAINER="${NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_TEMP[$DB_SERVICE]}"
    else
      TEMP_DB_CONTAINER="${NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_BASE[$DB_SERVICE]}"
    fi
    TEMP_POSTGRES_ENV=$(docker exec -i "$TEMP_DB_CONTAINER" env | grep POSTGRES_)
    TEMP_POSTGRES_USER=$(echo "$TEMP_POSTGRES_ENV" | grep POSTGRES_USER | cut -d '=' -f2 | tr -d '\r\n')
    TEMP_POSTGRES_PASSWORD=$(echo "$TEMP_POSTGRES_ENV" | grep POSTGRES_PASSWORD | cut -d '=' -f2 | tr -d '\r\n')
    TEMP_POSTGRES_DB=$(echo "$TEMP_POSTGRES_ENV" | grep POSTGRES_DB | cut -d '=' -f2 | tr -d '\r\n')
  fi
    
  # -----------------------------
  # Inject schema into temp DB
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_INJECT_SCHEMA )); then
    ndr_logInfo "Applying schema [$schemaFile] to temp container [$TEMP_DB_CONTAINER] for diff comparison..."

    # determine which user to use based on version (>=1.25.12 use supabase admin due to auth changes)
    ndr_version_ge "$gNDR_SUPABASE_GIT_VERSION_TAG" "1.25.12"
    return_code=$?
    if [ $return_code -eq 0 ]; then
      gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT="$gNDR_SUPABASE_DB_OPS_SUPABASE_ADMIN_USER"
      ndr_logDebug "Supabase version [$gNDR_SUPABASE_GIT_VERSION_TAG] >= 1.25.12, using supabase admin user [$gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT] for schema application."
    fi
    ndr_logInfo "Using schema account [$gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT] for schema application."

    # full command arg list
    # sqlOutput=$(docker compose exec -T "$DB_SERVICE" psql -U "$gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT" -d postgres -v ON_ERROR_STOP=1 < "$schemaFile")
    local psql_args=()
    psql_args+=("docker" "compose" "exec" "-T" "$DB_SERVICE" "psql" "-U" "$gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT" "-d" "$TEMP_POSTGRES_DB")

    # Conditionally add -v ON_ERROR_STOP=1
    if [[ "$gNDR_ALLOW_SCHEMA_ERRORS" != "true" ]]; then
      psql_args+=("-v" "ON_ERROR_STOP=1")
    fi

    # Execute and capture output
    local sqlOutput=$("${psql_args[@]}" < "$schemaFile")
    return_code=$?

    # Print any ERROR or WARNING lines from sqlOutput
    if [ -n "$sqlOutput" ]; then
      while IFS= read -r line; do
        if echo "$line" | grep -qE 'ERROR|WARNING'; then
          echo "$line"
        fi
      done <<< "$sqlOutput"
    fi

    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to apply upgrade schema to upgrade temp container [$TEMP_DB_CONTAINER]."
      return 1
    fi
  fi

  # -----------------------------
  # Validate schema applied by checking for a known table
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_VALIDATE_SCHEMA )); then    
    ndr_logInfo "Querying Supabase tables for schema..."
    local table_list=$(docker compose exec -T "$DB_SERVICE" psql -U "$gNDR_SUPABASE_DB_OPS_POSTGRES_ADMIN_USER" -d "$TEMP_POSTGRES_DB" -c '\dt' 2>/dev/null)
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logWarn "Failed to query schema status"
    fi
    
    local searchTable="recovery_plans"
    if [[ -n "$table_list" ]]; then
      # Search for the recovery_plans table
      if echo "$table_list" | grep -q "\b$searchTable\b"; then
        #ndr_logInfo "$table_list"
        ndr_logInfo "Table $searchTable found, schema applied."
      else
        ndr_logInfo "$table_list"
        ndr_logError "Table $searchTable not found. Schema may not have been applied."
        return 1
      fi
    else
      ndr_logError "Table list empty. Schema may not have been applied."
      return 1
    fi
  fi

  # -----------------------------
  # Compare table counts to ensure they are consistent (upgrade db count should be greater then or equal to prod db count)
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_VALIDATE_BUILD_TABLES )); then
    local prod_table_count=$(docker exec -i "$PROD_DB_CONTAINER" psql -U "$PROD_POSTGRES_USER" -d "$PROD_POSTGRES_DB" -At -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_type = 'BASE TABLE';")
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logWarn "Failed to query production table count"
    fi
    ndr_logInfo "Production table count: $prod_table_count"

    local temp_table_count=$(docker exec -i "$TEMP_DB_CONTAINER" psql -U "$TEMP_POSTGRES_USER" -d "$TEMP_POSTGRES_DB" -At -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_type = 'BASE TABLE';")
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logWarn "Failed to query upgrade table count"
    fi
    ndr_logInfo "Temp table count: $temp_table_count"

    if [[ "$temp_table_count" -lt "$prod_table_count" ]]; then
      ndr_logWarn "Temp table count ($temp_table_count) is less than production table count ($prod_table_count)."
    fi
  fi

  # -----------------------------
  # Create Python environment inside container
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_INSTALL_DIFF_UTILS )); then
    # -----------------------------
    # Copy Python script into container /tmp
    # -----------------------------
    local src="${gSCRIPT_HOME_DIR}/$NDR_SCHEMA_DIFF_PYTHON_SCRIPT_FILE"
    
    if [ ! -f "$src" ]; then
      ndr_logError "Failed to find schema diff script [$src]"
      return 1
    fi
  
    chmod +x "$src"

    local dest="$TEMP_DB_CONTAINER:/tmp/$NDR_SCHEMA_DIFF_PYTHON_SCRIPT_FILE"
    docker cp "$src" "$dest"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to copy [$src] to [$dest]."
      return 1
    fi
    ndr_logInfo "Copied schema diff script [$src] to container [$dest]."

    # -----------------------------
    # Install dependencies inside container (system-wide)
    # -----------------------------
    local -a diff_prereq_commands=(
      "apt-get update"
      "apt-get install -y python3-pip"
      "pip3 install --upgrade pip"
      "pip3 install psycopg2-binary sqlbag migra"
    )

    local max_retries=3
    for diff_prereq_command in "${diff_prereq_commands[@]}"; do
      local retry_count=1
      
      while true; do
        ndr_logInfo "Running schema diff prerequisite command in container [$TEMP_DB_CONTAINER]: [$diff_prereq_command] (attempt [$retry_count/$max_retries])"
        docker exec -i "$TEMP_DB_CONTAINER" bash -c "$diff_prereq_command"
        return_code=$?
        if [ $return_code -eq 0 ]; then
          break
        fi

        if [ $retry_count -ge $max_retries ]; then
          ndr_logError "Failed to run schema diff prerequisite command in container [$TEMP_DB_CONTAINER] after [$max_retries] attempts: [$diff_prereq_command]."
          return 1
        fi

        ndr_logWarn "Schema diff prerequisite command failed with return code [$return_code]. Waiting 3 seconds before retry."
        sleep 3
        ((retry_count++))
      done

    done

    ndr_logInfo "Schema diff prerequisites installed successfully inside container."
  fi

  ndr_logInfo "Supabase test database environment built successfully."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseSchemaDiffGenerate ()
{
  local logSectionDesc="Generating Supabase Schema Diff"
  ndr_logSecStart "$logSectionDesc"

  if [[ "$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY" != "$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY_DYNAMIC" ]]; then
    ndr_logInfo "Schema diff file generation disabled. Skipping operation."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # -----------------------------
  # Configuration
  # -----------------------------
  local DB_SERVICE="$NDR_SUPABASE_APP_SERVICE_NAME_DB"
  local PROD_DB_CONTAINER="$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME"
  local TEMP_DB_CONTAINER="${NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_TEMP[$DB_SERVICE]}"

  ndr_SupabaseDiffTempDatabase "$PROD_DB_CONTAINER" "$TEMP_DB_CONTAINER"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to generate Supabase schema diff of [$PROD_DB_CONTAINER] and [$TEMP_DB_CONTAINER]"
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseDiffTempDatabase ()
{
  local logSectionDesc="Generating Diff of Supabase Temp Databases"
  ndr_logSecStart "$logSectionDesc"
  
  # Argument validation
  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <baseline_db> <diff_db>"
    return 1
  fi

  local baselineDB=${1:-}
  local diffDB=${2:-}
    
  # -----------------------------
  # Prepare host workspace
  # -----------------------------
  if [ ! -d "$NDR_SCHEMA_DIFF_WORK_DIR" ]; then
    ndr_logInfo "Creating schema diff work dir [$NDR_SCHEMA_DIFF_WORK_DIR]"
    sudo mkdir -p "$NDR_SCHEMA_DIFF_WORK_DIR"  
    sudo chown "$(whoami)":"$(whoami)" "$NDR_SCHEMA_DIFF_WORK_DIR"
  fi
  cd "$NDR_SCHEMA_DIFF_WORK_DIR" || { ndr_logError "Failed to cd into dir [$NDR_SCHEMA_DIFF_WORK_DIR]"; return 1; }
  
  # -----------------------------
  # Detect Postgres credentials inside container
  # -----------------------------
  local PROD_POSTGRES_ENV=$(docker exec -i "$baselineDB" env | grep POSTGRES_)
  local PROD_POSTGRES_USER=$(echo "$PROD_POSTGRES_ENV" | grep POSTGRES_USER | cut -d '=' -f2 | tr -d '\r\n')
  local PROD_POSTGRES_PASSWORD=$(echo "$PROD_POSTGRES_ENV" | grep POSTGRES_PASSWORD | cut -d '=' -f2 | tr -d '\r\n')
  local PROD_POSTGRES_DB=$(echo "$PROD_POSTGRES_ENV" | grep POSTGRES_DB | cut -d '=' -f2 | tr -d '\r\n')
  local PROD_POSTGRES_PORT=$(echo "$PROD_POSTGRES_ENV" | grep POSTGRES_PORT | cut -d '=' -f2 | tr -d '\r\n')
  
  local TEMP_POSTGRES_ENV=$(docker exec -i "$diffDB" env | grep POSTGRES_)
  local TEMP_POSTGRES_USER=$(echo "$TEMP_POSTGRES_ENV" | grep POSTGRES_USER | cut -d '=' -f2 | tr -d '\r\n')
  local TEMP_POSTGRES_PASSWORD=$(echo "$TEMP_POSTGRES_ENV" | grep POSTGRES_PASSWORD | cut -d '=' -f2 | tr -d '\r\n')
  local TEMP_POSTGRES_DB=$(echo "$TEMP_POSTGRES_ENV" | grep POSTGRES_DB | cut -d '=' -f2 | tr -d '\r\n')
  
  # To run FROM upgr unix socket and connect TO prod via bridge net
  local PROD_DB_CONN_STR="postgresql://$PROD_POSTGRES_USER:$PROD_POSTGRES_PASSWORD@$baselineDB:$PROD_POSTGRES_PORT/$PROD_POSTGRES_DB"
  local TEMP_DB_CONN_STR="postgresql://$TEMP_POSTGRES_USER:$TEMP_POSTGRES_PASSWORD@/$TEMP_POSTGRES_DB?host=/var/run/postgresql"

  # -----------------------------
  # Run the diff inside container
  # -----------------------------
  local container_schema_diff_file="/tmp/$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF_FILENAME"
  # returns 0 for success, 1 for usage error, 2 for diff generation error, 3 for no diff found
  docker exec -i "$diffDB" bash -c "python3 /tmp/$NDR_SCHEMA_DIFF_PYTHON_SCRIPT_FILE '$PROD_DB_CONN_STR' '$TEMP_DB_CONN_STR' '$container_schema_diff_file'"
  return_code=$?
  if [ $return_code == 0 ]; then
    ndr_logInfo "Schema diff script executed successfully inside container [$diffDB]."
  elif [ $return_code -eq 3 ]; then
    ndr_logWarn "Schema Diff Utility indicated no basic table differences found between production and upgrade schemas. This is not expected but not necessarily an error. Continuing with additional diff processing..."
   else
    ndr_logError "Failed to execute schema diff script inside container [$diffDB], return code: $return_code."
    return 1
  fi
  
  ndr_logDebug "Diff cmd: [python3 /tmp/$NDR_SCHEMA_DIFF_PYTHON_SCRIPT_FILE '$PROD_DB_CONN_STR' '$TEMP_DB_CONN_STR' '$container_schema_diff_file']"
  
  # -----------------------------
  # Copy resulting diff back to host
  # -----------------------------
  local src="$diffDB:$container_schema_diff_file"
  local dest="$NDR_SCHEMA_DIFF_WORK_DIR/$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF_FILENAME"
  docker cp "$src" "$dest"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to copy diff file [$src] to [$dest]."
    return 1
  fi
  ndr_logInfo "Copied schema diff file from container [$src] to host [$dest]."

  gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF="$dest"

  # -----------------------------
  # Verify output
  # -----------------------------
  if [ ! -f "$dest" ]; then
    ndr_logError "Diff file not found [$dest]."
    return 1
  fi

  # -----------------------------
  # Compute and add any realtime publication diff's
  # -----------------------------
  ndr_SupabaseDiffTempDatabaseReplications "$baselineDB" "$diffDB"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to diff database replications."
    return 1
  fi

  # -----------------------------
  # check final file size after all processing
  # -----------------------------
  local fileSizeBytes=$(stat -c%s "$dest")
  if [ $fileSizeBytes -eq 0 ]; then
    ndr_logInfo "Diff file empty after all processing steps. Either no differences found between production and upgrade schemas or an unhandled error occurred generating the diff."

    echo -e "The $gCOMPANY_NAME database diff process found no difference between production and upgrade schemas."
    echo -e "This could indicate that the upgrade schema did not contain any changes or an error occurred during diff generation."
    read -p "Would you like to proceed with the upgrade without any schema changes? [Yes (default) to continue | No to abort]" -n 1 -r
    echo    # Move to a new line
    if [[ $REPLY =~ ^[Nn]$ ]]; then
      ndr_logInfo "Operation cancelled, aborting upgrade."
      rm -f "$dest"
      return 1
    fi
    ndr_logInfo "Proceeding with upgrade with empty schema diff."
  fi

  # -----------------------------
  # Embed version info header
  # -----------------------------
  ndr_SupabaseSchemaHeaderWrite "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to write schema diff header to file [$dest]."
    return 1
  fi
  
  # -----------------------------
  ndr_logInfo "Generated schema diff file [$dest]."
  ndr_logDebug "Diff file contents: $(cat "$dest")"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseSchemaDiffCleanup ()
{
  local logSectionDesc="Supabase Schema Diff Cleanup"
  ndr_logSecStart "$logSectionDesc"

  if [[ -n "$gNDR_SUPABASE_UPGRADE_SCHEMA_REPLAY_WORK_DIR" && -d "$gNDR_SUPABASE_UPGRADE_SCHEMA_REPLAY_WORK_DIR" ]]; then
    ndr_logInfo "Removing schema replay workspace [$gNDR_SUPABASE_UPGRADE_SCHEMA_REPLAY_WORK_DIR]."
    rm -rf "$gNDR_SUPABASE_UPGRADE_SCHEMA_REPLAY_WORK_DIR"
    gNDR_SUPABASE_UPGRADE_SCHEMA_REPLAY_WORK_DIR=""
  fi

  if [[ "$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY" != "$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY_DYNAMIC" ]]; then
    ndr_logInfo "Schema diff file generation disabled. Skipping operation."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  ndr_SupabaseCleanupTempDatabase "$NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_UPGRADE" "$NDR_SCHEMA_DIFF_SUPABASE_DIR"
  local return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to cleanup Supabase temp upgrade database."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# Build the logical upgrade path from the manifest only.
# This function does not download any diff files; it only resolves the ordered
# sequence of supported version hops that take us from the installed version
# to the target installer version.
#
# Output array entries are stored in the form:
#   from_version|to_version|release_dir|diff_schema_file
#
# Expect installed version, target version, and a nameref to the output array.

function ndr_SupabaseBuildUpgradeSchemaReplayVersionChain ()
{
  local logSectionDesc="Building Supabase Upgrade Schema Replay Version Chain"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 3 ]]; then
    ndr_logError "Usage: function <installed_version> <target_version> <version_chain_array_ref>"
    return 1
  fi

  local installed_version="${1:-}"
  local target_version="${2:-}"
  local version_chain_array_ref_name="${3:-}"
  local -n version_chain_array_ref="$version_chain_array_ref_name"
  local manifest_url="${gNDR_INSTALL_PACKAGE_MANIFEST_REMOTE_URL}"
  local manifest_file=""
  local current_version=""
  local next_entry=""
  local from_version=""
  local to_version=""
  local release_dir=""
  local diff_schema_file=""
  local diff_schema_url=""
  local diff_schema_local_file=""
  local hop_count=0
  local max_hops=100
  local return_code=0
  declare -A visited_versions=()

  version_chain_array_ref=()

  # Basic argument validation. Callers are expected to pass the already-known
  # "from" and "to" versions plus an array reference that we can populate.
  if [[ -z "$installed_version" || -z "$target_version" || -z "$version_chain_array_ref_name" ]]; then
    ndr_logError "Installed version, target version, and version chain array reference are required."
    return 1
  fi

  # No upgrade path is needed when installed and target versions already match.
  if [[ "$installed_version" == "$target_version" ]]; then
    ndr_logInfo "Installed version [$installed_version] already matches target version [$target_version]. No schema replay version chain required."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # Reset any prior replay workspace before starting a fresh manifest walk.
  # This keeps stale manifests and downloads from previous attempts from being reused.
  if [[ -n "$gNDR_SUPABASE_UPGRADE_SCHEMA_REPLAY_WORK_DIR" && -d "$gNDR_SUPABASE_UPGRADE_SCHEMA_REPLAY_WORK_DIR" ]]; then
    rm -rf "$gNDR_SUPABASE_UPGRADE_SCHEMA_REPLAY_WORK_DIR"
    gNDR_SUPABASE_UPGRADE_SCHEMA_REPLAY_WORK_DIR=""
  fi

  # Create a dedicated temp workspace for this resolution attempt. The manifest
  # is cached here now, and later functions may also use the same workspace for downloads.
  gNDR_SUPABASE_UPGRADE_SCHEMA_REPLAY_WORK_DIR="$(mktemp -d "/tmp/ndr-schema-replay_${installed_version}_to_${target_version}_XXXXXX")"
  if [[ -z "$gNDR_SUPABASE_UPGRADE_SCHEMA_REPLAY_WORK_DIR" || ! -d "$gNDR_SUPABASE_UPGRADE_SCHEMA_REPLAY_WORK_DIR" ]]; then
    ndr_logError "Failed to create schema replay workspace."
    return 1
  fi

  manifest_file="${gNDR_SUPABASE_UPGRADE_SCHEMA_REPLAY_WORK_DIR}/${gNDR_INSTALL_PACKAGE_MANIFEST_FILENAME}"

  # Download the public manifest once, then walk the from_version -> to_version chain hop by hop.
  # The manifest is the source of truth for which upgrade edges are supported.
  ndr_logInfo "Downloading install package manifest from [$manifest_url]."
  curl -fsSL "$manifest_url" -o "$manifest_file"
  return_code=$?
  if [[ $return_code -ne 0 || ! -s "$manifest_file" ]]; then
    ndr_logError "Failed to download install package manifest [$manifest_url]."
    return 1
  fi

  # Validate the manifest has the expected structure before we start querying it. We expect a top-level array of schema_diffs, but the array may be empty when no upgrades are needed.
  jq -e '(.schema_diffs // []) | type == "array"' "$manifest_file" >/dev/null
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Install package manifest [$manifest_file] is missing a valid [schema_diffs] array."
    return 1
  fi

  # Start from the currently installed version and repeatedly look up the next
  # supported hop until we reach the target version.
  current_version="$installed_version"

  while [[ "$current_version" != "$target_version" ]]; do
    # Guard against manifest mistakes that would create a loop in the version chain.
    if [[ -n "${visited_versions[$current_version]}" ]]; then
      ndr_logError "Detected circular schema replay chain while resolving manifest upgrades from [$installed_version] to [$target_version] at version [$current_version]."
      return 1
    fi
    visited_versions["$current_version"]=1

    # Query the manifest for the next hop that begins at the current version.
    # We expect at most one active edge for any given from_version in this model.
    next_entry=$(jq -r --arg from_version "$current_version" '
      (.schema_diffs // [])
      | map(select(.from_version == $from_version))
      | .[0]
      | if . == null then
          empty
        else
          [
            (.from_version // ""),
            (.to_version // ""),
            (.release_dir // ""),
            (.diff_schema_file // "")
          ] | @tsv
        end
    ' "$manifest_file")
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Failed to query install package manifest for next upgrade hop from version [$current_version]."
      return 1
    fi

    if [[ -z "$next_entry" ]]; then
      ndr_logError "No schema replay entry found in manifest for upgrade hop starting at version [$current_version]."
      return 1
    fi

    # Unpack the hop fields so they can be recorded and later used to download the diff file.
    IFS=$'\t' read -r from_version to_version release_dir diff_schema_file <<< "$next_entry"

    if [[ -z "$from_version" || -z "$to_version" || -z "$release_dir" || -z "$diff_schema_file" ]]; then
      ndr_logError "Manifest replay entry for version [$current_version] is incomplete [$next_entry]."
      return 1
    fi

    # Persist the resolved hop as a single pipe-delimited record so the version chain
    # remains index-linked with the file chain built later.
    version_chain_array_ref+=("${from_version}|${to_version}|${release_dir}|${diff_schema_file}")
    ndr_logInfo "Queued schema replay hop [$from_version -> $to_version] from release dir [$release_dir] and diff file [$diff_schema_file]."

    # Advance to the next version and continue until the final target is reached.
    current_version="$to_version"
    ((hop_count++))

    # Safety valve against malformed manifests that never terminate cleanly.
    if [[ $hop_count -gt $max_hops ]]; then
      ndr_logError "Exceeded max schema replay hop count [$max_hops] while resolving upgrade path to [$target_version]."
      return 1
    fi
  done

  ndr_logInfo "Resolved [$hop_count] schema replay hop(s) for upgrade path [$installed_version -> $target_version]."

  # Print the final ordered chain to make manifest resolution easy to inspect in logs.
  local version_chain_entry=""
  for version_chain_entry in "${version_chain_array_ref[@]}"; do
    ndr_logInfo "Schema replay hop chain entry [$version_chain_entry]."
  done
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# 
function ndr_SupabaseBuildUpgradeSchemaReplayList ()
{
  local logSectionDesc="Building Supabase Upgrade Schema Replay List"
  ndr_logSecStart "$logSectionDesc"

  # Build the physical list of local diff files to replay.
  # This function first resolves the manifest-defined hop chain, then downloads
  # each required diff file into the replay workspace and returns the resulting
  # local filenames through the caller-provided output array.
  #
  # Expect installed version, target version, and a nameref to the output array.
  if [[ $# -lt 3 ]]; then
    ndr_logError "Usage: function <installed_version> <target_version> <schema_file_array_ref>"
    return 1
  fi

  local installed_version="${1:-}"
  local target_version="${2:-}"
  local schema_file_array_ref_name="${3:-}"
  local -n schema_file_array_ref="$schema_file_array_ref_name"
  local release_base_url="${gNDR_INSTALL_PACKAGE_RELEASES_REMOTE_BASE_URL}"
  local version_chain=()
  local included_diff_file="${gSCRIPT_HOME_DIR}/${gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF_FILENAME_SHORT}"

  schema_file_array_ref=()

  # Resolve the logical version chain first. If we cannot determine the hop sequence,
  # there is no safe way to know which diff files to download.
  ndr_SupabaseBuildUpgradeSchemaReplayVersionChain "$installed_version" "$target_version" version_chain
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to resolve schema replay version chain."
    return 1
  fi

  # A zero-length chain means there is nothing to apply.
  if [[ ${#version_chain[@]} -eq 0 ]]; then
    ndr_logInfo "No schema replay files required for upgrade path [$installed_version -> $target_version]."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # Download each manifest-defined hop into the local replay workspace. The file chain
  # stays in the same order as the version chain so apply logic can replay sequentially.
  # For the final hop that lands on the target version, prefer the bundled local diff
  # file if it matches the expected hop header. Even when using the bundled diff, copy
  # it into the replay workspace so every replay file is sourced from the same local cache.
  for hop_entry in "${version_chain[@]}"; do
    local from_version=""
    local to_version=""
    local release_dir=""
    local diff_schema_file=""
    
    IFS='|' read -r from_version to_version release_dir diff_schema_file <<< "$hop_entry"

    if [[ -z "$from_version" || -z "$to_version" || -z "$release_dir" || -z "$diff_schema_file" ]]; then
      ndr_logError "Invalid schema replay hop entry [$hop_entry]."
      return 1
    fi

    # Construct the raw GitHub download URL for the version-specific diff file and
    # stage it locally under a name that keeps the hop direction visible for debugging.
    local diff_schema_url="${release_base_url}/${release_dir}/schema/${diff_schema_file}"
    local diff_schema_local_file="${gNDR_SUPABASE_UPGRADE_SCHEMA_REPLAY_WORK_DIR}/${from_version}_to_${to_version}_${diff_schema_file}"

    local diff_found=false

    if [[ "$diff_found" == false ]]; then
      if [[ "$to_version" == "$target_version" && -f "$included_diff_file" ]]; then
        ndr_logInfo "Final schema replay hop detected [$from_version -> $to_version]. Checking bundled local diff file [$included_diff_file]."

        ndr_SupabaseSchemaHeaderRead "$included_diff_file"
        return_code=$?
        if [[ $return_code -eq 0 ]] && \
          [[ "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_VAL" == "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_INCR" ]] && \
          [[ "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL" == "$from_version" ]] && \
          [[ "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL" == "$to_version" ]]; then
          cp -f "$included_diff_file" "$diff_schema_local_file"
          return_code=$?
          if [[ $return_code -ne 0 || ! -s "$diff_schema_local_file" ]]; then
            ndr_logError "Failed to stage bundled local schema replay file [$included_diff_file] to [$diff_schema_local_file]."
            return 1
          fi
          diff_found=true
          ndr_logInfo "Using bundled local schema diff for final replay hop [$from_version -> $to_version]."
        else
          ndr_logWarn "Bundled local schema diff file did not match expected final hop [$from_version -> $to_version]. Falling back to manifest download."
        fi
      fi
    fi

    if [[ "$diff_found" == false ]]; then
      ndr_logInfo "Downloading schema replay file [$diff_schema_url]."
      curl -fsSL "$diff_schema_url" -o "$diff_schema_local_file"
      return_code=$?
      if [[ $return_code -ne 0 || ! -s "$diff_schema_local_file" ]]; then
        ndr_logError "Failed to download schema replay file [$diff_schema_url]."
        return 1
      fi
      diff_found=true
      ndr_logInfo "Downloaded schema replay file [$diff_schema_url] to [$diff_schema_local_file]."
    fi

    schema_file_array_ref+=("$diff_schema_local_file")
    ndr_logInfo "Queued schema replay file [$diff_schema_local_file] for version hop [$from_version -> $to_version]."
  done

  ndr_logInfo "Resolved [${#schema_file_array_ref[@]}] schema replay file(s) for upgrade path [$installed_version -> $target_version]."
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# 
function ndr_SupabaseDetermineSchemaUpgradeStrategy ()
{
  local logSectionDesc="Determining Supabase Schema Upgrade Strategy"
  ndr_logSecStart "$logSectionDesc"

  # This resolver chooses between the two supported upgrade modes:
  #   1. REPLAY  - apply one or more manifest-defined incremental diff files
  #   2. DYNAMIC - generate a replacement diff on the fly and apply that instead
  #
  # The manifest is the primary source of truth. Replay-list construction now handles
  # both 1-hop and N-hop upgrades uniformly, with the bundled local diff preferred
  # only when it matches the final hop into the target version.
  local installed_version="${gINSTALLED_VERSION}"
  local target_version="${gPRODUCT_VERSION}"
  local version_chain=()
  local replay_files=()
  
  # Reset strategy state on every run so callers never inherit stale values from a
  # previous upgrade attempt in the same shell session.
  gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY=""
  gNDR_SUPABASE_UPGRADE_DIFF_VERSION_CHAIN=()
  gNDR_SUPABASE_UPGRADE_DIFF_FILE_CHAIN=()

  # Respect an explicitly requested dynamic-generation strategy, such as the
  # command-line force-regenerate option. In that case, skip replay resolution
  # and preserve the caller's decision.
  if [[ ! -z "$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY" ]]; then
    ndr_logInfo "Schema upgrade strategy already explicitly set to [$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY]."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # We cannot choose any upgrade path if either endpoint version is unknown.
  if [[ -z "$installed_version" || -z "$target_version" ]]; then
    ndr_logError "Installed version [$installed_version] or target version [$target_version] not available."
    return 1
  fi

  # Resolve the installed home directory if it has not already been populated.
  # This is needed to locate the installed full schema file for checksum validation.
  if [[ -z "$gNEXTDR_HOME_DIR" ]]; then
    gNEXTDR_HOME_DIR=$(ndr_getHomeDirReg)
    if [[ -z "$gNEXTDR_HOME_DIR" ]]; then
      ndr_logFail "Failed to retrieve install home dir from registry."
      return 1
    fi
  fi

  if [[ -z "$gACTIVE_NDR_SQL_SCHEMA_FILE" ]]; then
    ndr_SupabaseLocalSchemaFileCheck
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Failed to resolve active NDR SQL schema file."
      return 1
    fi
  fi

  if [[ -z "$gACTIVE_NDR_SQL_SCHEMA_FILE" || ! -f "$gACTIVE_NDR_SQL_SCHEMA_FILE" ]]; then
    ndr_logError "Active NDR SQL schema file not found [$gACTIVE_NDR_SQL_SCHEMA_FILE]."
    return 1
  fi

  gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL="$gACTIVE_NDR_SQL_SCHEMA_FILE"
  gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL="$gNEXTDR_HOME_DIR/$gSUPABASE_NEXTDR_SUB/$gNDR_REFERENCE_SQL_SCHEMA_FILENAME"
  
  # full schemas are required for any replay based strategy since they are the reference for SHA checksums of the start and end of the schema replay chain. 
  # If the installed schema file cannot be found, we have no way to verify that any replay-based diff file is valid for the currently installed schema, 
  # so we must fall back to dynamic generation which does not rely on the installed schema file for validation.
  if [[ ! -f "$gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL" ]]; then
    ndr_logWarn "Installed schema file not found at expected location [$gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL]. Falling back to dynamic diff generation."
    gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY="$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY_DYNAMIC"
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  if [[ -z "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL" || ! -f "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL" ]]; then
    ndr_logError "Upgrade schema file not found [$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL]."
    return 1
  fi

  # First resolve the expected hop chain from the manifest. This is the source of truth
  # for both 1-hop and N-hop replay decisions.
  ndr_SupabaseBuildUpgradeSchemaReplayVersionChain "$installed_version" "$target_version" version_chain
  return_code=$?
  if [[ $return_code -ne 0 || ${#version_chain[@]} -eq 0 ]]; then
    ndr_logWarn "Failed to build schema replay version chain. Falling back to dynamic diff generation."
    gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY="$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY_DYNAMIC"
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # Replay file construction is unified for both 1-hop and N-hop cases. The replay-list
  # builder will prefer the bundled local diff for the final hop when it matches, and
  # otherwise download the required diff file from the manifest-defined public location.
  ndr_logInfo "Schema upgrade replay path contains [${#version_chain[@]}] hop(s). Building manifest-defined diff file list."
  ndr_SupabaseBuildUpgradeSchemaReplayList "$installed_version" "$target_version" replay_files
  return_code=$?
  if [[ $return_code -ne 0 || ${#replay_files[@]} -ne ${#version_chain[@]} ]]; then
    ndr_logWarn "Failed to build complete schema replay file list. Falling back to dynamic diff generation."
    gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY="$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY_DYNAMIC"
    gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF=""
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # Persist the resolved replay plan globally so the later apply phase can execute it
  # without needing to recompute manifest state.
  gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY="$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY_REPLAY"
  gNDR_SUPABASE_UPGRADE_DIFF_VERSION_CHAIN=("${version_chain[@]}")
  gNDR_SUPABASE_UPGRADE_DIFF_FILE_CHAIN=("${replay_files[@]}")
  gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF="${gNDR_SUPABASE_UPGRADE_DIFF_FILE_CHAIN[0]}"
  ndr_logInfo "Using manifest-defined schema replay list with [${#gNDR_SUPABASE_UPGRADE_DIFF_FILE_CHAIN[@]}] diff file(s)."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# 
function ndr_SupabaseDiffTempDatabaseReplications ()
{
  local logSectionDesc="Generating Diff of Supabase Temp Database Replication entities"
  ndr_logSecStart "$logSectionDesc"
  
  # Argument validation
  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <baseline_db> <diff_db>"
    return 1
  fi

  local baselineDB=${1:-}
  local diffDB=${2:-}
  
  if [[ -z "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF" || ! -f "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF" ]]; then
    ndr_logError "Schema diff file not found: [$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF]."
    return 1
  fi

  local PUB_NAME="supabase_realtime"
  local SCHEMA="public"

  ndr_logInfo "Diffing realtime publication [$PUB_NAME] for schema [$SCHEMA]..."

  # -----------------------------
  # Detect Postgres credentials inside container
  # -----------------------------
  local PROD_POSTGRES_ENV=$(docker exec -i "$baselineDB" env | grep POSTGRES_)
  local PROD_POSTGRES_USER=$(echo "$PROD_POSTGRES_ENV" | grep POSTGRES_USER | cut -d '=' -f2 | tr -d '\r\n')
  local PROD_POSTGRES_PASSWORD=$(echo "$PROD_POSTGRES_ENV" | grep POSTGRES_PASSWORD | cut -d '=' -f2 | tr -d '\r\n')
  local PROD_POSTGRES_DB=$(echo "$PROD_POSTGRES_ENV" | grep POSTGRES_DB | cut -d '=' -f2 | tr -d '\r\n')
  
  local TEMP_POSTGRES_ENV=$(docker exec -i "$diffDB" env | grep POSTGRES_)
  local TEMP_POSTGRES_USER=$(echo "$TEMP_POSTGRES_ENV" | grep POSTGRES_USER | cut -d '=' -f2 | tr -d '\r\n')
  local TEMP_POSTGRES_PASSWORD=$(echo "$TEMP_POSTGRES_ENV" | grep POSTGRES_PASSWORD | cut -d '=' -f2 | tr -d '\r\n')
  local TEMP_POSTGRES_DB=$(echo "$TEMP_POSTGRES_ENV" | grep POSTGRES_DB | cut -d '=' -f2 | tr -d '\r\n')

  # -----------------------------
  # Tables currently in publication (prod)
  # -----------------------------
  mapfile -t BASE_TABLES < <(
    docker exec -i "$baselineDB" \
      psql -U "$PROD_POSTGRES_USER" -d "$PROD_POSTGRES_DB" -t -A -c "
        SELECT schemaname || '.' || tablename
        FROM pg_publication_tables
        WHERE pubname = '$PUB_NAME'
          AND schemaname = '$SCHEMA'
        ORDER BY 1;
      "
  )
  ndr_logInfo "Found [${#BASE_TABLES[@]}] total table publication entries in baseline DB."
  for tbl in "${BASE_TABLES[@]}"; do
    ndr_logDebug "Baseline DB table pub: [$tbl]"
  done

  # -----------------------------
  # Tables that exist in upgraded DB
  # -----------------------------
  mapfile -t UPGR_TABLES < <(
    docker exec -i "$diffDB" \
      psql -U "$TEMP_POSTGRES_USER" -d "$TEMP_POSTGRES_DB" -t -A -c "
        SELECT schemaname || '.' || tablename
        FROM pg_publication_tables
        WHERE pubname = '$PUB_NAME'
          AND schemaname = '$SCHEMA'
        ORDER BY 1;
      "
  )
  ndr_logInfo "Found [${#UPGR_TABLES[@]}] total table publication entries in upgrade DB."
  for tbl in "${UPGR_TABLES[@]}"; do
    ndr_logDebug "Upgrade DB table pub: [$tbl]"
  done

  # -----------------------------
  # Compute missing tables
  # -----------------------------
  local missing=()
  for tbl in "${UPGR_TABLES[@]}"; do
    if ! printf '%s\n' "${BASE_TABLES[@]}" | grep -qx "$tbl"; then
      missing+=("$tbl")
    fi
  done

  if [[ ${#missing[@]} -eq 0 ]]; then
    echo "✅ Realtime publication already up to date"
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

   # -----------------------------
  # Add publication updates to schema file
  # -----------------------------
  ndr_logInfo "Adding ${#missing[@]} tables to realtime publication..."

  for tbl in "${missing[@]}"; do
    line="alter publication $PUB_NAME add table $tbl;"
    ndr_logInfo "Adding publication entry to diff schema file [$line]"
    #echo "$line" >> "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF"
    printf '%s\n' "$line" | tee -a "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF" >/dev/null
    local return_code=${PIPESTATUS[0]}

    if (( return_code != 0 )); then
      ndr_logError "Failed writing [$line] to diff schema file: $gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF"
      return 1
    fi
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseCleanupTempDatabase ()
{
  local logSectionDesc="Cleanup Supabase Temp Database Environment"
  ndr_logSecStart "$logSectionDesc"
  
  # Argument validation
  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <db_build_options> <db_build_folder>"
    return 1
  fi

  local buildOptions=${1:-}
  local buildDBFolder=${2:-}
  
  local supabaseDockerDir="${buildDBFolder}/${NDR_SCHEMA_DIFF_SUPABASE_DOCKER_SUB_DIR}"
  local retVal=0
  
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CLEANUP_SERVICES )); then
    cd "$supabaseDockerDir" || { ndr_logError "Failed to cd into dir [$supabaseDockerDir]"; return 1; }

    for service in "${NDR_SCHEMA_DIFF_DOCKER_SERVICES[@]}"; do

      # -----------------------------
      # Gather image/container status
      # -----------------------------

      local remove_container=true
      local temp_container_name=""
      if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_UPGRADE )); then
        temp_container_name="${NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_TEMP[$service]}"
      else
        temp_container_name="${NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_BASE[$service]}"
      fi
      
      if [ -z "$temp_container_name" ]; then
        ndr_logError "Empty container name for service [$service], skipping container removal."
        retVal=1
        remove_container=false
      fi

      if [ "$remove_container" == true ]; then
        ndr_verifyDockerContainerExists "$temp_container_name" >/dev/null
        return_code=$?
        #2-error, 1-not found, 0-found
        if [[ $return_code != 0 ]]; then
          # skip if not found
          ndr_logWarn "Docker container '$temp_container_name' not found, nothing to prune."
          remove_container=false
        fi
      fi

      local remove_image=true;
      local temp_image_name=""
      if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_UPGRADE )); then
        temp_image_name="${NDR_SCHEMA_DIFF_DOCKER_SERVICE_IMAGES_TEMP[$service]}"
      else
        temp_image_name="${NDR_SCHEMA_DIFF_DOCKER_SERVICE_IMAGES_BASE[$service]}"
      fi
      
      if [ -z "$temp_image_name" ]; then
        ndr_logError "Empty image name for service [$service], skipping image removal."
        retVal=1
        remove_image=false
      fi

      if [ "$gNDR_RETAIN_DOCKER_IMAGES" == true ]; then
        ndr_logInfo "Retain docker images flag is set, skipping image removal for [$temp_image_name]."
        remove_image=false
      fi

      # verify the tmp container image exists
      if [ "$remove_image" == true ]; then
        ndr_verifyDockerImageExists "$temp_image_name" >/dev/null
        return_code=$?
        #2-error, 1-not found, 0-found
        if [ $return_code -ne 0 ]; then
          # skip if not found
          ndr_logWarn "Docker image [$temp_image_name] not found, nothing to prune."
          remove_image=false
        fi
      fi

      # if we know both image names for the prod db container and temp diff db container, check if they are same (can't prune) or different (can prune).
      if [ "$remove_image" == true ]; then
        local prod_image_name="${NDR_SCHEMA_DIFF_DOCKER_SERVICE_IMAGES_PROD[$service]}"
        if [[ -n "$prod_image_name" && -n "$temp_image_name" && "$prod_image_name" = "$temp_image_name" ]]; then
          ndr_logInfo "Temporary diff DB image [$temp_image_name] is the same as production DB image [$prod_image_name]. Skipping image prune."
          remove_image=false
        else
          ndr_logInfo "Temporary diff DB image [$temp_image_name] is different from production DB image [$prod_image_name]. Proceeding with image prune."
        fi
      fi

      # -----------------------------
      # removal actions
      # -----------------------------

      if [ "$remove_container" == true ]; then
        ndr_logInfo "Bringing down container [$temp_container_name]..."
        docker compose down --remove-orphans "$service"
        return_code=$?
        if [ $return_code -ne 0 ]; then
          ndr_logError "Failed to bring down and remove container [$temp_container_name]."
          retVal=1
        else
          ndr_logInfo "Container [$temp_container_name] removed successfully."
        fi
      fi

      if [ "$remove_image" == true ]; then
        ndr_logInfo "Removing image [$temp_image_name]..."
        docker image rm -f "$temp_image_name"
        return_code=$?
        if [[ $return_code != 0 ]]; then
          ndr_logError "Failed to remove image [$temp_image_name]."
          retVal=1
        else
          ndr_logInfo "Docker image [$temp_image_name] removal succeeded."
        fi
      fi
    done
  fi

  # -----------------------------
  # cleanup folders
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CLEANUP_FOLDERS )); then  
    if [[ -n "$buildDBFolder" && -d "$buildDBFolder" ]]; then
      ndr_logInfo "Removing temporary schema diff work directory [$buildDBFolder]..."
      rm -rf "$buildDBFolder"
    fi

    # if no more sub-folders exist, remove parent work dir
    if [ -d "$NDR_SCHEMA_DIFF_WORK_DIR" ] && [ -z "$(ls -A "$NDR_SCHEMA_DIFF_WORK_DIR")" ]; then
      ndr_logInfo "Removing empty schema diff work directory [$NDR_SCHEMA_DIFF_WORK_DIR]..."
      rm -rf "$NDR_SCHEMA_DIFF_WORK_DIR"
    fi
  fi

  if [ "$retVal" -ne 0 ]; then
    ndr_logWarn "One or more errors occurred during Supabase schema diff container cleanup."
  fi

  ndr_logSecEnd "$logSectionDesc"

  return $retVal
}

function ndr_SupabaseRollbackSchema() 
{
  local logSectionDesc="Rolling Back to Original Supabase Schema"
  ndr_logSecStart "$logSectionDesc"
  
  local schema_file="$1"

  # check for schema file
  if [ -z "$schema_file" ] || [ ! -f "$schema_file" ]; then
    ndr_logError "No active Supabase schema file or parameter option [$schema_file]."
    return 1
  fi

  ndr_logInfo "ROLLBACK: Restoring production DB '$gNDR_SUPABASE_DB_OPS_POSTGRES_ADMIN_USER' from backup '$schema_file'"

  ndr_SupabaseApplySchema "$schema_file"
  local nRollbackError=$?

  # always perform cleanup regardless of rollback success.
  ndr_SupabaseSchemaDiffCleanup

  ndr_logSecEnd "$logSectionDesc"

  if [ $nRollbackError -ne 0 ]; then
    ndr_logError "One or more errors occurred during rollback."
    return 1
  fi
  
  return 0
}

function ndr_SupabaseSchemaHeaderWrite ()
{
  local logSectionDesc="Writing Supabase Schema Header"
  ndr_logSecStart "$logSectionDesc"

  local schema_file="$1"

  # check for schema file
  if [ -z "$schema_file" ] || [ ! -f "$schema_file" ]; then
    ndr_logError "Invalid schema file or parameter option [$schema_file]."
    return 1
  fi

  # Values to update
  #-- NDR-SCHEMA-VERSION: 1.1.0
  #-- NDR-UPGRADE-FROM: 1.0.0
  #-- NDR_SCHEMA_TYPE: INCR
  #-- NDR-FULL-BASELINE-SCHEMA-SHA256-HASH: <hash_value>
  #-- NDR-FULL-UPGRADE-SCHEMA-SHA256-HASH: <hash_value>

  gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH_VAL=""
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL=""

  # compute sha256 checksum of the FULL baseline and upgrade schema file this DIFF weas generated from.
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH_VAL=$(sha256sum "$gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL" | awk '{print $1}')
  if [ -z "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH_VAL" ]; then
    ndr_logError "Failed to compute sha256 checksum of full schema file [$gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL]."
    return 1
  fi
  ndr_logInfo "Computed sha256 checksum [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH_VAL] of full baseline schema file: $gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL"

  gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL=$(sha256sum "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL" | awk '{print $1}')
  if [ -z "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL" ]; then
    ndr_logError "Failed to compute sha256 checksum of full schema file [$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL]."
    return 1
  fi
  ndr_logInfo "Computed sha256 checksum [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL] of full upgrade schema file: $gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL"

  # When generated from an acutal installation, the upgrade from version is the currently installed version.
  # but if run as a standalone diff generation, we would need to use the version embedded in the "from" schema file.
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL="$gINSTALLED_VERSION"
  
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL="$gPRODUCT_VERSION"
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_VAL="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_INCR"
  
  local search_pattern="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION"
  grep -q -- "$search_pattern" "$schema_file"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logInfo "Creating schema diff header in [$schema_file]"
    # inject initial values.
    local complete_header="--
$gNDR_SUPABASE_SCHEMA_FILE_HEADER_DESC 
$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION $gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL
$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM $gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL
$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE $gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_VAL
$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH $gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH_VAL
$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH $gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL
--"

    # Create temp file: header + original
    local tmpDiffFile="$schema_file.tmp"
    printf "%s\n\n%s" "$complete_header" "$(cat "$schema_file")" > "$tmpDiffFile"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to prepend schema version header to temp diff file [$tmpDiffFile]."
      return 1
    fi

    # Replace original file
    mv "$tmpDiffFile" "$schema_file"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to move temp diff file [$tmpDiffFile] to final diff file [$schema_file]."
      return 1
    fi

  else

    ndr_logInfo "Updating schema diff headers in [$schema_file]"

    local search_pattern="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION"
    local updated_header="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION $gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL"
    sed -i "s|.*${search_pattern}.*|${updated_header}|" "$schema_file"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to update schema version header [$search_pattern]"
      return 1
    fi

    search_pattern="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM"
    updated_header="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM $gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL"
    sed -i "s|.*${search_pattern}.*|${updated_header}|" "$schema_file"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to update schema upgrade version header [$search_pattern]"
      return 1
    fi

    search_pattern="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE"
    updated_header="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE $gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_VAL"
    sed -i "s|.*${search_pattern}.*|${updated_header}|" "$schema_file"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to update schema type header [$search_pattern]"
      return 1
    fi

    search_pattern="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH"
    updated_header="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH $gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH_VAL"
    sed -i "s|.*${search_pattern}.*|${updated_header}|" "$schema_file"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to update baseline schema hash header [$search_pattern]"
      return 1
    fi

    search_pattern="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH"
    updated_header="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH $gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL"
    sed -i "s|.*${search_pattern}.*|${updated_header}|" "$schema_file"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to update upschema version header [$search_pattern]"
      return 1
    fi
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseSchemaHeaderRead ()
{
  local logSectionDesc="Reading Supabase Schema Header"
  ndr_logSecStart "$logSectionDesc"

  local schema_file="$1"

  # check for schema file
  if [ -z "$schema_file" ] || [ ! -f "$schema_file" ]; then
    ndr_logError "Invalid schema file or parameter option [$schema_file]."
    return 1
  fi

  # Values to read
  #-- NDR-SCHEMA-VERSION: 1.1.0
  #-- NDR-UPGRADE-FROM: 1.0.0
  #-- NDR_SCHEMA_TYPE: INCR

  gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL=""
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL=""
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_VAL=""
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH_VAL=""
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL=""

  #--------------------------------
  # Version

  local search_pattern="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION"
  local line=$(grep "^$search_pattern" "$schema_file")

  if [[ -z "$line" ]]; then
    ndr_logError "Schema header [$search_pattern] not found in file [$schema_file]."
    return 1
  fi

  local val="$(
    echo "$line" | cut -d':' -f2 | tr -d ' '
  )"
  ndr_logInfo "Read schema header [$search_pattern $val]"
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL="$val"
  
  #--------------------------------
  # Upgrade from version

  search_pattern="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM"
  line=$(grep -- "$search_pattern" "$schema_file")

  if [[ -z "$line" ]]; then
    ndr_logError "Schema header [$search_pattern] not found in file [$schema_file]."
    return 1
  fi

  val="$(
    echo "$line" | cut -d':' -f2 | tr -d ' '
  )"
  ndr_logInfo "Read schema header [$search_pattern $val]"
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL="$val"

  #--------------------------------
  # Schema type

  search_pattern="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE"
  line=$(grep -- "$search_pattern" "$schema_file")

  if [[ -z "$line" ]]; then
    ndr_logError "Schema header [$search_pattern] not found in file [$schema_file]."
    return 1
  fi

  val="$(
    echo "$line" | cut -d':' -f2 | tr -d ' '
  )"
  ndr_logInfo "Read schema header [$search_pattern $val]"
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_VAL="$val"

  #--------------------------------
  # Baseline schema sha256 hash

  search_pattern="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH"
  line=$(grep -- "$search_pattern" "$schema_file")

  if [[ -z "$line" ]]; then
    ndr_logError "Schema header [$search_pattern] not found in file [$schema_file]."
    return 1
  fi

  val="$(
    echo "$line" | cut -d':' -f2 | tr -d ' '
  )"
  ndr_logInfo "Read schema header [$search_pattern $val]"
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH_VAL="$val"

  #--------------------------------
  # Upgrade schema sha256 hash

  search_pattern="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH"
  line=$(grep -- "$search_pattern" "$schema_file")

  if [[ -z "$line" ]]; then
    ndr_logError "Schema header [$search_pattern] not found in file [$schema_file]."
    return 1
  fi

  val="$(
    echo "$line" | cut -d':' -f2 | tr -d ' '
  )"
  ndr_logInfo "Read schema header [$search_pattern $val]"
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL="$val"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseSchemaDiffHeaderVerify ()
{
  local logSectionDesc="Verifying Supabase Schema Diff Header"
  ndr_logSecStart "$logSectionDesc"

  local schema_file="$1"

  # check for schema file
  if [ -z "$schema_file" ] || [ ! -f "$schema_file" ]; then
    ndr_logError "Invalid schema file or parameter option [$schema_file]."
    return 1
  fi

  # Values to validate
  #-- NDR-SCHEMA-VERSION: 1.1.0
  #-- NDR-UPGRADE-FROM: 1.0.0
  #-- NDR_SCHEMA_TYPE: INCR

  ndr_SupabaseSchemaHeaderRead "$schema_file"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to read schema diff header."
    return 1
  fi

  local nRet=0

  #--------------------------------
  # check basic verstion and type values

  if [ "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_VAL" != "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_INCR" ]; then
    ndr_logError "Schema diff type [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_VAL] is not incremental [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_INCR]."
    nRet=1
  fi

  if [ "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL" != "$gINSTALLED_VERSION" ]; then
    ndr_logError "Schema diff upgrade-from version [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL] does not match installed version [$gINSTALLED_VERSION]."
    nRet=1
  fi

  if [ "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL" != "$gPRODUCT_VERSION" ]; then
    ndr_logWarn "Schema diff target version [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL] does not match current version [$gPRODUCT_VERSION]."
    nRet=1
  fi

  #--------------------------------
  # read and compare checksums
  while true; do
    # compute sha256 checksum of the FULL baseline schema file this DIFF was generated from.
    if [ -z "$gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL" ] || [ ! -f "$gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL" ]; then
      ndr_logError "No active Supabase full installed schema file or value [$gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL]."
      nRet=1
      break
    fi

    local fullSchemaHash=$(sha256sum "$gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL" | awk '{print $1}')
    if [ -z "$fullSchemaHash" ]; then
      ndr_logError "Failed to compute sha256 checksum of full installed baseline schema file [$gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL]."
      nRet=1
      break
    fi
    ndr_logInfo "Computed sha256 checksum [$fullSchemaHash] of full installed baseline schema file: $gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL"

    if [ "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH_VAL" != "$fullSchemaHash" ]; then
      ndr_logError "Schema diff version of full schema hash [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH_VAL] does not match computed hash [$fullSchemaHash] of full installed baseline schema file [$gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL]."
      nRet=1
      break
    fi

    ndr_logInfo "Installed schema hash from diff header matches computed hash of installed baseline schema file."
    gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH_VAL="$fullSchemaHash"
    
    #--------------------------------
    # compute sha256 checksum of the FULL upgrade schema file this DIFF was generated from.
    if [ -z "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL" ] || [ ! -f "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL" ]; then
      ndr_logError "No active Supabase full upgrade schema file or value [$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL]."
      nRet=1
      break
    fi
    
    fullSchemaHash=""
    fullSchemaHash=$(sha256sum "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL" | awk '{print $1}')
    if [ -z "$fullSchemaHash" ]; then
      ndr_logError "Failed to compute sha256 checksum of full upgrade schema file [$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL]."
      nRet=1
      break
    fi
    ndr_logInfo "Computed sha256 checksum [$fullSchemaHash] of full upgrade schema file: $gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL"

    if [ "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL" != "$fullSchemaHash" ]; then
      ndr_logError "Schema diff version of full schema hash [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL] does not match computed hash [$fullSchemaHash] of full upgrade schema file [$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL]."
      nRet=1
      break
    fi

    ndr_logInfo "Upgrade schema hash from diff header matches computed hash of upgrade schema file."
    gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL="$fullSchemaHash"
    
    break
  done

  if [ $nRet -ne 0 ]; then
    ndr_logError "Schema diff header verification failed."
  else
    ndr_logInfo "Schema diff compatibility check passed."
  fi

  ndr_logSecEnd "$logSectionDesc"

  return $nRet
}


function ndr_SupabaseUpgradeSchema ()
{
  local logSectionDesc="Applying $gPRODUCT_NAME Supabase Upgrade Schema"
  ndr_logSecStart "$logSectionDesc"

  # optionally pass in a schema file to apply instead of the global one.
  gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL="${1:-$gACTIVE_NDR_SQL_SCHEMA_FILE}"
  
  # check for schema file
  if [ -z "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL" ] || [ ! -f "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL" ]; then
    ndr_logError "No active Supabase schema file or parameter option [$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL]."
    return 1
  fi

  gNDR_SUPABASE_DB_MERGE_TEMP_PROD_DB="NDR-merge-tmp-db_$$"
  #gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF_FILENAME="NDR-schema-diff_v${gPRODUCT_VERSION}_${NDR_GIT_REPO_COMMIT_HASH_SHORT}_$$.sql"

  local DB_SERVICE="$NDR_SUPABASE_APP_SERVICE_NAME_DB"
  
  # determine which user to use based on version (>=1.25.12 use supabase admin due to auth changes)
  ndr_version_ge "$gNDR_SUPABASE_GIT_VERSION_TAG" "1.25.12"
  return_code=$?
  if [ $return_code -eq 0 ]; then
    gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT="$gNDR_SUPABASE_DB_OPS_SUPABASE_ADMIN_USER"
    ndr_logDebug "Supabase version [$gNDR_SUPABASE_GIT_VERSION_TAG] >= 1.25.12, using supabase admin user [$gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT] for schema application."
  fi
  ndr_logInfo "Using schema account [$gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT] for schema application."

  # ----------------------------------------------------------------
  ndr_logInfo "Determining schema upgrade diff strategy..."
  ndr_SupabaseDetermineSchemaUpgradeStrategy
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to determine schema upgrade diff strategy."
    ndr_SupabaseSchemaDiffCleanup
    return 1
  fi
  ndr_logInfo "Selected schema upgrade diff strategy [$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY]."

  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into supabase project dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }

  # ----------------------------------------------------------------
  if [[ "$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY" == "$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY_DYNAMIC" ]]; then
    ndr_logInfo "Setting up diff environment for dynamic schema generation..."
    ndr_SupabaseSchemaDiffPrepare
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to prepare schema diff environment."
      ndr_SupabaseSchemaDiffCleanup
      return 1
    fi

    ndr_logInfo "Generating schema diff between production and upgraded temp DB's..."
    ndr_SupabaseSchemaDiffGenerate
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to generate schema diff."
      ndr_SupabaseSchemaDiffCleanup
      return 1
    fi

    cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into supabase project dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }

    # ----------------------------------------------------------------
    ndr_logInfo "Checking generated schema diff for compatibility..."
    ndr_SupabaseSchemaDiffHeaderVerify "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to validate generated schema diff."
      ndr_SupabaseSchemaDiffCleanup
      return 1
    fi

    # add the single generated diff file and version hop to the replay chain.
    gNDR_SUPABASE_UPGRADE_DIFF_VERSION_CHAIN=("${gINSTALLED_VERSION}|${gPRODUCT_VERSION}|generated|${gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF_FILENAME_SHORT}")
    gNDR_SUPABASE_UPGRADE_DIFF_FILE_CHAIN=("$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF")

  elif [[ "$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY" == "$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY_REPLAY" ]]; then
    ndr_logInfo "Using sequential schema replay with [${#gNDR_SUPABASE_UPGRADE_DIFF_FILE_CHAIN[@]}] diff file(s)."
  else
    ndr_logError "Unknown schema upgrade diff strategy [$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY]."
    ndr_SupabaseSchemaDiffCleanup
    return 1
  fi

  # ----------------------------------------------------------------
  # Validate the final replay plan before touching the live DB. The version and file
  # chains must stay index-aligned, and each diff file must match its expected hop header.
  if [[ ${#gNDR_SUPABASE_UPGRADE_DIFF_FILE_CHAIN[@]} -eq 0 || ${#gNDR_SUPABASE_UPGRADE_DIFF_VERSION_CHAIN[@]} -eq 0 ]]; then
    ndr_logError "No schema replay files or version chain entries were resolved for upgrade."
    ndr_SupabaseSchemaDiffCleanup
    return 1
  fi

  if [[ ${#gNDR_SUPABASE_UPGRADE_DIFF_FILE_CHAIN[@]} -ne ${#gNDR_SUPABASE_UPGRADE_DIFF_VERSION_CHAIN[@]} ]]; then
    ndr_logError "Schema replay file chain count [${#gNDR_SUPABASE_UPGRADE_DIFF_FILE_CHAIN[@]}] does not match version chain count [${#gNDR_SUPABASE_UPGRADE_DIFF_VERSION_CHAIN[@]}]."
    ndr_SupabaseSchemaDiffCleanup
    return 1
  fi

  for replay_idx in "${!gNDR_SUPABASE_UPGRADE_DIFF_FILE_CHAIN[@]}"; do
    local replay_hop_from_version=""
    local replay_hop_to_version=""
    local replay_hop_release_dir=""
    local replay_hop_diff_file=""
  
    local replay_hop_entry="${gNDR_SUPABASE_UPGRADE_DIFF_VERSION_CHAIN[$replay_idx]}"
    local replay_schema_file="${gNDR_SUPABASE_UPGRADE_DIFF_FILE_CHAIN[$replay_idx]}"
    IFS='|' read -r replay_hop_from_version replay_hop_to_version replay_hop_release_dir replay_hop_diff_file <<< "$replay_hop_entry"

    if [[ -z "$replay_hop_from_version" || -z "$replay_hop_to_version" || -z "$replay_schema_file" ]]; then
      ndr_logError "Invalid schema replay hop mapping at index [$replay_idx] [$replay_hop_entry] [$replay_schema_file]."
      ndr_SupabaseSchemaDiffCleanup
      return 1
    fi

    if [[ ! -f "$replay_schema_file" ]]; then
      ndr_logError "Schema replay file not found [$replay_schema_file] for hop [$replay_hop_from_version -> $replay_hop_to_version]."
      ndr_SupabaseSchemaDiffCleanup
      return 1
    fi

    ndr_SupabaseSchemaHeaderRead "$replay_schema_file"
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Failed to read schema replay file header [$replay_schema_file]."
      ndr_SupabaseSchemaDiffCleanup
      return 1
    fi

    if [[ "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_VAL" != "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_INCR" ]]; then
      ndr_logError "Schema replay file type [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_VAL] is not incremental for [$replay_schema_file]."
      ndr_SupabaseSchemaDiffCleanup
      return 1
    fi

    if [[ "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL" != "$replay_hop_from_version" ]]; then
      ndr_logError "Schema replay file upgrade-from version [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL] does not match expected hop-from [$replay_hop_from_version] for [$replay_schema_file]."
      ndr_SupabaseSchemaDiffCleanup
      return 1
    fi

    if [[ "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL" != "$replay_hop_to_version" ]]; then
      ndr_logError "Schema replay file target version [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL] does not match expected hop-to [$replay_hop_to_version] for [$replay_schema_file]."
      ndr_SupabaseSchemaDiffCleanup
      return 1
    fi

    ndr_logInfo "Validated schema replay file [$replay_schema_file] for hop [$replay_hop_from_version -> $replay_hop_to_version]."
  done

  # ----------------------------------------------------------------
  # Stop select services that may re-open connections
  ndr_logInfo "Stopping Supabase Dashboard and related services..."
  docker compose stop "$NDR_SUPABASE_APP_SERVICE_NAME_REALTIME" "$NDR_SUPABASE_APP_SERVICE_NAME_REST" "$NDR_SUPABASE_APP_SERVICE_NAME_KONG" "$NDR_SUPABASE_APP_SERVICE_NAME_STUDIO"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to stop Supabase Dashboard and related services."
    ndr_SupabaseSchemaDiffCleanup
    return 1
  fi

  # ----------------------------------------------------------------
  # Drop all current db connections
  ndr_logInfo "Dropping all active connections to $gNDR_SUPABASE_DB_OPS_PRODUCTION_DB"
  docker compose exec -T "$NDR_SUPABASE_APP_SERVICE_NAME_DB" psql -U "$gNDR_SUPABASE_DB_OPS_SUPABASE_ADMIN_USER" -d "$gNDR_SUPABASE_DB_OPS_PRODUCTION_DB" -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='postgres' AND pid <> pg_backend_pid();"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to drop active production DB connections."
    ndr_SupabaseSchemaDiffCleanup
    return 1
  fi
  
  # ----------------------------------------------------------------
  # Apply db upgrade diff to production DB
  ndr_logInfo "Applying upgrade schema to production DB..."
  # full command arg list
  # sqlOutput=$(docker compose exec -T "$DB_SERVICE" psql -U "$gNDR_SUPABASE_DB_OPS_POSTGRES_ADMIN_USER" -d postgres -v ON_ERROR_STOP=1 < "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF")
  local psql_args=()
  psql_args+=("docker" "compose" "exec" "-T" "$DB_SERVICE" "psql" "-U" "$gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT" "-d" "postgres")

  # Conditionally add -v ON_ERROR_STOP=1
  if [[ "$gNDR_ALLOW_SCHEMA_ERRORS" != "true" ]]; then
    psql_args+=("-v" "ON_ERROR_STOP=1")
  fi

  # Replay each diff file in order so downlevel installs can advance through each supported schema hop.
  local schema_replay_file=""
  sqlOutput=""
  for schema_replay_file in "${gNDR_SUPABASE_UPGRADE_DIFF_FILE_CHAIN[@]}"; do
    ndr_logInfo "Applying schema replay file [$schema_replay_file]..."

    sqlOutput=$("${psql_args[@]}" < "$schema_replay_file")
    return_code=$?

    # Print any ERROR or WARNING lines from sqlOutput
    if [ -n "$sqlOutput" ]; then
      while IFS= read -r line; do
        if echo "$line" | grep -qE 'ERROR|WARNING'; then
          echo "$line"
        fi
      done <<< "$sqlOutput"
    fi

    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to apply schema replay file [$schema_replay_file] to production DB."
      
      return 1
    fi
    
  done

  # ----------------------------------------------------------------
  # restart services
  docker compose start "$NDR_SUPABASE_APP_SERVICE_NAME_REALTIME" "$NDR_SUPABASE_APP_SERVICE_NAME_REST" "$NDR_SUPABASE_APP_SERVICE_NAME_KONG" "$NDR_SUPABASE_APP_SERVICE_NAME_STUDIO"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to start Supabase services."
    #return 1
  fi

  # ----------------------------------------------------------------
  ndr_logInfo "Success: Live DB upgraded."
  
  ndr_logInfo "Cleaning up temporary files..."
  
  ndr_SupabaseSchemaDiffCleanup
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseApplySchema ()
{
  local logSectionDesc="Applying $gPRODUCT_NAME Custom Supabase Schema"
  ndr_logSecStart "$logSectionDesc"

  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into supabase project dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }

  # optionally pass in a schema file to apply instead of the global one.
  local schema_file="${1:-$gACTIVE_NDR_SQL_SCHEMA_FILE}"

  # check for schema file
  if [ -z "$schema_file" ] || [ ! -f "$schema_file" ]; then
    ndr_logError "No active Supabase schema file or parameter option [$schema_file]."
    return 1
  fi

  local DB_SERVICE="$NDR_SUPABASE_APP_SERVICE_NAME_DB"
  
  # determine which user to use based on version (>=1.25.12 use supabase admin due to auth changes)
  ndr_version_ge "$gNDR_SUPABASE_GIT_VERSION_TAG" "1.25.12"
  return_code=$?
  if [ $return_code -eq 0 ]; then
    gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT="$gNDR_SUPABASE_DB_OPS_SUPABASE_ADMIN_USER"
    ndr_logDebug "Supabase version [$gNDR_SUPABASE_GIT_VERSION_TAG] >= 1.25.12, using supabase admin user [$gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT] for schema application."
  fi
  ndr_logInfo "Using schema account [$gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT] for schema application."

  # ----------------------------------------------------------------
  # Stop select services that may re-open connections
  ndr_logInfo "Stopping Supabase Dashboard and related services..."
  docker compose stop "$NDR_SUPABASE_APP_SERVICE_NAME_REALTIME" "$NDR_SUPABASE_APP_SERVICE_NAME_REST" "$NDR_SUPABASE_APP_SERVICE_NAME_KONG" "$NDR_SUPABASE_APP_SERVICE_NAME_STUDIO"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logWarn "Failed to stop Supabase Dashboard and related services."
  fi

  # ----------------------------------------------------------------
  # Drop all current db connections
  ndr_logInfo "Dropping all active connections to $gNDR_SUPABASE_DB_OPS_PRODUCTION_DB"
  docker compose exec -T $"$NDR_SUPABASE_APP_SERVICE_NAME_DB" psql -U "$gNDR_SUPABASE_DB_OPS_SUPABASE_ADMIN_USER" -d "$gNDR_SUPABASE_DB_OPS_PRODUCTION_DB" -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='postgres' AND pid <> pg_backend_pid();"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logWarn "Failed to drop active production DB connections."
  fi

  # ----------------------------------------------------------------
  ndr_logInfo "Resetting Supabase database..."
  declare -a schema_list=("public" "auth")

  for drop_schema in "${schema_list[@]}"; do
    # Check if schema file contains 'CREATE SCHEMA $drop_schema'
    if grep -q "^CREATE SCHEMA $drop_schema" "$schema_file"; then
      ndr_logInfo "Schema file [$schema_file] contains $drop_schema schema, resetting $drop_schema schema..."
    
      local sqlOutput=$(docker compose exec -T "$NDR_SUPABASE_APP_SERVICE_NAME_DB" psql -U "$gNDR_SUPABASE_DB_OPS_SUPABASE_ADMIN_USER" -d "$gNDR_SUPABASE_DB_OPS_PRODUCTION_DB" -c "DROP SCHEMA IF EXISTS $drop_schema CASCADE;") # sql script will recreate schema
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logWarn "Failed to reset Supabase database schema [$drop_schema]"
      fi
    else
      ndr_logInfo "Schema file [$schema_file] does not contain $drop_schema schema, skipping reset of $drop_schema schema."
    fi
  done

  # ----------------------------------------------------------------
  ndr_logInfo "Applying Supabase database schema [$schema_file]..."
  # full command arg list
  # sqlOutput=$(docker exec -i "$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME" psql -U "$gNDR_SUPABASE_DB_OPS_POSTGRES_ADMIN_USER" -d "$gNDR_SUPABASE_DB_OPS_PRODUCTION_DB" -v ON_ERROR_STOP=1 < "$schema_file") # error checking enabled
  
  psql_args=()
  psql_args+=("docker" "exec" "-i" "$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME" "psql" "-U" "$gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT" "-d" "$gNDR_SUPABASE_DB_OPS_PRODUCTION_DB")
  # Conditionally add -v ON_ERROR_STOP=1
  if [[ "$gNDR_ALLOW_SCHEMA_ERRORS" != "true" ]]; then
    psql_args+=("-v" "ON_ERROR_STOP=1")
  fi

  # Execute and capture output
  sqlOutput=$("${psql_args[@]}" < "$schema_file")
  return_code=$?
  # Print any ERROR or WARNING lines from sqlOutput
  if [ -n "$sqlOutput" ]; then
    while IFS= read -r line; do
      if echo "$line" | grep -qE 'ERROR|WARNING'; then
        echo "$line"
      fi
    done <<< "$sqlOutput"
  fi
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to apply Supabase database schema [$schema_file]"
    docker compose start "$NDR_SUPABASE_APP_SERVICE_NAME_REALTIME" "$NDR_SUPABASE_APP_SERVICE_NAME_REST" "$NDR_SUPABASE_APP_SERVICE_NAME_KONG" "$NDR_SUPABASE_APP_SERVICE_NAME_STUDIO"
    return 1
  fi
  #[ "$gDEBUG_MODE" == true ] && ndr_logInfo "$schemaReplay"
  
  # ----------------------------------------------------------------
  # restart services
  docker compose start "$NDR_SUPABASE_APP_SERVICE_NAME_REALTIME" "$NDR_SUPABASE_APP_SERVICE_NAME_REST" "$NDR_SUPABASE_APP_SERVICE_NAME_KONG" "$NDR_SUPABASE_APP_SERVICE_NAME_STUDIO"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logWarn "Failed to start Supabase Dashboard and related services."
  fi

  # ----------------------------------------------------------------
  # Validate schema applied by checking for a known table
  ndr_logInfo "Querying Supabase tables for schema..."
  local table_list=$(docker exec -i "$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME" psql -U "$gNDR_SUPABASE_DB_OPS_POSTGRES_ADMIN_USER" -d "$gNDR_SUPABASE_DB_OPS_PRODUCTION_DB" -c '\dt' 2>/dev/null)
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logWarn "Failed to query schema status"
  fi
  
  local searchTable="recovery_plans"
  if [[ -n "$table_list" ]]; then
    # Search for the recovery_plans table
    if echo "$table_list" | grep -q "\b$searchTable\b"; then
      #ndr_logInfo "$table_list"
      ndr_logInfo "Table $searchTable found, schema applied."
    else
      ndr_logInfo "$table_list"
      ndr_logError "Table $searchTable not found. Schema may not have been applied."
      return 1
    fi
  else
    ndr_logError "Table list empty. Schema may not have been applied."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_PromptNDRConsoleAdminAccount ()
{
  ndr_logInfo "Prompting for $gPRODUCT_NAME Console Admin Account details."
  ndr_logSecStart "$logSectionDesc"

  if [ "$gUPGRADE_MODE" == true ]; then
    ndr_logDebug "Upgrade mode set, skipping section."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # Prompt for admin email (username)
  if [[ -z "$gNDR_CONSOLE_ADMIN_ACCOUNT_USER" ]]; then
    while true; do
      read -p "Enter the $gPRODUCT_NAME Console Admin account email address to create: " input_email
      echo >&2 # new line
      # Basic email regex
      if [[ "$input_email" =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]]; then
        read -n 1 -p "You entered: $input_email. Is this correct? (Y/n): "
        echo >&2 # new line
        if [[ $REPLY =~ ^[Nn]$ ]]; then
          continue
        fi
        gNDR_CONSOLE_ADMIN_ACCOUNT_USER="$input_email"
        break
      else
        echo "Invalid email format. Please try again."
        continue
      fi
    done
    
    ndr_logInfo "Using user entered account [$gNDR_CONSOLE_ADMIN_ACCOUNT_USER] to create."
  else
    ndr_logInfo "Using predefined account [$gNDR_CONSOLE_ADMIN_ACCOUNT_USER] to create."
  fi

  # Prompt for admin password (with confirmation)
  if [[ -z "$gNDR_CONSOLE_ADMIN_ACCOUNT_PASSWORD" ]]; then
    while true; do
      read -s -p "Enter $gPRODUCT_NAME Console Admin password: " input_pass1
      echo >&2 # new line
      if [[ -z "$input_pass1" ]]; then
        echo "Password cannot be empty. Please try again."
        continue
      fi

      read -s -p "Re-enter password: " input_pass2
      echo >&2 # new line
      if [[ -z "$input_pass2" ]]; then
        echo "Password cannot be empty. Please try again."
        continue
      fi
      
      if [[ "$input_pass1" != "$input_pass2" ]]; then
        echo "Passwords do not match. Please try again."
        continue
      fi
      
      gNDR_CONSOLE_ADMIN_ACCOUNT_PASSWORD="$input_pass1"
      break
    done
    
    ndr_logInfo "Using user entered password to create."
  else
    ndr_logInfo "Using predefined password to create."
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_CreateNDRConsoleAdminAccount ()
{
  local logSectionDesc="Creating $gPRODUCT_NAME Console Admin Account"
  ndr_logSecStart "$logSectionDesc"

  if [ "$gUPGRADE_MODE" == true ]; then
    ndr_logDebug "Upgrade mode set, skipping section."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # Prompt for account info if not already set
  if [[ -z "$gNDR_CONSOLE_ADMIN_ACCOUNT_USER" || -z "$gNDR_CONSOLE_ADMIN_ACCOUNT_PASSWORD" ]]; then
    ndr_PromptNDRConsoleAdminAccount
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to get $gPRODUCT_NAME Console Admin account info."
      return 1
    fi
  else
    ndr_logInfo "$gPRODUCT_NAME Console Admin Account user and password already populated, skipping prompt."
  fi

  # Admin account creation can be run as a separate post-install command and so the folders need to be populated.
  if [ -z "$gSUPABASE_NEXTDR_HOME" ]; then
    gSUPABASE_NEXTDR_HOME="${gNEXTDR_HOME_DIR}/${gSUPABASE_NEXTDR_SUB}"
  fi
  if [ ! -d "$gSUPABASE_NEXTDR_HOME" ]; then
    ndr_logError "Unable to determine Supabase home directory or directory doesn't exist."
    return 1
  fi

  # Inject: Read API_EXTERNAL_URL and SERVICE_ROLE_KEY from env file
  local env_file="${gSUPABASE_NEXTDR_HOME}/${gNDR_ENV_TARGET_FILENAME}"
  if [[ ! -f "$env_file" ]]; then
    ndr_logError "Env file [$env_file] not found. API_EXTERNAL_URL and SERVICE_ROLE_KEY not loaded."
    return 1
  fi
  
  # todo - external ip resolving incorrectly on integration vm's, use localhost instead.
  #API_EXTERNAL_URL=$(grep -E '^API_EXTERNAL_URL=' "$env_file" | cut -d'=' -f2-)
  API_EXTERNAL_URL="http://localhost:8000"
  SERVICE_ROLE_KEY=$(grep -E '^SERVICE_ROLE_KEY=' "$env_file" | cut -d'=' -f2-)
  
  if [[ -z "$API_EXTERNAL_URL" || -z "$SERVICE_ROLE_KEY" ]]; then
    ndr_logError "Could not read API_EXTERNAL_URL or SERVICE_ROLE_KEY from env file [$env_file]."
    return 1
  fi
  ndr_logInfo "Read API_EXTERNAL_URL [$API_EXTERNAL_URL] and SERVICE_ROLE_KEY from env file [$env_file]."

  if [[ -z "$gNDR_CONSOLE_ADMIN_ACCOUNT_USER" || -z "$gNDR_CONSOLE_ADMIN_ACCOUNT_PASSWORD" ]]; then
    ndr_logError "$gPRODUCT_NAME Console Admin Account user or password is not set."
    return 1
  fi
  ndr_logInfo "Creating $gPRODUCT_NAME Console Admin Account user [$gNDR_CONSOLE_ADMIN_ACCOUNT_USER]."

  local curlRespFile="/tmp/curlReqResp.json"
  max_retries=5
  attempt=1

  while true; do
    rm -f "$curlRespFile"  # clean up prior

    sleep 5  # wait before attempting since this is called right after container startup.

    create_response=$(curl -s -o "$curlRespFile" -w "%{http_code}" -X POST "$API_EXTERNAL_URL/auth/v1/admin/users" \
    -H "apikey: $SERVICE_ROLE_KEY" \
    -H "Authorization: Bearer $SERVICE_ROLE_KEY" \
    -H "Content-Type: application/json" \
    -d "{
      \"email\": \"$gNDR_CONSOLE_ADMIN_ACCOUNT_USER\",
      \"password\": \"$gNDR_CONSOLE_ADMIN_ACCOUNT_PASSWORD\",
      \"email_confirm\": true,
      \"user_metadata\": {
      \"role\": \"admin\"
      }
    }")
    return_code=$?
    ndr_logInfo "ret code: $return_code"

    # Extract response body
    response_body=$(cat "$curlRespFile")
    #todo rm -f "$curlRespFile"  # clean up


    # Check if the request was successful
    if [[ "$create_response" -eq 200 || "$create_response" -eq 201 ]]; then
      # Parse JSON response for confirmation
      user_email=$(echo "$response_body" | jq -r '.email // empty')
      user_id=$(echo "$response_body" | jq -r '.id // empty')
      user_created_at=$(echo "$response_body" | jq -r '.created_at // empty')
      ndr_logInfo "User created: email=[$user_email], id=[$user_id], created_at=[$user_created_at]"
      break
    fi
    
    ndr_logWarn "Unable to create user [$gNDR_CONSOLE_ADMIN_ACCOUNT_USER]. Status code: [$create_response], Response body: [$response_body], retrying..."

    if [[ $attempt -ge $max_retries ]]; then
      ndr_logError "Max user creation retries reached. Exiting."
      return 1
    fi

    attempt=$((attempt + 1))
    
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_CreateSupabaseDashboardAccount ()
{
  local logSectionDesc="Creating Supabase Dashboard Account"
  ndr_logSecStart "$logSectionDesc"

  if [ "$gUPGRADE_MODE" == true ]; then
    ndr_logDebug "Upgrade mode set, skipping section."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  if [ "$gEXPRESS_MODE" == true ]; then
    # if the dashboard user/pass is not set in express mode, we can still use the standard account in the env file.
    if [[ -z "$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME" || -z "$gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD" ]]; then
      ndr_logWarn "Supabase Dashboard Admin Account user [$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME] or password is not explicitly set for express mode, using default template credentials."
    else
      ndr_logInfo "Using Supabase Dashboard Admin account user [$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME] and password for express mode."
    fi
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # by default, we do not prompt interactively unless in advanced mode or auto generation fails.
  local promptInteractively=false
  #if [ "$gNDR_ADVANCED_MODE" == "true" ]; then
  #  promptInteractively=true
  #fi

  if [[ -z "$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME" || -z "$gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD" ]]; then
    ndr_logWarn "Could not prepopulate DASHBOARD_USERNAME or DASHBOARD_PASSWORD from any source."
    promptInteractively=true
  fi
  
  if [ "$promptInteractively" == false ]; then
    gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD=$(ndr_generateSecurePassword "$gSUPABASE_DASHBOARD_PASSWORD_LENGTH" 2>/dev/null)
    #gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD="ndr"
    return_code=$?
    if [[ $return_code -ne 0 || -z "$gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD" ]]; then
      ndr_logWarn "Failed to generate Supabase Dashboard Admin Account password, forcing interactive prompt."
      promptInteractively=true
    fi
  fi
  
  if [ "$promptInteractively" == true ]; then
    # Prompt for admin email (username)
    echo -e "The Supabase Dashboard Admin Account username is currently [$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME]. Is this the username you wish to use for the Dashboard Admin Account?" >&2
    read -p "Choose YES to continue with this username or NO to be prompted to enter a new one [Y|n]" -n 1 -r
    echo >&2   # Move to a new line
    if [[ $REPLY =~ ^[Nn]$ ]]; then
      # clear it and we will prompt below to enter
      gSUPABASE_ENV_VAL_DASHBOARD_USERNAME=""
    fi
      
    if [ -z "$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME" ]; then
      while true; do
        read -p "Enter the Supabase Dashboard Admin account to create: " gSUPABASE_ENV_VAL_DASHBOARD_USERNAME
        echo >&2 # new line
    
        if [ -n "$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME" ]; then
          read -n 1 -p "You entered: $gSUPABASE_ENV_VAL_DASHBOARD_USERNAME. Is this correct? (Y/n): "
          echo >&2 # new line
          if [[ $REPLY =~ ^[Nn]$ ]]; then
            gSUPABASE_ENV_VAL_DASHBOARD_USERNAME=""
            continue
          fi
          break
        else
          echo "Invalid username. Please try again."
          continue
        fi
      done
    fi
    
    # Prompt for admin password (with confirmation)
    while true; do
      read -s -p "Enter Supabase Dashboard Admin Account password: " input_pass1
      echo >&2 # new line
      if [[ -z "$input_pass1" ]]; then
        echo "Password cannot be empty. Please try again."
        continue
      fi

      read -s -p "Re-enter password: " input_pass2
      echo >&2 # new line
      if [[ -z "$input_pass2" ]]; then
        echo "Password cannot be empty. Please try again."
        continue
      fi
      
      if [[ "$input_pass1" != "$input_pass2" ]]; then
        echo "Passwords do not match. Please try again."
        continue
      fi
      
      gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD="$input_pass1"
      break
    done
    
    if [[ -z "$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME" || -z "$gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD" ]]; then
      ndr_logError "Supabase Dashboard Admin Account user or password is not set."
      return 1
    fi
  fi

  ndr_logInfo "Creating Supabase Dashboard Admin Account user [$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME] and password."

  # update env var map entries
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_DASHBOARD_USERNAME"]="$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_DASHBOARD_PASSWORD"]="$gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD"
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_BackupPostgresDB () 
{
  local logSectionDesc="Backing up Supabase Postgres DB"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -ne 2 ]]; then
    ndr_logError "Usage: function <staging_folder> <options>"
    return 1
  fi

  local staging_folder="$1"
  local options="$2"

  local retCode=0
  
  # ----------------------------------------------------------------
  # prereq module checks
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
  local dbInstalled=$?
  if [ "$dbInstalled" -ne 0 ]; then
    ndr_logWarn "The $gCOMPANY_NAME Supabase database module does not appear to be currently installed."
    return 0
  fi

  local containerName="$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME"
  ndr_verifyDockerContainerExists "$containerName" >/dev/null
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Container not present [$containerName]"
    return 1
  fi
    
  ndr_verifyDockerContainerRunning "$containerName" >/dev/null
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Container not running [$containerName]"
    return 1
  fi

  # ----------------------------------------------------------------
  # form local home folder paths.
  if [[ -z "$gNEXTDR_HOME_DIR" || ! -d "$gNEXTDR_HOME_DIR" ]]; then
    ndr_logInfo "Home directory is not set or does not exist. Attempting to determine home directory..."
    
    # read from registry if package already present.
    gNEXTDR_HOME_DIR=$(ndr_getHomeDirReg)
    return_code=$?
    if [[ $return_code -eq 0 && -n "$gNEXTDR_HOME_DIR" && -d "$gNEXTDR_HOME_DIR" ]]; then
      ndr_logInfo "Found home directory entry [$gNEXTDR_HOME_DIR] in registry."
    else
      ndr_logWarn "No home directory entry found in registry."
    fi
  fi

  gSUPABASE_NEXTDR_HOME="${gNEXTDR_HOME_DIR}/${gSUPABASE_NEXTDR_SUB}"
  if [[ -z "$gSUPABASE_NEXTDR_HOME" || ! -d "$gSUPABASE_NEXTDR_HOME" ]]; then
    ndr_logError "Unable to determine Supabase home directory or directory doesn't exist. Please install the local Supabase module prior to pulling the reference schema so there is a local instance to link the remote instance to."
    return 1
  fi

  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into supabase project dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }

  local backup_folder="${staging_folder}/${gNDR_APP_BACKUP_DB_SCHEMA_SUB}"
  if [ ! -d "$backup_folder" ]; then
    mkdir "$backup_folder"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to create db backup folder [$backup_folder]"
      return 1
    fi
    ndr_logInfo "Successfully created db backup folder [$backup_folder]"
  else
    ndr_logInfo "DB backup folder already exists [$backup_folder]"
  fi

  while true; do
    # ----------------------------------------------------------------
    # Stop select services that may re-open connections
    ndr_logInfo "Stopping Supabase Dashboard and related services..."
    docker compose stop "$NDR_SUPABASE_APP_SERVICE_NAME_REALTIME" "$NDR_SUPABASE_APP_SERVICE_NAME_REST" "$NDR_SUPABASE_APP_SERVICE_NAME_KONG" "$NDR_SUPABASE_APP_SERVICE_NAME_STUDIO"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logWarn "Failed to stop Supabase Dashboard and related services."
    fi

    # ----------------------------------------------------------------
    # Drop all current db connections
    ndr_logInfo "Dropping all active connections to $gNDR_SUPABASE_DB_OPS_PRODUCTION_DB"
    docker compose exec -T "$NDR_SUPABASE_APP_SERVICE_NAME_DB" psql -U "$gNDR_SUPABASE_DB_OPS_SUPABASE_ADMIN_USER" -d "$gNDR_SUPABASE_DB_OPS_PRODUCTION_DB" -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='postgres' AND pid <> pg_backend_pid();"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logWarn "Failed to drop active production DB connections."
    fi
    
    # ----------------------------------------------------------------
    local version_stamp=$(ndr_getModuleVersionReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME")
    return_code=$?
    if [[ $return_code -ne 0 || -n "$version_stamp" ]]; then
      version_stamp="$gPRODUCT_VERSION"
    fi

    # create backup file dump
    local timestamp
    timestamp=$(date +"%Y%m%d_%H%M%S")
    gNDR_SUPABASE_DB_BACKUP_FILE="${backup_folder}/NDR-schema-bkp_v${version_stamp}_${timestamp}.sql"

    ndr_logInfo "🔄 Starting full Postgres backup to: $gNDR_SUPABASE_DB_BACKUP_FILE"

    # build as an array to allow for easier conditional appending of options.
    if false; then
    # deprecated - switched to pg_dumpall to perform a try full backup to capture global objects like roles and extensions in addition to the schema and data.
    local cmd=(docker compose exec -T db pg_dump -U postgres -d postgres --no-owner --schema=public)
    cmd+=(--schema=auth)

    if [ "$gNDR_POSTGRES_EXPORT_SCHEMA_ONLY" == true ]; then
      cmd+=(--schema-only)
    fi
    fi

    local cmd=(docker compose exec -T db pg_dumpall -U supabase_admin)
    
    "${cmd[@]}" > "$gNDR_SUPABASE_DB_BACKUP_FILE"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Backup failed."
      retCode=1
      break
    fi
    echo "Backup dump completed successfully: $gNDR_SUPABASE_DB_BACKUP_FILE"

    # ----------------------------------------------------------------
    # Back up the pgsodium encryption key (stored in a Docker named volume)
    
    # prepare backup folder for key backup
    backup_folder="${staging_folder}/${gNDR_APP_BACKUP_DB_KEYS_SUB}"
    if [ ! -d "$backup_folder" ]; then
      mkdir "$backup_folder"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "Failed to create db backup folder [$backup_folder]"
        return 1
      fi
      ndr_logInfo "Successfully created db backup folder [$backup_folder]"
    else
      ndr_logInfo "DB backup folder already exists [$backup_folder]"
    fi

    local pgsodium_key_backup_file="${backup_folder}/pgsodium_root.key.backup"
    docker compose run --rm db cat /etc/postgresql-custom/pgsodium_root.key > "$pgsodium_key_backup_file"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Backup of pgsodium encryption key failed."
      retCode=1
      break
    fi
    echo "Backup of pgsodium encryption key completed successfully: $pgsodium_key_backup_file"

    # ----------------------------------------------------------------
    # Stop remaining services to ensure db consistency during file copy
    ndr_logInfo "Stopping remaining Supabase services to ensure DB consistency..."

    ndr_StopSupabaseDockerServices
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logWarn "Failed to stop remaining Supabase services."
    fi

    # ----------------------------------------------------------------
    # prepare backup folder for db vol data

    backup_folder="${staging_folder}/${gNDR_APP_BACKUP_DB_DATA_SUB}"
    if [ ! -d "$backup_folder" ]; then
      mkdir "$backup_folder"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "Failed to create db backup folder [$backup_folder]"
        return 1
      fi
      ndr_logInfo "Successfully created db backup folder [$backup_folder]"
    else
      ndr_logInfo "DB backup folder already exists [$backup_folder]"
    fi
    
    # ----------------------------------------------------------------
    # create tarball of the entire db folder
    local db_dir="$gSUPABASE_NEXTDR_HOME/volumes/db/data"
    local db_tar_file="${backup_folder}/NDR-db-vol-bkp_v${version_stamp}_${timestamp}.tar.gz"
    ndr_logInfo "Creating tarball of Supabase Postgres data folder: $db_dir to $db_tar_file"
    tar -czf "$db_tar_file" -C "$db_dir" .
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to create archive $db_tar_file from $db_dir"
      retCode=1
      break
    fi
    ndr_logInfo "Created archive $db_tar_file from $db_dir"

    break
  done

  # ----------------------------------------------------------------
  # always restart containers after backup
  #docker compose start "$NDR_SUPABASE_APP_SERVICE_NAME_REALTIME" "$NDR_SUPABASE_APP_SERVICE_NAME_REST" "$NDR_SUPABASE_APP_SERVICE_NAME_KONG" "$NDR_SUPABASE_APP_SERVICE_NAME_STUDIO"
  ndr_StartSupabaseDockerServices
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to restart Supabase services."
    #return 1
  fi
  
  # ----------------------------------------------------------------
  if (( options & gNDR_APP_BACKUP_RESTORE_OPTIONS_DB_CACHE_SCHEMA_BACKUP )); then
    ndr_logInfo "Caching db schema backup..."

    local schema_cache_dir="/var/backups/ndr/schema-tmp"
    local schema_cache_file="${schema_cache_dir}/$(basename "$gNDR_SUPABASE_DB_BACKUP_FILE")"

    if [[ -z "$gNDR_SUPABASE_DB_BACKUP_FILE" || ! -s "$gNDR_SUPABASE_DB_BACKUP_FILE" ]]; then
      ndr_logError "Cannot cache db schema backup; source file is missing or empty [$gNDR_SUPABASE_DB_BACKUP_FILE]"
      return 1
    fi

    sudo mkdir -p "$schema_cache_dir"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to create db schema backup cache folder [$schema_cache_dir]"
      return 1
    fi

    sudo cp -f "$gNDR_SUPABASE_DB_BACKUP_FILE" "$schema_cache_file"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to cache db schema backup [$gNDR_SUPABASE_DB_BACKUP_FILE] to [$schema_cache_file]"
      return 1
    fi

    gNDR_SUPABASE_DB_BACKUP_FILE="$schema_cache_file"
    ndr_logInfo "Cached db schema backup to: $gNDR_SUPABASE_DB_BACKUP_FILE"
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_RestorePostgresDB () 
{
  local logSectionDesc="Restoring Supabase Postgres DB"
  ndr_logSecStart "$logSectionDesc"

  # todo +++ switch to the rollback procedure here:
  # https://supabase.com/docs/guides/self-hosting/postgres-upgrade-17#rollback
  # or here:
  # https://supabase.com/docs/guides/self-hosting/postgres-upgrade-17#restoring-from-a-manual-backup

  # Restore expects the staged db_data component folder from the backup manifest.
  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <db_backup_folder>"
    return 1
  fi

  local backup_folder="$1"
  if [[ ! -d "$backup_folder" ]]; then
    ndr_logError "DB data backup folder not found [$backup_folder]."
    return 1
  fi

  # ----------------------------------------------------------------
  # prereq module checks

  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
  local dbInstalled=$?
  if [[ "$dbInstalled" -ne 0 ]]; then
    ndr_logWarn "The $gCOMPANY_NAME Supabase database module does not appear to be currently installed."
    #return 1
  fi

  local containerName="$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME"
  ndr_verifyDockerContainerExists "$containerName" >/dev/null
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Container not present [$containerName]"
    #return 1
  fi
    
  # ----------------------------------------------------------------
  # Stop remaining services to ensure db consistency during file copy
  ndr_logInfo "Stopping remaining Supabase services to ensure DB consistency..."

  ndr_StopSupabaseDockerServices
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logWarn "Failed to stop remaining Supabase services."
  fi

  # ----------------------------------------------------------------
  # form local home folder paths for restoring data to.

  if [[ -z "$gNEXTDR_HOME_DIR" || ! -d "$gNEXTDR_HOME_DIR" ]]; then
    ndr_logInfo "Home directory is not set or does not exist. Attempting to determine home directory..."
    
    # read from registry if package already present.
    gNEXTDR_HOME_DIR=$(ndr_getHomeDirReg)
    return_code=$?
    if [[ $return_code -eq 0 && -n "$gNEXTDR_HOME_DIR" && -d "$gNEXTDR_HOME_DIR" ]]; then
      ndr_logInfo "Found home directory entry [$gNEXTDR_HOME_DIR] in registry."
    else
      ndr_logWarn "No home directory entry found in registry."
    fi
  fi

  gSUPABASE_NEXTDR_HOME="${gNEXTDR_HOME_DIR}/${gSUPABASE_NEXTDR_SUB}"
  if [[ -z "$gSUPABASE_NEXTDR_HOME" || ! -d "$gSUPABASE_NEXTDR_HOME" ]]; then
    ndr_logError "Unable to determine Supabase home directory or directory doesn't exist. Please install the local Supabase module prior to pulling the reference schema so there is a local instance to link the remote instance to."
    return 1
  fi

  # ----------------------------------------------------------------
  # Prepare the db data folder for restore by clearing out the existing contents
  local db_data_folder="$gSUPABASE_NEXTDR_HOME/volumes/db/data"
  if [[ -d "$db_data_folder" ]]; then
    ndr_logInfo "Clearing existing contents of db data folder [$db_data_folder] in preparation for restore."
    rm -rf "${db_data_folder}"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to clear existing contents of db data folder [$db_data_folder]"
      return 1
    fi
  fi
  
  mkdir -p "$db_data_folder"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to re-create db data folder [$db_data_folder]"
    return 1
  fi
  ndr_logInfo "Prepared db data folder [$db_data_folder] for restore."

  # ----------------------------------------------------------------
  # now untar the backup data into the db data folder

  # first locate the tar.gz file in the backup folder.
  local db_tar_file=$(find "$backup_folder" -type f -name "*.tar.gz" | head -n 1)
  if [[ -z "$db_tar_file" ]]; then
    ndr_logError "No db data tar.gz file found in backup folder [$backup_folder]"
    return 1
  fi

  ndr_logInfo "Restoring db data from tarball [$db_tar_file] to folder [$db_data_folder]"
  tar -xzf "$db_tar_file" -C "$db_data_folder"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to extract db data tarball [$db_tar_file] to folder [$db_data_folder]"
    return 1
  fi
  ndr_logInfo "Successfully restored db data from tarball [$db_tar_file] to folder [$db_data_folder]"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_RestorePostgresEncryptionKey () 
{
  local logSectionDesc="Restoring Supabase Postgres Encryption Key"
  ndr_logSecStart "$logSectionDesc"

  # Restore expects the staged db_keys component folder from the backup manifest.
  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <db_keys_backup_folder>"
    return 1
  fi

  local backup_folder="$1"
  if [[ ! -d "$backup_folder" ]]; then
    ndr_logError "DB keys backup folder not found [$backup_folder]."
    return 1
  fi

  # ----------------------------------------------------------------
  # prereq module checks

  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
  local dbInstalled=$?
  if [[ "$dbInstalled" -ne 0 ]]; then
    ndr_logError "The $gCOMPANY_NAME Supabase database module does not appear to be currently installed."
    return 1
  fi

  local imageName="$NDR_SUPABASE_APP_SERVICE_NAME_DB_IMAGE_NAME"
  ndr_verifyDockerImageExists "$imageName" >/dev/null
  return_code=$?
  #2-error, 1-not found, 0-found
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Image not present [$imageName]"
    return 1
  fi

  # container should not be running.
  local containerName="$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME"
  ndr_verifyDockerContainerRunning "$containerName" >/dev/null
  return_code=$?
  if [ $return_code -eq 0 ]; then
    ndr_logError "Container is currently running [$containerName]. Please stop the container before attempting to restore the encryption key."
    return 1
  fi

  # ----------------------------------------------------------------
  
  # locate the key backup file in the backup folder.
  local key_backup_file=$(find "$backup_folder" -type f -name "pgsodium_root.key.backup" | head -n 1)
  if [[ -z "$key_backup_file" ]]; then
    ndr_logError "No pgsodium key backup file found in backup folder [$backup_folder]"
    return 1
  fi

  ndr_logInfo "Restoring pgsodium encryption key from file [$key_backup_file] to Supabase Postgres container [$containerName]"
  
  #docker compose run --rm db sh -c "cat > /etc/postgresql-custom/pgsodium_root.key" < "$key_backup_file"
  
  docker compose run --rm db \
    sh -c 'cat > /etc/postgresql-custom/pgsodium_root.key' < "$key_backup_file" && \
  docker compose run --rm db \
    chown postgres:postgres /etc/postgresql-custom/pgsodium_root.key && \
  docker compose run --rm db \
    chmod 600 /etc/postgresql-custom/pgsodium_root.key

  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to restore pgsodium encryption key from file [$key_backup_file] to Supabase Postgres container [$containerName]"
    return 1
  fi
  
  ndr_logInfo "Successfully restored pgsodium encryption key from file [$key_backup_file] to Supabase Postgres container [$containerName]"
 
  ndr_logSecEnd "$logSectionDesc"
 
  return 0
}

function ndr_SupabaseQueryLatestTag ()
{
  local logSectionDesc="Querying Latest Supabase Repo Tag"
  ndr_logSecStart "$logSectionDesc"

  local repo="$gNDR_SUPABASE_GIT_REPO"
  local startTag="$gNDR_SUPABASE_GIT_VERSION_TAG"

  # Normalize the input tag (remove 'v' prefix if present)
  cleanStartTag=$(echo "$startTag" | sed 's/^v//')

  # Fetch and normalize all tags
  ndr_logInfo "Fetching and sorting tags from $repo..."
  tag_list=$(
    curl -s "https://api.github.com/repos/$repo/tags?per_page=100" |
    jq -r '.[].name' |
    awk '{ orig=$0; clean=$0; gsub(/^v/, "", clean); print clean "\t" orig }' |
    sort -V -k1,1
  )

  # Print tag list for visibility (optional)
  #echo "Sorted tags:"
  #echo "$tag_list" | awk '{print NR " → " $2 " (clean=" $1 ")"}'

  # Get the last/latest entry
  latest_tag=$(echo "$tag_list" | tail -n 1 | awk '{print $2}')

  ndr_logInfo "Latest tag detected: ${latest_tag:-none}"
  if [ -z "$latest_tag" ]; then
    ndr_logWarn "Unable to find latest tag beyond [$startTag]"
    return 1
  fi

  if [ "$latest_tag" == "$cleanStartTag" ]; then
    ndr_logInfo "Tag [$cleanStartTag] is already latest/up to date for repo."
    return 0
  fi

  # query for hash for this tag
  local commit=$(curl -s "https://api.github.com/repos/$repo/git/ref/tags/$latest_tag" | jq -r '.object.sha')

  if [ -z "$commit" ] || [ "$commit" == "null" ]; then
    ndr_logWarn "No commit found for tag $latest_tag."
    return 1
  fi

  gNDR_SUPABASE_GIT_VERSION_COMMIT_HASH_FULL="$commit"
  gNDR_SUPABASE_GIT_VERSION_COMMIT_HASH_SHORT=$(echo "$commit" | cut -c1-7)
  gNDR_SUPABASE_GIT_VERSION_TAG="$latest_tag"

  ndr_logInfo "Updating to latest Supabase tag [$gNDR_SUPABASE_GIT_VERSION_TAG], commit [$gNDR_SUPABASE_GIT_VERSION_COMMIT_HASH_FULL ($gNDR_SUPABASE_GIT_VERSION_COMMIT_HASH_SHORT)]"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseQueryLatestCommit ()
{
  local logSectionDesc="Querying Latest Supabase Repo Commit"
  ndr_logSecStart "$logSectionDesc"

  local repo="$gNDR_SUPABASE_GIT_REPO"
  local startTag="$gNDR_SUPABASE_GIT_VERSION_TAG"

  #if [[ -n "$gNDR_SUPABASE_GIT_VERSION_TAG_NEXT" && -n "$gNDR_SUPABASE_GIT_VERSION_COMMIT_HASH_FULL" ]]; then
  #  ndr_logInfo "Supabase repo version info already populated. Skipping."
  #  ndr_logSecEnd "$logSectionDesc"
  #  return 0
  #fi

  # Normalize the input tag (remove 'v' prefix if present)
  local cleanStartTag=$(echo "$startTag" | sed 's/^v//')

  # Fetch and normalize all tags
  ndr_logInfo "Fetching and sorting tags from $repo..."
  tag_list=$(
    curl -s "https://api.github.com/repos/$repo/tags?per_page=100" |
    jq -r '.[].name' |
    awk '{ orig=$0; clean=$0; gsub(/^v/, "", clean); print clean "\t" orig }' |
    sort -V -k1,1
  )

  # Print tag list for visibility (optional)
  #echo "Sorted tags:"
  #echo "$tag_list" | awk '{print NR " → " $2 " (clean=" $1 ")"}'

  # Find next tag after the given one
  local nextTag=$(echo "$tag_list" | awk -v target="$cleanStartTag" '
    found { print $2; exit }   # print the next tag after the match
    $1 == target { found=1 }   # mark when we find the current tag
  ')

  echo "Matched cleanStartTag: $cleanStartTag"
  echo "Next tag detected: ${nextTag:-none}"

  if [ -z "$nextTag" ]; then
    nextTag="master"
  fi
  gNDR_SUPABASE_GIT_VERSION_TAG_NEXT="$nextTag"
  
  # all commits between startTag and nextTag
  #local commits=$(curl -s "https://api.github.com/repos/$repo/compare/$startTag...$nextTag" | jq -r '.commits[].sha')

  # only latest commit between startTag and nextTag
  local commit=$(curl -s "https://api.github.com/repos/$repo/compare/$startTag...$nextTag" | jq -r '.commits[-1].sha')
  if [ -z "$commit" ] || [ "$commit" == "null" ]; then
    ndr_logWarn "No commits found between $startTag and $nextTag."
    return 1
  fi

  gNDR_SUPABASE_GIT_VERSION_COMMIT_HASH_FULL="$commit"
  gNDR_SUPABASE_GIT_VERSION_COMMIT_HASH_SHORT=$(echo "$commit" | cut -c1-7)
  ndr_logInfo "Latest commit between $startTag and $nextTag: $commit ($gNDR_SUPABASE_GIT_VERSION_COMMIT_HASH_SHORT)"
  

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseUpgradeCheck ()
{
  local logSectionDesc="Building and Installing Supabase Docker application"
  ndr_logSecStart "$logSectionDesc"

  if [[ "$gUPGRADE_MODE" != true ]]; then
    ndr_logDebug "Upgrade mode not set, skipping section."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # check for supabase tag upgrade by comparing the currently installed tag (if any) to the target tag for this installation. 
  # If they differ, we know we are performing an upgrade that includes a supabase version change and can set a flag to trigger any additional upgrade logic needed for that scenario.
  local targetSupabaseTag="${gNDR_SUPABASE_GIT_VERSION_TAG#v}"
  targetSupabaseTag="${targetSupabaseTag#V}"

  if [[ -z "$gNEXTDR_HOME_DIR" || ! -d "$gNEXTDR_HOME_DIR" ]]; then
    ndr_logError "Home directory [$gNEXTDR_HOME_DIR] is not set or does not exist. Cannot check installed Supabase version for upgrade comparison."
    return 1
  fi
  
  local installedSupabaseTag=""
  if ! installedSupabaseTag=$(ndr_getSupabaseTagReg 2>/dev/null); then
    installedSupabaseTag=""
  fi
  if [[ -z "$installedSupabaseTag" ]]; then
    local installedSupabaseScript="${gNEXTDR_HOME_DIR}/ndrSupabase.sh"
    if [[ ! -f "$installedSupabaseScript" ]]; then
      ndr_logError "Installed Supabase script not found at expected location [$installedSupabaseScript]. Cannot check installed Supabase version for upgrade comparison."
      return 1
    fi

    installedSupabaseTag=$(sed -n 's/^export gNDR_SUPABASE_GIT_VERSION_TAG="\([^"]*\)".*/\1/p' "$installedSupabaseScript" | head -n 1)
  fi
  if [[ -z "$installedSupabaseTag" ]]; then
    ndr_logError "Unable to resolve installed Supabase tag."
    return 1
  fi
  installedSupabaseTag="${installedSupabaseTag#v}"
  installedSupabaseTag="${installedSupabaseTag#V}"

  if [[ "$installedSupabaseTag" != "$targetSupabaseTag" ]]; then
    gNDR_SUPABASE_GIT_VERSION_TAG_UPGRADE=true
    gNDR_SUPABASE_POSTGRES_MINOR_VERSION_UPGRADE=true # we can assume that at least a minor version upgrade will be needed if the supabase tag is changing, but we will check the postgres image tag below to determine if a major version upgrade is also needed.
    ndr_logInfo "Installed Supabase tag [$installedSupabaseTag] differs from target tag [$gNDR_SUPABASE_GIT_VERSION_TAG]. Supabase version upgrade enabled."
  else
    ndr_logInfo "Installed Supabase tag [$installedSupabaseTag] matches target tag [$gNDR_SUPABASE_GIT_VERSION_TAG]. No Supabase version upgrade needed."
  fi

  # todo: for tag upgrades, read both the currently installed and target compose files and build arrays of services names and thier image names. iterate through the installed service array and find its match in the target array. if the image name version tag has changed, that service and its container needs to be de-composed later during pre install container cleanup. if not changed, it can just be stopped.
  if [[ "$gNDR_SUPABASE_GIT_VERSION_TAG_UPGRADE" == true ]]; then
    # parse target compose file to get the list of services and their image tags for comparison to the currently installed compose file services and image tags.
    declare -a target_services=()
    declare -A target_service_container_names=()
    declare -A target_service_image_names=()
    declare -A target_service_image_tags=()

    declare -a target_compose_files=("$NDR_STANDARD_DOCKER_COMPOSEFILE_FILENAME")
    if [[ "$gNDR_SUPABASE_USE_LATEST_POSTGRES_IMAGE" == true ]]; then
      target_compose_files+=("docker-compose.pg17.yml")
    fi

    local tmpPath="/tmp"

    for targetComposeFileName in "${target_compose_files[@]}"; do
      local targetComposeFileUrl="https://raw.githubusercontent.com/supabase/supabase/$gNDR_SUPABASE_GIT_VERSION_TAG/docker/$targetComposeFileName"
      local targetComposeFile="$tmpPath/ndr-target-$targetComposeFileName"
      local curlErrorFile="$tmpPath/ndr-target-supabase-compose-curl.err"

      rm -f "$curlErrorFile" "$targetComposeFile"
      curl --fail --location --retry 5 --retry-delay 2 --retry-connrefused "$targetComposeFileUrl" -o "$targetComposeFile" 2>"$curlErrorFile"
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Failed to download target Supabase compose file from [$targetComposeFileUrl]."
        if [ -s "$curlErrorFile" ]; then
          ndr_logError "curl error output: $(tr '\n' ' ' < "$curlErrorFile")"
        fi
        return 1
      fi
      rm -f "$curlErrorFile"
      ndr_logInfo "Downloaded target Supabase compose file [$targetComposeFile] from [$targetComposeFileUrl]."
      
      local options="$gNDR_PARSE_COMPOSE_FILE_OPTIONS_APPEND"
      ndr_ParseComposeFileServicesV2 "$targetComposeFile" target_services target_service_container_names target_service_image_names target_service_image_tags "$options"
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Failed to parse compose file [$targetComposeFile] for service details."
        return 1
      fi

      if [[ ${#target_services[@]} -eq 0 ]]; then
        ndr_logWarn "No services found in the compose file '$targetComposeFile'."
        return 1
      fi
    done

    # parse installed compose file to get the list of services and their image tags for comparison to the target compose file services and image tags.
    local installedComposeFile="${gNEXTDR_HOME_DIR}/${gSUPABASE_NEXTDR_SUB}/docker-compose.yml"
    if [[ ! -f "$installedComposeFile" ]]; then
      ndr_logError "Installed Supabase compose file not found at expected location [$installedComposeFile]. Cannot check installed Postgres version for upgrade comparison."
      return 1
    fi

    # clear and use the global arrays for the installed servuces since we will need this info later during the pre-install cleanup process to determine which containers need to be removed vs just stopped.
    ndr_supabase_container_services=()
    ndr_supabase_container_service_container_names=()
    ndr_supabase_container_service_image_names=()
    ndr_supabase_container_service_image_tags=()

    ndr_ParseComposeFileServicesV2 "$installedComposeFile" ndr_supabase_container_services ndr_supabase_container_service_container_names ndr_supabase_container_service_image_names ndr_supabase_container_service_image_tags "$options"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to parse compose file [$installedComposeFile] for service details."
      return 1
    fi

    if [[ ${#ndr_supabase_container_services[@]} -eq 0 ]]; then
      ndr_logWarn "No services found in the compose file '$installedComposeFile'."
      return 1
    fi

    # iterate through source services and compare to target services to determine which services are changing in the upgrade and need to be removed vs just stopped during the pre-install cleanup process.
    # set the ndr_supabase_container_service_image_update flag with [true|false] for that service to trigger the image update logic during the install process for that service.
    for service in "${ndr_supabase_container_services[@]}"; do
      local installedImageTag="${ndr_supabase_container_service_image_tags["$service"]}"
      local targetImageTag="${target_service_image_tags["$service"]}"
      if [[ -z "$installedImageTag" || -z "$targetImageTag" ]]; then
        ndr_logWarn "Unable to resolve image tags for service [$service] to compare for upgrade. Skipping image comparison for this service."
        ndr_supabase_container_service_image_update["$service"]=false
        continue
      fi

      if [[ "$installedImageTag" != "$targetImageTag" ]]; then
        ndr_logInfo "Service [$service] image tag is changing in the upgrade from [$installedImageTag] to [$targetImageTag]. Image update will be needed for this service during upgrade."
        ndr_supabase_container_service_image_update["$service"]=true
      else
        ndr_logInfo "Service [$service] image tag is not changing in the upgrade and remains at [$installedImageTag]. No image update will be needed for this service during upgrade."
        ndr_supabase_container_service_image_update["$service"]=false
      fi
    done

    # If a tag upgrade is needed, only then should we check the supabase major/minor versions for further actions and decisions.
    # Check Postgres major/minor versions for a potential version upgrade scenario that may require special handling.
    # Resolve the target version from the target Supabase compose file rather than assuming a fixed Postgres major.
    
    # get target postgres image from the target array
    local targetPostgresTag="${target_service_image_tags["$NDR_SUPABASE_APP_SERVICE_NAME_DB"]}"
    if [[ -z "$targetPostgresTag" ]]; then
      ndr_logError "Unable to resolve target Postgres image tag from target services array."
      return 1
    fi

    local targetPostgresMajor="${targetPostgresTag%%.*}"
    local targetPostgresMinor="${targetPostgresTag#*.}"
    targetPostgresMinor="${targetPostgresMinor%%.*}"
    if [[ ! "$targetPostgresMajor" =~ ^[0-9]+$ ]]; then
      ndr_logError "Unable to resolve target Postgres major version from image [$targetPostgresTag]."
      return 1
    fi
    if [[ ! "$targetPostgresMinor" =~ ^[0-9]+$ ]]; then
      ndr_logError "Unable to resolve target Postgres minor version from image [$targetPostgresTag]."
      return 1
    fi

    local installedPostgresTag="${ndr_supabase_container_service_image_tags["$NDR_SUPABASE_APP_SERVICE_NAME_DB"]}"
    if [[ -z "$installedPostgresTag" ]]; then
      ndr_logError "Unable to resolve installed Postgres image tag from installed services array."
      return 1
    fi

    local installedPostgresMajor="${installedPostgresTag%%.*}"
    local installedPostgresMinor="${installedPostgresTag#*.}"
    installedPostgresMinor="${installedPostgresMinor%%.*}"
    if [[ ! "$installedPostgresMajor" =~ ^[0-9]+$ ]]; then
      ndr_logError "Unable to resolve installed Postgres major version from image [$installedPostgresTag]."
      return 1
    fi
    if [[ ! "$installedPostgresMinor" =~ ^[0-9]+$ ]]; then
      ndr_logError "Unable to resolve installed Postgres minor version from image [$installedPostgresTag]."
      return 1
    fi
    
    ndr_logInfo "Installed Postgres image [$installedPostgresTag] version [$installedPostgresTag], upgrade target image [$targetPostgresTag] version [$targetPostgresTag]."

    if (( installedPostgresMajor < targetPostgresMajor )); then
      gNDR_SUPABASE_POSTGRES_MAJOR_VERSION_UPGRADE=true
    elif (( installedPostgresMajor == targetPostgresMajor && installedPostgresMinor < targetPostgresMinor )); then
      ndr_logInfo "Postgres minor version upgrade detected [$installedPostgresMajor.$installedPostgresMinor -> $targetPostgresMajor.$targetPostgresMinor]. Minor upgrades are supported through image swaps."
    fi

    if [[ "$gNDR_SUPABASE_POSTGRES_MAJOR_VERSION_UPGRADE" == true && "$gNDR_SUPABASE_ALLOW_POSTGRES_MAJOR_VERSION_UPGRADE" == false ]]; then
      ndr_logWarn "Installed Postgres major version [$installedPostgresMajor] is below target major version [$targetPostgresMajor]. Postgres major version upgrade is currently prohibited."
      return 1
    fi
  fi

  # determine the schema upgrade strategy.
  ndr_SupabaseDetermineSchemaUpgradeStrategy 
  return_code=$? 
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to determine Supabase schema upgrade strategy."
    return 1
  fi
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_BuildSupabaseApplication ()
{
  local logSectionDesc="Building and Installing Supabase Docker application"
  ndr_logSecStart "$logSectionDesc"

  local return_code=0

  local appBuildOptions="${1:-$NDR_SUPABASE_APP_BUILD_OPTIONS_NONE}"
  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_NONE )); then
    ndr_logError "No build options specified."
    return 1
  fi

  while true; do
    ndr_PrepareSupabaseInstallation "$appBuildOptions"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Supabase prepare step failed."
      break
    fi

    ndr_ConfigureSupabaseInstallation "$appBuildOptions"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Supabase configure step failed."
      gNDR_UPGRADE_FAILURE_ROLLBACK_REQUIRED=true # product irreversably modified, may require rollback recovery.
      break
    fi
    
    ndr_InstallSupabaseApplication "$appBuildOptions"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Supabase install step failed."
      gNDR_UPGRADE_FAILURE_ROLLBACK_REQUIRED=true # product irreversably modified, may require rollback recovery.
      break
    fi
    
    ndr_PostInstallSupabaseApplication "$appBuildOptions"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Supabase post install step failed."
      break
    fi

    break
  done

  # attempt to restore from backup on upgrade failures
  if [[ $return_code -ne 0 && "$gUPGRADE_MODE" == "true" && "$gNDR_UPGRADE_FAILURE_ROLLBACK_REQUIRED" == "true" ]]; then
    ndr_logError "Supabase application upgrade failed with errors. Please review the logs and resolve any issues before retrying the installation. Attempting to clean up installation failure by restoring from backup if possible."
    
    if [[ -n "$gNDR_APP_BACKUP_FILE" && ! -f "$gNDR_APP_BACKUP_FILE" ]]; then
      ndr_logError "Cached restore archive file [$gNDR_APP_BACKUP_FILE] was not found, restore from backup is not possible."
      return 1
    fi

    local restoreOptions="$gNDR_APP_BACKUP_RESTORE_OPTIONS_ALL_MODULES"

    # if we have updated containers, we can attempt to remove the current images and containers and put back the images and container from the restored version.
    if [[ "$gNDR_SUPABASE_GIT_VERSION_TAG_UPGRADE" == "true" ]]; then
      restoreOptions=$(( restoreOptions | gNDR_APP_BACKUP_RESTORE_OPTIONS_RESTORE_DOCKER_ENTITIES ))
    fi

    ndr_RestoreApplication "$restoreOptions"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Automatic attempt of application restore failed. Manual recovery may be needed. Please review the logs and attempt to resolve any issues with the backup file or restore process and try again. If restore continues to fail, please contact support for further assistance."
      ndr_logInfo "To recover, please reinstall the previous version of the application that was just upgraded from and then restore the backup using the following command: "
      ndr_logInfo "sudo ./ndrInstall.sh -e restoreapp \"$gNDR_APP_BACKUP_FILE\""
    fi

    ndr_logInfo "Application restore from backup completed successfully. Please review the logs for details on the restore process and resolve any issues if needed."
  fi

  ndr_logSecEnd "$logSectionDesc"

  return "$return_code"
}

function ndr_PrepareSupabaseInstallation ()
{
  local logSectionDesc="Prepare Supabase Application"
  ndr_logSecStart "$logSectionDesc"

  local appBuildOptions="${1:-$NDR_SUPABASE_APP_BUILD_OPTIONS_NONE}"
  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_NONE )); then
    ndr_logError "No build options specified."
    return 1
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_INSTALL_PREREQUISITES )); then
    ndr_packagePrereqCheck
    return_code=$?
    if [ $return_code -ne 0 ]; then
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_HOME_DIR_CHECK )); then
    ndr_InstallHomeCheck
    return_code=$?
    if [ $return_code -ne 0 ]; then
      return 1
    fi
    
    gSUPABASE_NEXTDR_HOME="${gNEXTDR_HOME_DIR}/${gSUPABASE_NEXTDR_SUB}"
    gSUPABASE_TEMPLATE_HOME="${gNEXTDR_HOME_DIR}/${gSUPABASE_TEMPLATE_SUB}"
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_PREUPGRADE )); then
    ndr_SupabaseUpgradeCheck
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failure while performing Supabase upgrade checks."
      return 1
    fi

    if [[ "$gUPGRADE_MODE" == true ]]; then
      ndr_logInfo "Upgrade mode enabled. Performing pre-upgrade backup of application and configuration data." 

      local backupOptions=$(( $gNDR_APP_BACKUP_RESTORE_OPTIONS_ALL_MODULES | $gNDR_APP_BACKUP_RESTORE_OPTIONS_DB_CACHE_SCHEMA_BACKUP ))
      ndr_BackupApplication "$backupOptions"
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Application backup failed."
        gNDR_APP_BACKUP_FILE="" # clear backup file variable since backup failed and file may not be valid.
        #return 1
      fi

      ndr_PreserveSupabaseConfigFiles
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Config file backup failed."
        #return 1
      fi
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_INSTALL_PROMPTS )); then
    ndr_PromptHostAddress
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to prompt for host address."
      return 1
    fi

    ndr_PromptNDRConsoleAdminAccount
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to prompt for Supabase dashboard account details."
      return 1
    fi

    if [[ "$gNDR_ADVANCED_MODE" == true ]]; then
      ndr_PromptCaddyProxyMode
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Failed to prompt for Caddy container proxy configuration mode."
        return 1
      fi
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_CLEANUP_EXISTING_APP )); then
    local cleanupOptions=$NDR_SUPABASE_CLEANUP_OPTION_BEST_EFFORT
    ndr_SupabaseContainerCleanup $cleanupOptions
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to clean up Supabase containers."
      gNDR_UPGRADE_FAILURE_ROLLBACK_REQUIRED=true # product irreversably modified, may require rollback recovery.
      return 1
    fi
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_ConfigureSupabaseInstallation ()
{
  local logSectionDesc="Configuring Supabase Installation"
  ndr_logSecStart "$logSectionDesc"

  local appBuildOptions="${1:-$NDR_SUPABASE_APP_BUILD_OPTIONS_NONE}"
  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_NONE )); then
    ndr_logError "No build options specified."
    return 1
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_SUPABASE_DIRS )); then
    ndr_CreateSupabaseFolders
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to create Supabase folders."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_GIT_CLONE_TEMPLATE )); then
    ndr_PullSupabaseGitTemplate
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to pull Supabase git template."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_TEMPLATE_FILES )); then
    ndr_CopySupabaseTemplateFiles
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to copy Supabase template files."
      return 1
    fi
  fi
  
  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_CUSTOMIZE_COMPOSE_FILE )); then
    ndr_customizeSupabaseDockerComposeFile "$appBuildOptions"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to customize $gCOMPANY_NAME Docker compose file."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_QUERY_COMPOSE_SERVICES )); then
    local dockerComposeFile="$gSUPABASE_NEXTDR_HOME/docker-compose.yml"
    ndr_ParseComposeFileServices "$dockerComposeFile"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to parse Docker compose file [$dockerComposeFile] service entries."
      return 1
    fi
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_InstallSupabaseApplication ()
{
  local logSectionDesc="Installing Supabase Application"
  ndr_logSecStart "$logSectionDesc"

  local appBuildOptions="${1:-$NDR_SUPABASE_APP_BUILD_OPTIONS_NONE}"
  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_NONE )); then
    ndr_logError "No build options specified."
    return 1
  fi

  if [ "$gUPGRADE_MODE" == false ]; then
    if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_SUPABASE_APP_REGISTRY )); then
      ndr_RegistryCreateV2 "$gPRODUCT_VERSION" "$gNEXTDR_HOME_DIR" "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
      return_code=$?
      if [ $return_code -ne 0 ]; then
        return 1
      fi

      ndr_setSupabaseTagReg "$gNDR_SUPABASE_GIT_VERSION_TAG"
      return_code=$?
      if [ $return_code -ne 0 ]; then
        return 1
      fi
      
      ndr_logInfo "Successfully created registry."
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_POPULATE_HOST_ADDRESS )); then
    ndr_PopulateHostAddress
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to populate hostname/ip address for remote host resolution."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_DASHBOARD_ACCOUNT )); then
    ndr_CreateSupabaseDashboardAccount
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to create Supabase Dashboard account."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_SCHEMA_FILE_CHECK )); then
    ndr_SupabaseLocalSchemaFileCheck
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "No active Supabase schema file found."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_ENV_FILE )); then
    ndr_CopySupabaseEnvFile
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to copy $gCOMPANY_NAME Supabase env file."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_CUSTOMIZE_ENV_FILE )); then
    ndr_CustomizeSupabaseEnvFileV2
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to customize $gCOMPANY_NAME Supabase env file."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_PULL_SUPABASE_BASE_IMAGES )); then
    ndr_PullSupabaseBaseDockerImagesV2
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to pull Supabase base Docker images."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_BRIDGE_NETWORK )); then
    # create the bridge network if it does not exist
    ndr_createDockerBridgeNetwork
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to create Docker bridge network."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_START_CONTAINERS )); then
    ndr_ComposeSupabaseDockerContainers
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to start Supabase $gCOMPANY_NAME Docker containers."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_VERIFY_CONTAINERS )); then
    # check if the newly built Docker containers exist
    ndr_verifySupabaseContainersExist
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Docker container verification failed."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_SUPABASE_APP_REGISTRY )); then
    ndr_RegistryAddKeyServiceEntries
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to add Docker service entries to registry"
      return 1
    fi
    ndr_logInfo "Successfully added Docker compose file service entries to registry."
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_INSTALL_FILES )); then
    ndr_CopyInstallHomeFiles
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to copy install home files"
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_SCHEMA_FILE )); then
    ndr_CopySupabaseSchemaFile
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to copy $gCOMPANY_NAME Supabase schema file."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_APPLY_SCHEMA )); then
    if [ "$gUPGRADE_MODE" == true ]; then
      ndr_SupabaseUpgradeSchema "$gACTIVE_NDR_SQL_SCHEMA_FILE"
    else
      ndr_SupabaseApplySchema "$gACTIVE_NDR_SQL_SCHEMA_FILE"
    fi
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Application of custom schema failed."
      return 1
    fi
  fi

  if [ "$gUPGRADE_MODE" == true ]; then
    if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_SUPABASE_APP_REGISTRY )); then
      ndr_RegistryCreateV2 "$gPRODUCT_VERSION" "$gNEXTDR_HOME_DIR" "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
      return_code=$?
      if [ $return_code -ne 0 ]; then
        return 1
      fi

      ndr_setSupabaseTagReg "$gNDR_SUPABASE_GIT_VERSION_TAG"
      return_code=$?
      if [ $return_code -ne 0 ]; then
        return 1
      fi
      
      ndr_logInfo "Successfully updated registry."
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_ADMIN_ACCOUNT )); then
    ndr_CreateNDRConsoleAdminAccount
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Admin account creation failed."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_SYSTEMD )); then
    ndr_InstallSystemdUnit_Supabase
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to create systemd service unit for Supabase"
      return 1
    fi
  fi
  
  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_APP_INSTALL_COMPLETE_NOTIFY )); then
    ndr_SupabaseInstallCompletePopulateReport
    ndr_SupabaseInstallCompleteNotify
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_PostInstallSupabaseApplication ()
{
  local logSectionDesc="Post install Supabase Application"
  ndr_logSecStart "$logSectionDesc"

  local appBuildOptions="${1:-$NDR_SUPABASE_APP_BUILD_OPTIONS_NONE}"
  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_NONE )); then
    ndr_logError "No build options specified."
    return 1
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_CLEANUP_SUPABASE_DIRS )); then
    ndr_CleanupSupabaseProjectDirs
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to clean up Supabase Docker folders."
      return 1
    fi
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ndr_logWarn "This is a bash module--there is no direct execution capabilities in this file."
  exit 0
fi
