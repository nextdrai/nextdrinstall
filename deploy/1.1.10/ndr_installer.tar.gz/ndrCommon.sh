#!/bin/bash
# ndrCommon.sh - A Bash module providing common definitions and functions

source "$(dirname "${BASH_SOURCE[0]}")/ndrVersion.sh"

# company/product naming
export gCOMPANY_NAME="NextDR"
export gPRODUCT_NAME="NextDR"
export gPRODUCT_NAME_SHORT="ndr"

# upgrade
export gUPGRADE_MODE=false # used for major upgrades
export gUPDATE_MODE=false # used for minor, patch or image updates.
export gINSTALLED_VERSION=""
export gNDR_UPGRADE_FAILURE_ROLLBACK_REQUIRED=false # flag to indicate whether a rollback is needed due to upgrade failure that may have left the application in a broken state, used to trigger additional recovery steps such as restoring from backup or re-installing the previous version's images/containers.

# globals influencing various common and shared script behaviors
export gTRACELOG_TO_STDOUT=true # global flag to indicate if logging should be sent to stdout in addition to the log file.
export gTRACELOG_TO_FILE=true # global flag to indicate if logging should be sent to a log file.
export gNDR_DEVOPS_MODE=false
export gNDR_INSTALL_MODE=false
export gNDR_ADMIN_MODE=false
export gNDR_RETAIN_DOCKER_IMAGES=false # flag to retain docker images after uninstalling module. Can save time when performing repeated uninstall/reinstalls in various test/integration scenarios.
export gNDR_USE_LOCAL_IMAGE_FOR_APP_INSTALL=false # flag to enable the use of local images for container creation during install. Useful for integration of apps in installed invironment with integration builds.
export gNDR_RECREATE_DOCKER_CONTAINERS=false # flag to re-create docker containers via docker compose CLI during admin script start (vs start existing container). Useful for pulling in new environment changes.
export gNDR_SKIP_REMOTE_IMAGE_REPO_UPDATE_CHECK=false # flag to skip the remote image repo update check. Useful for installing the tagged installer version without checking for a newer version in remote docker hub repo.
export gNDR_HAS_TTY=true
export gNDR_MAX_IMAGE_LIST=5 # max number of remote docker hub images to list during advanced install of packaged.
export gNDR_FULL_SUPABASE_SERVICES_MODE=false # flag to enable full supabase services in docker compose file by including *all* services (not removing optional services such as storage, functions, analytics, etc).

# install engine options
export gNDR_INSTALL_ENG_VER="$gNDR_INSTALL_ENG_VERSION_V2" # flag to enable the installer version mode.
export gNDR_INSTALL_ENG_VERSION_V1="INSTALL_ENGINE_V1" # use for install V1. New Deprecated.
export gNDR_INSTALL_ENG_VERSION_V2="INSTALL_ENGINE_V2" # use for unified client install V2.

# common
export gPrereqCheckComplete=0 # flag to indicate if prereq checks have been completed and not needed to be run again on subsequent interactive commands
export gNEXTDR_HOME_DIR="/opt/$gPRODUCT_NAME_SHORT"
export gSCRIPT_HOME_DIR="$PWD"
export gLOG_FILE=""
export gEXPRESS_MODE=false
export gExpressOption=""
export gDEBUG_MODE=false
export gNDR_SERVER_HOST_ADDRESS="localhost" # default address, can be updated to actual ip or host address of the server.
export gNDR_ADVANCED_MODE=false # enables advanced options in menus.
export gNDR_PAUSE_ON_ERROR_MODE=false # enables pause on error mode.

# install package schema upgrade manifest
export gNDR_INSTALL_PACKAGE_MANIFEST_FILENAME="install-package-manifest.json"
export gNDR_INSTALL_PACKAGE_MANIFEST_FILE="" # optional override; defaults to manifest filename in PWD.

export gNDR_INSTALL_PACKAGE_RELEASE_MODE_PUBLIC="PUBLIC" # Used primarily for manifest generation and install package creation, indicates that the install package was built against a public release.
export gNDR_INSTALL_PACKAGE_RELEASE_MODE_PRIVATE="PRIVATE" # Used primarily for manifest generation and install package creation, indicates that the install package was built against a private build.
export gNDR_INSTALL_PACKAGE_RELEASE_MODE_CURRENT="$gNDR_INSTALL_PACKAGE_RELEASE_MODE_PRIVATE" # default to private, can be overridden by env var or command line arg during install package creation.

# NDR application suite backup and restores
export gNDR_APP_BACKUP_DIR="/var/backups/${gPRODUCT_NAME_SHORT}"
export gNDR_APP_BACKUP_STAGING_SUB="app_backup_staging"

export gNDR_APP_BACKUP_SKIP=false # flag to allow selective skipping of app backup

export gNDR_APP_BACKUP_NAME="" # default to empty, will be set dynamically during backup creation to include datetime for uniqueness.

export gNDR_APP_BACKUP_FILE="" # default to empty, will be set dynamically during backup creation to include datetime for uniqueness.

export gNDR_APP_BACKUP_DB_DATA_SUB="db_data"
export gNDR_APP_BACKUP_DB_SCHEMA_SUB="db_schema"
export gNDR_APP_BACKUP_DB_KEYS_SUB="db_keys"
export gNDR_APP_BACKUP_REGISTRY_SUB="registry"
export gNDR_APP_BACKUP_HOME_DIR_SUB="home_dir"

export gNDR_APP_BACKUP_RESTORE_OPTIONS_DB=0x1
export gNDR_APP_BACKUP_RESTORE_OPTIONS_HOME_DIR=0x2
export gNDR_APP_BACKUP_RESTORE_OPTIONS_REGISTRY=0x4
export gNDR_APP_BACKUP_RESTORE_OPTIONS_ALL_MODULES=$(( gNDR_APP_BACKUP_RESTORE_OPTIONS_DB | gNDR_APP_BACKUP_RESTORE_OPTIONS_HOME_DIR | gNDR_APP_BACKUP_RESTORE_OPTIONS_REGISTRY ))
export gNDR_APP_BACKUP_RESTORE_OPTIONS_DB_CACHE_SCHEMA_BACKUP=0x8 # option to cache a copy of the db schema backup in the backup staging directory for potential use in restores, so that we can restore the schema without needing to access the original backup file which may be on a different host or deleted by the user after backup creation.
export gNDR_APP_BACKUP_RESTORE_OPTIONS_RESTORE_DOCKER_ENTITIES=0x10 # option to attempt to restore Docker images/containers by performing compose down/image rm of failed install, then pull/compose up of restored. Only valid when restoring home_dir option which restores all compose files.

#secrets
export gNDR_SECRETS_LOADED=false
export gNDR_SECRETS_FILENAME=".secrets"
export gNDR_SECRETS_GPG_FILENAME=".secrets.gpg"
export gNDR_SECRETS_PASSPHRASE=""

export gNDR_CONSOLE_ADMIN_ACCOUNT_USER=""
export gNDR_CONSOLE_ADMIN_ACCOUNT_PASSWORD=""

# env files
export gNDR_MODULE_ENV_SOURCE_VAR_FILENAME=".env.nextdr" # master environment file for NextDR modules (not Supabase).
export gNDR_SUPABASE_ENV_TEMPLATE_VAR_FILENAME=".env.example" # the supabase template env file.
export gNDR_ENV_TARGET_FILENAME=".env"
export gNDR_ENV_BACKUP_FILENAME="${gNDR_ENV_TARGET_FILENAME}.bkp"

# supabase
export gSUPABASE_CLI_CMD="npx supabase"

# Global arrays
declare -a ndr_supabase_container_services=()
declare -A ndr_supabase_container_service_container_names=()
declare -A ndr_supabase_container_service_image_names=()
declare -A ndr_supabase_container_service_image_tags=()
declare -A ndr_supabase_container_service_image_update=() # used during supabase upgrades, tracks whether the service's image tag is being updated or remains unchanged in the target compose file vs the currently installed compose file.

declare -a ndr_client_container_services=()
declare -A ndr_client_container_service_container_names=()
declare -A ndr_client_container_service_image_names=()
declare -A ndr_client_container_service_image_tags=()

# package prereq versions
NDR_MIN_REQUIRED_VERSION_DEFAULT="0.0.0"
NDR_MIN_REQUIRED_YQ_VERSION="1.0.0"

# git
export NDR_GIT_REPO_COMMIT_HASH="0673f1b1a2e857d5cfb7d34aed27167d0924838a"
export NDR_GIT_REPO_COMMIT_HASH_SHORT="0673f1b"
export NDR_GIT_REPO_COMMIT_TIMESTAMP="1765483304" # in epoch format

# OS type
export osTypeMajor=""
export distroFamily=""
export distroId=""

# docker repo
export NDR_DOCKER_REPO_ACCOUNT="nextdr" #SECRETS
export NDR_DOCKER_REPO_ACCESS_TOKEN="" #SECRETS
export NDR_DOCKER_SERVICE_PUBLIC_REPO_NAME="nextdr-svc"
export NDR_DOCKER_UI_PUBLIC_REPO_NAME="nextdr-ui"

export NDR_DOCKER_REPO_TYPE_PUBLIC_NDR="PUBLIC_NDR" # public NDR specific repo on docker hub, does not require authentication to pull.
export NDR_DOCKER_REPO_TYPE_LOCAL_REGISTRY="LOCAL_REGISTRY" # local registry repo, requires the local registry host and port to be set and accessible, and images to be pre-pushed to the local registry.
export NDR_DOCKER_REPO_TYPE_PUBLIC_ALL="PUBLIC_ALL" # standard public docker hub repo, does not require authentication to pull. This is the default for 3rd party images such as supabase.
export NDR_DOCKER_REPO_TYPE_GCP_REGISTRY="GCP_REGISTRY"
export NDR_DOCKER_REPO_TYPE_CURRENT=$NDR_DOCKER_REPO_TYPE_PUBLIC_NDR # default for now, need a more robust way to handle the type and switching depending on operational context.

# docker bridge network
export NDR_DOCKER_BRIDGE_NETWORK_NAME="ndr_bridge_net"

# docker app build enum
export NDR_DOCKER_APP_MANAGE_OPTIONS_NONE=0x0
export NDR_DOCKER_APP_MANAGE_OPTIONS_IMAGE=0x1 # build/remove image only.
export NDR_DOCKER_APP_MANAGE_OPTIONS_CONTAINER=0x2 # build/remove container only. In build mode, does not interactively prompt for container creation.
export NDR_DOCKER_APP_MANAGE_OPTIONS_CONTAINER_OPTIONAL=0x4 # Optional flag for container. In build mode, this triggers an interactive prompt for container creation.
export NDR_DOCKER_APP_MANAGE_OPTIONS_REMOVE_NO_PROMPT=0x8 # remove existing container without prompting.
export NDR_DOCKER_APP_MANAGE_OPTIONS_UPLOAD_NO_PROMPT=0x10 # upload container without prompting.
export NDR_DOCKER_APP_MANAGE_OPTIONS_BUILD_IMAGE_AND_CONTAINER=$(( NDR_DOCKER_APP_MANAGE_OPTIONS_IMAGE | NDR_DOCKER_APP_MANAGE_OPTIONS_CONTAINER )) # build image and container (does not prompt for container creation).
export NDR_DOCKER_APP_MANAGE_OPTIONS_REMOVE_ALL=$(( NDR_DOCKER_APP_MANAGE_OPTIONS_IMAGE | NDR_DOCKER_APP_MANAGE_OPTIONS_CONTAINER | NDR_DOCKER_APP_MANAGE_OPTIONS_REMOVE_NO_PROMPT )) # everything.
export NDR_DOCKER_APP_MANAGE_OPTIONS_DEFAULT=$(( NDR_DOCKER_APP_MANAGE_OPTIONS_IMAGE | NDR_DOCKER_APP_MANAGE_OPTIONS_CONTAINER_OPTIONAL )) # standard behavior of create image, then prompt for optional operations such as module preclean and continer build/start.
export NDR_DOCKER_APP_MANAGE_OPTIONS_START_EXISTING=0x20 # only starts existing containers, will prevent re-compose. used for admin start/stop purposes.
export NDR_DOCKER_APP_MANAGE_OPTIONS_SKIP_PREPARE=0x40 # skips the prepare step, used for re-composing containers for already installed modules.

# admin home dir
export NDR_ADMIN_HOME_LOC="admin"

# nextdr unified client app (groups together service, ui, caddy, and any other future apps into a single client application for the user to interact with, vs interacting with each module separately).
export NDR_CLIENT_APPLICATION_NAME="$gCOMPANY_NAME Application" # friendly applications display name
export NDR_CLIENT_APP_HOME_LOC="client"
export NDR_STANDARD_DOCKER_COMPOSEFILE_FILENAME="docker-compose.yml"
export NDR_CLIENT_APP_COMPOSEFILE_FILENAME="$NDR_STANDARD_DOCKER_COMPOSEFILE_FILENAME"
export NDR_CLIENT_APP_CADDY_COMPOSEFILE_FILENAME="docker-compose-caddy.yml"

# docker caddy app
export NDR_CADDYFILE_NAME="Caddyfile"
export NDR_CADDY_HOME_LOC="caddy"
export NDR_CADDY_CONFIG_LOC="${NDR_CADDY_HOME_LOC}/config"
export NDR_CADDY_DATA_LOC="${NDR_CADDY_HOME_LOC}/data"
export NDR_CADDY_ENABLED=false # secure caddy proxy mode is off by default. all behavior and config files are set to install and run without caddy. only by enabling this do we make the changes necessary to add, enable and configure caddy.

# docker service app
export NDR_SERVICE_HOME_LOC="nextdr-svc"
export NDR_SERVICE_IMAGE_NAME="nextdr-svc-img"
declare -n NDR_SERVICE_IMAGE_VERSION=gPRODUCT_VERSION # dynamically linked to common product value so updates are symmetrical.
export NDR_SERVICE_IMAGE_VERSION_TAG="$NDR_SERVICE_IMAGE_VERSION-$NDR_SERVICE_IMAGE_COMMIT_HASH_SHORT-$NDR_SERVICE_IMAGE_COMMIT_TIMESTAMP_UTC" # full image tag syntax "version-commithashshort-UTCdatetime"
export NDR_SERVICE_CONTAINER_NAME="nextdr-svc-app"
export NDR_SERVICE_CONTAINER_PORT="8081"
export NDR_SERVICE_DOCKER_COMPOSE_SERVICE_NAME="nextdr-svc"
export NDR_SERVICE_COMPOSEFILE_FILENAME="docker-compose-svc.yml"
export NDR_SERVICE_IMAGE_COMMIT_HASH_SHORT=$NDR_GIT_REPO_COMMIT_HASH_SHORT # short form of the commit hash, used for image tagging. do not dynamically to common product value as updates from other modules will affect this value.
export NDR_SERVICE_IMAGE_COMMIT_TIMESTAMP_UTC=$NDR_GIT_REPO_COMMIT_TIMESTAMP # UTC epoch timestamp of the image build time, collected during build time. do not dynamically to common product value as updates from other modules will affect this value.

# docker ui app
export NDR_UI_HOME_LOC="nextdr-ui"
export NDR_UI_IMAGE_NAME="nextdr-ui-img"
declare -n NDR_UI_IMAGE_VERSION=gPRODUCT_VERSION # dynamically linked to common product value so updates are symmetrical.
export NDR_UI_IMAGE_VERSION_TAG="$NDR_UI_IMAGE_VERSION-$NDR_UI_IMAGE_COMMIT_HASH_SHORT-$NDR_UI_IMAGE_COMMIT_TIMESTAMP_UTC" # full image tag syntax "version-commithashshort-UTCdatetime"
export NDR_UI_CONTAINER_NAME="nextdr-ui-app"
export NDR_UI_CONTAINER_PORT="80"
export NDR_UI_DOCKER_COMPOSE_SERVICE_NAME="nextdr-ui"
export NDR_UI_COMPOSEFILE_FILENAME="docker-compose-ui.yml"
export NDR_UI_IMAGE_COMMIT_HASH_SHORT=$NDR_GIT_REPO_COMMIT_HASH_SHORT # short form of the commit hash, used for image tagging. do not dynamically to common product value as updates from other modules will affect this value.
export NDR_UI_IMAGE_COMMIT_TIMESTAMP_UTC=$NDR_GIT_REPO_COMMIT_TIMESTAMP # UTC epoch timestamp of the image build time, collected during build time. do not dynamically to common product value as updates from other modules will affect this value.

export NDR_DOCKER_MODULE_NAME_EMPTY_VALUE="<empty>"

# docker supabase app
export NDR_SUPABASE_CONTAINER_PORT="8000"

# systemd service names and descriptions
export NDR_SYSTEMD_SUPABASE_SVC_NAME="ndr-supabase"
export NDR_SYSTEMD_SUPABASE_SVC_DESC="$gPRODUCT_NAME Supabase Docker Container Service"
export NDR_SYSTEMD_SUPABASE_SVC_START_CMD="ndrAdmin.sh --express startdb"
export NDR_SYSTEMD_SUPABASE_SVC_STOP_CMD="ndrAdmin.sh --express stopdb"

export NDR_SYSTEMD_SERVICE_SVC_NAME="ndr-service"
export NDR_SYSTEMD_SERVICE_SVC_DESC="$gPRODUCT_NAME Service Docker Container Service"
export NDR_SYSTEMD_SERVICE_SVC_START_CMD="ndrAdmin.sh --express startservice"
export NDR_SYSTEMD_SERVICE_SVC_STOP_CMD="ndrAdmin.sh --express stopservice"

export NDR_SYSTEMD_UI_SVC_NAME="ndr-ui"
export NDR_SYSTEMD_UI_SVC_DESC="$gPRODUCT_NAME UI Docker Container Service"
export NDR_SYSTEMD_UI_SVC_START_CMD="ndrAdmin.sh --express startui"
export NDR_SYSTEMD_UI_SVC_STOP_CMD="ndrAdmin.sh --express stopui"

# installation report
declare -a NDR_INSTALLATION_REPORT=()

# older version of Docker
export dockerRemovePkgs=(
  docker.io
  docker-doc
  docker-compose
  docker-compose-v2
  podman-docker
  containerd
  runc
)

# newer version of Docker
export dockerInstallPackages=(
  "docker-ce" \
  "docker-ce-cli" \
  "containerd.io" \
  "docker-buildx-plugin" \
  "docker-compose-plugin"
)
  
  
# ANSI color codes or logging
RESET="\033[0m"
BOLD="\033[1m"
RED="\033[31m"
YELLOW="\033[33m"
TEAL="\033[36m"
CYAN="\033[1;36m"
GREEN="\033[32m"
BLUE="\033[34m"

# log modes
export NDR_LOG_POLICY_MODE_NORMAL=0 # alternate mode for production: logs tracelog to file, stdout to file, stdout to terminal.
export NDR_LOG_POLICY_MODE_QUIET=1 # default mode for production: logs tracelog to file, stdout to file, keep terminal clean with TEE redirecting to file.
export NDR_LOG_POLICY_MODE_SILENT=2 # total silent mode: suppress all stdout/stderr, logs tracelog to file only.
export NDR_LOG_POLICY_MODE_CURRENT=$NDR_LOG_POLICY_MODE_NORMAL

export NDR_LOG_POLICY_FORCE_PRINT_NONE=0x0 # no force print option
export NDR_LOG_POLICY_FORCE_PRINT_TERMINAL=0x1
export NDR_LOG_POLICY_FORCE_PRINT_FILE=0x2

# similar to C pragma once, put at end of all declarations.
[[ -n "$_NDR_COMMON_LOADED" ]] && return
_NDR_COMMON_LOADED=1


# ----------------------

# --- FUNCTIONS ---

ndr_SetLogPolicy() 
{
  if [[ $# -lt 1 ]]; then
    return 1
  fi

  local newPolicy="$1"
  NDR_LOG_POLICY_MODE_CURRENT=$newPolicy

  # Save original stdout/stderr if not already done
  local NDR_STD_FDS_SAVED=false
  [[ -z "$NDR_STD_FDS_SAVED" ]] && exec 3>&1 4>&2 && NDR_STD_FDS_SAVED=true

  case "$newPolicy" in
    "$NDR_LOG_POLICY_MODE_NORMAL")
      # Echo to screen and log file via tee
      exec &> >(tee -a "$gLOG_FILE")
      gTRACELOG_TO_STDOUT=true
      gTRACELOG_TO_FILE=true
      ;;
    "$NDR_LOG_POLICY_MODE_QUIET")
      # Echo to terminal only (no tee/logfile for stdout)
      exec &> /dev/tty
      gTRACELOG_TO_STDOUT=false
      gTRACELOG_TO_FILE=true
      ;;
    "$NDR_LOG_POLICY_MODE_SILENT")
      exec 1>/dev/null 2>/dev/null        # suppress all stdout/stderr
      gTRACELOG_TO_STDOUT=false
      gTRACELOG_TO_FILE=true
      ;;
    *)
      ndr_logError "Invalid log mode: $newPolicy" >&2
      return 1
      ;;
  esac

  ndr_logDebug "Log policy set to $NDR_LOG_POLICY_MODE_CURRENT"

  return 0
}

function ndr_logSecStartDebug ()
{
  if [[ "$gDEBUG_MODE" == true ]]; then
    ndr_logSecStart "$1"
  fi
}

function ndr_logSecEndDebug ()
{
  if [[ "$gDEBUG_MODE" == true ]]; then
    ndr_logSecEnd "$1"
  fi
}

function ndr_logSecStart () 
{
  local logLine="${BLUE}+++ START [${RESET} $1 ${BLUE}] +++${RESET}"
  local plainLogLine="+++ START [ $1 ] +++"
      
  if [[ "$gTRACELOG_TO_STDOUT" == true ]]; then
    if [[ "$gNDR_HAS_TTY" == true ]]; then
      echo -e "${logLine}" > /dev/tty
    else
      echo -e "${logLine}"
    fi
  fi

  if [[ "$gTRACELOG_TO_FILE" == true ]]; then
    echo "${plainLogLine}" >> "$gLOG_FILE"
  fi
}

function ndr_logSecEnd () 
{
  local logLine="${GREEN}--- COMPLETE [${RESET} $1 ${GREEN}] ---${RESET}"
  local plainLogLine="--- COMPLETE [ $1 ] ---"

  if [[ "$gTRACELOG_TO_STDOUT" == true ]]; then
    if [[ "$gNDR_HAS_TTY" == true ]]; then
      echo -e "${logLine}" > /dev/tty
    else
      echo -e "${logLine}"
    fi
  fi
  
  if [[ "$gTRACELOG_TO_FILE" == true ]]; then    
    echo "${plainLogLine}" >> "$gLOG_FILE"
  fi
}

function _log_format () 
{
  local caller="$1" # optional, can be blank.
  local color="$2" # required
  local level="$3" # required
  local message="$4" # required
  local forcePrint="${5:-NDR_LOG_POLICY_FORCE_PRINT_NONE}" # optional, if value set, forces printing even if global flags are diabled. Useful for forcing a notification to reach the user in quiet mode

  local datetime="[$(date '+%Y-%m-%d %H:%M:%S')]"
  
  if [[ -n "$caller" ]]; then
    caller=" $caller"
  fi

  local logLine="${datetime}${caller} ${color}${level}${RESET} ${message}"
  local plainLogLine="${datetime}${caller} ${level} ${message}"

  if [[ "$gTRACELOG_TO_STDOUT" == true || $(( forcePrint & NDR_LOG_POLICY_FORCE_PRINT_TERMINAL )) -ne 0 ]]; then
    if [[ "$gNDR_HAS_TTY" == true ]]; then
      echo -e "${logLine}" > /dev/tty # send only to terminal, not to STDOUT since STDOUT is sometimes redirected to a file with tee and the color codes do not translate in file.
    else
      echo -e "${logLine}"
    fi
  fi

  if [[ "$gTRACELOG_TO_FILE" == true || $(( forcePrint & NDR_LOG_POLICY_FORCE_PRINT_FILE )) -ne 0 ]]; then
    echo -e "${plainLogLine}" >> "$gLOG_FILE"
  fi

  # Log file rotation: if log file >= 5MB, rename with datetime
  if [[ -f "$gLOG_FILE" ]]; then
    local log_size_bytes
    log_size_bytes=$(stat -c%s "$gLOG_FILE")
    local max_size_bytes=$((5 * 1024 * 1024))
    if (( log_size_bytes >= max_size_bytes )); then
      local base_name ext_name datetime_stamp rotated_name
      base_name="${gLOG_FILE%.*}"
      ext_name="${gLOG_FILE##*.}"
      datetime_stamp="$(date '+%Y%m%d_%H%M%S')"
      if [[ "$gLOG_FILE" == *.* ]]; then
        rotated_name="${base_name}_${datetime_stamp}.${ext_name}"
      else
        rotated_name="${gLOG_FILE}_${datetime_stamp}"
      fi
      mv "$gLOG_FILE" "$rotated_name"
    fi
  fi
}

function ndr_logGetCaller()
{
  local i fn

  for (( i=1; i<${#FUNCNAME[@]}; i++ )); do
    fn="${FUNCNAME[$i]}"

    # Skip all logging wrapper functions
    if [[ "$fn" == ndr_log* ]]; then
      continue
    fi

    echo "${BASH_SOURCE[$i]}::${fn:-main}(${BASH_LINENO[$((i-1))]})"
    return 0
  done

  echo "unknown"
}

# only logs at info level if debug mode is enabled.
function ndr_logDebug ()
{
  if [[ "$gDEBUG_MODE" == true ]]; then
    ndr_logInfo "$1" "$2"
  fi
}

function ndr_logInfo () 
{
  local caller_info=""
  if [[ "$gDEBUG_MODE" == true ]]; then
    caller_info=$(ndr_logGetCaller)
  fi
  
  _log_format "$caller_info" "$TEAL" "ℹ️ INFO" "$1" "$2"
}

function ndr_logWarn () 
{
  local caller_info=""
  if [[ "$gDEBUG_MODE" == true ]]; then
    caller_info=$(ndr_logGetCaller)
  fi
  
  _log_format "$caller_info" "$YELLOW" "⚠️ WARNING" "$1" "$2"
}

function ndr_logError () 
{
  local caller_info=""
  if [[ "$gDEBUG_MODE" == true ]]; then
    caller_info=$(ndr_logGetCaller)
  fi

  _log_format "$caller_info" "$RED" "❌ ERROR" "$1" "$2"

  if [[ "$gNDR_PAUSE_ON_ERROR_MODE" == true ]]; then
    read -p "Pause on error mode is enabled. Press [D/d] disable or ANY key to continue..." -n 1 -r
    if [[ $REPLY =~ ^[Dd]$ ]]; then
      ndr_logInfo "Disabling pause on error mode."
      gNDR_PAUSE_ON_ERROR_MODE=false
    fi
  fi
}

# Takes a single prompt string argument
# Returns 0 for yes, 1 for no, 2 for error
# Ensures the prompt is visible even with stdout redirected (via /dev/tty)
export NDR_PROMPT_DEFAULT_INPUT_YES=0
export NDR_PROMPT_DEFAULT_INPUT_NO=1

export NDR_PROMPT_RETURN_YES=0
export NDR_PROMPT_RETURN_NO=1
export NDR_PROMPT_RETURN_ERROR=2

function ndr_PromptYesNo() 
{
  local prompt="$1"
  local defaultInput="$2"

  # Validate argument count
  if [[ -z "$prompt" || -z "$defaultInput" ]]; then
    echo "Usage: ndr_PromptYesNo \"Prompt text\" <default (0=yes, 1=no)>" >&2
    return $NDR_PROMPT_RETURN_ERROR
  fi

  # Determine prompt label and default return logic
  local promptSuffix defaultChoice
  if [[ "$defaultInput" -eq "$NDR_PROMPT_DEFAULT_INPUT_YES" ]]; then
    promptSuffix="[Y/n]"
    defaultChoice="yes"
  elif [[ "$defaultInput" -eq "$NDR_PROMPT_DEFAULT_INPUT_NO" ]]; then
    promptSuffix="[y/N]"
    defaultChoice="no"
  else
    echo "Error: Invalid default input option: '$defaultInput'" >&2
    return $NDR_PROMPT_RETURN_ERROR
  fi

  # Terminal mode with read
  while true; do
    read -p "$prompt $promptSuffix: " yn < /dev/tty > /dev/tty
    yn="${yn,,}"  # normalize to lowercase
    case "$yn" in
      y|yes) return $NDR_PROMPT_RETURN_YES ;;
      n|no)  return $NDR_PROMPT_RETURN_NO ;;
      "")    [[ "$defaultChoice" == "yes" ]] && return $NDR_PROMPT_RETURN_YES || return $NDR_PROMPT_RETURN_NO ;;
      *)     echo "Please answer yes or no." < /dev/tty > /dev/tty ;;
    esac
  done
}

function ndr_PromptInputValue ()
{
  local logSectionDesc="Prompt for Input Value"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <value> <value_description>"
    ndr_logSecEnd "$logSectionDesc"
    return 1
  fi

  local value="$1"
  local value_desc="$2"

  if [[ "$gEXPRESS_MODE" == true ]]; then
    if [[ -z "$value" ]]; then
      ndr_logError "Express mode enabled but no $value_desc is set."
      ndr_logSecEnd "$logSectionDesc"
      return 1
    fi
    
    ndr_logInfo "Express mode enabled, skipping prompt for $value_desc."
    ndr_logSecEnd "$logSectionDesc"
    echo "$value"
    return 0
  fi

  echo "The current or default value for $value_desc is [$value]." < /dev/tty > /dev/tty
  echo "Is this the correct value to use for creating and/or administering this resource?" < /dev/tty > /dev/tty
  read -p "Choose YES to continue with this value or NO to be prompted to enter a new one [Y|n|a]: " < /dev/tty > /dev/tty #-n 1 -r
  echo >&2   # Move to a new line
  if [[ $REPLY =~ ^[Nn]$ ]]; then
    value=""
  elif [[ $REPLY =~ ^[Aa]$ ]]; then
    return 1
  fi
  
  if [[ -z "$value" ]]; then  
    while true; do
      read -p "Please enter the value for the $value_desc: " -r value
      #echo < /dev/tty > /dev/tty   # Move to a new line
      
      if [[ -n "$value" ]]; then
        read -p "You entered [$value]. Is this the correct value for the $value_desc (Yes|no|abort)? [Y|n|a]: " < /dev/tty > /dev/tty #-n 1 -r
        echo < /dev/tty > /dev/tty  # Move to a new line
        
        if [[ $REPLY =~ ^[Nn]$ ]]; then
          # clear it and we will prompt below to enter
          value=""
          echo < /dev/tty > /dev/tty  # Move to a new line
          continue
        elif [[ $REPLY =~ ^[Aa]$ ]]; then
          # abort
          return 1
        else
          # answered yes, accept value and continue.
          break
        fi
      fi
      
      echo "No $value_desc provided, please enter a valid value for $value_desc" < /dev/tty > /dev/tty
      continue
    done  
  fi

  ndr_logInfo "The $value_desc set to [$value]"

  ndr_logSecEnd "$logSectionDesc"

  echo "$value"

  return 0
}

# Usage: function <value> <flag>
# Returns 0 (true) if the flag is set, 1 (false) otherwise
function ndr_checkFlag () 
{
  local value="$1"
  local flag="$2"

  if (( (value & flag) != 0 )); then
    return 0  # flag is set
  else
    return 1  # flag is not set
  fi
}

function ndr_osTypeCheck () 
{
  local logSectionDesc="Operating system type check"
  ndr_logSecStartDebug "$logSectionDesc"

  os_type=$(uname -s)
  case "$os_type" in
    Linux)
      osTypeMajor="Linux"
      gSUPABASE_CLI_CMD="sudo npx supabase"
      ;;
    unix*)
      osTypeMajor="Unix"
      gSUPABASE_CLI_CMD="sudo npx supabase"
      ;;
    Windows*)
      osTypeMajor="Windows"
      gSUPABASE_CLI_CMD="npx supabase"
      ;;
    *NT*)
      osTypeMajor="Windows"
      gSUPABASE_CLI_CMD="sudo npx supabase"
      ;;
    *)
      osTypeMajor="Unknown"
      ;;
  esac

  ndr_logDebug "Operating system is [$osTypeMajor], type [$os_type | $OSTYPE]"
  
  if [[ "$osTypeMajor" == "Windows" ]]; then
    distroFamily="Windows"
    distroId="Windows"
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # Try to read from /etc/*release
  if grep -q "^ID=" /etc/*release 2>/dev/null; then
    distroId=$(grep "^ID=" /etc/*release | head -n1 | cut -d= -f2 | tr -d '"' | tr '[:upper:]' '[:lower:]')
  elif [[ "$(uname)" == "Darwin" ]]; then
    distroFamily="osx"
    distroId="Darwin"
  else
    ndr_logError "Unable to detect distribution."
    return 1
  fi

  # Map to main distro families
  case "$distroId" in
    ubuntu|debian|linuxmint|elementary|pop|zorin)
      distroFamily="debian"
      ;;
    rhel|redhat|centos|fedora|rocky|almalinux|scientific)
      distroFamily="redhat"
      ;;
    arch|manjaro|endeavouros)
      distroFamily="arch"
      ;;
    opensuse|suse|sles|opensuse-tumbleweed|suse-leap|opensuse-leap|suse-sles)
      distroFamily="suse"
      ;;
    alpine)
      distroFamily="alpine"
      ;;
    osx|darwin)
      distroFamily="osx"
      ;;
    *)
      distroFamily="unknown"
      ;;
  esac

  ndr_logDebug "Detected distro: $distroId, family: $distroFamily."

  # set os/disto specific commands

  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

function ndr_UpgradeModeCheck ()
{
  local logSectionDesc="Checking upgrade mode"
  ndr_logSecStartDebug "$logSectionDesc"

  # perform initial basic reg existance check. if product not installed, no need to check versions.
  ndr_RegistryExists
  return_code=$?
  if [ $return_code -eq 1 ]; then
    ndr_logDebug "No existing installation detected, no upgrade needed."
    return 0
  fi

  gINSTALLED_VERSION=$(ndr_getVersionReg)
  gUPGRADE_MODE=false

  # check overall product version first.
  if [ ! -z "$gINSTALLED_VERSION" ]; then
    if [[ "$gINSTALLED_VERSION" == "$gPRODUCT_VERSION" ]]; then
      # versions equal, no upgrade needed.
      ndr_logDebug "Current installed version [$gINSTALLED_VERSION] matches product installer version [$gPRODUCT_VERSION]."
    elif [[ "$(printf '%s\n%s\n' "$gINSTALLED_VERSION" "$gPRODUCT_VERSION" | sort -V | head -n1)" == "$gINSTALLED_VERSION" ]]; then
      ndr_logInfo "Upgrade detected (installer: $gPRODUCT_VERSION > current: $gINSTALLED_VERSION)"
      gUPGRADE_MODE=true
    else
      ndr_logError "Downgrade detected (current: $gINSTALLED_VERSION > installer: $gPRODUCT_VERSION). Downgrades are not supported."
      return 1
    fi
  fi

  # check individual module versions and set upgrade mode if any module needs upgrade.
  ndr_logDebug "Checking individual module versions for upgrade..."
 
  # Check each module's installed version against the product version
  for module in "${gREGISTRY_ENTRY_MODULE_STATUS_NAME_LIST[@]}"; do
    local installedVersion=$(ndr_getModuleVersionReg "$module")
    if [[ -n "$installedVersion" && "$installedVersion" != "$gPRODUCT_VERSION" ]]; then
      ndr_logInfo "Module [$module] requires upgrade (current: $installedVersion, installer required: $gPRODUCT_VERSION)"
      gUPGRADE_MODE=true
    fi
  done
  
  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

function ndr_UpdateProductVersion ()
{
  local logSectionDesc="Updating product version in registry"
  ndr_logSecStart "$logSectionDesc"

  # Check each module's installed version against the product version
  local upgradeRequired=false
  for module in "${gREGISTRY_ENTRY_MODULE_STATUS_NAME_LIST[@]}"; do
    local installedVersion=$(ndr_getModuleVersionReg "$module")
    if [[ -n "$installedVersion" && "$installedVersion" != "$gPRODUCT_VERSION" ]]; then
      ndr_logInfo "Module [$module] requires upgrade (installed: $installedVersion, required: $gPRODUCT_VERSION)"
      upgradeRequired=true
    fi
  done

  if [ "$upgradeRequired" == true ]; then
    ndr_logInfo "One or more modules require upgrade, cannot update main product version."
  else
    ndr_logInfo "All modules are up to date, updating main product version from $gINSTALLED_VERSION to $gPRODUCT_VERSION."
  
    # Update overall product version
    ndr_RegistryAddKey "$gREGISTRY_ENTRY_VERSION" "$gPRODUCT_VERSION"

    ndr_setRegistryUpdateDate
  fi
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_parseCommandLineArgs ()
{
  local logSectionDesc="Parsing common command line arguments"
  ndr_logSecStartDebug "$logSectionDesc"

  if ndr_RegistryExists; then
    # Read and populate certain values that would have previously set during the initial install
    # These valued would need to be observed as they dictate future, post-install operational behavior to be consistent with that established at install time.
    gNDR_INSTALL_ENG_VER=$(ndr_getInstallEngineVersionReg)
    NDR_CADDY_ENABLED=$(ndr_getCaddyEnabledReg)
    NDR_DOCKER_REPO_TYPE_CURRENT=$(ndr_getDockerRepoTypeReg)
    
    if [[ "$NDR_DOCKER_REPO_TYPE_CURRENT" == "$NDR_DOCKER_REPO_TYPE_GCP_REGISTRY" ]]; then
      gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT=$(ndr_getDockerPrivateRepoPrefixReg)
      if [[ -z "$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT" ]]; then
        ndr_logError "Invalid registry root option [$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT]"
        return 1
      fi
      ndr_logInfo "Docker repo type set to [$NDR_DOCKER_REPO_TYPE_CURRENT] using prefix [$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT]."
    elif [[ "$NDR_DOCKER_REPO_TYPE_CURRENT" == "$NDR_DOCKER_REPO_TYPE_LOCAL_REGISTRY" ]]; then
      local host_and_port=$(ndr_getDockerPrivateRepoPrefixReg)
      gNDR_DOCKER_LOCAL_REGISTRY_HOST="${host_and_port%%:*}"
      gNDR_DOCKER_LOCAL_REGISTRY_PORT="${host_and_port##*:}"
      if [[ -z "$gNDR_DOCKER_LOCAL_REGISTRY_HOST" || -z "$gNDR_DOCKER_LOCAL_REGISTRY_PORT" ]]; then
        ndr_logError "Invalid registry host:port option [$host_and_port]"
        return 1
      fi
      ndr_logInfo "Docker repo type set to [$NDR_DOCKER_REPO_TYPE_CURRENT] using host and port [$gNDR_DOCKER_LOCAL_REGISTRY_HOST:$gNDR_DOCKER_LOCAL_REGISTRY_PORT]."
    fi
  fi

  # Parse arguments
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --express|-e)
        if [[ -n "$2" && "$2" != --* ]]; then
          gEXPRESS_MODE=true
          gExpressOption="$2"
          ndr_logInfo "Express option set to [$gExpressOption]"
          shift 2
        else
          ndr_logError "--express requires a value."
          return 1
        fi
        ;;
      --admin-user|--au)
        if [[ -n "$2" && "$2" != --* ]]; then
          gNDR_CONSOLE_ADMIN_ACCOUNT_USER="$2"
          ndr_logInfo "Console admin account user set to [$gNDR_CONSOLE_ADMIN_ACCOUNT_USER]"
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --admin-password|--ap)
        if [[ -n "$2" && "$2" != --* ]]; then
          gNDR_CONSOLE_ADMIN_ACCOUNT_PASSWORD="$2"
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --dashboard-user|--dashuser|--du)
        if [[ -n "$2" && "$2" != --* ]]; then
          gSUPABASE_ENV_VAL_DASHBOARD_USERNAME="$2"
          ndr_logInfo "Supabase Dashboard account user set to [$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME]"
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --dashboard-password|--dashpass|--dp)
        if [[ -n "$2" && "$2" != --* ]]; then
          gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD="$2"
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --gpg-secret)
        if [[ -n "$2" && "$2" != --* ]]; then
          gNDR_SECRETS_PASSPHRASE="$2"
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --logpolicy)
        if [[ -n "$2" && "$2" != --* ]]; then
          NDR_LOG_POLICY_MODE_CURRENT="$2"
          ndr_logInfo "Setting log policy to [$NDR_LOG_POLICY_MODE_CURRENT]"
          ndr_SetLogPolicy "$NDR_LOG_POLICY_MODE_CURRENT"
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --ip|--hostaddress)
        if [[ -n "$2" && "$2" != --* ]]; then
          gNDR_SERVER_HOST_ADDRESS="$2"
          ndr_logInfo "Host address set to [$gNDR_SERVER_HOST_ADDRESS]"
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --schemafile|--sf)
        if [[ -n "$2" && "$2" != --* ]]; then
          gNDR_SUPABASE_DB_SCHEMA_FILE="$2"
          ndr_logInfo "Supabase schema file [$gNDR_SUPABASE_DB_SCHEMA_FILE]"
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --diffschemafile|--dsf)
        if [[ -n "$2" && "$2" != --* ]]; then
          gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF="$2"
          gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY="$gNDR_SUPABASE_UPGRADE_DIFF_STRATEGY_REPLAY"
          ndr_logInfo "Supabase diff schema file [$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF]"
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --manifestfile|--manifest)
        if [[ -n "$2" && "$2" != --* ]]; then
          gNDR_INSTALL_PACKAGE_MANIFEST_FILE="$2"
          ndr_logInfo "Install package manifest file [$gNDR_INSTALL_PACKAGE_MANIFEST_FILE]"
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --archivefile|--afile)
        if [[ -n "$2" && "$2" != --* ]]; then
          gNDR_APP_BACKUP_FILE="$2"
          ndr_logInfo "Application backup file [$gNDR_APP_BACKUP_FILE]"
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --releasemode|--rm)
        if [[ -n "$2" && "$2" != --* ]]; then
          gNDR_INSTALL_PACKAGE_RELEASE_MODE_CURRENT="$2"
          ndr_logInfo "Install package release mode set to [$gNDR_INSTALL_PACKAGE_RELEASE_MODE_CURRENT]"
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --schema-only|--so)
        gNDR_POSTGRES_EXPORT_SCHEMA_ONLY=true
        ndr_logInfo "Schema only mode for PostgreSQL export enabled."
        shift
        ;;
      --allow-schema-errors)
        gNDR_ALLOW_SCHEMA_ERRORS=true
        ndr_logInfo "Allow schema errors option enabled."
        shift
        ;;
      --retain-docker-images|--retainimages)
        gNDR_RETAIN_DOCKER_IMAGES=true
        ndr_logInfo "Docker image retention option enabled."
        shift
        ;;
      --publicrepo)
        NDR_DOCKER_REPO_TYPE_CURRENT=$NDR_DOCKER_REPO_TYPE_PUBLIC_NDR
        ndr_logInfo "Docker repo type set to [$NDR_DOCKER_REPO_TYPE_CURRENT]."
        shift
        ;;
      --localregistry|--localreg)
        if [[ -n "$2" && "$2" != --* ]]; then
          local host_and_port="$2"
          gNDR_DOCKER_LOCAL_REGISTRY_HOST="${host_and_port%%:*}"
          gNDR_DOCKER_LOCAL_REGISTRY_PORT="${host_and_port##*:}"
          if [[ -z "$gNDR_DOCKER_LOCAL_REGISTRY_HOST" || -z "$gNDR_DOCKER_LOCAL_REGISTRY_PORT" ]]; then
            ndr_logError "Invalid registry host:port option [$host_and_port]"
            return 1
          fi
          NDR_DOCKER_REPO_TYPE_CURRENT=$NDR_DOCKER_REPO_TYPE_LOCAL_REGISTRY
          ndr_logInfo "Docker repo type set to [$NDR_DOCKER_REPO_TYPE_CURRENT] using host and port [$gNDR_DOCKER_LOCAL_REGISTRY_HOST:$gNDR_DOCKER_LOCAL_REGISTRY_PORT]."
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --gcpregistry|--gcpreg)
         if [[ -n "$2" && "$2" != --* ]]; then
          gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT="$2"
          NDR_DOCKER_REPO_TYPE_CURRENT=$NDR_DOCKER_REPO_TYPE_GCP_REGISTRY
          ndr_logInfo "GCP registry root [$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT]"
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --debug)
        gDEBUG_MODE=true
        ndr_logInfo "Debug log mode enabled."
        shift
        ;;
      --advanced|--adv)
        gNDR_ADVANCED_MODE=true
        ndr_logInfo "Advanced mode enabled."
        shift
        ;;
      --pauseonerror|--poe)
        gNDR_PAUSE_ON_ERROR_MODE=true
        ndr_logInfo "Pause on error mode enabled."
        shift
        ;;
      --max-images)
        if [[ -n "$2" && "$2" != --* ]]; then
          gNDR_MAX_IMAGE_LIST="$2"
          ndr_logInfo "Setting max remote image list to [$gNDR_MAX_IMAGE_LIST]"
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --locregport|--privregport)
        if [[ -n "$2" && "$2" != --* ]]; then
          gNDR_DOCKER_LOCAL_REGISTRY_PORT="$2"
          ndr_logInfo "Local Docker registry port set to [$gNDR_DOCKER_LOCAL_REGISTRY_PORT]."
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --locreghost|--privreghost)
        if [[ -n "$2" && "$2" != --* ]]; then
          gNDR_DOCKER_LOCAL_REGISTRY_HOST="$2"
          ndr_logInfo "Local Docker Registry host set to [$gNDR_DOCKER_LOCAL_REGISTRY_HOST]."
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --enablecaddy)
        NDR_CADDY_ENABLED=true
        ndr_logInfo "Secure Caddy enabled option set."
        shift
        ;;
      --fullsupabase|--fulldb)
        gNDR_FULL_SUPABASE_SERVICES_MODE=true
        ndr_logInfo "Full Supabase services mode enabled."
        shift
        ;;
      --noapplicationbackup|--nobackup)
        gNDR_APP_BACKUP_SKIP=true
        ndr_logInfo "Skip application backup option enabled."
        shift
        ;;
      *)
        shift
        ;;
    esac
  done

  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

# Function to compare semantic versions
# Returns 0 (true) if $1 < $2
# Returns 1 (false) if $1 >= $2
function version_lt() 
{
  [ "$(printf '%s\n' "$1" "$2" | sort -V | head -n1)" != "$2" ]
}

function ndr_checkAndInstallPrerequisites () 
{
  local logSectionDesc="Checking prerequisites"
  ndr_logSecStart "$logSectionDesc"

  if [[ $gPrereqCheckComplete -eq 1 ]]; then
    ndr_logInfo "Prerequesite check complete, skipping."
    return 0
  fi

  local checkOnlyFlag=false
  if [[ "$1" == "checkOnly" ]]; then
    checkOnlyFlag=true
  fi

  declare -A mapPackageAndVersions=()

  if [[ "$gNDR_DEVOPS_MODE" == true ]]; then
    #mapPackageAndVersions["makeself"]="$NDR_MIN_REQUIRED_YQ_VERSION"
    mapPackageAndVersions["npm"]="$NDR_MIN_REQUIRED_VERSION_DEFAULT"
    mapPackageAndVersions["postgresql-client"]="$NDR_MIN_REQUIRED_VERSION_DEFAULT"
    mapPackageAndVersions["trivy"]="$NDR_MIN_REQUIRED_VERSION_DEFAULT"
  fi
  mapPackageAndVersions["yq"]="$NDR_MIN_REQUIRED_YQ_VERSION"
  mapPackageAndVersions["git"]="$NDR_MIN_REQUIRED_VERSION_DEFAULT"
  mapPackageAndVersions["docker"]="$NDR_MIN_REQUIRED_VERSION_DEFAULT"
  #mapPackageAndVersions["$gSUPABASE_CLI_CMD"]="$NDR_MIN_REQUIRED_VERSION_DEFAULT"
  mapPackageAndVersions["rsync"]="$NDR_MIN_REQUIRED_YQ_VERSION"
  
  local packageInstalled=false
  local checkOnlyPackagesRequired=false

  # Execute a preliminary install cache update appropriate to the distro.
  # this is useful on fresh vm's where the cache has never been init'd.
  if [[ "$distroFamily" == "debian" ]]; then
    cmd="sudo apt-get update"
  fi
  if [[ -n "$cmd" ]]; then
    $cmd
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "[$cmd] failure"
    fi
  fi
  
  for pkg in "${!mapPackageAndVersions[@]}"; do
    local minPkgVersion="${mapPackageAndVersions[$pkg]}"
    
    # assume all packages are not installed by default, then check one by one.
    packageInstalled=false
    local removeRequired=false

    while true; do
      if ! command -v "$pkg" &> /dev/null; then
        ndr_logWarn "$pkg requires installation."
        break
      fi
      
      # some version of package is least installed, check version independently below.
      packageInstalled=true # package is installed
      
      # only check version if min required version for package is populated with valid value.
      if [[ "$minPkgVersion" == "$NDR_MIN_REQUIRED_VERSION_DEFAULT" ]]; then
        # package is installed and version check is not required.
        break
      fi

      local pkgOutput=$("$pkg" --version)
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logWarn "Error scraping $pkg version output [$return_code -> $pkgOutput]"
        packageInstalled=false
        break
      fi
      
      # parse the installed numerical version from the command output. If version number not present, skip version checks.
      local pkgInstalledVersion=$(echo "$pkgOutput" | sed -nE 's/.*([0-9]+\.[0-9]+\.[0-9]+).*/\1/p')
      if [[ -z $pkgInstalledVersion ]]; then
        # unable to parse out specific version info, skip further processing.
        ndr_logWarn "Version info not found for package [$pkg], [$pkgOutput]"
        packageInstalled=false
        break
      fi
      ndr_logInfo "Found [$pkg] package version installed [$pkgInstalledVersion] compared to min reqd version [$minPkgVersion]"
      
      version_lt "$pkgInstalledVersion" "$minPkgVersion"
      return_code=$?
      if [ $return_code -eq 0 ]; then
        ndr_logInfo "Older version of [$pkg] detected. Replacing with latest..."
        removeRequired=true # removal of old version will be required.
        packageInstalled=false # then installation of new version.
      else
        ndr_logInfo "✅ Package [$pkg] is up to date."
      fi
      
      break
    done

    if [ $packageInstalled == true ]; then
      # package is installed and version is matching, nothing more to do.
      ndr_logInfo "✅ $pkg is installed."
      continue;
    fi

    if [ $checkOnlyFlag == true ]; then
      # executed in check only mode, do not actually install any packages.
      checkOnlyPackagesRequired=true
      continue
    fi

    # skip individual package prompts in express mode.
    if [[ "$gEXPRESS_MODE" == false ]]; then
      read -p "Would you like to install/update $pkg now? [Y/n] " REPLY
      if [[ $REPLY =~ ^[Nn]$ ]]; then
        ndr_logWarn "Skipping installation of $pkg."
        continue;
      fi
    fi

    ndr_logInfo "Installing [$pkg] package..."
    case "$pkg" in
      rsync)
        packageURL="https://rsync.samba.org/"
        
        if [[ "$distroFamily" == "debian" ]]; then
          cmd="sudo apt-get install --assume-yes rsync"
        elif [[ "$distroFamily" == "redhat" ]]; then
          cmd="sudo dnf install rsync"
        elif [[ "$distroFamily" == "suse" ]]; then
          cmd="sudo zypper install --no-confirm rsync"
        elif [[ "$distroFamily" == "osx" ]]; then
          cmd="brew install rsync"
        fi
        
        $cmd
        return_code=$?
        if [ $return_code != 0 ]; then
          ndr_logError "[$cmd] failure, $pkg package not installed, please manually install package before proceeding ($packageURL)"
          return 1
        fi
        ndr_logInfo "$pkg package installed successfully."
        ;;
      postgresql-client)
        packageURL="https://www.postgresql.org/download/linux/ubuntu/"
        
        if [[ "$distroFamily" == "debian" ]]; then
          cmd="sudo apt-get install --assume-yes postgresql-client"
        elif [[ "$distroFamily" == "redhat" ]]; then
          cmd="sudo dnf install postgresql"
        elif [[ "$distroFamily" == "suse" ]]; then
          cmd="sudo zypper install --no-confirm postgresql-client"
        elif [[ "$distroFamily" == "osx" ]]; then
          cmd="brew install postgresql-client"
        fi
        
        $cmd
        return_code=$?
        if [ $return_code != 0 ]; then
          ndr_logError "[$cmd] failure, $pkg package not installed, please manually install package before proceeding ($packageURL)"
          return 1
        fi
        ndr_logInfo "$pkg package installed successfully."
        ;;

      yq)
        packageURL="https://github.com/mikefarah/yq"

        if [ $removeRequired == true ]; then
          if [[ "$distroFamily" == "debian" ]]; then
            cmd="sudo apt-get remove --assume-yes yq"
          elif [[ "$distroFamily" == "redhat" ]]; then
            cmd="sudo dnf remove yq"
          elif [[ "$distroFamily" == "suse" ]]; then
            cmd="sudo zypper remove --no-confirm yq"
          elif [[ "$distroFamily" == "osx" ]]; then
            cmd="brew remove yq"
          fi

           $cmd
          return_code=$?
          if [ $return_code != 0 ]; then
            ndr_logError "[$cmd] failure, $pkg package not removed, please manually remove package before proceeding"
            return 1
          fi
        fi

        cmd="wget https://github.com/mikefarah/yq/releases/latest/download/yq_linux_amd64 -O /usr/local/bin/yq"
        $cmd
        return_code=$?
        if [ $return_code != 0 ]; then
          ndr_logError "[$cmd] failure, $pkg package not installed, please manually install package before proceeding ($packageURL)"
          return 1
        fi
        sudo chmod +x /usr/local/bin/yq

        ndr_logInfo "$pkg package installed successfully."
        ;;

      makeself)
        packageURL="https://makeself.io/"
        
        if [[ "$distroFamily" == "debian" ]]; then
          cmd="sudo apt-get install --assume-yes makeself"
        elif [[ "$distroFamily" == "redhat" ]]; then
          cmd="sudo dnf install makeself"
        elif [[ "$distroFamily" == "suse" ]]; then
          cmd="sudo zypper install --no-confirm makeself"
        elif [[ "$distroFamily" == "osx" ]]; then
          cmd="brew install makeself"
        fi
        
        $cmd
        return_code=$?
        if [ $return_code != 0 ]; then
          ndr_logError "[$cmd] failure, $pkg package not installed, please manually install package before proceeding ($packageURL)"
          return 1
        fi
        ndr_logInfo "$pkg package installed successfully."
        ;;

      awk|gawk)
        packageURL="https://www.gnu.org/software/gawk/manual/gawk.html"
        
        if [[ "$distroFamily" == "debian" ]]; then
          cmd="sudo apt-get install --assume-yes gawk"
        elif [[ "$distroFamily" == "redhat" ]]; then
          cmd="sudo dnf install gawk"
        elif [[ "$distroFamily" == "suse" ]]; then
          cmd="sudo zypper install --no-confirm gawk"
        elif [[ "$distroFamily" == "osx" ]]; then
          cmd="brew install gawk"
        fi
        
        $cmd
        return_code=$?
        if [ $return_code != 0 ]; then
          ndr_logError "[$cmd] failure, $pkg package not installed, please manually install package before proceeding ($packageURL)"
          return 1
        fi
        ndr_logInfo "$pkg package installed successfully."
        ;;

      npm|npx)
        packageURL="https://docs.npmjs.com/downloading-and-installing-node-js-and-npm"
        
        if [[ "$distroFamily" == "debian" ]]; then
          cmd="sudo apt install --assume-yes npm"
        elif [[ "$distroFamily" == "redhat" ]]; then
          cmd="sudo dnf install nodejs"
        elif [[ "$distroFamily" == "suse" ]]; then
          cmd="sudo zypper install --no-confirm nodejs"
        elif [[ "$distroFamily" == "osx" ]]; then
          cmd="brew install node"
        fi
        
        $cmd
        return_code=$?
        if [ $return_code != 0 ]; then
          ndr_logError "[$cmd] failure, $pkg package not installed, please manually install package before proceeding ($packageURL)"
          return 1
        fi
        ndr_logInfo "$pkg package installed successfully."
        ;;

      git)
        packageURL="https://git-scm.com/downloads"
        
        if [[ "$distroFamily" == "debian" ]]; then
          cmd="sudo apt install --assume-yes git"
        elif [[ "$distroFamily" == "redhat" ]]; then
          cmd="sudo dnf install git"
        elif [[ "$distroFamily" == "suse" ]]; then
          cmd="sudo zypper install --no-confirm git"
        elif [[ "$distroFamily" == "osx" ]]; then
          cmd="brew install git"
        fi

        $cmd
        return_code=$?
        if [ $return_code != 0 ]; then
          ndr_logError "[$cmd] failure, $pkg package not installed, please manually install package before proceeding ($packageURL)"
          return 1
        fi
        ndr_logInfo "$pkg package installed successfully."
        ;;

      docker)
        packageURL="https://docs.docker.com/engine/install/"
        if [[ "$distroFamily" == "debian" ]]; then
          local installCmds=(
            ndr_checkAndInstallDocker
          )
        elif [[ "$distroFamily" == "debianOLD" ]]; then
          local installCmds=(
                "sudo apt-get install --assume-yes gnome-terminal"
                "sudo apt-get update" \
                "sudo apt-get install --assume-yes ca-certificates" \
                "sudo apt-get install --assume-yes curl" \
                "sudo install -m 0755 -d /etc/apt/keyrings" \
                "sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc" \
                "sudo chmod a+r /etc/apt/keyrings/docker.asc" \
                #"echo deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo ${UBUNTU_CODENAME:-$VERSION_CODENAME}) stable | sudo tee /etc/apt/sources.list.d/docker.list"
                # Step 1: Get system architecture
                "arch=$(dpkg --print-architecture)" \
                # Step 2: Get Ubuntu codename (e.g., focal, jammy)
                ". /etc/os-release" \
                "codename=\"${UBUNTU_CODENAME:-$VERSION_CODENAME}\"" \
                # Step 3: Construct the deb line
                "deb_line=\"deb [arch=$arch signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu $codename stable\"" \
                # Step 4: Write to APT sources list with sudo
                "echo \"$deb_line\" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null" \
                "sudo apt-get update" \
                "sudo apt-get install --assume-yes docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin")
        elif [[ "$distroFamily" == "redhat" ]]; then
          local installCmds=(
                "sudo dnf install gnome-terminal" \
                "sudo dnf -y install dnf-plugins-core" \
                "sudo dnf-3 config-manager --add-repo https://download.docker.com/linux/fedora/docker-ce.repo" \
                "sudo dnf install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin" \
                "sudo systemctl enable --now docker")
        elif [[ "$distroFamily" == "suse" ]]; then
          local installCmds=(
                "sudo zypper addrepo https://download.opensuse.org/repositories/Virtualization:containers/openSUSE_Tumbleweed_and_d_l_g/Virtualization:containers.repo" \
                "sudo zypper addrepo https://download.docker.com/linux/sles/docker-ce.repo" \
                "sudo zypper refresh" \
                "sudo zypper install docker-compose" \
                "sudo systemctl enable docker.service" \
                "sudo usermod -aG docker $USER" \
                "sudo systemctl start docker.service" \
                "sudo zypper install docker")
        fi

        for installCmd in "${installCmds[@]}"; do
        ndr_logInfo "Executing installation command [$installCmd]..."
          $installCmd
          return_code=$?
          if [ $return_code != 0 ]; then
            ndr_logError "[$installCmd] failure, $pkg package not installed, please manually install package before proceeding ($packageURL)"
            # skip apt-get command failures
            if [[ "$installCmd" == *"apt-get update"* || "$installCmd" == *addrepo* ]]; then
              continue
            fi
            return 1
          fi
        done
        
        getent group docker || sudo groupadd docker
        return_code=$?
        if [ $return_code -ne 0 ]; then
          ndr_logError "Failed to create docker group. Please check your system configuration."
          return 1
        fi
        ndr_logInfo "Created docker group if it did not exist."

        sudo usermod -aG docker "$USER"
        return_code=$?
        if [ $return_code -ne 0 ]; then
          ndr_logError "Failed to add user $USER to docker group. Please check your system configuration."
          return 1
        fi
        ndr_logInfo "User $USER added to docker group. You may need to log out and back in for this change to take effect."

        if systemctl is-active --quiet docker; then
          ndr_logInfo "Docker is running."
        else
          # Optional: try to start it
          ndr_logInfo "Docker is NOT running, attempting to start Docker..."
          
          sudo systemctl start docker

          # Check again after attempt
          if systemctl is-active --quiet docker; then
              ndr "Docker started successfully."
          else
              ndr_logError "Failed to start Docker. Check logs with: journalctl -u docker. A reboot may be required to complete the installation."
              return 1
          fi
        fi
        
        ndr_logInfo "$pkg package installed successfully."            
        ;;

      trivy)
        packageURL="https://trivy.dev/latest/getting-started/installation/"

        if [[ "$distroFamily" == "debian" || "$distroFamily" == "debianOLD" ]]; then
          local installCmds=(
            "sudo apt-get install --assume-yes -qq wget gnupg lsb-release apt-transport-https"
            "sudo install -m 0755 -d /usr/share/keyrings"
            "bash -c 'wget -qO - https://aquasecurity.github.io/trivy-repo/deb/public.key | gpg --dearmor | sudo tee /usr/share/keyrings/trivy.gpg > /dev/null'"
            "bash -c 'echo \"deb [signed-by=/usr/share/keyrings/trivy.gpg] https://aquasecurity.github.io/trivy-repo/deb $(lsb_release -sc) main\" | sudo tee /etc/apt/sources.list.d/trivy.list > /dev/null'"
            "sudo apt-get update -qq"
            "sudo env DEBIAN_FRONTEND=noninteractive apt-get install --assume-yes -qq trivy"
          )
        else
          ndr_logError "Automatic installation for [$pkg] is only implemented for Ubuntu/Debian. Please manually install package before proceeding ($packageURL)"
          return 1
        fi

        for installCmd in "${installCmds[@]}"; do
          ndr_logInfo "Executing installation command [$installCmd]..."
          eval "$installCmd"
          return_code=$?
          if [ $return_code != 0 ]; then
            ndr_logError "[$installCmd] failure, $pkg package not installed, please manually install package before proceeding ($packageURL)"
            return 1
          fi
        done

        ndr_logInfo "$pkg package installed successfully."
        ;;

      supabase)
        packageURL="https://supabase.com/docs/guides/local-development"

        cmd="sudo npm install supabase --save-dev"
        
        $cmd
        return_code=$?
        if [ $return_code != 0 ]; then
          ndr_logError "[$cmd] failure, $pkg package not installed, please manually install package before proceeding ($packageURL)"
          return 1
        fi
        ndr_logInfo "$pkg package installed successfully."
        ;;
      
      *)
        ndr_logWarn "Unknown package [$pkg] "
        continue
        ;;
    esac

    packageInstalled=true

  done

  # the prereq check complete flag needs to be qualfied by all packages installed before setting
  if [ $packageInstalled == true ]; then
    ndr_logInfo "All required packages are installed."
    gPrereqCheckComplete=1
  else
    ndr_logError "Some required packages are not installed. Please install them before proceeding."
    return 1
  fi

  if [[ "$checkOnlyFlag" == true && "$checkOnlyPackagesRequired" == true ]]; then
    ndr_logWarn "Some packages require installation. Please review the output above for details."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}


function ndr_checkAndInstallDocker ()
{
  # -------------------------------------
  # cleanup old docker packages

  local logSectionDesc="Conflicting Docker package removal"
  ndr_logSecStart "$logSectionDesc"

  # Loop through each package and remove it
  for pkg in "${dockerRemovePkgs[@]}"; do
    if dpkg -l | grep -q "$pkg"; then
      ndr_logInfo "🗑️ Removing $pkg..."
      sudo apt-get remove --assume-yes "$pkg"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "$pkg package not removed, please manually remove package before proceeding."
        return 1
      fi
    else
      ndr_logInfo "$pkg is not installed, skipping."
    fi
  done

  ndr_logSecEnd "$logSectionDesc"
  
  # -------------------------------------
  # 🚮 Remove any stale Docker APT source files

  local logSectionDesc="🧹 Cleaning up old Docker APT source entries"
  ndr_logSecStart "$logSectionDesc"

  # Remove docker.list if it exists
  docker_list="/etc/apt/sources.list.d/docker.list"
  if [[ -f "$docker_list" ]]; then
    sudo rm -f "$docker_list"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "file $docker_list not removed, please manually remove file before proceeding."
      return 1
    fi
    ndr_logInfo "🗑️ Removed stale Docker source file."
  fi

  # Optional: grep and warn about any other Docker-related entries
  if grep -r "download.docker.com" /etc/apt/sources.list.d/ > /dev/null; then
    ndr_logWarn "Found other Docker source entries in [/etc/apt/sources.list.d/]."
  fi

  if grep -q "download.docker.com" /etc/apt/sources.list; then
    ndr_logWarn "Found Docker source entry in [/etc/apt/sources.list]  You may want to clean that manually.033[0m"
  fi

  ndr_logSecEnd "$logSectionDesc"

  # -------------------------------------
  # Add Docker's official GPG key:

  local logSectionDesc="Adding Official Docker GPG Key"
  ndr_logSecStart "$logSectionDesc"

  sudo apt-get update
  pkgs=(
    ca-certificates
    curl
  )
  # Loop through each package and install it
  for pkg in "${pkgs[@]}"; do
    ndr_logInfo "💾 Installing $pkg..."
    sudo apt-get install --assume-yes "$pkg"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "$pkg package not installed, please manually install package before proceeding."
      return 1
    fi
  done

  local cmds=(
    "sudo install -m 0755 -d /etc/apt/keyrings" \
    "sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc" \
    "sudo chmod a+r /etc/apt/keyrings/docker.asc"
    )
  
  for cmd in "${cmds[@]}"; do
    ndr_logInfo "💾 Executing command [$cmd]..."
    $cmd
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Command [$cmd] failure, please run manually before proceeding."
      return 1
    fi
  done

  ndr_logSecEnd "$logSectionDesc"

  # -------------------------------------
  # add deb line to apt sources list

  local logSectionDesc="Adding Docker APT source entries"
  ndr_logSecStart "$logSectionDesc"
  
  # single line execution
  #echo deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo ${UBUNTU_CODENAME:-$VERSION_CODENAME}) stable | sudo tee /etc/apt/sources.list.d/docker.list

  # multi line execution
  # Step 1: Get system architecture
  arch=$(dpkg --print-architecture)

  # Step 2: Get Ubuntu codename (e.g., focal, jammy)
  . /etc/os-release
  codename="${UBUNTU_CODENAME:-$VERSION_CODENAME}"

  # Step 3: Construct the deb line
  deb_line="deb [arch=$arch signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu $codename stable"

  # Step 4: Write to APT sources list with sudo 
  apt_source_file="/etc/apt/sources.list.d/docker.list"
  echo "$deb_line" | sudo tee "$apt_source_file" > /dev/null
  
  ndr_logInfo "Adding deb line [$deb_line] to list file [$apt_source_file]."

  sudo apt-get update

  ndr_logSecEnd "$logSectionDesc"

  # -------------------------------------
  # verify apt sources

  local logSectionDesc="Verifying Docker APT source entries"
  ndr_logSecStart "$logSectionDesc"

  # Step 1: Verify the deb line exists
  if [[ ! -f "$apt_source_file" ]]; then
    ndr_logError "APT source file not found: [$apt_source_file]."
    return 1
  fi

  if grep -Fxq "$deb_line" "$apt_source_file"; then
    ndr_logInfo "Docker APT source entry is present."
  else
    ndr_logError "Docker APT source entry is missing or incorrect."
    return 1
  fi

  # Step 2: Update APT
  ndr_logInfo "🔄 Running apt-get update..."
  sudo apt-get update -qq
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "apt-get update failed."
    return 1
  fi

  # Step 3: Check for Docker packages
  for pkg in "${dockerInstallPackages[@]}"; do
    ndr_logInfo "🔍 Checking if Docker package [$pkg] is available..."
    repo_line=$(apt-cache policy "$pkg" 2>/dev/null | grep "https://download.docker.com/linux/ubuntu $codename")
    return_code=$?
    if [[ $return_code -eq 0 && -n "$repo_line" ]]; then
      ndr_logInfo "✅ Docker package [$pkg] is available from Docker's APT repository."
    else
      ndr_logError "Docker package [$pkg] not found in the expected repository."
      return 1
    fi
  done

  ndr_logSecEnd "$logSectionDesc"

  # -------------------------------------
  # install docker packages
  
  local logSectionDesc="Installing Docker packages"
  ndr_logSecStart "$logSectionDesc"

  #sudo apt-get install --assume-yes docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
  for pkg in "${dockerInstallPackages[@]}"; do
    ndr_logInfo "🔍 Installing Docker engine package [$pkg]..."
    cmd="sudo apt-get install --assume-yes $pkg"
    $cmd
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to install Docker package [$pkg]."
      return 1
    else
      ndr_logInfo "✅ Docker package [$pkg] installed successfully."
    fi
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}


# Running Supabase locally in a Docker container
# to create build env prerequsiites, some prerequisites must be interactively installed before the scripting can proceed.
# https://supabase.com/docs/guides/self-hosting/docker
# 1. install NPM/NPX (https://docs.npmjs.com/downloading-and-installing-node-js-and-npm)
# 2. install GIT (https://git-scm.com/downloads)
# 3. install docker (https://docs.docker.com/desktop/setup/install/windows-install/ or https://docs.docker.com/desktop/setup/install/linux-install/)
# 4. create docker account and log in (docker desktop and pulls will not function without this). With the Docker UI open, you can observe the images and containers getting created and onlined in real time.
function ndr_packagePrereqCheck ()
{
  local logSectionDesc="Checking package prerequisites"
  ndr_logSecStart "$logSectionDesc"

  ndr_checkAndInstallPrerequisites checkOnly
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Package prereq only check failed."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

NDR_ModuleContainerEnvVars=(
  "SITE_URL" \
  "POSTGRES_PASSWORD" \
  "ANON_KEY" \
  "NDR_SUPABASE_URL" \
  "NDR_SUPABASE_ANON_KEY" \
  "NDR_API_SERVER_URL" \
  "NDR_LICENSE_SERVER_URL" \
  "NDR_LICENSE_PUBLIC_KEY" \
  "NDR_SUPABASE_SERVICE_KEY" \
  "NDR_PASSWORD_ENC_SECRET"
  )
  
# Usage: ndr_BuildModuleEnvFile <folder>
function ndr_BuildModuleEnvFile () 
{
  local logSectionDesc="Constructing module env file"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 1 ]]; then
    ndr_logError "Usage: ndr_BuildModuleEnvFile <folder>"
    return 1
  fi

  local containerFolder="$1"
  local sourceEnvFile="${gSCRIPT_HOME_DIR}/${gNDR_MODULE_ENV_SOURCE_VAR_FILENAME}"
  
  # Check source file
  if [[ ! -f "$sourceEnvFile" ]]; then
    ndr_logError "Source env file '$sourceEnvFile' not found."
    return 1
  fi

  # check destination folder
  local destFolder="$containerFolder"
  if [[ ! -d "$destFolder" ]]; then
    ndr_logError "Destination folder '$destFolder' does not exist."
    return 1
  fi
  local destEnvFile="${destFolder}/${gNDR_ENV_TARGET_FILENAME}"
  
  if [[ -z "$gNDR_SERVER_HOST_ADDRESS" || "$gNDR_SERVER_HOST_ADDRESS" == "localhost" ]]; then
    local hostAddress=$(ndr_getHostAddressReg)
    if [[ -n "$hostAddress" && "$hostAddress" != "localhost" ]]; then
      gNDR_SERVER_HOST_ADDRESS="$hostAddress"
      ndr_logInfo "Using host address [$gNDR_SERVER_HOST_ADDRESS] from registry for $gPRODUCT_NAME specific target server addresses".
    fi
  fi

  
  if false; then
  # Empty or create output file
  rm -f "$destEnvFile"
  > "$destEnvFile"

  # Copy specified variables
  for var in "${NDR_ModuleContainerEnvVars[@]}"; do
    line=$(grep -E "^${var}=" "$sourceEnvFile" | head -n1)
    if [[ -n "$line" ]]; then
      echo "$line" >> "$destEnvFile"
    else
      ndr_logError "Warning: Variable '$var' not found in $sourceEnvFile"
      return 1
    fi
  done
  fi

  # Load source env into a map
  declare -A source_map
  while IFS='=' read -r key value; do
    [[ -z "$key" || "$key" == \#* ]] && continue
    source_map["$key"]="$value"
  done < "$sourceEnvFile"
  ndr_logInfo "Read [${#source_map[@]}] entries from source env file [$sourceEnvFile]."

  # Load destination env into a map (if exists)
  declare -A dest_map
  if [[ -f "$destEnvFile" ]]; then
    while IFS='=' read -r key value; do
      [[ -z "$key" || "$key" == \#* ]] && continue
      dest_map["$key"]="$value"
    done < "$destEnvFile"
    ndr_logInfo "Read [${#dest_map[@]}] entries from existing dest env file [$destEnvFile]."
  else
    ndr_logInfo "Dest env file [$destEnvFile] does not exist, will create new."
  fi

  # Update dest_map with resolved values from source_map
  for var in "${NDR_ModuleContainerEnvVars[@]}"; do
    if [[ -z "${source_map[$var]+_}" ]]; then
      ndr_logWarn "Variable '$var' not found in source env file. Skipping."
      continue
    fi

    raw_value="${source_map[$var]}"
    if [[ "$raw_value" =~ ^\$\{([A-Za-z_][A-Za-z0-9_]*)\}$ ]]; then
      ref_key="${BASH_REMATCH[1]}"
      if [[ -z "${source_map[$ref_key]+_}" ]]; then
        ndr_logWarn "Referenced variable '$ref_key' (in $var) not found. Skipping."
        continue
      fi
      resolved_value="${source_map[$ref_key]}"
    else
      resolved_value="$raw_value"
    fi

    # If variable is prefixed with NDR_ and contains 'localhost' and $gNDR_SERVER_HOST_ADDRESS is valid, substitute $gNDR_SERVER_HOST_ADDRESS
    if [[ "$var" == NDR_* && "$resolved_value" == *localhost* && "$gNDR_SERVER_HOST_ADDRESS" != "localhost" ]]; then
      resolved_value="${resolved_value//localhost/$gNDR_SERVER_HOST_ADDRESS}"
      ndr_logInfo "Updating [$var -> $resolved_value] to reflect target IP [$gNDR_SERVER_HOST_ADDRESS]"
    fi

    dest_map["$var"]="$resolved_value"
  done

  # Write merged map to destination file
  {
    for key in "${!dest_map[@]}"; do
      echo "$key=${dest_map[$key]}"
    done | sort
  } > "$destEnvFile"
  ndr_logInfo "Wrote [${#dest_map[@]}] entries to dest env file [$destEnvFile]."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# Usage: function <folder>
function ndr_BuildModuleEnvFileV2 () 
{
  local logSectionDesc="Constructing module env file"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <folder> <docker_image_base_name>"
    return 1
  fi

  local containerFolder="$1"
  local dockerImageBaseName="$2"
  local sourceEnvFile="${gSCRIPT_HOME_DIR}/${gNDR_MODULE_ENV_SOURCE_VAR_FILENAME}" # Source env file (references + comments)

  # Check source file
  if [[ ! -f "$sourceEnvFile" ]]; then
    ndr_logError "Source env file '$sourceEnvFile' not found."
    return 1
  fi

  if [ -z "$gSUPABASE_NEXTDR_HOME" ]; then
    gSUPABASE_NEXTDR_HOME="${gNEXTDR_HOME_DIR}/${gSUPABASE_NEXTDR_SUB}"
  fi
  if [ ! -d "$gSUPABASE_NEXTDR_HOME" ]; then
    ndr_logError "Unable to determine Supabase home directory or directory doesn't exist [$gSUPABASE_NEXTDR_HOME]."
    return 1
  fi

  local supabaseEnvFile="${gSUPABASE_NEXTDR_HOME}/${gNDR_ENV_TARGET_FILENAME}"   # Supabase env file (lookup values from here)

  # Check supabase file
  if [[ ! -f "$supabaseEnvFile" ]]; then
    ndr_logError "Supabase env file '$supabaseEnvFile' not found."
    return 1
  fi

  # check destination folder
  local destFolder="$containerFolder"
  if [[ ! -d "$destFolder" ]]; then
    ndr_logError "Destination folder '$destFolder' does not exist."
    return 1
  fi
  local destEnvFile="${destFolder}/${gNDR_ENV_TARGET_FILENAME}" # Destination env file to generate
  local destEnvFileTmp="${destEnvFile}.tmp"

  # check if dest and temp env files exist and remove
  if [[ -f "$destEnvFile" ]]; then
    ndr_logInfo "Removing existing dest env file [$destEnvFile] before regenerating."
    rm -f "$destEnvFile"
  fi
  if [[ -f "$destEnvFileTmp" ]]; then
    ndr_logInfo "Removing existing temp env file [$destEnvFileTmp] before regenerating."
    rm -f "$destEnvFileTmp"
  fi

  # --- Load Supabase env vars into a lookup map ---
  declare -A supabase_map
  while IFS='=' read -r key value; do
    [[ -z "$key" || "$key" == \#* ]] && continue
    supabase_map["$key"]="$value"
  done < "$supabaseEnvFile"

  # --- Read the entire source file into lines (preserving comments & spaces) ---
  mapfile -t lines < "$sourceEnvFile"
  if [[ $? -ne 0 ]]; then
    ndr_logError "Failed to read $sourceEnvFile"
    return 1
  fi

  linesCustomValues=0
  for line in "${lines[@]}"; do
    # Preserve comments and empty lines as-is
    if [[ -z "$line" || "$line" =~ ^[[:space:]]*# ]]; then
      continue
    else
      linesCustomValues=$((linesCustomValues += 1))
    fi
  done
  ndr_logInfo "Read [$linesCustomValues] custom values from source file [$sourceEnvFile] to update in module env file [$destEnvFile]."

  local new_lines=()

  local linesWritten=0

  # --- Process source lines one by one ---
  for line in "${lines[@]}"; do
    # Preserve comments and empty lines as-is
    if [[ -z "$line" || "$line" =~ ^[[:space:]]*# ]]; then
      new_lines+=("$line")
      continue
    fi

    # Match VAR=VALUE pairs
    if [[ "$line" =~ ^([A-Za-z_][A-Za-z0-9_]*)=(.*)$ ]]; then
      key="${BASH_REMATCH[1]}"
      value="${BASH_REMATCH[2]}"

      # Detect value reference like $OTHER_VAR or ${OTHER_VAR}
      if [[ "$value" =~ ^\$\{?([A-Za-z_][A-Za-z0-9_]*)\}?$ ]]; then
        ref="${BASH_REMATCH[1]}"
        if [[ -n "${supabase_map[$ref]+_}" ]]; then
          value="${supabase_map[$ref]}"
          ndr_logInfo "Resolved reference $key from $ref"
        else
          ndr_logError "Reference $ref for $key not found in $supabaseEnvFile"
          return 1
        fi
      fi

      if [[ "$value" == *"localhost"* ]]; then
        value="${value//localhost/$gNDR_SERVER_HOST_ADDRESS}"
        ndr_logInfo "Updating host address key with actual value [$key=$value]"
        linesUpdated=$((linesUpdated += 1))
      fi

      linesWritten=$((linesWritten += 1))

      # Append resolved key=value pair
      new_lines+=("$key=$value")
    else
      # For any non-standard lines, keep as-is
      new_lines+=("$line")
    fi
  done

  # --- Open temp file for writing ---
  exec 3> "$destEnvFileTmp" || {
    ndr_logError "Failed to open $destEnvFileTmp for writing"
    return 1
  }

  # --- Write processed lines one by one ---
  for l in "${new_lines[@]}"; do
    if ! printf '%s\n' "$l" >&3; then
      ndr_logError "Failed to write line to $destEnvFileTmp: $l"
      exec 3>&-
      return 1
    fi
  done

  # --- Build list of additional environment variables ---
  NDR_SUPABASE_CONTAINER_PORT=$(grep -E '^KONG_HTTP_PORT=' "$supabaseEnvFile" | cut -d '=' -f2-)
  NDR_DOCKER_SUPABASE_URL="http://${NDR_SUPABASE_APP_SERVICE_NAME_KONG}:${NDR_SUPABASE_CONTAINER_PORT}"
  
  local commit_hash_short="$NDR_GIT_REPO_COMMIT_HASH_SHORT"
  local commit_timestamp="$NDR_GIT_REPO_COMMIT_TIMESTAMP"
  if [ "$dockerImageBaseName" == "$NDR_SERVICE_IMAGE_NAME" ]; then
    commit_hash_short="$NDR_SERVICE_IMAGE_COMMIT_HASH_SHORT"
    commit_timestamp="$NDR_SERVICE_IMAGE_COMMIT_TIMESTAMP"
  elif [ "$dockerImageBaseName" == "$NDR_UI_IMAGE_NAME" ]; then
    commit_hash_short="$NDR_UI_IMAGE_COMMIT_HASH_SHORT"
    commit_timestamp="$NDR_UI_IMAGE_COMMIT_TIMESTAMP"
  elif [ "$dockerImageBaseName" == "$NDR_CLIENT_APPLICATION_NAME" ]; then
    # hack for unified client application mode since the client will use the global hash and ts values.
    commit_hash_short="$NDR_GIT_REPO_COMMIT_HASH_SHORT"
    commit_timestamp="$NDR_GIT_REPO_COMMIT_TIMESTAMP"
  else
    ndr_logError "Unknown docker image base name [$dockerImageBaseName]."
    return 1
  fi

  declare -A additional_vars
  additional_vars=(
    ["NDR_HOME_DIR"]="${gNEXTDR_HOME_DIR}"
    ["NDR_LOGS_DIR"]="${gNEXTDR_HOME_DIR}/logs"
    ["NDR_SUPABASE_HOME_DIR"]="${gSUPABASE_NEXTDR_HOME}"
    ["NDR_SUPABASE_DB_BACKUP_DIR"]="${gNDR_APP_BACKUP_DB_DATA_SUB}"
    ["NDR_VERSION"]="${gPRODUCT_VERSION}"
    ["NDR_COMMIT_HASH"]="${commit_hash_short}"
    ["NDR_COMMIT_TIMESTAMP"]="${NDR_GIT_REPO_COMMIT_TIMESTAMP}"
    ["NDR_DOCKER_SUPABASE_URL"]="${NDR_DOCKER_SUPABASE_URL}"
  )

  # write additional vars to dest env file temp
  for key in "${!additional_vars[@]}"; do
    value="${additional_vars[$key]}"
    if ! printf '%s=%s\n' "$key" "$value" >&3; then
      ndr_logError "Failed to write additional var to $destEnvFileTmp: $key=$value"
      exec 3>&-
      return 1
    fi
    linesWritten=$((linesWritten += 1))
  done

  # --- Close temp file ---
  exec 3>&-

  # --- Move temp file into final location ---
  if ! mv "$destEnvFileTmp" "$destEnvFile"; then
    ndr_logError "Failed to replace $destEnvFile with updated content"
    return 1
  fi

  if [[ "$NDR_CADDY_ENABLED" == true ]]; then
    ndr_CustomizeClientEnvFileCaddy "$destEnvFile"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to customize the client env file for secure caddy mode [$destEnvFile]"
      return 1
    fi
    ndr_logInfo "client env file successfully configured for secure caddy mode [$destEnvFile]"
  fi

  ndr_logInfo "Module env file [$destEnvFile] successfully generated with [$linesWritten] entries"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_BuildModuleComposeFile ()
{
  local logSectionDesc="Building module compose file"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: ndr_BuildModuleComposeFile <folder> <docker_image_base_name>"
    return 1
  fi

  # the compose file is directly linked to the module's env file because the env file will have
  # the explicit name/value pairs that the compose file implicitly references.
  local containerFolder="$1"
  local dockerImageBaseName="$2"
  local ENV_FILE="${containerFolder}/${gNDR_ENV_TARGET_FILENAME}"
  
  # Check for env file
  if [[ ! -f "$ENV_FILE" ]]; then
    ndr_logError "env file '$ENV_FILE' not found."
    return 1
  fi

  # copy the app specific compose file to app home dir.
  # hack
  local sourceFileName
  local serviceName
  local imageNameVersion
  if [ "$dockerImageBaseName" == "$NDR_SERVICE_IMAGE_NAME" ]; then
    sourceFileName="$NDR_SERVICE_COMPOSEFILE_FILENAME"
    serviceName=$NDR_SERVICE_DOCKER_COMPOSE_SERVICE_NAME
    imageNameVersion="${NDR_DOCKER_REPO_ACCOUNT}/${NDR_DOCKER_SERVICE_PUBLIC_REPO_NAME}:${dockerImageBaseName}_${NDR_SERVICE_IMAGE_VERSION_TAG}"
  elif [ "$dockerImageBaseName" == "$NDR_UI_IMAGE_NAME" ]; then
    sourceFileName="$NDR_UI_COMPOSEFILE_FILENAME"
    serviceName=$NDR_UI_DOCKER_COMPOSE_SERVICE_NAME
    imageNameVersion="${NDR_DOCKER_REPO_ACCOUNT}/${NDR_DOCKER_UI_PUBLIC_REPO_NAME}:${dockerImageBaseName}_${NDR_UI_IMAGE_VERSION_TAG}"
  else
    ndr_logError "Unknown docker image base name [$dockerImageBaseName]."
    return 1
  fi

  local sourceFile="${gSCRIPT_HOME_DIR}/${sourceFileName}"
  local destFile="${containerFolder}/${NDR_STANDARD_DOCKER_COMPOSEFILE_FILENAME}" # rename the module specific compose file to the common name
  cp -f $sourceFile $destFile
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to copy [$sourceFile] to [$destFile]"
    return 1
  fi
  ndr_logInfo "Successfully copied [$sourceFile] to [$destFile]"

  # check for compose file
  local COMPOSE_FILE="${destFile}"
  if [[ ! -f "$COMPOSE_FILE" ]]; then
    ndr_logError "Compose file '$COMPOSE_FILE' not found."
    return 1
  fi

  # update image name with current version.
  yq eval -i ".services.\"${serviceName}\".image = \"${imageNameVersion}\"" "$COMPOSE_FILE"
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logWarn "Failed to update image name with version in [$COMPOSE_FILE] to [$imageNameVersion]"
  fi
  ndr_logInfo "Updated image name with version [$imageNameVersion] in [$COMPOSE_FILE]"

  # --- Load env vars into a lookup map ---
  declare -A env_map
  while IFS='=' read -r key value; do
    [[ -z "$key" || "$key" == \#* ]] && continue
    env_map["$key"]="$value"
  done < "$ENV_FILE"

  linesAdded=0
  # Add each env var from env file to the environment: section of the compose file using yq
  for var in "${!env_map[@]}"; do
    # Add or update the environment variable in the compose file
    yq eval -i ".services.*.environment.${var} = \"\${${var}}\"" "$COMPOSE_FILE"
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logWarn "Failed to add $var to environment section in $COMPOSE_FILE"
    else
      ndr_logInfo "Added $var: \${$var} to environment section in $COMPOSE_FILE"
      linesAdded=$((linesAdded += 1))
    fi
  done

  ndr_logInfo "Compose file [$COMPOSE_FILE] successfully updated with [$linesAdded] environment values"

  # Add bridge network
  ndr_CustomizeDockerComposeFileAddBridgeNetwork "$COMPOSE_FILE"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to add bridge network to compose file [$COMPOSE_FILE]."
    return 1
  fi

  # Add bind mounts
  ndr_CreateDockerBindMounts "$COMPOSE_FILE"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to add bind mounts to compose file [$COMPOSE_FILE]."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function <env_file>
function ndr_CustomizeClientEnvFileCaddy ()
{
  local logSectionDesc="Customizing the Client env File for Caddy"
  ndr_logSecStart "$logSectionDesc"
  
  if [[ $# -lt 1 ]]; then
    ndr_logError "Usage: function <env_file>"
    return 1
  fi

  local env_file="$1"
  
  # --- Check that files exist ---
  if [ ! -f "$env_file" ]; then
    ndr_logError "Env file no found [$env_file]"
    return 1
  fi

  # Configuring the product in general for use with secure caddy means altering urls and ports from http to https
  local url_vars=("NDR_DOCKER_SUPABASE_URL" "NDR_API_SERVER_URL" "NDR_SUPABASE_URL" "SITE_URL")
  local var_name
  for var_name in "${url_vars[@]}"; do
    ndr_ConvertEnvVarHTTPToHTTPS "$env_file" "$var_name"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to update $var_name in env file [$env_file]."
      return 1
    fi
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function 
function ndr_ConfigureCaddyProxy ()
{
  local logSectionDesc="Configuring Caddy Proxy"
  ndr_logSecStart "$logSectionDesc"

  if [[ -z "$gNDR_SERVER_HOST_ADDRESS" ]]; then
    ndr_logError "Server host address is empty. Unable to customize Caddyfile."
    return 1
  fi

  local CADDYFILE="${gNEXTDR_HOME_DIR}/${NDR_CADDY_HOME_LOC}/${NDR_CADDYFILE_NAME}"
  
  if [[ ! -f $CADDYFILE ]]; then
    ndr_logError "Caddyfile [$CADDYFILE] not found."
    return 1
  fi

  # replace template placeholder addresses with live values.
  gNDR_SERVER_HOST_ADDRESS=$(ndr_getHostAddressReg)

  if ! grep -q "0\.0\.0\.0" "$CADDYFILE"; then
    ndr_logError "No 0.0.0.0 entries found in Caddyfile [$CADDYFILE]. Skipping replacement."
    return 1
  fi

  # Replace all zeroed-out addresses with the configured host address
  sed -i "s/0\\.0\\.0\\.0/${gNDR_SERVER_HOST_ADDRESS}/g" "$CADDYFILE"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to update Caddyfile [$CADDYFILE] with server host address."
    return 1
  fi

  ndr_logInfo "Caddyfile [$CADDYFILE] updated to use host address [$gNDR_SERVER_HOST_ADDRESS]."
  
  # compose file configuration
  # in secure mode, we want to modify some service port sections to remove the sections and shift those to caddy.
  local COMPOSE_FILE="${gNEXTDR_HOME_DIR}/${NDR_CLIENT_APP_HOME_LOC}/docker-compose.yml"
  
  if [[ ! -f $COMPOSE_FILE ]]; then
    ndr_logError "Docker compose file [$COMPOSE_FILE] not found."
    return 1
  fi

  local services=("$NDR_SERVICE_DOCKER_COMPOSE_SERVICE_NAME" "$NDR_UI_DOCKER_COMPOSE_SERVICE_NAME")

  for service_name in "${services[@]}"; do
    # Remove the entire port section under this service
    local ports_exist
    ports_exist=$(yq eval ".services.\"$service_name\" | has(\"ports\")" "$COMPOSE_FILE")
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logWarn "Failed to determine whether ports section exists for service [$service_name] in compose file."
    fi

    if [ "$ports_exist" == "true" ]; then
      yq eval -i "del(.services.\"$service_name\".ports)" "$COMPOSE_FILE"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logWarn "Failed to remove the ports section for service [$service_name] in compose file."
        return 1
      fi
      ndr_logInfo "Removed the ports section for service [$service_name] in compose file."
    else
      ndr_logInfo "Ports section not present for service [$service_name] in compose file. Skipping removal."
    fi
  done

  local service_name="caddy"
  local port_entry="80:80"

  # Ensure ports section exists
  local ports_exist
  ports_exist=$(yq eval ".services.\"$service_name\" | has(\"ports\")" "$COMPOSE_FILE")
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Failed to determine whether ports section exists for service [$service_name] in compose file."
  fi

  if [ "$ports_exist" != "true" ]; then
    yq eval -i ".services.\"$service_name\".ports = []" "$COMPOSE_FILE"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to create ports section for service [$service_name] in compose file."
      return 1
    fi
    ndr_logInfo "Created ports section for service [$service_name] in compose file."
  fi

  # Add port mapping if missing
  yq eval ".services.\"$service_name\".ports[]" "$COMPOSE_FILE" | grep -qx "$port_entry"
  return_code=$?
  if [ $return_code -eq 0 ]; then
    ndr_logInfo "Port mapping [$port_entry] already exists for service [$service_name], skipping."
  else
    yq eval -i ".services.\"$service_name\".ports += [\"$port_entry\"]" "$COMPOSE_FILE"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to add port mapping [$port_entry] to service [$service_name] in compose file."
      return 1
    fi
    ndr_logInfo "Added port mapping [$port_entry] to service [$service_name] in compose file."
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function <compose_file>
function ndr_CustomizeDockerComposeFileAddBridgeNetwork () 
{
  local logSectionDesc="Customizing Docker compose file to add bridge network"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 1 ]]; then
    ndr_logError "Usage: ndr_CustomizeDockerComposeFileAddBridgeNetwork <compose_file>"
    return 1
  fi

  local COMPOSE_FILE="$1"
  
  if [[ ! -f $COMPOSE_FILE ]]; then
    ndr_logError "Docker compose file [$COMPOSE_FILE] not found."
    return 1
  fi

  # Add the root-level external network if it doesn't exist
  # Check if the network 'ndr_bridge_net' is already defined
  local network_check=$(yq eval ".networks.${NDR_DOCKER_BRIDGE_NETWORK_NAME}" "$COMPOSE_FILE")
  
  # Now check if it's null or empty
  if [[ "$network_check" == "null" || -z "$network_check" ]]; then
    yq eval ".networks.${NDR_DOCKER_BRIDGE_NETWORK_NAME}.external = true" "$COMPOSE_FILE" -i
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to add root-level network '$NDR_DOCKER_BRIDGE_NETWORK_NAME'."
      return 1
    else
      ndr_logInfo "Root-level network '$NDR_DOCKER_BRIDGE_NETWORK_NAME' added."
    fi
  else
    ndr_logInfo "Root-level network '$NDR_DOCKER_BRIDGE_NETWORK_NAME' already exists in compose file."
  fi
  
  # Get list of services
  mapfile -t services < <(yq eval '.services | keys | .[]' "$COMPOSE_FILE")
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to retrieve services from compose file [$COMPOSE_FILE]."
    return 1
  fi

  if [[ ${#services[@]} -eq 0 ]]; then
    echo "No services found in compose file."
    return 1
  fi

  # Iterate over services and add network assignment
  for service_name in "${services[@]}"; do
    local network_type
    network_type=$(yq eval ".services.\"$service_name\".networks | type" "$COMPOSE_FILE")
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to inspect network configuration for service '$service_name'."
      return 1
    fi

    if [[ "$network_type" == "!!null" ]]; then
      # For debugging, do not add the explicit default network here.
      # This lets us confirm whether preserving the implicit default network
      # is what triggers the compose issue during install.
      yq eval ".services.\"$service_name\".networks = [\"$NDR_DOCKER_BRIDGE_NETWORK_NAME\"]" "$COMPOSE_FILE" -i
      return_code=$?
    elif [[ "$network_type" == "!!seq" ]]; then
      yq eval ".services.\"$service_name\".networks[]" "$COMPOSE_FILE" | grep -qx "$NDR_DOCKER_BRIDGE_NETWORK_NAME"
      return_code=$?
      if [ $return_code -eq 0 ]; then
        ndr_logInfo "Service '$service_name' already uses network '$NDR_DOCKER_BRIDGE_NETWORK_NAME', skipping."
        continue
      fi

      yq eval ".services.\"$service_name\".networks += [\"$NDR_DOCKER_BRIDGE_NETWORK_NAME\"]" "$COMPOSE_FILE" -i
      return_code=$?
    elif [[ "$network_type" == "!!map" ]]; then
      local network_exists
      network_exists=$(yq eval ".services.\"$service_name\".networks | has(\"$NDR_DOCKER_BRIDGE_NETWORK_NAME\")" "$COMPOSE_FILE")
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Failed to inspect existing bridge network usage for service '$service_name'."
        return 1
      fi

      if [[ "$network_exists" == "true" ]]; then
        ndr_logInfo "Service '$service_name' already uses network '$NDR_DOCKER_BRIDGE_NETWORK_NAME', skipping."
        continue
      fi

      # Preserve any existing per-network options such as aliases while adding
      # the bridge network as an empty config block.
      yq eval ".services.\"$service_name\".networks.\"$NDR_DOCKER_BRIDGE_NETWORK_NAME\" = {}" "$COMPOSE_FILE" -i
      return_code=$?
    else
      ndr_logError "Unsupported networks type [$network_type] for service '$service_name'."
      return 1
    fi

    if [ $return_code -ne 0 ]; then
      ndr_logError "Error adding network '$NDR_DOCKER_BRIDGE_NETWORK_NAME' to service '$service_name'. Aborting."
      return 1
    else
      ndr_logInfo "Network '$NDR_DOCKER_BRIDGE_NETWORK_NAME' added to service '$service_name' using network type [$network_type]."
    fi
  done

  ndr_logInfo "All services updated successfully in compose file [$COMPOSE_FILE]."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_CreateDockerBindMounts ()
{
  local logSectionDesc="Create Docker Bind Mounts"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 1 ]]; then
    ndr_logError "Usage: ndr_CreateDockerBindMounts <compose_file>"
    return 1
  fi

  local compose_file=$1
  local vol_entry="$gNEXTDR_HOME_DIR:$gNEXTDR_HOME_DIR:rw"

  # Get list of services
  mapfile -t services < <(yq eval '.services | keys | .[]' "$compose_file")
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to retrieve services from compose file [$compose_file]."
    return 1
  fi

  if [[ ${#services[@]} -eq 0 ]]; then
    echo "No services found in compose file."
    return 1
  fi

  # Iterate over services and add volume entry
  for service in "${services[@]}"; do
    # Check if service includes the volume entry
    local has_volumes_section=false
    yq eval ".services.${service}.volumes[]" "$compose_file" | grep -qx "$vol_entry"
    return_code=$?
    if [ $return_code -eq 0 ]; then
      ndr_logInfo "Service '$service' already contains volume entry '$vol_entry'"
      has_volumes_section=true
    fi

    # --- Step 2: Add volumes section if missing ---
    if [ "$has_volumes_section" = false ]; then
      yq eval -i ".services[\"$service\"].volumes = []" "$compose_file"
      return_code=$?
      if [[ $return_code -ne 0 ]]; then
        ndr_logError "Failed to add volumes section for service '$service'"
        return 1
      fi
      ndr_logInfo "Added volumes section for service $service"
    fi

    # --- Step 3: Check if desired entry exists ---
    if yq eval ".services[\"$service\"].volumes[]" "$compose_file" 2>/dev/null | grep -Fxq "$vol_entry"; then
      ndr_logInfo "Volume entry already exists for $service: $vol_entry"
    else
      yq eval -i ".services[\"$service\"].volumes += [\"$vol_entry\"]" "$compose_file"
      return_code=$?
      if [[ $return_code -ne 0 ]]; then
        ndr_logError "Failed to add volume entry for service '$service'"
        return 1
      fi
      ndr_logInfo "Adding volume entry for $service: $vol_entry"
    fi
  done

  ndr_logInfo "Docker bind mounts [$vol_entry] created."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_CleanupModuleEnvFile ()
{
  local logSectionDesc="Cleaning up module environment file"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 1 ]]; then
    ndr_logError "Usage: ndr_CleanupModuleEnvFile <folder>"
    return 1
  fi

  local containerFolder="$1"
  local destEnvFile="${containerFolder}/${gNDR_ENV_TARGET_FILENAME}"

  # Check destination file
  if [[ ! -f "$destEnvFile" ]]; then
    ndr_logError "Destination env file '$destEnvFile' not found."
    return 1
  fi

  # Remove the file
  rm -f "$destEnvFile"
  ndr_logInfo "Module environment file '$destEnvFile' removed."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_InstallHomeCheck ()
{
  local logSectionDesc="$gCOMPANY_NAME install home check"
  ndr_logSecStart "$logSectionDesc"
  
  # if some package is already installed, read from registry. home dir cannot be modified once a package is installed.
  local homeDir=""
  homeDir=$(ndr_getHomeDirReg)
  return_code=$?
  if [[ $return_code -eq 0 && -n "$homeDir" ]]; then
    ndr_logInfo "Found home directory entry [$homeDir] in registry from prior package installation."
    gNEXTDR_HOME_DIR="$homeDir"
    return 0
  fi

  if [ "$gEXPRESS_MODE" == true ]; then
    if [ -z "$gNEXTDR_HOME_DIR" ]; then
      ndr_logError "gNEXTDR_HOME_DIR is not set in express mode. Please set it before proceeding."
      return 1
    fi
    
    # we should also create if it does not exist
    if [ ! -d "$gNEXTDR_HOME_DIR" ]; then
      ndr_logInfo "Creating directory [$gNEXTDR_HOME_DIR] for product and container installation."
      
      mkdir -p "$gNEXTDR_HOME_DIR"
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Failed to create directory [$gNEXTDR_HOME_DIR]. Please check permissions and try again."
        return 1
      fi
    fi

    #ndr_logInfo "Skipping install home check in express mode to directory [$gNEXTDR_HOME_DIR]."
    return 0
  fi

  echo "This will install $gCOMPANY_NAME and its application containers under the directory [default: $gNEXTDR_HOME_DIR]."
  echo "If this is not the desired installation location, please select No and enter the correct location or select quit to return to the main menu."
  
  read -p "Are you sure you want to proceed? (Yes/no/quit) " -n 1 -r
  echo    # Move to a new line
  if [[ $REPLY =~ ^[Qq]$ ]]; then
      ndr_logWarn "Operation cancelled."
      return 1

  elif [[ $REPLY =~ ^[Nn]$ ]]; then

    while true; do
      inputDir=""
      read -r -p "Enter the directory where you want to install the softare package: " inputDir
      if [ -z "$inputDir" ]; then
        ndr_logError "No directory entered. Please enter a valid directory."
        continue;
      fi
      
      confirm=""
      read -r -p "You entered: [$inputDir], is this correct? (Y/n)" confirm
      if [[ "$confirm" =~ ^[Nn]$ ]]; then
        ndr_logInfo "Please re-enter the directory."
        continue
      fi

      if [ ! -d "$inputDir" ]; then
        ndr_logWarn "Directory [$inputDir] does not exist, creating..."
        mkdir -p "$inputDir"
        return_code=$?
        if [ $return_code -ne 0 ]; then
          ndr_logError "Failed to create directory [$inputDir]. Please check permissions and try again."
          continue
        fi
        ndr_logInfo "Directory [$inputDir] created successfully."
      fi

      # Check if the directory is writable
      if [ ! -w "$inputDir" ]; then
        ndr_logError "Directory [$inputDir] is not writable. Please choose a different directory."
        continue
      fi

      # If we reach here, the directory is valid and writable
      ndr_logInfo "Using directory [$inputDir] for $gCOMPANY_NAME installation."
      gNEXTDR_HOME_DIR="$inputDir"
      
      break
    done
  else

    if [ ! -d "$gNEXTDR_HOME_DIR" ]; then
      ndr_logWarn "Directory [$gNEXTDR_HOME_DIR] does not exist, creating..."
      mkdir -p "$gNEXTDR_HOME_DIR"
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Failed to create directory [$gNEXTDR_HOME_DIR]. Please check permissions and try again."
        return 1
      fi
      ndr_logInfo "Directory [$gNEXTDR_HOME_DIR] created successfully."
    fi

    # Check if the directory is writable
    if [ ! -w "$gNEXTDR_HOME_DIR" ]; then
      ndr_logError "Directory [$gNEXTDR_HOME_DIR] is not writable. Please choose a different directory."
      return 1
    fi

    # If we reach here, the directory is valid and writable
    ndr_logInfo "Using directory [$gNEXTDR_HOME_DIR] for $gCOMPANY_NAME installation."

  fi
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_CreateApplicationFolders ()
{
  local logSectionDesc="Creating Application Folders"
  ndr_logSecStart "$logSectionDesc"

  # array of folders to create
  local foldersToCreate=()
  foldersToCreate+=("${gNEXTDR_HOME_DIR}/${NDR_CLIENT_APP_HOME_LOC}")

  if [[ "$NDR_CADDY_ENABLED" == true ]]; then
    foldersToCreate+=("${gNEXTDR_HOME_DIR}/${NDR_CADDY_HOME_LOC}")
    foldersToCreate+=("${gNEXTDR_HOME_DIR}/${NDR_CADDY_CONFIG_LOC}")
    foldersToCreate+=("${gNEXTDR_HOME_DIR}/${NDR_CADDY_DATA_LOC}")
  fi

  for folder in "${foldersToCreate[@]}"; do
    ndr_logInfo "Creating application folder [$folder]..."
    if [ ! -d "$folder" ]; then
      mkdir -p "$folder"
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Failed to create directory [$folder]. Please check permissions and try again."
        return 1
      fi
      ndr_logInfo "Created directory [$folder]."
    else
      ndr_logInfo "Directory [$folder] already exists."
    fi
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_CleanupApplicationFolders ()
{
  local logSectionDesc="Cleaning up application folders"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: ndr_CleanupApplicationFolders <application_folder>"
    return 1
  fi

  local applicationFolder=$1

  # remove this applications specific home dir
  local applicationHomeDir="${gNEXTDR_HOME_DIR}/${applicationFolder}"
  if [[ ! -d "$applicationHomeDir" ]]; then
    ndr_logInfo "Application home dir [$applicationHomeDir] does not exist, nothing to remove."
  else
    rm -rf "$applicationHomeDir"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to remove application home dir [$applicationHomeDir]"
      return 1
    else
      ndr_logInfo "Removed application home dir [$applicationHomeDir]"
    fi
  fi

  # if all applications are being removed, then also remove the company home dir
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
  local dbInstalled=$?
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_CLIENT_NAME"
  local clientInstalled=$?
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SERVICE_NAME"
  local svcInstalled=$?
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_UI_NAME"
  local uiInstalled=$?

  while true; do
    # if all modules are not installed, then remove the company home dir
    if [[ "$dbInstalled" -eq 0 || "$svcInstalled" -eq 0 || "$uiInstalled" -eq 0 || "$clientInstalled" -eq 0 ]]; then
      ndr_logInfo "Not removing company home dir [$gNEXTDR_HOME_DIR] since some modules are still installed."
      break;
    fi
    ndr_logInfo "All modules are uninstalled, removing company home dir [$gNEXTDR_HOME_DIR]."

    if [[ ! -d "$gNEXTDR_HOME_DIR" ]]; then
      ndr_logInfo "Company home dir [$gNEXTDR_HOME_DIR] does not exist, nothing to remove."
      break
    fi

    # check for a docker local registry folder
    if [[ -d "$gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR" ]]; then
      ndr_logInfo "Docker registry dir [$gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR] found, skipping removal of company home dir [$gNEXTDR_HOME_DIR]. Please uninstall the local docker registry before removing the company home dir."
      break
    fi

    # remove the company home dir
    rm -rf "$gNEXTDR_HOME_DIR"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to remove company home dir [$gNEXTDR_HOME_DIR]"
      break
    fi
      
    ndr_logInfo "Removed company home dir [$gNEXTDR_HOME_DIR]"
    break
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_BackupHomeDirectory ()
{
  local logSectionDesc="Backing up home directory"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 1 || $# -gt 2 ]]; then
    ndr_logError "Usage: function <staging_folder>"
    return 1
  fi

  local staging_folder="$1"
  
  if [[ -z "$gNEXTDR_HOME_DIR" ]]; then
    gNEXTDR_HOME_DIR=$(ndr_getHomeDirReg)
  fi
  if [[ -z "$gSUPABASE_NEXTDR_HOME" ]]; then
    gSUPABASE_NEXTDR_HOME="${gNEXTDR_HOME_DIR}/${gSUPABASE_NEXTDR_SUB}"
  fi

  local backup_folder="${staging_folder}/${gNDR_APP_BACKUP_HOME_DIR_SUB}"
  if [[ ! -d "$backup_folder" ]]; then
    mkdir -p "$backup_folder"
  fi

  local source_dir="${gNEXTDR_HOME_DIR%/}"
  local source_name
  source_name=$(basename "$source_dir")

  local exclude_subdir="$gSUPABASE_NEXTDR_HOME/volumes/db/data"
  
  if [[ -n "$exclude_subdir" && -e "$exclude_subdir" ]]; then
    ndr_logInfo "Excluding home directory subfolder [$exclude_subdir] from backup."
    local exclude_pattern="${exclude_subdir%/}"
    if [[ "$exclude_pattern" == "$source_dir/"* ]]; then
      exclude_pattern="${exclude_pattern#"$source_dir/"}"
    fi

    mkdir -p "${backup_folder}/${source_name}"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to create application home backup folder [${backup_folder}/${source_name}]"
      return 1
    fi

    rsync -a --exclude="/${exclude_pattern%/}/" "$source_dir/" "${backup_folder}/${source_name}/"
    return_code=$?
  else
    cp -rf "$source_dir" "$backup_folder"
    return_code=$?
  fi

  if [ $return_code != 0 ]; then
    ndr_logError "Failed to backup application home dir to [$backup_folder]"
    return 1
  fi
  ndr_logInfo "Backed up application home dir to [$backup_folder]"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_RestoreHomeDirectory ()
{
  local logSectionDesc="Restoring home directory"
  ndr_logSecStart "$logSectionDesc"

  # Restore expects the staged home_dir component folder from the backup manifest.
  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <home_backup_folder>"
    return 1
  fi

  local backup_folder="$1"
  if [[ ! -d "$backup_folder" ]]; then
    ndr_logError "Home directory backup folder not found [$backup_folder]."
    return 1
  fi

  # Prefer the configured home dir, but fall back to the registry when restore
  # is running before install globals have been fully hydrated.
  if [[ -z "$gNEXTDR_HOME_DIR" ]]; then
    gNEXTDR_HOME_DIR=$(ndr_getHomeDirReg)
  fi
  if [[ -z "$gNEXTDR_HOME_DIR" ]]; then
    ndr_logError "Unable to determine restore home directory."
    return 1
  fi

  local restore_parent
  restore_parent=$(dirname "${gNEXTDR_HOME_DIR%/}")
  local restore_name
  restore_name=$(basename "${gNEXTDR_HOME_DIR%/}")
  local source_dir="${backup_folder}/${restore_name}"

  # ndr_BackupHomeDirectory stores the home copy under home_dir/<home-basename>.
  # If the target basename differs, accept a single directory in the component
  # folder as the source to support restoring to an alternate home path.
  if [[ ! -d "$source_dir" ]]; then
    local -a backup_entries=()
    mapfile -t backup_entries < <(find "$backup_folder" -mindepth 1 -maxdepth 1 -type d -print)
    if [[ ${#backup_entries[@]} -eq 1 ]]; then
      source_dir="${backup_entries[0]}"
    else
      ndr_logError "Unable to identify home directory backup source in [$backup_folder]."
      return 1
    fi
  fi

  # Ensure the destination exists before syncing files into it.
  mkdir -p "$restore_parent" "$gNEXTDR_HOME_DIR"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create restore home directory [$gNEXTDR_HOME_DIR]."
    return 1
  fi

  # Overlay the backup contents into the home directory. The home backup may
  # intentionally exclude database volume data, so do not delete extra files.
  rsync -a "$source_dir/" "${gNEXTDR_HOME_DIR%/}/"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to restore home directory from [$source_dir] to [$gNEXTDR_HOME_DIR]."
    return 1
  fi

  # Keep the derived Supabase home global aligned for later restore steps.
  if [[ -z "$gSUPABASE_NEXTDR_HOME" ]]; then
    gSUPABASE_NEXTDR_HOME="${gNEXTDR_HOME_DIR}/${gSUPABASE_NEXTDR_SUB}"
  fi

  ndr_logInfo "Restored home directory from [$source_dir] to [$gNEXTDR_HOME_DIR]."
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_BackupRegistryData ()
{
  local logSectionDesc="Backing up registry data"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <staging_folder>"
    return 1
  fi

  local staging_folder="$1"
  
  local backup_folder="${staging_folder}/${gNDR_APP_BACKUP_REGISTRY_SUB}"
  if [[ ! -d "$backup_folder" ]]; then
    mkdir -p "$backup_folder"
  fi

  # ----------------------------------------------------------------
  # backup the ndr registry
  local registry_backup_file="$backup_folder/$gREGISTRY_FILENAME"
  cp -p "$gREGISTRY_FILE" "$registry_backup_file"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Backup of NDR registry file failed."
    return 1
  fi
  echo "Backup of NDR registry file completed successfully: $registry_backup_file"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_RestoreRegistryData ()
{
  local logSectionDesc="Restoring registry data"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <registry_backup_folder>"
    return 1
  fi

  local backup_folder="$1"
  local registry_backup_file="${backup_folder}/${gREGISTRY_FILENAME}"

  if [[ ! -f "$registry_backup_file" ]]; then
    ndr_logError "Registry backup file not found [$registry_backup_file]."
    return 1
  fi

  local registry_dir
  registry_dir=$(dirname "$gREGISTRY_FILE")
  if [[ ! -d "$registry_dir" ]]; then
    ndr_logInfo "Registry directory [$registry_dir] does not exist, creating..."
  
    mkdir -p "$registry_dir"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to create registry directory [$registry_dir]."
      return 1
    fi
    ndr_logInfo "Registry directory [$registry_dir] created successfully."
  fi

  # clean existing registry file before restore to ensure removed entries are properly cleaned up, then copy the backup over.
  if [[ -f "$gREGISTRY_FILE" ]]; then
    rm -f "$gREGISTRY_FILE"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logWarn "Failed to remove existing registry file [$gREGISTRY_FILE] before restore."
      #return 1
    else
      ndr_logInfo "Removed existing registry file [$gREGISTRY_FILE] before restore."
    fi
  fi

  cp -p "$registry_backup_file" "$gREGISTRY_FILE"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Restore of NDR registry file failed."
    return 1
  fi
  ndr_logInfo "Restore of NDR registry file completed successfully: $gREGISTRY_FILE"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# produces a backup of the entire NDR application and all its consituent parts and stores into a tar file.
# backup includes db schema, db volume data, registry file, and home dir with the following structure:
# backup-ndr-<timestamp>/
#   db_schema/
#   db_data/
#   registry/
#   home_dir/
# usage: ndr_BackupApplication [options]
function ndr_BackupApplication ()
{
  local logSectionDesc="Backing up application data and configuration"
  ndr_logSecStart "$logSectionDesc"

  if [[ "$gNDR_APP_BACKUP_SKIP" == true ]]; then
    ndr_logInfo "Option to skip application backup is enabled."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  local options="${1:-$gNDR_APP_BACKUP_RESTORE_OPTIONS_ALL_MODULES}"

  ndr_isAnyModuleInstalledReg
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "No modules are currently installed, skipping application backup."
    return 0
  fi

  ndr_logInfo "Starting application backup with options [$options]..."

  local timestamp=$(date +"%Y%m%d_%H%M%S")
  if [[ -z "$gNDR_APP_BACKUP_NAME" ]]; then
    gNDR_APP_BACKUP_NAME="NDR-app-bkp_v${gINSTALLED_VERSION}_${timestamp}"
  fi
  local staging_root="${gNDR_APP_BACKUP_DIR}/${gNDR_APP_BACKUP_STAGING_SUB}/${gNDR_APP_BACKUP_NAME}"
  
  gNDR_APP_BACKUP_FILE="${gNDR_APP_BACKUP_DIR}/${gNDR_APP_BACKUP_NAME}.tar.gz"
  
  mkdir -p "$staging_root"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create backup staging directory [$staging_root]."
    return 1
  fi

  # ----------------------------------------------------------------
  # backup each component.

  if (( options & gNDR_APP_BACKUP_RESTORE_OPTIONS_DB )); then
    ndr_logInfo "Backing up database schema..."
    ndr_BackupPostgresDB "$staging_root" "$options"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to backup database schema."
      return 1
    fi
  fi

  if (( options & gNDR_APP_BACKUP_RESTORE_OPTIONS_REGISTRY )); then
    ndr_logInfo "Backing up registry data..."
    ndr_BackupRegistryData "$staging_root"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to backup registry data."
      return 1
    fi
  fi

  if (( options & gNDR_APP_BACKUP_RESTORE_OPTIONS_HOME_DIR )); then
    ndr_logInfo "Backing up home directory..."
    ndr_BackupHomeDirectory "$staging_root"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to backup home directory."
      return 1
    fi
  fi

  # ----------------------------------------------------------------
  # create manifest file with metadata about the backup and instructions for restore, then archive everything together.

  local manifest_file="${staging_root}/manifest.json"

  local created_at_utc
  created_at_utc=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
  local backup_host
  backup_host=$(hostname 2>/dev/null || echo "unknown")
  local -a manifest_items=()

  if (( options & gNDR_APP_BACKUP_RESTORE_OPTIONS_DB )); then
    manifest_items+=('    {"id":"db_schema","description":"Supabase/Postgres schema backup","path":"'"$gNDR_APP_BACKUP_DB_SCHEMA_SUB"'"}')
    manifest_items+=('    {"id":"db_data","description":"Supabase/Postgres data backup","path":"'"$gNDR_APP_BACKUP_DB_DATA_SUB"'"}')
    manifest_items+=('    {"id":"db_keys","description":"Supabase/Postgres encryption keys backup","path":"'"$gNDR_APP_BACKUP_DB_KEYS_SUB"'"}')
  fi
  if (( options & gNDR_APP_BACKUP_RESTORE_OPTIONS_REGISTRY )); then
    manifest_items+=('    {"id":"registry","description":"NextDR registry backup","path":"'"$gNDR_APP_BACKUP_REGISTRY_SUB"'"}')
  fi
  if (( options & gNDR_APP_BACKUP_RESTORE_OPTIONS_HOME_DIR )); then
    manifest_items+=('    {"id":"home_dir","description":"NextDR home directory backup","path":"'"$gNDR_APP_BACKUP_HOME_DIR_SUB"'"}')
  fi

  # use installed version sincea different version of this script could be used to generate the backup, and the manifest should reflect the version of the product that was backed up for compatibility during restore
  local version=$(ndr_getVersionReg)
  if [[ -z "$version" ]]; then
    # fall back to script version.
    version="$gPRODUCT_VERSION"
  fi

  {
    printf '{\n'
    printf '  "manifest_version": 1,\n'
    printf '  "product": "%s",\n' "$gPRODUCT_NAME"
    printf '  "product_version": "%s",\n' "$version"
    printf '  "backup_name": "%s",\n' "$gNDR_APP_BACKUP_NAME"
    printf '  "created_at_utc": "%s",\n' "$created_at_utc"
    printf '  "host": "%s",\n' "$backup_host"
    printf '  "options": "%s",\n' "$options"
    printf '  "included": [\n'
    local i
    for (( i=0; i<${#manifest_items[@]}; i++ )); do
      if (( i + 1 < ${#manifest_items[@]} )); then
        printf '%s,\n' "${manifest_items[$i]}"
      else
        printf '%s\n' "${manifest_items[$i]}"
      fi
    done
    printf '  ]\n'
    printf '}\n'
  } > "$manifest_file"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create backup manifest [$manifest_file]."
    return 1
  fi
  ndr_logInfo "Created backup manifest [$manifest_file]."
  
  # ----------------------------------------------------------------
  # create archive of the backup staging folder
  tar -czf "$gNDR_APP_BACKUP_FILE" -C "$gNDR_APP_BACKUP_DIR/$gNDR_APP_BACKUP_STAGING_SUB" "$gNDR_APP_BACKUP_NAME"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create backup archive [$gNDR_APP_BACKUP_FILE]."
    return 1
  fi
  ndr_logInfo "Created backup archive [$gNDR_APP_BACKUP_FILE]."

  # ----------------------------------------------------------------
  # clean up the staging folder after successful archive creation
  rm -rf "$staging_root"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logWarn "Failed to clean up backup staging folder [$staging_root]. Please check permissions and remove manually."
  fi
  ndr_logInfo "Cleaned up backup staging folder [$staging_root]."
  gNDR_APP_BACKUP_NAME=""

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_RestoreApplication ()
{
  # Top-level logging for the restore operation; used to group output
  local logSectionDesc="Restoring application from backup archive"
  ndr_logSecStart "$logSectionDesc"

  # Restore options: caller may pass a bitmask to control which components
  # are restored (DB, registry, home dir, etc.). Default to restoring all.
  local options="${1:-$gNDR_APP_BACKUP_RESTORE_OPTIONS_ALL_MODULES}"
  
  ndr_logInfo "Restore options: [$options]"

  local installation_present=true
  ndr_isAnyModuleInstalledReg
  return_code=$?
  if [ $return_code -ne 0 ]; then
    installation_present=false
    ndr_logWarn "No modules are currently installed, will addtionally perform a docker entity restore."
    options=$((options | gNDR_APP_BACKUP_RESTORE_OPTIONS_RESTORE_DOCKER_ENTITIES))
  fi

  # ----------------------------------------------------------------
  # Confirm the restore with the user unless we're in express (non-interactive)
  # mode. Restores are destructive (overwrite existing data), so require
  # explicit confirmation by default.
  if [ "$gEXPRESS_MODE" == false ]; then
    echo "WARNING: Restoring from backup will overwrite any existing application data and configuration."
    read -r -p "Are you sure you want to continue with restore? (y/N) " confirm_restore
    if [[ ! "$confirm_restore" =~ ^[Yy]([Ee][Ss])?$ ]]; then
      ndr_logWarn "Restore operation cancelled."
      ndr_logSecEnd "$logSectionDesc"
      return 1
    fi
  fi

  # ----------------------------------------------------------------
  # Validate cached archive path (if present). If it doesn't exist, clear
  # `gNDR_APP_BACKUP_FILE` so the interactive selection below will run.
  if [[ -n "$gNDR_APP_BACKUP_FILE" && ! -f "$gNDR_APP_BACKUP_FILE" ]]; then
    ndr_logWarn "Cached restore archive file [$gNDR_APP_BACKUP_FILE] was not found."
    gNDR_APP_BACKUP_FILE=""
  fi

  # If an archive file is set and present, use it; otherwise locate available
  # archive files in the backup directory and prompt the user to choose one.
  if [[ -n "$gNDR_APP_BACKUP_FILE" && -f "$gNDR_APP_BACKUP_FILE" ]]; then
    ndr_logInfo "Using cached restore archive file [$gNDR_APP_BACKUP_FILE]."
  else
    ndr_logInfo "No cached restore archive file found, searching backup directory for available archives..."

    # Find .tar.gz archives in the backup dir, newest first.
    local backup_archives=()
    mapfile -t backup_archives < <(find "$gNDR_APP_BACKUP_DIR" -maxdepth 1 -type f -name "*.tar.gz" -printf "%T@ %p\n" 2>/dev/null | sort -nr | cut -d' ' -f2-)

    if [[ ${#backup_archives[@]} -eq 0 ]]; then
      ndr_logError "No backup archives found in backup directory [$gNDR_APP_BACKUP_DIR]."
      ndr_logSecEnd "$logSectionDesc"
      return 1
    fi

    # Present choices to the user and read selection.
    echo "Available backup archives:"
    local archive_index=1
    local archive_basename
    for archive_file in "${backup_archives[@]}"; do
      archive_basename=$(basename "$archive_file")
      echo "  ${archive_index}. ${archive_basename}"
      ((archive_index++))
    done
    echo "  q. Exit/Abort"

    local selected_archive=""
    local archive_choice=""
    while [[ -z "$selected_archive" ]]; do
      read -r -p "Select backup archive to restore [1-${#backup_archives[@]}/q]: " archive_choice
      case "$archive_choice" in
        q|Q)
          ndr_logWarn "Restore operation cancelled."
          ndr_logSecEnd "$logSectionDesc"
          return 1
          ;;
        ''|*[!0-9]*)
          ndr_logWarn "Invalid selection [$archive_choice], please enter a number from 1 to ${#backup_archives[@]} or q to abort."
          ;;
        *)
          if (( archive_choice >= 1 && archive_choice <= ${#backup_archives[@]} )); then
            selected_archive="${backup_archives[$((archive_choice - 1))]}"
          else
            ndr_logWarn "Invalid selection [$archive_choice], please enter a number from 1 to ${#backup_archives[@]} or q to abort."
          fi
          ;;
      esac
    done
    
    gNDR_APP_BACKUP_FILE="$selected_archive"
  fi

  ndr_logInfo "Selected restore archive file [$gNDR_APP_BACKUP_FILE]."

  # ----------------------------------------------------------------
  # Prepare a staging area for extraction. The archive name (without
  # .tar.gz) is used as the staging folder name so multiple archives can be
  # staged independently.
  gNDR_APP_BACKUP_NAME="$(basename "$gNDR_APP_BACKUP_FILE" .tar.gz)"

  local staging_root="${gNDR_APP_BACKUP_DIR}/${gNDR_APP_BACKUP_STAGING_SUB}/${gNDR_APP_BACKUP_NAME}"

  # if staging root already exists from a prior restore attempt, remove it to ensure a clean restore environment. This prevents issues where files from a prior failed restore could interfere with the current restore attempt.
  if [[ -d "$staging_root" ]]; then
    ndr_logWarn "Staging directory [$staging_root] already exists from a prior restore attempt, removing to ensure a clean restore environment."
    rm -rf "$staging_root"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to remove existing staging directory [$staging_root]. Please check permissions and remove manually before attempting restore again."
      return 1
    fi
    ndr_logInfo "Removed existing staging directory [$staging_root]."
  fi

  mkdir -p "$staging_root"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create backup staging directory [$staging_root]."
    return 1
  fi
  ndr_logInfo "Created backup staging directory [$staging_root]."

  # Extract the archive into the staging parent directory so the expected
  # internal layout (including manifest.json) is preserved.
  local staging_parent="${gNDR_APP_BACKUP_DIR}/${gNDR_APP_BACKUP_STAGING_SUB}"
  ndr_logInfo "Extracting restore archive [$gNDR_APP_BACKUP_FILE] to staging location [$staging_parent]."
  tar -xzf "$gNDR_APP_BACKUP_FILE" -C "$staging_parent"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to extract restore archive [$gNDR_APP_BACKUP_FILE] to [$staging_parent]."
    return 1
  fi

  # The restore manifest must exist and contain an `included` array describing
  # components that were backed up and their restore order/paths.
  local manifest_file="${staging_root}/manifest.json"
  if [[ ! -f "$manifest_file" ]]; then
    ndr_logError "Backup manifest file not found in restore staging directory [$manifest_file]."
    return 1
  fi

  jq -e '.included and (.included | type == "array")' "$manifest_file" >/dev/null
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Backup manifest is invalid or missing included component metadata [$manifest_file]."
    return 1
  fi

  # ----------------------------------------------------------------
  # read manifest version and compare to installed version.
  local installed_version="$gREGISTRY_ENTRY_MODULE_STATUS_NOT_INSTALLED"
  if [[ "$installation_present" == true ]]; then
    installed_version=$(ndr_getVersionReg)
    if [[ $? -ne 0 || -z "$installed_version" ]]; then
      ndr_logError "Unable to determine installed product version from registry for restore compatibility check."
      return 1
    fi
  fi

  local manifest_version="$gREGISTRY_ENTRY_MODULE_STATUS_NOT_INSTALLED"
  manifest_version=$(jq -r '.product_version' "$manifest_file")
  if [[ -z "$manifest_version" ]]; then
    ndr_logError "Backup manifest is missing product_version field [$manifest_file]."
    return 1
  fi

  if [[ "$manifest_version" != "$installed_version" ]]; then
    ndr_logWarn "Backup manifest version [$manifest_version] in [$manifest_file] does not match installed version [$installed_version]. Will additionally perform a docker entity restore."
    options=$(( options | gNDR_APP_BACKUP_RESTORE_OPTIONS_RESTORE_DOCKER_ENTITIES ))
  fi

  ndr_logInfo "Installed version [$installed_version] will be overritten by backup manifest version [$manifest_version]."

  # ----------------------------------------------------------------
  # Read manifest `included` entries without trusting any restore-order that
  # may have been recorded at backup time. The restore ordering is decided
  # here at restore time according to the predefined sequence below.
  local -a manifest_restore_entries=()
  mapfile -t manifest_restore_entries < <(
    jq -r '
      .included
      | .[]
      | [.id, (.path // "")]
      | @tsv
    ' "$manifest_file"
  )

  # Map component ids to their staged paths (if present and requested).
  local registry_path=""
  local home_dir_path=""
  local db_data_path=""
  local db_keys_path=""
  local db_schema_path=""
  local restore_bitmask=0
  local manifest_entry component_id component_path component_mask

  for manifest_entry in "${manifest_restore_entries[@]}"; do
    IFS=$'\t' read -r component_id component_path <<< "$manifest_entry"

    case "$component_id" in
      registry)
        component_mask=$gNDR_APP_BACKUP_RESTORE_OPTIONS_REGISTRY
        ;;
      home_dir)
        component_mask=$gNDR_APP_BACKUP_RESTORE_OPTIONS_HOME_DIR
        ;;
      db_data)
        component_mask=$gNDR_APP_BACKUP_RESTORE_OPTIONS_DB
        ;;
      db_keys)
        component_mask=$gNDR_APP_BACKUP_RESTORE_OPTIONS_DB
        ;;
      db_schema)
        # unused for now.
        ;;
      *)
        ndr_logWarn "Skipping unknown backup component [$component_id] from manifest [$manifest_file]."
        continue
        ;;
    esac

    # Respect the caller's restore options bitmask; skip if not requested.
    if ! (( options & component_mask )); then
      ndr_logInfo "Skipping backup component [$component_id] because it was not requested by restore options [$options]."
      continue
    fi

    # Ensure the component payload exists in the staging area.
    if [[ -z "$component_path" || ! -e "${staging_root}/${component_path}" ]]; then
      ndr_logError "Backup component [$component_id] path is missing from staging directory [${staging_root}/${component_path}]."
      return 1
    fi

    restore_bitmask=$(( restore_bitmask | component_mask ))
    case "$component_id" in
      registry)
        registry_path="${staging_root}/${component_path}"
        ndr_logInfo "Found registry component at [$registry_path]."
        ;;
      home_dir)
        home_dir_path="${staging_root}/${component_path}"
        ndr_logInfo "Found home_dir component at [$home_dir_path]."
        ;;
      db_data)
        db_data_path="${staging_root}/${component_path}"
        ndr_logInfo "Found db_data component at [$db_data_path]."
        ;;
      db_keys)
        db_keys_path="${staging_root}/${component_path}"
        ndr_logInfo "Found db_keys component at [$db_keys_path]."
        ;;
    esac
  done

  if [[ -z "$registry_path" && -z "$home_dir_path" && -z "$db_data_path" && -z "$db_keys_path" ]]; then
    ndr_logError "No requested restore components were found in backup manifest [$manifest_file]."
    return 1
  fi
  ndr_logInfo "Prepared restore plan with bitmask [$restore_bitmask] from manifest [$manifest_file]."

  # ---------------------------------------------------------------- 
  # setup essential home dirs and globals that may be needed during restore actions.

  if [[ -z "$gNEXTDR_HOME_DIR" ]]; then
    gNEXTDR_HOME_DIR=$(ndr_getHomeDirReg)
  fi
  if [[ -z "$gSUPABASE_NEXTDR_HOME" ]]; then
    gSUPABASE_NEXTDR_HOME="${gNEXTDR_HOME_DIR}/${gSUPABASE_NEXTDR_SUB}"
  fi

  # ----------------------------------------------------------------
  # stop all services before restoring any data to ensure files are not in use and to prevent conflicts between running services and the restore operation.
  ndr_logInfo "Stopping all services before restore..."
  
  local service_options="$gNDR_DOCKER_SERVICE_CONTROL_STOP"
  if (( options & gNDR_APP_BACKUP_RESTORE_OPTIONS_RESTORE_DOCKER_ENTITIES )); then
    ndr_logInfo "Cleaning up Docker images and containers before restore."
    service_options=$(( service_options | gNDR_DOCKER_SERVICE_CONTROL_REMOVE ))
  fi

  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_CLIENT_NAME"
  local clientInstalled=$?
  if [[ "$clientInstalled" -eq 0 ]]; then  
    ndr_StopClientDockerServices "$service_options"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to stop client Docker services before restore."
      return 1
    fi
  fi

  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
  local dbInstalled=$?
  if [[ "$dbInstalled" -eq 0 ]]; then
    if (( restore_bitmask & gNDR_APP_BACKUP_RESTORE_OPTIONS_DB )); then
      ndr_logInfo "Stopping database services before restore."
      ndr_StopSupabaseDockerServices "$service_options"
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Failed to stop database services before restore."
        return 1
      fi
    fi
  fi

  # ----------------------------------------------------------------
  # Execute restore actions in the canonical, predefined sequence. This
  # guarantees consistent restore ordering regardless of what was recorded
  # in the backup manifest.

  # 1) Registry
  if [[ -n "$registry_path" ]]; then
    ndr_logInfo "Restoring registry data..."
    ndr_RestoreRegistryData "$registry_path"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to restore registry data."
      return 1
    fi
  fi

  # update application status from restored registry.
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
  dbInstalled=$?
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_CLIENT_NAME"
  clientInstalled=$?

  # 2) Home directory
  if [[ -n "$home_dir_path" ]]; then
    ndr_logInfo "Restoring home directory..."
    ndr_RestoreHomeDirectory "$home_dir_path"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to restore home directory."
      return 1
    fi
  fi

  # 3) Database data
  if [[ -n "$db_data_path" ]]; then
    ndr_logInfo "Restoring database data..."
    ndr_RestorePostgresDB "$db_data_path"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to restore database data."
      return 1
    fi
  fi

  # If we are restoring Docker entities, then before doing database keys, we need to ensure the docker images are at least present.
  if (( options & gNDR_APP_BACKUP_RESTORE_OPTIONS_RESTORE_DOCKER_ENTITIES )); then
    if [[ "$dbInstalled" -eq 0 ]]; then
      if (( restore_bitmask & gNDR_APP_BACKUP_RESTORE_OPTIONS_DB )); then
        ndr_logInfo "Restoring database images..."
    
        service_options="$gNDR_DOCKER_SERVICE_CONTROL_PULL"
        ndr_StartSupabaseDockerServices "$service_options"
        return_code=$?
        if [ $return_code -ne 0 ]; then
          ndr_logError "Failed to pull database images."
          return 1
        fi

        # and recreate network
        ndr_createDockerBridgeNetwork
        return_code=$?
        if [ $return_code -ne 0 ]; then
          ndr_logError "Failed to create Docker bridge network."
          return 1
        fi
      fi
    fi
  fi

  # 4) Database keys
  if [[ -n "$db_keys_path" ]]; then
    ndr_logInfo "Restoring database keys..."
    ndr_RestorePostgresEncryptionKey "$db_keys_path"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logWarn "Automatic restore of DB keys failed; you may need to restore keys manually from [$db_keys_path]."
    fi
  fi

  # ----------------------------------------------------------------
  # restart services after restore to ensure the application is running with the restored data and configuration.
  ndr_logInfo "Starting all services after restore..."

  service_options="$gNDR_DOCKER_SERVICE_CONTROL_START"
  if (( options & gNDR_APP_BACKUP_RESTORE_OPTIONS_RESTORE_DOCKER_ENTITIES )); then
    ndr_logInfo "Pulling and composing Docker images and containers afterrestore."
    service_options="$gNDR_DOCKER_SERVICE_CONTROL_PULL_AND_COMPOSE"
  fi

  if [[ "$dbInstalled" -eq 0 ]]; then
    if (( restore_bitmask & gNDR_APP_BACKUP_RESTORE_OPTIONS_DB )); then
      ndr_logInfo "Starting database services after restore."
      ndr_StartSupabaseDockerServices "$service_options"
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Failed to start database services after restore."
        return 1
      fi
    fi
  fi

  if [[ "$clientInstalled" -eq 0 ]]; then  
    ndr_logInfo "Starting client Docker services after restore."
    ndr_StartClientDockerServices "$service_options"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to start client Docker services after restore."
      return 1
    fi
  fi

  ndr_logInfo "All services started successfully after restore."

  # ----------------------------------------------------------------
  # cleanup and finish

  ndr_logInfo "Cleaning up restore staging folder [$staging_root]."
  rm -rf "$staging_root"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logWarn "Failed to clean up restore staging folder [$staging_root]. Please check permissions and remove manually."
  fi

  ndr_logInfo "Restore operation completed successfully for [$gNDR_APP_BACKUP_NAME]."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# docker service control commands for start/stop/pull/compose/remove functions.
export gNDR_DOCKER_SERVICE_CONTROL_START=0x1
export gNDR_DOCKER_SERVICE_CONTROL_PULL=0x2
export gNDR_DOCKER_SERVICE_CONTROL_COMPOSE=0x4
export gNDR_DOCKER_SERVICE_CONTROL_PULL_AND_COMPOSE=$(( gNDR_DOCKER_SERVICE_CONTROL_PULL | gNDR_DOCKER_SERVICE_CONTROL_COMPOSE ))
export gNDR_DOCKER_SERVICE_CONTROL_STOP=0x10
export gNDR_DOCKER_SERVICE_CONTROL_REMOVE=0x20

# usage: ndr_StopClientDockerServices [options]
function ndr_StopClientDockerServices ()
{
  # bring the containers down.
  local logSectionDesc="Stopping client Docker Service Containers"
  ndr_logSecStart "$logSectionDesc"
  
  local options="${1:-$gNDR_DOCKER_SERVICE_CONTROL_STOP}"

  local app_home=""

  if (( options & gNDR_DOCKER_SERVICE_CONTROL_REMOVE )); then
    ndr_logInfo "Option specified to remove Docker images and containers."
  else
    ndr_logInfo "No remove option specified, stopping containers."
  fi

  # if client not installed, then skip
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_CLIENT_NAME"
  local clientInstalled=$?
  if [ $clientInstalled -ne 0 ]; then
    ndr_logInfo "Client module is not installed, skipping stop of client Docker services."
  fi
  
  ndr_logInfo "Stopping Docker services."
  local app_home="${gNEXTDR_HOME_DIR}/${NDR_CLIENT_APP_HOME_LOC}"

  cd "$app_home" || { ndr_logError "Failed to cd into application dir [$app_home]"; return 1; }
  
  if (( options & gNDR_DOCKER_SERVICE_CONTROL_STOP )); then
    docker compose stop
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logInfo "Failed to stop Docker Container services"
      return 1
    fi
  
    ndr_logInfo "Stopped Docker container services successfully."
  fi

  if (( options & gNDR_DOCKER_SERVICE_CONTROL_REMOVE )); then
    ndr_logInfo "Option specified to remove Docker images and containers."

    docker compose down -v --rmi all --remove-orphans
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logInfo "Failed to remove Docker Containers and images"
      return 1
    fi
    ndr_logInfo "Removed Docker containers and images successfully."
  fi
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: ndr_StartClientDockerServices [options]
function ndr_StartClientDockerServices ()
{
  # bring the containers up.
  local logSectionDesc="Starting client Docker Service Containers"
  ndr_logSecStart "$logSectionDesc"
  
  local options="${1:-$gNDR_DOCKER_SERVICE_CONTROL_START}" 

  local app_home=""

  if (( options & gNDR_DOCKER_SERVICE_CONTROL_PULL_AND_COMPOSE )); then
    ndr_logInfo "Option specified to pull Docker images and compose containers."
  else
    ndr_logInfo "No pull/compose option specified, starting existing containers."
  fi

  # if client not installed, then skip
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_CLIENT_NAME"
  local clientInstalled=$?
  if [ $clientInstalled -ne 0 ]; then
    ndr_logInfo "Client module is not installed, skipping start of client Docker services."
  fi
    
  ndr_logInfo "Starting Docker services."
  local app_home="${gNEXTDR_HOME_DIR}/${NDR_CLIENT_APP_HOME_LOC}"

  cd "$app_home" || { ndr_logError "Failed to cd into application dir [$app_home]"; return 1; }
  
  if (( options & gNDR_DOCKER_SERVICE_CONTROL_PULL )); then
    docker compose pull
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logInfo "Failed to start Docker Container services"
      return 1
    fi
    ndr_logInfo "Pulled Docker images for Docker Container services successfully."
  fi

  if (( options & gNDR_DOCKER_SERVICE_CONTROL_COMPOSE )); then
    docker compose up -d
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logInfo "Failed to compose Docker Container services"
      return 1
    fi
    ndr_logInfo "Composed Docker container services successfully."
  fi

  if (( options & gNDR_DOCKER_SERVICE_CONTROL_START )); then
    docker compose start
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logInfo "Failed to start Docker Container services"
      return 1
    fi
    ndr_logInfo "Started Docker container services successfully."
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_UpdateInstallPackageManifest ()
{
  local logSectionDesc="Updating install package schema upgrade manifest"
  ndr_logSecStart "$logSectionDesc"

  # Resolve the manifest file. The workflow normally checks out the public
  # package repo and runs this from the manifest directory; callers can override
  # with --manifestfile for a fully-qualified or alternate relative path.
  # if the manifest file was supplied but does not exist, error out since we dont want to create a version that will overwrite an existing one.
  if [[ -n "$gNDR_INSTALL_PACKAGE_MANIFEST_FILE" && ! -f "$gNDR_INSTALL_PACKAGE_MANIFEST_FILE" ]]; then
    ndr_logError "Install package manifest file override provided but not found [$gNDR_INSTALL_PACKAGE_MANIFEST_FILE]."
    return 1
  fi
  if [[ -z "$gNDR_INSTALL_PACKAGE_MANIFEST_FILE" ]]; then
    gNDR_INSTALL_PACKAGE_MANIFEST_FILE="${PWD}/$gNDR_INSTALL_PACKAGE_MANIFEST_FILENAME"
    ndr_logInfo "No install package manifest file override provided, using default path [$gNDR_INSTALL_PACKAGE_MANIFEST_FILE]."
  fi
  
  local manifest_dir
  manifest_dir=$(dirname "$gNDR_INSTALL_PACKAGE_MANIFEST_FILE")
  
  # Resolve the schema diff file. If no command line override was provided,
  # use the standard package diff filename in the current working directory.
  if [[ -z "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF" ]]; then
    gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF="${PWD}/$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF_FILENAME_SHORT"
    ndr_logInfo "No schema diff file override provided, using default path [$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF]."
  fi
  if [[ ! -f "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF" ]]; then
    ndr_logError "Schema diff file not found [$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF]."
    return 1
  fi
  
  ndr_logInfo "Using install package manifest file [$gNDR_INSTALL_PACKAGE_MANIFEST_FILE] in release mode [$gNDR_INSTALL_PACKAGE_RELEASE_MODE_CURRENT]."
  ndr_logInfo "Using schema diff file [$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF]."
  
  # Read and validate the schema diff header using the existing Supabase parser.
  ndr_SupabaseSchemaHeaderRead "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to read schema diff header from [$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF]."
    return 1
  fi

  if [[ "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_VAL" != "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_INCR" ]]; then
    ndr_logError "Schema diff type [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_VAL] is not incremental [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_INCR]."
    return 1
  fi

  if [[ -z "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL" || -z "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL" ]]; then
    ndr_logError "Schema diff header is missing from/to version values."
    return 1
  fi

  if [[ "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL" == "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL" ]]; then
    ndr_logError "Schema diff from/to versions are the same [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL]. Cannot add manifest entry."
    return 1
  fi

  if [[ "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL" != "$gPRODUCT_VERSION" ]]; then
    ndr_logError "Schema diff target version [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL] does not match current product version [$gPRODUCT_VERSION]."
    return 1
  fi

  local release_dir="${gPRODUCT_VERSION}"
  local schema_path="deploy/${release_dir}/schema"
  local full_schema_file="$gNDR_REFERENCE_SQL_SCHEMA_FILENAME"
  local diff_schema_file="$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF_FILENAME_SHORT"
  local created_at_utc=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
  local release_mode="$gNDR_INSTALL_PACKAGE_RELEASE_MODE_CURRENT"

  # Use jq for structured JSON manipulation.
  local manifest_entry_tmp="${gNDR_INSTALL_PACKAGE_MANIFEST_FILE}.entry.tmp"
  local manifest_tmp="${gNDR_INSTALL_PACKAGE_MANIFEST_FILE}.tmp"

  if [[ ! -s "$gNDR_INSTALL_PACKAGE_MANIFEST_FILE" ]]; then
    ndr_logInfo "Install package manifest is missing or empty, creating base manifest [$gNDR_INSTALL_PACKAGE_MANIFEST_FILE]."
    jq -n \
      --arg product "$gPRODUCT_NAME" \
      --arg generated_at_utc "$created_at_utc" \
      '{
        manifest_version: 1,
        product: $product,
        generated_at_utc: $generated_at_utc,
        schema_diffs: []
      }' > "$gNDR_INSTALL_PACKAGE_MANIFEST_FILE"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to create base install package manifest [$gNDR_INSTALL_PACKAGE_MANIFEST_FILE]."
      rm -f "$manifest_entry_tmp" "$manifest_tmp"
      return 1
    fi
  else
    ndr_logInfo "Validating install package manifest JSON [$gNDR_INSTALL_PACKAGE_MANIFEST_FILE]."
    jq empty "$gNDR_INSTALL_PACKAGE_MANIFEST_FILE"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Install package manifest is not valid JSON [$gNDR_INSTALL_PACKAGE_MANIFEST_FILE]."
      rm -f "$manifest_entry_tmp" "$manifest_tmp"
      return 1
    fi
  fi

  # Build the new entry as standalone JSON.
  ndr_logInfo "Creating manifest entry JSON for schema diff [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL -> $gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL]."
  jq -n \
    --arg from_version "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL" \
    --arg to_version "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL" \
    --arg release_dir "$release_dir" \
    --arg release_mode "$release_mode" \
    --arg full_schema_file "$full_schema_file" \
    --arg diff_schema_file "$diff_schema_file" \
    --arg baseline_schema_sha256 "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH_VAL" \
    --arg upgrade_schema_sha256 "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL" \
    '{
      from_version: $from_version,
      to_version: $to_version,
      release_dir: $release_dir,
      release_mode: $release_mode,
      full_schema_file: $full_schema_file,
      diff_schema_file: $diff_schema_file,
      baseline_schema_sha256: $baseline_schema_sha256,
      upgrade_schema_sha256: $upgrade_schema_sha256
    }' > "$manifest_entry_tmp"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create manifest entry JSON [$manifest_entry_tmp]."
    rm -f "$manifest_entry_tmp" "$manifest_tmp"
    return 1
  fi

  # Check whether the existing from/to entry is already identical. If so,
  # there is no need to rewrite the manifest or update generated_at_utc.
  ndr_logInfo "Checking for existing matching manifest entry."
  jq -e \
    --slurpfile entry "$manifest_entry_tmp" \
    --arg from_version "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL" \
    --arg to_version "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL" \
    '
    (.schema_diffs // [])
    | map(select(.from_version == $from_version and .to_version == $to_version))
    | length as $match_count
    | if $match_count == 0 then
        false
      elif $match_count == 1 then
        (.[0] == $entry[0])
      else
        error("Multiple matching manifest entries found for from/to version pair")
      end
    ' "$gNDR_INSTALL_PACKAGE_MANIFEST_FILE" >/dev/null
  return_code=$?
  if [ $return_code -eq 0 ]; then
    ndr_logInfo "Existing manifest entry is already up to date for schema diff [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL -> $gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL]."
    rm -f "$manifest_entry_tmp" "$manifest_tmp"
    ndr_logSecEnd "$logSectionDesc"
    return 0
  elif [ $return_code -eq 1 ]; then
    ndr_logInfo "Matching manifest entry is missing or stale; manifest update required."
  else
    ndr_logError "Failed to check existing matching manifest entry in [$gNDR_INSTALL_PACKAGE_MANIFEST_FILE]."
    rm -f "$manifest_entry_tmp" "$manifest_tmp"
    return 1
  fi

  # if the manifest entry is already present and is tagged with public release mode, then do not allow an update if 
  # the current release mode is private, since that would overwrite the public entry with potentially less stable private build metadata. 
  # We can allow the reverse (overwriting a private entry with a public entry) since that would represent the transition from private integration builds to public releases.
  local existing_release_mode=$(jq -r \
    --arg from_version "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL" \
    --arg to_version "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL" \
    '
    (.schema_diffs // []) 
    | map(select(.from_version == $from_version and .to_version == $to_version)) 
    | .[0].release_mode // ""
    ' "$gNDR_INSTALL_PACKAGE_MANIFEST_FILE" 2>/dev/null || true)

  if [[ -n "$existing_release_mode" && "$existing_release_mode" == "$gNDR_INSTALL_PACKAGE_RELEASE_MODE_PUBLIC" && "$gNDR_INSTALL_PACKAGE_RELEASE_MODE_CURRENT" == "$gNDR_INSTALL_PACKAGE_RELEASE_MODE_PRIVATE" ]]; then
    ndr_logWarn "Cannot overwrite PUBLIC manifest entry (release_mode=PUBLIC) with PRIVATE build; current mode is $gNDR_INSTALL_PACKAGE_RELEASE_MODE_CURRENT. Skipping manifest update."
    rm -f "$manifest_entry_tmp" "$manifest_tmp"
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # Remove any existing entry for the same from/to pair before appending the
  # current entry. Normal manifests should only have one, but this keeps the
  # upsert operation deterministic.
  ndr_logInfo "Removing existing manifest entry for schema diff [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL -> $gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL] if present."
  jq \
    --arg product "$gPRODUCT_NAME" \
    --arg from_version "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL" \
    --arg to_version "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL" \
    '
    .manifest_version = (.manifest_version // 1)
    | .product = (.product // $product)
    | .schema_diffs = (
        (.schema_diffs // [])
        | map(select(.from_version != $from_version or .to_version != $to_version))
      )
    ' "$gNDR_INSTALL_PACKAGE_MANIFEST_FILE" > "$manifest_tmp"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to remove existing matching manifest entry into [$manifest_tmp]."
    rm -f "$manifest_entry_tmp" "$manifest_tmp"
    return 1
  fi
  mv "$manifest_tmp" "$gNDR_INSTALL_PACKAGE_MANIFEST_FILE"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to replace install package manifest after removing matching entry [$gNDR_INSTALL_PACKAGE_MANIFEST_FILE]."
    rm -f "$manifest_entry_tmp" "$manifest_tmp"
    return 1
  fi

  # Append the current entry.
  ndr_logInfo "Appending current schema diff entry to manifest."
  jq \
    --slurpfile entry "$manifest_entry_tmp" \
    --arg generated_at_utc "$created_at_utc" \
    '
    .schema_diffs = ((.schema_diffs // []) + [$entry[0]])
    | .generated_at_utc = $generated_at_utc
    ' "$gNDR_INSTALL_PACKAGE_MANIFEST_FILE" > "$manifest_tmp"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to append current manifest entry into [$manifest_tmp]."
    rm -f "$manifest_entry_tmp" "$manifest_tmp"
    return 1
  fi
  mv "$manifest_tmp" "$gNDR_INSTALL_PACKAGE_MANIFEST_FILE"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to replace install package manifest after appending current entry [$gNDR_INSTALL_PACKAGE_MANIFEST_FILE]."
    rm -f "$manifest_entry_tmp" "$manifest_tmp"
    return 1
  fi

  # Sort entries by semantic from/to versions.
  ndr_logInfo "Sorting manifest schema diff entries."
  jq \
    '
    def version_key:
      tostring
      | ltrimstr("v")
      | split(".")
      | map(tonumber? // .);

    .schema_diffs = (
      (.schema_diffs // [])
      | sort_by([(.from_version // "" | version_key), (.to_version // "" | version_key)])
    )
    ' "$gNDR_INSTALL_PACKAGE_MANIFEST_FILE" > "$manifest_tmp"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to sort install package manifest entries into [$manifest_tmp]."
    rm -f "$manifest_entry_tmp" "$manifest_tmp"
    return 1
  fi

  mv "$manifest_tmp" "$gNDR_INSTALL_PACKAGE_MANIFEST_FILE"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to replace install package manifest after sorting [$gNDR_INSTALL_PACKAGE_MANIFEST_FILE]."
    rm -f "$manifest_entry_tmp" "$manifest_tmp"
    return 1
  fi

  ndr_logInfo "Install package manifest updated with schema diff entry [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL -> $gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL]."
  ndr_logDebug "Updated manifest section content:"
  cat "$manifest_entry_tmp"

  rm -f "$manifest_entry_tmp" "$manifest_tmp"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# ====================================================
# Create systemd service unit file
# usage: ndr_CreateSystemdServiceUnit <service_name> <description> <exec_start_command> <exec_stop_command>
# ====================================================
function ndr_CreateSystemdServiceUnit() 
{
  local logSectionDesc="Creating systemd service unit file"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -ne 4 ]]; then
    ndr_logError "Usage: <service_name> <description> <exec_start_command> <exec_stop_command>"
    return 1
  fi

  if [[ -z "$gNEXTDR_HOME_DIR" ]]; then
    ndr_logError "Invalid home directory."
    return 1
  fi

  local serviceName="$1"
  local description="$2"
  local execStart="$gNEXTDR_HOME_DIR/$3"
  local execStop="$gNEXTDR_HOME_DIR/$4"

  local systemdPath="/etc/systemd/system/${serviceName}.service"

  # Check if the unit file already exists
  if [ -f "$systemdPath" ]; then
    ndr_logInfo "Systemd unit already exists: $systemdPath — skipping creation."
    return 0
  fi

  sudo tee "$systemdPath" > /dev/null <<EOF
[Unit]
Description=$description
After=docker.service
Requires=docker.service

[Service]
Type=oneshot
RemainAfterExit=true
ExecStart=$execStart
ExecStop=$execStop
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to write unit file: $systemdPath (code $return_code)"
    return 1
  fi
  ndr_logInfo "Unit file created: $systemdPath"
  
  # Reload systemd and enable the service
  sudo systemctl daemon-reload
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to reload systemd: (code $return_code)"
    return 1
  fi
  ndr_logInfo "Reloaded systemd daemon."

  sudo systemctl enable "$serviceName"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to enable systemd service: $serviceName (code $return_code)"
    return 1
  fi
  ndr_logInfo "Enabled systemd service: $serviceName"

  ndr_logSecEnd "$logSectionDesc"
  return 0
}

function ndr_InstallSystemdUnit_Supabase() 
{
  local logSectionDesc="Installing systemd unit for Supabase"
  ndr_logSecStart "$logSectionDesc"

  if [ "$gUPGRADE_MODE" == true ]; then
    ndr_logDebug "Upgrade mode set, skipping section."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi
  
  local svc="$NDR_SYSTEMD_SUPABASE_SVC_NAME"
  local desc="$NDR_SYSTEMD_SUPABASE_SVC_DESC"
  local startCmd="$NDR_SYSTEMD_SUPABASE_SVC_START_CMD"
  local stopCmd="$NDR_SYSTEMD_SUPABASE_SVC_STOP_CMD"

  ndr_CreateSystemdServiceUnit "$svc" "$desc" "$startCmd" "$stopCmd"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create systemd unit for $svc"
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"
  return 0
}

function ndr_InstallSystemdUnit_Service() 
{
  local logSectionDesc="Installing systemd unit for Service"
  ndr_logSecStart "$logSectionDesc"

  local svc="$NDR_SYSTEMD_SERVICE_SVC_NAME"
  local desc="$NDR_SYSTEMD_SERVICE_SVC_DESC"
  local startCmd="$NDR_SYSTEMD_SERVICE_SVC_START_CMD"
  local stopCmd="$NDR_SYSTEMD_SERVICE_SVC_STOP_CMD"

  ndr_CreateSystemdServiceUnit "$svc" "$desc" "$startCmd" "$stopCmd"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create systemd unit for $svc"
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"
  return 0
}

function ndr_InstallSystemdUnit_UI() 
{
  local logSectionDesc="Installing systemd unit for UI"
  ndr_logSecStart "$logSectionDesc"
  
  local svc="$NDR_SYSTEMD_UI_SVC_NAME"
  local desc="$NDR_SYSTEMD_UI_SVC_DESC"
  local startCmd="$NDR_SYSTEMD_UI_SVC_START_CMD"
  local stopCmd="$NDR_SYSTEMD_UI_SVC_STOP_CMD"

  ndr_CreateSystemdServiceUnit "$svc" "$desc" "$startCmd" "$stopCmd"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create systemd unit for $svc"
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"
  return 0
}

function ndr_UninstallSystemdUnit() 
{
  local logSectionDesc="Uninstalling systemd unit"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: ndr_UninstallSystemdUnit <service_name>"
    return 1
  fi

  local svc="$1"
  local systemdUnitRemoved=true


  # Check if the systemd unit exists before disabling
  systemctl list-unit-files | grep -q "^${svc}\.service"
  return_code=$?
  if [ $return_code -eq 0 ]; then
    sudo systemctl disable "$svc"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to disable systemd service: $svc (code $return_code)"
      systemdUnitRemoved=false
    else
      ndr_logInfo "Disabled systemd service: $svc"
    fi
  else
    ndr_logInfo "Systemd service $svc does not exist or is not installed. Skipping disable."
  fi

  local serviceFile="/etc/systemd/system/${svc}.service"
  if [[ -f "$serviceFile" ]]; then
    sudo rm -f "$serviceFile"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to remove systemd service file: $serviceFile (code $return_code)"
      systemdUnitRemoved=false
    else
      ndr_logInfo "Removed systemd service file: $serviceFile"
    fi
  else
    ndr_logWarn "Systemd file [$serviceFile] does not exist, skipping removal."
  fi

  sudo systemctl daemon-reload
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to reload systemd daemon: (code $return_code)"
    systemdUnitRemoved=false
  else
    ndr_logInfo "Removed systemd service: $svc"
  fi

  if [[ "$systemdUnitRemoved" == false ]]; then
    ndr_logError "Errors encountered removing systemd for service [$svc]"
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"
  return 0
}

function ndr_UninstallSystemdUnit_Supabase() 
{
  local logSectionDesc="Uninstalling systemd unit for Supabase"
  ndr_logSecStart "$logSectionDesc"

  ndr_UninstallSystemdUnit "$NDR_SYSTEMD_SUPABASE_SVC_NAME"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to uninstall systemd unit for Supabase"
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"
  return 0
}

function ndr_UninstallSystemdUnit_Service() 
{
  local logSectionDesc="Uninstalling systemd unit for Service"
  ndr_logSecStart "$logSectionDesc"

  ndr_UninstallSystemdUnit "$NDR_SYSTEMD_SERVICE_SVC_NAME"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to uninstall systemd unit for Service"
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"
  return 0
}

function ndr_UninstallSystemdUnit_UI() 
{
  local logSectionDesc="Uninstalling systemd unit for UI"
  ndr_logSecStart "$logSectionDesc"

  ndr_UninstallSystemdUnit "$NDR_SYSTEMD_UI_SVC_NAME"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to uninstall systemd unit for UI"
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"
  return 0
}

# usage: function [force_prompt]
function ndr_QueryHostAddress ()
{
  local logSectionDesc="Query for product host address"
  ndr_logSecStart "$logSectionDesc"

  local forcePrompt="${1:-false}"
  local hostAddress=""

  # express mode check where user specified ip address as cmdline arg
  if [[ "$gEXPRESS_MODE" == true && -n "$gNDR_SERVER_HOST_ADDRESS" && "$gNDR_SERVER_HOST_ADDRESS" != "localhost" ]]; then
    ndr_logInfo "Using host address [$gNDR_SERVER_HOST_ADDRESS] cmdline option in express mode"
    hostAddress="$gNDR_SERVER_HOST_ADDRESS"
  fi

  # Get current address from registry, if any.
  local bVerifyQueryAddress=false
  if [[ -z "$hostAddress" || "$hostAddress" == "localhost" ]]; then
    hostAddress=$(ndr_getHostAddressReg)
    if [[ -z "$hostAddress" || "$hostAddress" == "localhost" ]]; then
      ndr_logWarn "Unable to retrieve host address from registry, trying other options."
    else
      ndr_logInfo "Pulled host address [$hostAddress] from registry."
    fi
  fi

  # Get IP if nothing currently provided.
  if [[ -z "$hostAddress" || "$hostAddress" == "localhost" ]]; then
    # no ip in registry, attempt to get from the system
    local queryHostAddress=$(curl -fsSL https://ifconfig.me)
    if [[ -n "$queryHostAddress" ]]; then
      hostAddress=$(printf "%s" "$queryHostAddress") # do this to trim out any line breaks that seem to come embedded in the output from this curl query.
      ndr_logInfo "Found possible external address from network query [$queryHostAddress]"
      bVerifyQueryAddress=true
    fi
  fi

  # if in express mode, we have to skip all interactive prompts and run with the value we have.
  if [ "$gEXPRESS_MODE" == false ]; then
    # if force prompt option was set, we should always show the prompt.
    if [[ "$forcePrompt" == true ]]; then
      ndr_logInfo "Force prompt option was set, forcing user prompt to verify."
      bVerifyQueryAddress=true
    fi

    # we *may* have an address, verify with user this is the correct one.
    if [[ -z "$hostAddress" || "$hostAddress" == "localhost" || $bVerifyQueryAddress == true ]]; then
      echo -e "The host address currently set for $gPRODUCT_NAME is [$hostAddress]. Is this the correct external host address where the application modules will be hosted on and accessible from?" >&2
      read -p "Choose YES to continue with this address or NO to be prompted to enter a new one [Y|n]" -n 1 -r
      echo >&2   # Move to a new line
      if [[ $REPLY =~ ^[Nn]$ ]]; then
        # clear it and we will prompt below to enter
        hostAddress=""
      fi
    fi

    # still invalid from curl query failure, no reg entry or user indicating entry is required, prompt user to enter now.
    if [[ -z "$hostAddress" ]]; then
      while true; do
        read -p "No host address is currently set for the $gPRODUCT_NAME application modules. Please enter the host address of this server: " -r hostAddress
        #echo >&2   # Move to a new line
        if [[ -n "$hostAddress" ]]; then
          read -p "The host address entered is [$hostAddress]. Is this the correct external host address where the application modules will be accessible from (Yes|no|abort)? [Y|n|a]" -n 1 -r
          echo  >&2  # Move to a new line
          if [[ $REPLY =~ ^[Nn]$ ]]; then
            # clear it and we will prompt below to enter
            hostAddress=""
            echo    # Move to a new line
            continue
          elif [[ $REPLY =~ ^[Aa]$ ]]; then
            # abort
            hostAddress=""
            break
          else
            # answered yes, accept value and continue.
            break
          fi
        fi
        echo "No host address provided, please enter a valid address"
        continue
      done  
    fi
  fi

  if [[ -z "$hostAddress" ]]; then
    ndr_logWarn "Warning, no host address found or specified."
  else
    ndr_logInfo "Using specified host address [$hostAddress]."
  fi

  ndr_logSecEnd "$logSectionDesc"

  local nRet=1
  if [[ -n "$hostAddress" ]]; then
    nRet=0
    echo "$hostAddress"
  fi
  return $nRet
}

function ndr_PromptHostAddress ()
{
  local logSectionDesc="Prompting for Host Address"
  ndr_logSecStart "$logSectionDesc"

  # if address empty or set to localhost, query for current.
  if [[ -z "$gNDR_SERVER_HOST_ADDRESS" || "$gNDR_SERVER_HOST_ADDRESS" == "localhost" ]]; then
    local hostAddress=$(ndr_QueryHostAddress)
    return_code=$?
    if [[ $return_code -ne 0 || -z $gNDR_SERVER_HOST_ADDRESS ]]; then
      ndr_logError "Failed to retrieve IP address."
      return 1
    fi
    gNDR_SERVER_HOST_ADDRESS="$hostAddress"
  fi
  ndr_logInfo "Host address set to [$gNDR_SERVER_HOST_ADDRESS]"  
    
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_PopulateHostAddress ()
{
  local logSectionDesc="Populating Host Address"
  ndr_logSecStart "$logSectionDesc"

  # if address empty or set to localhost, query for current.
  if [[ -z "$gNDR_SERVER_HOST_ADDRESS" || "$gNDR_SERVER_HOST_ADDRESS" == "localhost" ]]; then
    ndr_PromptHostAddress
    return_code=$?
    if [[ $return_code -ne 0 || -z $gNDR_SERVER_HOST_ADDRESS ]]; then
      ndr_logError "Failed to retrieve IP address."
      return 1
    fi
  fi

  # populate registry value. Check for reg existance to handle devops mode where no reg is installed.
  ndr_RegistryExists
  return_code=$?
  if [ "$return_code" -eq 0 ]; then
    local regHostAddress=$(ndr_getHostAddressReg)
    if [[ "$regHostAddress" != "$gNDR_SERVER_HOST_ADDRESS" ]]; then
      ndr_setHostAddressReg "$gNDR_SERVER_HOST_ADDRESS"
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Failed to set host address [$gNDR_SERVER_HOST_ADDRESS] in registry."
        return 1
      fi
    else
      ndr_logInfo "Existing host address in registry [$regHostAddress] same as set value [$gNDR_SERVER_HOST_ADDRESS], skipping update."
    fi
  else
    ndr_logInfo "Registry not present, not updating host address in registry."
  fi

  ndr_logInfo "Populated Host address [$gNDR_SERVER_HOST_ADDRESS]"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

export NDR_ADDR_TYPE_IPV4="ipv4"
export NDR_ADDR_TYPE_IPV6="ipv6"
export NDR_ADDR_TYPE_HOSTNAME_SHORT="hostname_short"
export NDR_ADDR_TYPE_HOSTNAME_LONG="hostname_long"
export NDR_ADDR_TYPE_LOCALHOST="localhost"
export NDR_ADDR_TYPE_UNKNOWN="unknown"
export NDR_SERVER_HOST_ADDRESS_TYPE="$NDR_ADDR_TYPE_UNKNOWN"
  
# prompts for the proxy configuration mode that Caddy will run as.
# ideally this should only be done after the ip/hostname has been collected so we can inform/warn the user if 
# the mode they've selected isn't compatible with that particular style network address format.
function ndr_PromptCaddyProxyMode ()
{
  local logSectionDesc="Prompting for Caddy Proxy Configuration Mode"
  ndr_logSecStart "$logSectionDesc"

  # ----------------------------------------------------------------
  # Determine host address type (ipv4, ipv6, hostname long/short, localhost)
  local addr_type="$NDR_ADDR_TYPE_UNKNOWN"

  local addr_raw="$gNDR_SERVER_HOST_ADDRESS"
  local addr_no_brackets="${addr_raw#[}"
  addr_no_brackets="${addr_no_brackets%]}"
  local addr_lc
  addr_lc=$(printf "%s" "$addr_no_brackets" | tr '[:upper:]' '[:lower:]')

  if [[ "$addr_lc" == "localhost" || "$addr_lc" == "localhost.localdomain" || "$addr_lc" == "ip6-localhost" || "$addr_lc" == "ip6-loopback" || "$addr_no_brackets" == "127.0.0.1" || "$addr_no_brackets" == "::1" ]]; then
    addr_type="$NDR_ADDR_TYPE_LOCALHOST"
  elif [[ "$addr_no_brackets" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
    local o1 o2 o3 o4
    IFS='.' read -r o1 o2 o3 o4 <<< "$addr_no_brackets"
    if (( o1 <= 255 && o2 <= 255 && o3 <= 255 && o4 <= 255 )); then
      addr_type="$NDR_ADDR_TYPE_IPV4"
    fi
  elif [[ "$addr_no_brackets" == *:* && "$addr_no_brackets" =~ ^[0-9A-Fa-f:]+$ ]]; then
    addr_type="$NDR_ADDR_TYPE_IPV6"
  fi

  if [[ "$addr_type" == "$NDR_ADDR_TYPE_UNKNOWN" ]]; then
    if [[ "$addr_no_brackets" == *.* ]]; then
      if [[ "$addr_no_brackets" =~ ^[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+$ ]]; then
        addr_type="$NDR_ADDR_TYPE_HOSTNAME_LONG"
      fi
    else
      if [[ "$addr_no_brackets" =~ ^[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?$ ]]; then
        addr_type="$NDR_ADDR_TYPE_HOSTNAME_SHORT"
      fi
    fi
  fi

  NDR_SERVER_HOST_ADDRESS_TYPE="$addr_type"
  ndr_logInfo "Host address type set to [$NDR_SERVER_HOST_ADDRESS_TYPE]"

  # ----------------------------------------------------------------
  # express mode check
  if [[ "$gEXPRESS_MODE" == true ]]; then
    if [[ "$NDR_CADDY_ENABLED" == true && "$NDR_SERVER_HOST_ADDRESS_TYPE" != "$NDR_ADDR_TYPE_IPV4" && "$NDR_SERVER_HOST_ADDRESS_TYPE" != "$NDR_ADDR_TYPE_HOSTNAME_LONG" ]]; then
      ndr_logError "Secure Caddy mode is incompatible with host address type [$NDR_SERVER_HOST_ADDRESS_TYPE] for address [$gNDR_SERVER_HOST_ADDRESS]. Use IPv4 or a long hostname, or disable caddy option."
      return 1
    fi
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # ----------------------------------------------------------------
  # prompt for config type

  while true; do

    echo "===================================================================="
    echo "Caddy proxy configuration mode selection"
    echo "===================================================================="
    echo "Please select an option:"
    echo ""
    echo "S. Secure HTTPS mode using Caddy proxy. Supports valid public URLs with CA-signed certificates and internal URL's with static IP's and self-signed certificates."
    echo "B. Basic HTTP mode. Supports any internal or external URL type, static or dynamic, without the security layer."
    echo "q. Exit/Abort"
    echo ""
    read -p "Enter your choice [S/B/q]: " choice

    # check for valid selection (QqBbSs)
    case "$choice" in
      q|Q)
        ndr_logInfo "Aborting caddy mode selection."
        return 1
        ;;
      s|S)
        # perform compatibility check of ip type.
        if [[ "$NDR_SERVER_HOST_ADDRESS_TYPE" == "$NDR_ADDR_TYPE_IPV4" || "$NDR_SERVER_HOST_ADDRESS_TYPE" == "$NDR_ADDR_TYPE_HOSTNAME_LONG" ]]; then
          NDR_CADDY_ENABLED=true
          ndr_logInfo "Selected secure Caddy mode."
          break
        fi
        
        echo "Secure Caddy mode requires IPv4 or long hostname. Current host address type [$NDR_SERVER_HOST_ADDRESS_TYPE] for address [$gNDR_SERVER_HOST_ADDRESS]."
        echo "Please make a different selection or go back and enter a different hostname compatible with this selection."
        continue
        ;;
      b|B)
        NDR_CADDY_ENABLED=false
        ndr_logInfo "Selected basic HTTP/non-caddy mode."
        break
        ;;
      *)
        ndr_logWarn "Invalid selection [$choice], please try again."
        continue
        ;;
    esac
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_DecryptPopulateSecrets ()
{
  local logSectionDesc="Decrypting and Populating Secrets"
  ndr_logSecStart "$logSectionDesc"

  if [ "$gNDR_SECRETS_LOADED" == true ]; then
    ndr_logInfo "Secrets already loaded"
    return 0
  fi

  local encSecretsFile="${gSCRIPT_HOME_DIR}/$gNDR_SECRETS_GPG_FILENAME"
  
  if [ ! -f "$encSecretsFile" ]; then
    ndr_logError "Secrets file not found [$encSecretsFile]"
    return 1
  fi

  set +H  # Disable history expansion for passwords (!)

  # use local secrets file. It is encrypted so it will require user interaction to decript.
  local decSecretsFile=$gNDR_SECRETS_FILENAME
  local DECRYPTED=""

  max_retries=3
  attempt=1
  while true; do
    #gpgconf --kill gpg-agent
    if [ -z "$gNDR_SECRETS_PASSPHRASE" ]; then
      ndr_logInfo "Secrets key empty, prompting interactively"
      echo "Please (re)enter the GPG passphrase to decrypt the $gCOMPANY_NAME secrets file:"
      DECRYPTED=$(gpg --pinentry-mode loopback --decrypt "$encSecretsFile")
    else
      DECRYPTED=$(gpg --batch --yes --passphrase "$gNDR_SECRETS_PASSPHRASE" --decrypt "$encSecretsFile")
    fi
    return_code=$?
    if [ $return_code -eq 0 ]; then
      ndr_logInfo "Decrypted secrets file [$encSecretsFile]"
      break;
    fi

    if [[ $attempt -ge $max_retries ]]; then
      ndr_logError "Max decrypt retries reached. Exiting."
      return 1
    fi

    ndr_logWarn "Failed to decrypt secrets file [$encSecretsFile], retrying..."
    rm -f "$decSecretsFile"
    attempt=$((attempt + 1))
    gNDR_SECRETS_PASSPHRASE=""
    sleep 1  # Optional: wait before retrying
  done

  # immediately clean up decrypted file
  rm -f "$decSecretsFile"

  if [ -z "$DECRYPTED" ]; then
    ndr_logError "Decrypted secrets empty."
    return 1
  fi

  # Load into environment
  eval "$DECRYPTED"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to load secrets into local environment."
    return 1
  fi

  gNDR_SECRETS_LOADED=true

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_CopyClientModuleFiles ()
{
  local logSectionDesc="Copying Client Module Files"
  ndr_logSecStart "$logSectionDesc"

  # copy all module files to install dir.
  # The files being copied are those required by our modules to start and run such as YML, ENV and any other supporing configuration file needed at a later date.

  declare -A copyFileList=()
  
  copyFileList[".env.nextdr"]="${NDR_CLIENT_APP_HOME_LOC}/.env.nextdr"
  
  if [[ "$NDR_CADDY_ENABLED" == true ]]; then
    copyFileList["$NDR_CADDYFILE_NAME"]="${NDR_CADDY_HOME_LOC}" # omit the filename because it has no extension
    copyFileList["$NDR_CLIENT_APP_CADDY_COMPOSEFILE_FILENAME"]="${NDR_CLIENT_APP_HOME_LOC}/${NDR_CLIENT_APP_COMPOSEFILE_FILENAME}" # copy and rename.
  else
    copyFileList["$NDR_CLIENT_APP_COMPOSEFILE_FILENAME"]="${NDR_CLIENT_APP_HOME_LOC}/${NDR_CLIENT_APP_COMPOSEFILE_FILENAME}"
  fi

  for filename in "${!copyFileList[@]}"; do
    local sourceFile="${gSCRIPT_HOME_DIR}/${filename}"
    local destFile="${gNEXTDR_HOME_DIR}/${copyFileList[$filename]}"
    
    if [ ! -f "$sourceFile" ]; then
      ndr_logError "File not found [$sourceFile]"
      return 1
    fi

    cp -f $sourceFile $destFile
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to copy file [$sourceFile] to [$destFile]"
      return 1
    fi
    ndr_logInfo "Successfully copied file [$sourceFile] to [$destFile]"
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_CopyInstallHomeFiles ()
{
  local logSectionDesc="Copying Installation Home Files"
  ndr_logSecStart "$logSectionDesc"

  local copyFileList=(
    "ndrInstall.sh" \
    "ndrAdmin.sh" \
    "ndrInterface.sh" \
    "ndrCommon.sh" \
    "ndrVersion.sh" \
    "ndrDocker.sh" \
    "ndrRegistry.sh" \
    "ndrSupabase.sh" \
    ".env.nextdr" \
    "$NDR_CADDYFILE_NAME" \
    "$NDR_CLIENT_APP_COMPOSEFILE_FILENAME" \
    "$NDR_CLIENT_APP_CADDY_COMPOSEFILE_FILENAME" \
  )

  local admin_dir="${gNEXTDR_HOME_DIR}/${NDR_ADMIN_HOME_LOC}"

  # if we are running from the home dir (ie. user is administering from the install home)), then we can skip copying files to the same location.
  if [[ "$gSCRIPT_HOME_DIR" == "$admin_dir" ]]; then
    ndr_logInfo "Script home dir [$gSCRIPT_HOME_DIR] same as admin home dir [$admin_dir], skipping file copy."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi
  
  # clean the folder if it exists, otherwise create it.
  if [[ -d "$admin_dir" ]]; then
    ndr_logInfo "Cleaning existing admin home dir [$admin_dir]"
    rm -rf "$admin_dir"/*
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to clean existing admin home dir [$admin_dir]"
      #return 1
    fi
  fi

  # create the admin home dir if it doesn't exist.
  if [[ ! -d "$admin_dir" ]]; then
    mkdir -p "$admin_dir"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to create admin home dir [$admin_dir]"
      return 1
    fi
    ndr_logInfo "Created admin home dir [$admin_dir]"
  fi

  for filename in "${copyFileList[@]}"; do
    local sourceFile="${gSCRIPT_HOME_DIR}/$filename"
    local destFile="${admin_dir}/$filename"
    
    if [ ! -f "$sourceFile" ]; then
      ndr_logError "File not found [$sourceFile]"
      return 1
    fi

    cp -f $sourceFile $destFile
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to copy file [$sourceFile] to [$destFile]"
      return 1
    fi
    ndr_logInfo "Successfully copied file [$sourceFile] to [$destFile]"

    # if extension is .sh, set execute permissions on the copied file
    if [[ "$filename" == *.sh ]]; then
      chmod +x "$destFile"
    fi
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_getRegistryNameForImageName ()
{
  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <image_name>"
    return 1
  fi

  local imageName="$1"
  local registryName=""

  if [ "$imageName" == "$NDR_SERVICE_IMAGE_NAME" ]; then
    registryName="$gREGISTRY_ENTRY_MODULE_STATUS_SERVICE_NAME"
  elif [ "$imageName" == "$NDR_UI_IMAGE_NAME" ]; then
    registryName="$gREGISTRY_ENTRY_MODULE_STATUS_UI_NAME"
  fi

  if [ -z "$registryName" ]; then
    ndr_logError "Unable to translate image name [$imageName]."
    return 1
  fi
  
  echo "$registryName"

  return 0
}

function ndr_getHomeDirForImageName ()
{
  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <image_name> <module_subfolder>"
    return 1
  fi

  local imageName="$1"
  local containerFolder="$2"
  local appHomeDir=""

  local registryName=$(ndr_getRegistryNameForImageName "$imageName")
  if [ -z "$registryName" ]; then
    ndr_logError "Failed to translate image name [$imageName] to registry name fo home dir lookup."
    return 1
  fi

  ndr_isModuleInstalledReg "$registryName"
  local moduleInstalled=$?
  if [ "$moduleInstalled" -ne 0 ]; then
    # module not installed, home dir can only be a local devops style path.
    local relPath="${gSCRIPT_HOME_DIR}/../${containerFolder}"
    # try to resolve relative to absolute path
    appHomeDir=$(realpath "$relPath")
    if [ -z "$relPath" ]; then
      # fall back to relative path.
      appHomeDir="${relPath}"
    fi
    echo "$appHomeDir"
    return 0
  fi
  
  # module is installed, get home folder from reg
  local homeDir=$(ndr_getHomeDirReg)
  return_code=$?
  if [[ $return_code -ne 0 || -z "$homeDir" ]]; then
    ndr_logError "Failed to retrieve home dir from registry."
    return 1
  fi
  gNEXTDR_HOME_DIR=$(ndr_getHomeDirReg)

  appHomeDir="${gNEXTDR_HOME_DIR}/${containerFolder}"
  echo "$appHomeDir"

  return 0
}

function ndr_InstallationReportAddEntry ()
{
  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: ndr_InstallationReportAddEntry <entry_text>"
    return 1
  fi
  
  NDR_INSTALLATION_REPORT+=("$1")
  
  return 0
}

function ndr_PrintInstallationReport ()
{
  if [ ${#NDR_INSTALLATION_REPORT[@]} -eq 0 ]; then
    ndr_logError "No installation report entries found."
    return 0
  fi

  echo "================ Installation Report ================"
  for entry in "${NDR_INSTALLATION_REPORT[@]}"; do
    echo "- $entry"
  done
  echo "====================================================="

  return 0
}

# Generates a secure random password of the given length
# Usage: ndr_generateSecurePassword <length>
function ndr_generateSecurePassword()
{
  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: ndr_generateSecurePassword <length>"
    return 1
  fi

  local length="$1"

  # Validate length is a positive integer
  if ! [[ "$length" =~ ^[0-9]+$ ]] || [[ "$length" -le 0 ]]; then
    ndr_logError "Password length must be a positive integer."
    return 1
  fi

  # Generate password using /dev/urandom (cryptographically strong)
  # The tr filters out unwanted chars, and head limits to desired length
  local password
  password=$(tr -dc 'A-Za-z0-9!@#%^*_+=-' < /dev/urandom | head -c "$length")

  if [[ -z "$password" ]]; then
    ndr_logError "Failed to generate password."
    return 1
  fi

  echo "$password"
  return 0
}

# given an env file and a var name, will convert it inline from basic HTTP to secure HTTPS format
# eg. SITE_URL=http://34.122.203.121:3000 -> SITE_URL=https://34.122.203.121:3000
function ndr_ConvertEnvVarHTTPToHTTPS
{
  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <env_file> <var_name>"
    return 1
  fi

  local env_file="$1"
  local var_name="$2"
  
  # --- Check that files exist ---
  if [ ! -f "$env_file" ]; then
    ndr_logError "Env file no found [$env_file]"
    return 1
  fi

  local current_value
  current_value=$(grep -E "^${var_name}=" "$env_file" | head -n1 | cut -d= -f2-)
  if [[ -z "$current_value" ]]; then
    ndr_logWarn "$var_name not found in env file [$env_file], skipping update."
    return 0
  fi

  local updated_value="${current_value/http:\/\//https:\/\/}"
  if [[ "$updated_value" != "$current_value" ]]; then
    sed -i "s|^${var_name}=.*|${var_name}=$updated_value|" "$env_file"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to update $var_name in env file [$env_file]."
      return 1
    fi
    ndr_logInfo "Updated $var_name to [$updated_value] in env file."
  else
    ndr_logInfo "$var_name already uses https. Skipping update."
  fi

  return 0
}

# given an env file and a var name, will convert it inline from secure HTTPS to HTTP format
# eg. SITE_URL=http://34.122.203.121:3000 -> SITE_URL=https://34.122.203.121:3000
function ndr_ConvertEnvVarHTTPSToHTTP
{
  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <env_file> <var_name>"
    return 1
  fi

  local env_file="$1"
  local var_name="$2"
  
  # --- Check that files exist ---
  if [ ! -f "$env_file" ]; then
    ndr_logError "Env file no found [$env_file]"
    return 1
  fi

  local current_value
  current_value=$(grep -E "^${var_name}=" "$env_file" | head -n1 | cut -d= -f2-)
  if [[ -z "$current_value" ]]; then
    ndr_logWarn "$var_name not found in env file [$env_file], skipping update."
    return 0
  fi

  local updated_value="${current_value/https:\/\//http:\/\/}"
  if [[ "$updated_value" != "$current_value" ]]; then
    sed -i "s|^${var_name}=.*|${var_name}=$updated_value|" "$env_file"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to update $var_name in env file [$env_file]."
      return 1
    fi
    ndr_logInfo "Updated $var_name to [$updated_value] in env file."
  else
    ndr_logInfo "$var_name already uses http. Skipping update."
  fi

  return 0
}

# given a valid network address (ip, or long hostname), we reconfigure the product to replace all locations where the network address is stored.
# eg. client and supabase env files, caddyfile, others.
function ndr_ConfigureNetworkHostAddress
{
  local logSectionDesc="Configuring Network Host Address"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <address>"
    return 1
  fi

  local new_address="$1"

  local prev_address=$(ndr_getHostAddressReg)
  if [[ -z "$prev_address" ]]; then
    ndr_logError "Failed to get current network host address from registry."
    return 1
  fi
  
  if [[ -z "$gNEXTDR_HOME_DIR" ]]; then
    gNEXTDR_HOME_DIR=$(ndr_getHomeDirReg)
  fi
  gSUPABASE_NEXTDR_HOME="${gNEXTDR_HOME_DIR}/${gSUPABASE_NEXTDR_SUB}" 
  
  local files=()

  # handle client
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_CLIENT_NAME"
  local clientInstalled=$?
  if [[ "$clientInstalled" -eq 0 ]]; then
    files+=("${gNEXTDR_HOME_DIR}/${NDR_CLIENT_APP_HOME_LOC}/.env")
    
    NDR_CADDY_ENABLED=$(ndr_getCaddyEnabledReg)
    if [[ "$NDR_CADDY_ENABLED" == true ]]; then
      files+=("${gNEXTDR_HOME_DIR}/${NDR_CADDY_HOME_LOC}/${NDR_CADDYFILE_NAME}")
    fi
  fi

  # handle supabase
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
  local dbInstalled=$?
  if [[ "$dbInstalled" -eq 0 ]]; then
    files+=("${gSUPABASE_NEXTDR_HOME}/.env")
  fi

  # ensure all files exist
  for file in "${files[@]}"; do
    if [[ ! -f "$file" ]]; then
      ndr_logError "File not found [$file]"
      return 1
    fi
  done

  nrd_logInfo "Replacing previous network address [$prev_address] with new address [$new_address]."

  # scan each file for the previous address and replace with the new address.
  total_replacements=0

  for file in "${files[@]}"; do
    ndr_logInfo "Processing file [$file]"

    tmp_file="$(mktemp)"
    file_replacements=0

    while IFS= read -r line; do
      if [[ "$line" == *"$prev_address"* ]]; then
        original_line="$line"
        line="${line/$prev_address/$new_address}"

        ((file_replacements++))
        ((total_replacements++))

        ndr_logDebug "Updated line: [$original_line] -> [$line]"
      fi

      echo "$line"
    done < "$file" > "$tmp_file"

    # Replace original file
    mv "$tmp_file" "$file"

    ndr_logInfo "File [$file] updated ($file_replacements replacements)"
  done

  ndr_logInfo "Total replacements across all files: $total_replacements"

  # update registry
  gNDR_SERVER_HOST_ADDRESS=$new_address
  ndr_PopulateHostAddress
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to populate host address."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_Test ()
{
  local logSectionDesc="Copying Installation Home Files"
  ndr_logSecStart "$logSectionDesc"

  local version_chain=()
  ndr_SupabaseBuildUpgradeSchemaReplayVersionChain "1.1.5" "1.1.7" version_chain

  local replay_files=()
  ndr_SupabaseBuildUpgradeSchemaReplayList "1.1.5" "1.1.7" replay_files
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ndr_logWarn "This is a bash module--there is no direct execution capabilities in this file."
  exit 0
fi
