#!/bin/bash
# ndrDocker.sh - A Bash module providing common Docker related functions

source "$(dirname "${BASH_SOURCE[0]}")/ndrCommon.sh"

#---------------------------------------------------------
# docker architectural variables
export gNDR_DOCKER_ARCHITECTURE_AUTO_DETECT="auto-detect"
export gNDR_DOCKER_ARCHITECTURE_LINUX_AMD64="linux/amd64"
export gNDR_DOCKER_ARCHITECTURE_CURRENT="$gNDR_DOCKER_ARCHITECTURE_AUTO_DETECT"

#---------------------------------------------------------
# local Docker registry related variables

export gNDR_DOCKER_LOCAL_REGISTRY_PORT=5150
export gNDR_DOCKER_LOCAL_REGISTRY_PORT_DESC="Local Docker Registry port"

export gNDR_DOCKER_LOCAL_REGISTRY_HOST="" #"localhost"
export gNDR_DOCKER_LOCAL_REGISTRY_HOST_DESC="Local Docker Registry host"

export gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME="$gPRODUCT_NAME_SHORT-registry"
export gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME_DESC="Local Docker Registry container name"

export gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR="/opt/ndr-docker-registry"
export gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR_DESC="Local Docker Registry data directory on host"

#---------------------------------------------------------
# remote repo related variables

export NDR_DOCKER_REMOTE_REPO_AUTHENTICATED=false
export NDR_DOCKER_REMOTE_REPO_QUERIED=false

#---------------------------------------------------------
# GCP artifact registry related variables

export gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT="" #"us-east5-docker.pkg.dev/nextdr2"
export gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT_DESC="Google Cloud Docker Artifact Registry Root (format: <region_url>/<project_id>, eg. us-east5-docker.pkg.dev/nextdr2)"

#---------------------------------------------------------
# general docker related variables

declare -a NDR_REMOTE_DOCKER_IMAGE_LIST=()

#---------------------------------------------------------

# --- FUNCTIONS ---

function ndr_removeDockerPackages ()
{
  local logSectionDesc="Cleaning up packages"
  ndr_logSecStart "$logSectionDesc"

  # Loop through each package and remove it
  for pkg in "${dockerRemovePkgs[@]}"; do
    if dpkg -l | grep -q "$pkg"; then
      ndr_logInfo "🗑️ Removing $pkg..."
      sudo apt-get remove --assume-yes "$pkg"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "$pkg package not removed, please manually remove package before proceeding."
        return 1
      fi
    else
      ndr_logInfo "$pkg is not installed, skipping."
    fi
  done

  # Loop through each package and remove it
  for pkg in "${dockerInstallPackages[@]}"; do
    if dpkg -l | grep -q "$pkg"; then
      ndr_logInfo "🗑️ Removing $pkg..."
      sudo apt-get remove --assume-yes "$pkg"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "$pkg package not removed, please manually remove package before proceeding."
        return 1
      fi
    else
      ndr_logInfo "$pkg is not installed, skipping."
    fi
  done

  sudo apt-get autoremove --assume-yes
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to autoremove unused packages."
    #return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# returns 2 for usage or general error
# returns 1 for image not found
# returns 0 for image found
# usage: function <image:tag>
function ndr_verifyDockerImageExists () 
{
  local logSectionDesc="Verifying Docker Image Exists"
  ndr_logSecStartDebug "$logSectionDesc"

  local retVal=0

  if [[ $# -lt 1 ]]; then
    ndr_logWarn "Usage: ndr_verifyDockerImageExists <image:tag>"
    return 2
  fi

  local image_name="$1"
  
  # check for existance of optional image tag.
  local tagPresent=false
  if [[ "$image_name" == *:* ]]; then
    tagPresent=true
  fi

  # if image name was supplied with a "docker.io/library" prefix, remove it for local image searching since local images won't have that prefix in their name.
  if [[ "$image_name" == docker.io/library* ]]; then
    image_name="${image_name#docker.io/library/}"
  fi
  
  # Run command and capture both output and return status
  while true; do
    
    local output=$(docker images --format "{{.Repository}}:{{.Tag}}" 2>/dev/null)
    return_code=$?
    if [[ $return_code != 0 ]]; then
      ndr_logError "Failed to query for Docker images."
      retVal=2
      break
    fi

    # check if output is empty (no images at all present)
    if [[ -z "$output" ]]; then
      ndr_logInfo "No Docker images found."
      retVal=1
      break
    fi

    # there is output, check for target item.
    local matches
    if [[ "$tagPresent" == true ]]; then
      matches=$(echo "$output" | grep -Fx "$image_name")
    else
      matches=$(echo "$output" | grep -E "^${image_name}:")
    fi

    if [[ -n "$matches" ]]; then
      ndr_logInfo "✅ Docker image(s) found for '${image_name}':"
      echo "$matches"
      retVal=0
    else
      ndr_logInfo "No matching local Docker image(s) found for '${image_name}'."
      retVal=1
    fi
    
    break
  done
  
  ndr_logSecEndDebug "$logSectionDesc"

  return $retVal
}

# returns 2 for usage or general error
# returns 1 for container not found
# returns 0 for container found
# usage: function <container_name>
function ndr_verifyDockerContainerExists () 
{
  local logSectionDesc="Verifying Docker Container Exists"
  ndr_logSecStartDebug "$logSectionDesc"

  local retVal=0

  if [[ $# -lt 1 ]]; then
    ndr_logWarn "Usage: ndr_verifyDockerContainerExists <container_name>"
    return 2
  fi

  local container_name="$1"
  if [[ -z "$container_name" ]]; then
    echo "❌ Usage: ndr_verifyDockerContainerExists <container_name>"
    return 2
  fi

  # Capture the output and return code separately
  while true; do
    
    local output
    output=$(docker ps -a --format '{{.Names}}' 2>/dev/null)
    local status=$?

    # Check if docker failed
    if [[ $status -ne 0 ]]; then
      ndr_logError "Failed to query for Docker containers."
      retVal=2
      break
    fi

    # check if output is empty (no containers at all present)
    if [[ -z "$output" ]]; then
      ndr_logInfo "No Docker containers found."
      retVal=1
      break
    fi

    # there is output, check for target item.
    echo "$output" | grep -Fxq "$container_name"
    return_code=$?
    if [[ $return_code -eq 0 ]]; then
      ndr_logDebug "✅ Docker container '${container_name}' exists."
      retVal=0
    else
      ndr_logInfo "No matching container output returned for '${container_name}'."
      retVal=1
      break
    fi

    break
  done

  ndr_logSecEndDebug "$logSectionDesc"

  return $retVal
}

# usage: function <container_name> [container_port]
function ndr_verifyDockerContainerRunning () 
{
  local logSectionDesc="Verifying Docker Container is Running"
  ndr_logSecStartDebug "$logSectionDesc"

  local dockerContainerName="$1"
  local dockerContainerPort="${2:-}"
  
  # Validate argument count
  if [[ $# -lt 1 ]]; then
    ndr_logError "Usage: function <container_name> [container_port]"
    return 1
  fi

  # check if the container is running
  docker ps -a | grep "$dockerContainerName" | grep "Up"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Docker container [$dockerContainerName] is not running."
    return 2
  fi
  ndr_logInfo "Docker container [$dockerContainerName] is running."

  if [[ -z "$dockerContainerPort" ]]; then
    ndr_logInfo "Port not supplied for container [$dockerContainerName], skipping optional port and curl check."
  else
    local dockerContainerURL="http://localhost:$dockerContainerPort"

    # check if the container is running on specified container port
    docker ps -a | grep "$dockerContainerName" | grep "$dockerContainerPort"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logWarn "Docker container [$dockerContainerName] is NOT running on port $dockerContainerPort."
      return 1
    fi
    ndr_logInfo "Docker container [$dockerContainerName] is running on port $dockerContainerPort."
    
    # execute curl command to check if the container is running
    curl -s -o /dev/null -w "%{http_code}" "$dockerContainerURL"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logWarn "Failed to access the container at $dockerContainerURL"
      #todo, restore this once service can respond to curl return 1
    fi
    ndr_logInfo "Successfully accessed the container at $dockerContainerURL"
  fi

  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

# usage: function <image_name> [build_mode_options]
function ndr_cleanupDockerImage() 
{
  local logSectionDesc="Cleaning up Docker Image"
  ndr_logSecStart "$logSectionDesc"

  # Validate argument count
  if [[ $# -lt 1 ]]; then
    ndr_logError "Usage: function <image_name> [build_mode_options]"
    return 1
  fi

  local search_image_name="$1"
  if [[ -z "$search_image_name" ]]; then
    ndr_logWarn "Usage: function <image_name> [build_mode_options]"
    return 2
  fi
  
  local dockerAppManageOptions="${2:-$NDR_DOCKER_APP_MANAGE_OPTIONS_DEFAULT}"

  if [[ "$gNDR_RETAIN_DOCKER_IMAGES" == true ]]; then
    ndr_logInfo "Global flag to retain Docker images is set, skipping delete of [$search_image_name]"
    return 0
  fi

  local retVal=0
  
  # query for all images matching the name. Useful for older style image tags without embedded commit hash or datetime and for cleaning out all images with same base name.
  mapfile -t images < <(docker images --format "{{.Repository}}:{{.Tag}}" | grep "$search_image_name")

  ndr_logInfo "Found ${#images[@]} matching image [$search_image_name]"

  for image_name in "${images[@]}"; do
    ndr_logInfo "Removing image [$image_name]..."

    ndr_verifyDockerImageExists "$image_name"
    return_code=$?
    #2-error, 1-not found, 0-found
    if [[ $return_code != 0 ]]; then
      # skip if not found
      ndr_logInfo "Docker image '${image_name}' not found, no cleanup needed."
      #retVal=0
      #break
      continue
    fi
    
    # if option to remove without prompting is present, skip interactive prompt and remove.
    ndr_checkFlag "$dockerAppManageOptions" "$NDR_DOCKER_APP_MANAGE_OPTIONS_REMOVE_NO_PROMPT"
    return_code=$?
    if [[ $return_code != 0 ]]; then
      ndr_logInfo "Existing Docker image '${image_name}' found. Removing it will erase it permanently."
      read -p "Are you sure you want to proceed? [Y|n] " -n 1 -r
      echo    # Move to a new line
      if [[ $REPLY =~ ^[Nn]$ ]]; then
        ndr_logInfo "Skipping docker image removal."
        #retVal=0
        #break
        continue
      fi
    fi

    ndr_logInfo "🧹 Forcing removal of image '${image_name}'..."
    docker image rm -f "$image_name"
    return_code=$?
    if [[ $return_code != 0 ]]; then
      ndr_logError "Failed to remove image '${image_name}'."
      retVal=1
      #break
      continue
    fi
    ndr_logInfo "Docker image '${image_name}' removal command succeeded."

    docker buildx prune -f
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logWarn "Failed to prune docker build cache entries."
    fi
    ndr_logInfo "Successfully pruned docker build cache entries."

    ndr_verifyDockerImageExists "$image_name"
    return_code=$?
    #2-error, 1-not found, 0-found
    if [[ $return_code -eq 0 ]]; then
      # image still exists after removal attempt
      ndr_logError "Error, image still present after removal '${image_name}'."
      retVal=1
      #break
      continue
    fi

    ndr_logInfo "✅ Image '${image_name}' successfully removed and verified."

  done

  if [ "$retVal" -ne 0 ]; then
    ndr_logError "One or more errors encountered during image cleanup."
  fi

  ndr_logSecEnd "$logSectionDesc"

  #return 0
  return "$retVal"
}

# usage: function  <image_name> [build_mode_options]
function ndr_cleanupDockerContainer ()
{
  local logSectionDesc="Cleaning up Docker Container"
  ndr_logSecStart "$logSectionDesc"

  local retVal=0

  while true; do
    local container_name="$1"
    
    if [[ -z "$container_name" ]]; then
      ndr_logWarn "Usage: ndr_cleanupDockerContainer <container_name> [build_mode_options]"
      retVal=2
      break
    fi

    local dockerAppManageOptions="${2:-$NDR_DOCKER_APP_MANAGE_OPTIONS_DEFAULT}"

    ndr_verifyDockerContainerExists "$container_name"
    return_code=$?
    #2-error, 1-not found, 0-found
    if [[ $return_code != 0 ]]; then
      # skip if not found
      ndr_logInfo "Docker container '${container_name}' not found, nothing to remove."
      retVal=0
      break
    fi

     # if option to remove without prompting is present, skip interactive prompt and remove.
    ndr_checkFlag "$dockerAppManageOptions" "$NDR_DOCKER_APP_MANAGE_OPTIONS_REMOVE_NO_PROMPT"
    return_code=$?
    if [[ $return_code != 0 ]]; then
      ndr_logInfo "Existing Docker container '${container_name}' found. Removing it will erase it permanently."
      read -p "Are you sure you want to proceed? [Y|n] " -n 1 -r
      echo    # Move to a new line
      if [[ $REPLY =~ ^[Nn]$ ]]; then
        ndr_logInfo "Skipping docker container removal."
        retVal=0
        break
      fi
    fi

    ndr_logInfo "🛑 Stopping container '${container_name}', please wait..."

    docker stop "$container_name"
    return_code=$?
    if [[ $return_code != 0 ]]; then
      ndr_logWarn "Failed to stop Docker container '${container_name}'."
      #retVal=1
      #break
    fi

    ndr_logInfo "🧹 Removing container '${container_name}', please wait..."
    
    docker container rm -f "$container_name"
    return_code=$?
    if [[ $return_code != 0 ]]; then
      ndr_logError "Failed to remove Docker container '${container_name}'."
      retVal=1
      break
    fi
    ndr_logInfo "Docker container removal command succeeded."

    ndr_verifyDockerContainerExists "$container_name"
    return_code=$?
    #2-error, 1-not found, 0-found
    if [[ $return_code -eq 0 ]]; then
      ndr_logError "Error, container still present after removal '${container_name}'."
      retVal=1
      break
    fi

    ndr_logInfo "✅ Container '${container_name}' successfully removed and verified."

    break
  done
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# given a compose file, will attempt to clean up any containers and images related to the compose file. 
# This is useful for cleaning up old versions of the application before deploying a new version with the same compose file. 
# The function will attempt to query the compose file for container and image names to clean up and will fail if the compose file cannot be found or parsed for necessary information.
# The function will also respect global and passed in options for whether to prompt before deleting and whether to retain images.
# usage: function <compose_file> [build_mode_options]
function ndr_cleanupDockerApplications ()
{
  local logSectionDesc="Cleanup Docker Application"
  ndr_logSecStart "$logSectionDesc"

  # Validate argument count
  if [[ $# -lt 1 ]]; then
    ndr_logError "Usage: ndr_cleanupDockerApplication <compose_file> [build_mode_options]"
    return 1
  fi

  local compose_file="$1"
  local dockerAppManageOptions="${2:-$NDR_DOCKER_APP_MANAGE_OPTIONS_DEFAULT}"

  if [[ ! -f "$compose_file" ]]; then
    ndr_logWarn "Compose file [$compose_file] does not exist."
    return 0
  fi

  # get container folder from compose file path
  local containerFolder=""
  containerFolder=$(dirname "$compose_file")
  if [[ -z "$containerFolder" ]]; then
    ndr_logError "Failed to determine container folder from compose file path [$compose_file]."
    return 1
  fi

  # move from the install directory to the container/module directory
  cd "$containerFolder" || { ndr_logError "Failed to cd into $containerFolder"; return 1; }

  declare -a ndr_client_container_services_loc=()
  declare -A ndr_client_container_service_container_names_loc=()
  declare -A ndr_client_container_service_image_names_loc=()
  declare -A ndr_client_container_service_image_tags_loc=()

  ndr_ParseComposeFileServicesV2 "$compose_file" ndr_client_container_services_loc ndr_client_container_service_container_names_loc ndr_client_container_service_image_names_loc ndr_client_container_service_image_tags_loc
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to parse compose file [$compose_file] for service details."
    return 1
  fi

  if [[ ${#ndr_client_container_services_loc[@]} -eq 0 ]]; then
    ndr_logWarn "No services found in the compose file '$compose_file'."
    return 0
  fi
  
  #---------------------------------------------------------
  # For each service, read service details: image, container, etc:
  
  for service in "${ndr_client_container_services_loc[@]}"; do
    local dockerContainerName="${ndr_client_container_service_container_names_loc[$service]}"
    local dockerFullImageName="${ndr_client_container_service_image_names_loc[$service]}"
    local dockerImageTag="${ndr_client_container_service_image_tags_loc[$service]}"

    # query for full image tag in use by container
    #dockerImageName=$(ndr_QueryContainerImageVersionTag "$dockerContainerName") # only retrieves the version part of the image tag, not the full tag with the image base name. This will cause the code to prune any other image with that version tag.
    dockerImageName=$(ndr_QueryContainerImageName "$dockerContainerName")
    return_code=$?
    if [[ "$return_code" -ne 0 || -z "$dockerImageName" ]]; then
      ndr_logWarn "Failed to query for image tag in use by container [$dockerContainerName], image may not be present and/or image cleanup may not succeed."
      dockerImageName="$dockerImageBaseName:$dockerImageVersion"
    fi

    if (( dockerAppManageOptions & NDR_DOCKER_APP_MANAGE_OPTIONS_CONTAINER )); then
      # remove any existing Docker container with the same name
      ndr_cleanupDockerContainer "$dockerContainerName" "$dockerAppManageOptions"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "Failed to remove existing Docker container."
        return 1
      fi
    fi

    if (( dockerAppManageOptions & NDR_DOCKER_APP_MANAGE_OPTIONS_IMAGE )); then
      # remove any existing image with the same name
      ndr_cleanupDockerImage "$dockerFullImageName" "$dockerAppManageOptions"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "Failed to remove existing Docker image."
        return 1
      fi
    fi
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function <folder> <image_name> <image_version> <container_name> [build_mode_options]
function ndr_cleanupDockerApplication ()
{
  local logSectionDesc="Cleanup Docker Application"
  ndr_logSecStart "$logSectionDesc"

  local containerFolder="$1"
  local dockerImageBaseName="$2"
  local dockerImageVersion="$3"
  local dockerImageName="$dockerImageBaseName_$dockerImageVersion"
  local dockerContainerName="$4"
  
  local dockerAppManageOptions="${5:-$NDR_DOCKER_APP_MANAGE_OPTIONS_DEFAULT}"

  # Validate argument count
  if [[ $# -lt 4 ]]; then
    ndr_logError "Usage: ndr_cleanupDockerApplication <folder> <image_name> <image_version> <container_name> [build_mode_options]"
    return 1
  fi

  if [[ ! -d "$containerFolder" ]]; then
    ndr_logWarn "Container path [$containerFolder] does not exist."
    return 0
  fi

  # move from the install directory to the container/module directory
  cd "$containerFolder" || { ndr_logError "Failed to cd into $containerFolder"; return 1; }

  # query for full image tag in use by container
  #dockerImageName=$(ndr_QueryContainerImageVersionTag "$dockerContainerName") # only retrieves the version part of the image tag, not the full tag with the image base name. This will cause the code to prune any other image with that version tag.
  dockerImageName=$(ndr_QueryContainerImageName "$dockerContainerName")
  return_code=$?
  if [[ "$return_code" -ne 0 || -z "$dockerImageName" ]]; then
    ndr_logWarn "Failed to query for image tag in use by container [$dockerContainerName], image may not be present and/or image cleanup may not succeed."
    dockerImageName="$dockerImageBaseName:$dockerImageVersion"
  else
    ndr_logInfo "Docker image in use by container [$dockerContainerName] is [$dockerImageName]."
  fi

  if (( (dockerAppManageOptions & NDR_DOCKER_APP_MANAGE_OPTIONS_CONTAINER) || (dockerAppManageOptions & NDR_DOCKER_APP_MANAGE_OPTIONS_CONTAINER_OPTIONAL) )); then
    # remove any existing Docker container with the same name
    ndr_cleanupDockerContainer "$dockerContainerName" "$dockerAppManageOptions"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to remove existing Docker container."
      return 1
    fi
  fi

  if (( dockerAppManageOptions & NDR_DOCKER_APP_MANAGE_OPTIONS_IMAGE )); then
    # remove any existing image with the same name
    ndr_cleanupDockerImage "$dockerImageName" "$dockerAppManageOptions"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to remove existing Docker image."
      return 1
    fi
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# prepares the container for running by performing whatever steps needed to prepare and configure before running.
# usage: function <folder> <image_name> <image_version> <container_name> [build_mode_options]
function ndr_prepareDockerApplicationContainer ()
{
  local logSectionDesc="Preparing Docker Application Container"
  ndr_logSecStart "$logSectionDesc"

  local containerFolder="$1"
  local dockerImageBaseName="$2"
  local dockerImageVersion="$3"
  local dockerImageVersionCleanup=$gINSTALLED_VERSION
  local dockerImageName="$dockerImageBaseName:$dockerImageVersion"
  local dockerContainerName=$4
  
  local dockerAppManageOptions="${5:-$NDR_DOCKER_APP_MANAGE_OPTIONS_NONE}"

  # Validate argument count
  if [[ $# -lt 4 ]]; then
    ndr_logError "Usage: function <folder> <image_name> <image_version> <container_name> [build_mode_options]"
    return 1
  fi

  # move from the install directory to the container/module directory
  #cd "$containerFolder" || { ndr_logError "Failed to cd into $containerFolder"; return 1; }
  
  dockerAppManageOptions=$(( dockerAppManageOptions | NDR_DOCKER_APP_MANAGE_OPTIONS_CONTAINER | NDR_DOCKER_APP_MANAGE_OPTIONS_REMOVE_NO_PROMPT ))

  # remove any existing Docker container with the same name
  ndr_cleanupDockerApplication "$containerFolder" "$dockerImageBaseName" "$dockerImageVersionCleanup" "$dockerContainerName" "$dockerAppManageOptions"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to remove existing Docker application container."
    return 1
  fi

  # populate host address before env file construction.
  ndr_PopulateHostAddress
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to populate host address."
    return 1
  fi

  # construct env file
  ndr_BuildModuleEnvFileV2 "$containerFolder" "$dockerImageBaseName"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to build module env file for [$containerFolder]."
    return 1
  fi

  # construct the compose file
  ndr_BuildModuleComposeFile "$containerFolder" "$dockerImageBaseName"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to customize module compose file for [$containerFolder]."
    return 1
  fi
  
  # create the bridge network if it does not exist
  ndr_createDockerBridgeNetwork
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to create Docker bridge network."
    return 1
  fi
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# runs a fully prep'd container, or restarts one already created.
# usage: function <folder> <image_name> <image_version> <container_name> <container_port> [build_mode_options]
function ndr_runDockerApplicationContainer ()
{
  local logSectionDesc="Running Docker Application Container"
  ndr_logSecStart "$logSectionDesc"

  local containerFolder="$1"
  local dockerImageBaseName="$2"
  local dockerImageVersion="$3"
  local dockerImageName="$dockerImageBaseName:$dockerImageVersion"
  local dockerContainerName=$4
  local dockerContainerPort=$5
  local dockerContainerURL="http://localhost:$dockerContainerPort"

  local dockerAppManageOptions="${6:-$NDR_DOCKER_APP_MANAGE_OPTIONS_NONE}"

  # Validate argument count
  if [[ $# -lt 5 ]]; then
    ndr_logError "Usage: function <folder> <image_name> <image_version> <container_name> <container_port> [build_mode_options]"
    return 1
  fi

  # move from the install directory to the container/module directory
  cd "$containerFolder" || { ndr_logError "Failed to cd into $containerFolder"; return 1; }
  
  # Check if the .env file exists. 
  # env file is needed for both container start modes to either be an explicit input (run mode) or implicitly linked to compose file (compose mode).
  local envFile="${containerFolder}/${gNDR_ENV_TARGET_FILENAME}"
  if [[ ! -f "$envFile" ]]; then
    ndr_logError "env file '$envFile' not found."
    return 1
  fi
    
  # Check if the compose file exists
  local composeFile="${containerFolder}/${NDR_STANDARD_DOCKER_COMPOSEFILE_FILENAME}"
  if [[ ! -f "$composeFile" ]]; then
    ndr_logError "Compose file '$composeFile' not found."
    return 1
  fi

  docker compose up -d 
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to run Docker container [$dockerContainerName]."
    return 1
  fi

  # check if the newly built Docker container exists
  ndr_verifyDockerContainerExists "$dockerContainerName"
  return_code=$?
  #2-error, 1-not found, 0-found
  if [ $return_code -ne 0 ]; then
    ndr_logError "Docker container verification failed."
    return 1
  fi

  # check if the container is running
  ndr_verifyDockerContainerRunning "$dockerContainerName" "$dockerContainerPort"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Docker container [$dockerContainerName] is not running."
    return 1
  fi
  
  ndr_logInfo "Docker container [$dockerContainerName] is running and accessible at [$dockerContainerURL]"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_postExecDockerApplicationContainer ()
{
  local logSectionDesc="Post exec Docker Application Container"
  ndr_logSecStart "$logSectionDesc"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function <folder> <image_name> <image_version> <container_name> <container_port> [build_mode_options]
function ndr_ComposeDockerApplicationContainer ()
{
  local logSectionDesc="Composing Docker Application Container"
  ndr_logSecStart "$logSectionDesc"

  local containerFolder="$1"
  local dockerImageBaseName="$2"
  local dockerImageVersion="$3"
  local dockerImageName="$dockerImageBaseName:$dockerImageVersion"
  local dockerContainerName=$4
  local dockerContainerPort=$5
  local dockerContainerURL="http://localhost:$dockerContainerPort"

  local dockerAppManageOptions="${6:-$NDR_DOCKER_APP_MANAGE_OPTIONS_NONE}"

  # Validate argument count
  if [[ $# -lt 5 ]]; then
    ndr_logError "Usage: function <folder> <image_name> <image_version> <container_name> <container_port> [build_mode_options]"
    return 1
  fi

  # prepare container for running
  if (( dockerAppManageOptions & NDR_DOCKER_APP_MANAGE_OPTIONS_SKIP_PREPARE )); then
    ndr_logInfo "Skipping preparation of Docker container [$dockerContainerName] as requested."
  else
    ndr_prepareDockerApplicationContainer "$containerFolder" "$dockerImageBaseName" "$dockerImageVersion" "$dockerContainerName"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to prepare Docker container [$dockerContainerName]."
      return 1
    fi
  fi

  # run container
  ndr_runDockerApplicationContainer "$containerFolder" "$dockerImageBaseName" "$dockerImageVersion" "$dockerContainerName" "$dockerContainerPort"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to run Docker container [$dockerContainerName]."
    return 1
  fi

  # post exec cleanup
  ndr_postExecDockerApplicationContainer
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to run post exec on Docker container [$dockerContainerName]."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# prepares the container for running by performing whatever steps needed to prepare and configure before running.
# usage: function <app_folder> <compose_file> [build_mode_options]
function ndr_prepareDockerApplicationContainers ()
{
  local logSectionDesc="Preparing Docker Application Containers"
  ndr_logSecStart "$logSectionDesc"

  # Validate argument count
  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <app_folder> <compose_file> [build_mode_options]"
    return 1
  fi

  local application_folder="$1"
  local compose_file="$2"
  local dockerAppManageOptions="${3:-$NDR_DOCKER_APP_MANAGE_OPTIONS_NONE}"
  dockerAppManageOptions=$(( dockerAppManageOptions | NDR_DOCKER_APP_MANAGE_OPTIONS_CONTAINER | NDR_DOCKER_APP_MANAGE_OPTIONS_REMOVE_NO_PROMPT ))

  # check if the compose file exists
  if [[ ! -f "$compose_file" ]]; then
    ndr_logError "Compose file '$compose_file' not found."
    return 1
  fi
  
  # remove any existing Docker container with the same name
  ndr_cleanupDockerApplications "$compose_file" "$dockerAppManageOptions"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to remove existing Docker application container."
    return 1
  fi

  # populate host address before env file construction.
  ndr_PopulateHostAddress
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to populate host address."
    return 1
  fi

  # construct env file
  ndr_BuildModuleEnvFileV2 "$application_folder" "$NDR_CLIENT_APPLICATION_NAME"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to build module env file for [$NDR_CLIENT_APPLICATION_NAME]."
    return 1
  fi

  # create the bridge network if it does not exist
  # DEPRECATED due to all bridge networking being handled by the compose file.
  if false; then
  ndr_createDockerBridgeNetwork
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to create Docker bridge network."
    return 1
  fi
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# runs fully prep'd containers, or restarts those already created.
# usage: function <app_folder> <compose_file> [build_mode_options]
function ndr_runDockerApplicationContainers ()
{
  local logSectionDesc="Running Docker Application Containers"
  ndr_logSecStart "$logSectionDesc"

  # Validate argument count
  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <app_folder> <compose_file> [build_mode_options]"
    return 1
  fi

  local application_folder="$1"
  local compose_file="$2"
  local dockerAppManageOptions="${3:-$NDR_DOCKER_APP_MANAGE_OPTIONS_NONE}"

  # move from the install directory to the container/module directory
  cd "$application_folder" || { ndr_logError "Failed to cd into $application_folder"; return 1; }
  
  # Check if the .env file exists. 
  # env file is needed for both container start modes to either be an explicit input (run mode) or implicitly linked to compose file (compose mode).
  local envFile="${application_folder}/${gNDR_ENV_TARGET_FILENAME}"
  if [[ ! -f "$envFile" ]]; then
    ndr_logError "env file '$envFile' not found."
    return 1
  fi
    
  # Check if the compose file exists
  if [[ ! -f "$compose_file" ]]; then
    ndr_logError "Compose file '$compose_file' not found."
    return 1
  fi

  if (( "$dockerAppManageOptions" & NDR_DOCKER_APP_MANAGE_OPTIONS_START_EXISTING )); then
    ndr_logInfo "Starting Docker containers with compose file [$compose_file]..."
    docker compose start
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to start Docker containers for compose file [$compose_file]."
      return 1
    fi
  else
    ndr_logInfo "Running Docker containers with compose file [$compose_file]..."
    docker compose up -d 
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to compose Docker containers for compose file [$compose_file]."
      return 1
    fi
  fi

  declare -a ndr_client_container_services_loc=()
  declare -A ndr_client_container_service_container_names_loc=()
  declare -A ndr_client_container_service_image_names_loc=()
  declare -A ndr_client_container_service_image_tags_loc=()

  ndr_ParseComposeFileServicesV2 "$compose_file" ndr_client_container_services_loc ndr_client_container_service_container_names_loc ndr_client_container_service_image_names_loc ndr_client_container_service_image_tags_loc
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to parse compose file [$compose_file] for service details."
    return 1
  fi

  if [[ ${#ndr_client_container_services_loc[@]} -eq 0 ]]; then
    ndr_logWarn "No services found in the compose file '$compose_file'."
    return 0
  fi
  
  #---------------------------------------------------------
  # For each service, read service details: image, container, etc:
  ndr_logInfo "Performing per-service processing and customization."
  
  for service in "${ndr_client_container_services_loc[@]}"; do
    local dockerContainerName="${ndr_client_container_service_container_names_loc[$service]}"
    local dockerFullImageName="${ndr_client_container_service_image_names_loc[$service]}"
    local dockerImageTag="${ndr_client_container_service_image_tags_loc[$service]}"

    # check if the newly built Docker container exists
    ndr_verifyDockerContainerExists "$dockerContainerName"
    return_code=$?
    #2-error, 1-not found, 0-found
    if [ $return_code -ne 0 ]; then
      ndr_logError "Docker container verification failed."
      return 1
    fi

    # check if the container is running
    ndr_verifyDockerContainerRunning "$dockerContainerName"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Docker container [$dockerContainerName] is not running."
      return 1
    fi

    ndr_logInfo "Docker container [$dockerContainerName] is composed and running."
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_postExecDockerApplicationContainers ()
{
  local logSectionDesc="Post exec Docker Application Containers"
  ndr_logSecStart "$logSectionDesc"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_stopDockerApplicationContainers ()
{
  local logSectionDesc="Stopping Docker Application Containers"
  ndr_logSecStart "$logSectionDesc"

  # Validate argument count
  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <app_folder> <compose_file> [build_mode_options]"
    return 1
  fi

  local application_folder="$1"
  local compose_file="$2"
  local dockerAppManageOptions="${3:-$NDR_DOCKER_APP_MANAGE_OPTIONS_NONE}"

  if [[ ! -d "$application_folder" ]]; then
    ndr_logWarn "Application path [$application_folder] does not exist."
    return 0
  fi
  
  # move from the install directory to the container/module directory
  cd "$application_folder" || { ndr_logError "Failed to cd into $application_folder"; return 1; }
  
  # Check if the compose file exists
  if [[ ! -f "$compose_file" ]]; then
    ndr_logError "Compose file '$compose_file' not found."
    return 1
  fi

  ndr_logInfo "Stopping Docker containers with compose file [$compose_file]..."
  docker compose stop
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to stop Docker containers for compose file [$compose_file]."
    return 1
  fi
  
  declare -a ndr_client_container_services_loc=()
  declare -A ndr_client_container_service_container_names_loc=()
  declare -A ndr_client_container_service_image_names_loc=()
  declare -A ndr_client_container_service_image_tags_loc=()

  ndr_ParseComposeFileServicesV2 "$compose_file" ndr_client_container_services_loc ndr_client_container_service_container_names_loc ndr_client_container_service_image_names_loc ndr_client_container_service_image_tags_loc
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to parse compose file [$compose_file] for service details."
    return 1
  fi

  if [[ ${#ndr_client_container_services_loc[@]} -eq 0 ]]; then
    ndr_logWarn "No services found in the compose file '$compose_file'."
    return 0
  fi
  
  #---------------------------------------------------------
  # For each service, read service details: image, container, etc:
  ndr_logInfo "Performing per-service processing and customization."
  
  for service in "${ndr_client_container_services_loc[@]}"; do
    local dockerContainerName="${ndr_client_container_service_container_names_loc[$service]}"
    local dockerFullImageName="${ndr_client_container_service_image_names_loc[$service]}"
    local dockerImageTag="${ndr_client_container_service_image_tags_loc[$service]}"

    # check if the container is running
    ndr_verifyDockerContainerRunning "$dockerContainerName"
    return_code=$?
    if [ $return_code != 1 ]; then
      ndr_logError "Unable to stop Docker container [$dockerContainerName]."
      #return 1
    fi

    ndr_logInfo "Docker container [$dockerContainerName] is STOPPED."
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# used for composing multiple containers together with a compose file.
# the compose file will be expected to be already customized and ready to go, this function is just for running the compose file and doing any post exec steps needed. 
# This is useful for scenarios where multiple containers need to be composed together. 
# usage: function <folder> <compose_file> [build_mode_options]
function ndr_ComposeDockerApplicationContainers ()
{
  local logSectionDesc="Composing Docker Application Containers"
  ndr_logSecStart "$logSectionDesc"

  # Validate argument count
  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <folder> <compose_file> [build_mode_options]"
    return 1
  fi
  
  local application_folder="$1"
  local compose_file="$2"
  local dockerAppManageOptions="${3:-$NDR_DOCKER_APP_MANAGE_OPTIONS_NONE}"

  if [[ ! -d "$application_folder" ]]; then
    ndr_logWarn "Application path [$application_folder] does not exist."
    return 0
  fi
  
  if [[ ! -f "$compose_file" ]]; then
    ndr_logWarn "Compose file [$compose_file] does not exist."
    return 0
  fi

  # prepare container for running
  ndr_prepareDockerApplicationContainers "$application_folder" "$compose_file"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to prepare Docker containers for compose file [$compose_file]."
    return 1
  fi

  # run container
  ndr_runDockerApplicationContainers "$application_folder" "$compose_file"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to run Docker containers for compose file [$compose_file]."
    return 1
  fi

  # post exec cleanup
  ndr_postExecDockerApplicationContainers "$application_folder" "$compose_file"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to run post exec on Docker containers for compose file [$compose_file]."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_scrubAllDockerResources ()
{
  local logSectionDesc="Force Removing All Local Docker Resources"
  ndr_logSecStart "$logSectionDesc"  

  if [ "$gEXPRESS_MODE" == false ]; then
    ndr_logInfo "ALL existing local Docker resources will be removed, both active and inactive. Warning, this action cannot be undone!"
    read -p "Are you sure you want to proceed? [y|N] " -n 1 -r
    echo    # Move to a new line
    if [[ $REPLY =~ ^[Yy]$ ]]; then
      ndr_logInfo "Proceeding with all local Docker resource removal."
    else
      ndr_logInfo "Operation cancelled, returning to main menu."
      return 0
    fi
  fi

  # docker cleanup
  # https://stackoverflow.com/questions/45357771/stop-and-remove-all-docker-containers

  #Stop all the containers
  docker stop $(docker ps -a -q)
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Error encountered with docker stop."
  fi

  #Remove all the containers
  docker rm -f $(docker ps -a -q)
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Error encountered with docker rm."
  fi

  #Deleting no longer needed containers (stopped)
  docker container prune -f
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Error encountered with docker container prune."
  fi

  #Deleting no longer needed images which means, that it only deletes images, which are not tagged and are not pointed on by "latest" - so no real images you can regularly use are deleted
  if [ "$gNDR_RETAIN_DOCKER_IMAGES" == false ]; then
    docker image prune -a -f
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logWarn "Error encountered with docker image prune."
    fi
  else
    ndr_logInfo "Skipping Docker image prune due to global retain image option being enabled."
  fi

  #Delete all volumes, which are not used by any existing container ( even stopped containers do claim volumes ). 
  # This usually cleans up dangling anon-volumes of containers have been deleted long time ago. 
  # It should never delete named volumes since the containers of those should exists / be running. 
  # Be careful, ensure your stack at least is running before going with this one
  docker volume prune -f
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Error encountered with docker volume prune."
  fi

  #Same for unused networks
  docker network prune -f
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Error encountered with docker network prune."
  fi

  #And finally, if you want to get rid if all the trash - to ensure nothing happens to your production, be sure all stacks are running and then run
  docker system prune -f
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Error encountered with docker system prune."
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function [compose_file_path] [service_name] [is_owned_ref]
# [is_owned_ref] is passed by reference and will be set to true if service is owned by NextDR, false if not owned, or blank if ownership cannot be determined due to error. 
# Caller should check return code for error and not rely on is_owned_ref value if error return code is returned.
function ndr_IsDockerServiceNextDROwned ()
{
  local logSectionDesc="Checking if Docker Service is $gCOMPANY_NAME Owned"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 3 ]]; then
    ndr_logWarn "Usage: function [compose_file_path] [service_name] [is_owned_ref]"
    return 1
  fi
  local compose_file=$1
  local service_name=$2
  local -n is_owned_ref=$3
  
  is_owned_ref="" # default to blank for undetermined ownership in case of error
  
  if [[ ! -f "$compose_file" ]]; then
    ndr_logError "Compose file not found: $compose_file"
    return 1
  fi

  # Check if the service is owned by NextDR by looking for the label in the compose file
  local is_owned=$(yq eval ".services.\"$service_name\".labels.\"ai.nextdr.owned\" // \"\"" "$compose_file")
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to check ownership of service '$service_name'"
    return 1
  fi

  if [[ "$is_owned" == "false" ]]; then
    is_owned_ref="false"
    ndr_logDebug "Service '$service_name' is NOT owned by $gCOMPANY_NAME."
  else
    is_owned_ref="true"
    ndr_logDebug "Service '$service_name' is OWNED by $gCOMPANY_NAME."
  fi
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}


# given an NDR image tag, we can parse out the version details and update the requisite global variables (commit hash and timestamp).
# image tag can be complete, just the tag or just the version, but it must contain the version and commit hash in order to parse out the details and update the global variables.
# usage: function <image_tag>
function ndr_UpdateProductVersionDetails ()
{
  local logSectionDesc="Updating product version details from image tag"
  ndr_logSecStart "$logSectionDesc"
  
  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <image_tag>"
    return 1
  fi

  local imageName="$1"
  local version=""
  local hash=""
  local timestamp=""

  # parse the image version tag into the ndr versioning parts
  ndr_ParseImageTagVersionParts "$imageName" version hash timestamp
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to parse image version tag parts from [$imageName]."
    return 1
  fi

  # update global variables with the parsed details only if they are newer than the existing ones (based on the timestamp).
  # this handles the case where we may be calling this function multiple times for different images but we only want to update to the latest version details across all images.
  if [[ $timestamp -le "$gNDR_PRODUCT_VERSION_TIMESTAMP" ]]; then
    ndr_logInfo "Parsed version timestamp [$timestamp] from image [$imageName] is not newer than existing version timestamp [$gNDR_PRODUCT_VERSION_TIMESTAMP], skipping update of product version details."
    return 0
  fi

  #gNDR_PRODUCT_VERSION="$version"
  NDR_GIT_REPO_COMMIT_HASH_SHORT="$hash"
  NDR_GIT_REPO_COMMIT_TIMESTAMP="$timestamp"

  ndr_logInfo "Updated product version details from image [$imageName]: hash [$NDR_GIT_REPO_COMMIT_HASH_SHORT], timestamp [$NDR_GIT_REPO_COMMIT_TIMESTAMP]."

  ndr_logSecEnd "$logSectionDesc"
  
  return 0
}

# usage: function <compose_file_path> <service_name> <full_image_name>
# full image name should be in the format of [repo_account]/[repo_name]:[image_tag]
# in the case of NDR, [repo_account]/[repo_name]:image_base_name]_[version_tag]
function ndr_UpdateComposeFileServiceImage ()
{
  local logSectionDesc="Updating Docker Compose File Service Details"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 3 ]]; then
    ndr_logWarn "Usage: function <compose_file_path> <service_name> <full_image_name>"
    return 1
  fi

  local compose_file=$1
  local service_name=$2
  local full_image_name=$3

  if [[ ! -f "$compose_file" ]]; then
    ndr_logError "Compose file not found: $compose_file"
    return 1
  fi

  # Update the image field for the specified service in the compose file using yq
  yq eval -i ".services.\"$service_name\".image = \"$full_image_name\"" "$compose_file"
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to update image for service '$service_name' in $compose_file"
    return 1
  fi

  ndr_logDebug "Successfully updated image for service '$service_name' to '$full_image_name' in $compose_file"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# Function to parse details of a given service
# Usage: function [compose_file_path] [service_name] [container_name_ref] [image_name_ref] [version_tag_ref]"
# note, compose file is standard input variable. All arrays are passed as a name-ref.
function ndr_ParseComposeFileServiceDetailsV2 () 
{
  if [[ $# -lt 5 ]]; then
    ndr_logWarn "Usage: function [compose_file_path] [service_name] [container_name_ref] [image_name_ref] [version_tag_ref]"
    return 1
  fi

  local compose_file=$1
  local service=$2
  # Pass-by-reference array
  local -n container_ref=$3
  local -n image_ref=$4
  local -n version_tag_ref=$5

  if [[ ! -f "$compose_file" ]]; then
    ndr_logError "Compose file not found: $compose_file"
    return 1
  fi

  # Extract container_name, image full string

  container_ref=$(yq eval ".services.\"$service\".container_name // \"\"" "$compose_file")
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to parse container_name for service '$service'"
    return 1
  fi

  image_ref=$(yq eval ".services.\"$service\".image // \"\"" "$compose_file")
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to parse image for service '$service'" >&2
    return 1
  fi

  # Split image into name and tag by ':'
  if [[ "$image_ref" != *:* ]]; then
    ndr_logError "Image field for service '$service' does not contain a tag. Expected format '[repo_account]/[repo_name]:[image_tag]'. Found: '$image_ref'"
    return 1
  fi
  
  version_tag_ref="${image_ref##*:}"
  
  return 0
}

# compose file parsing options
export gNDR_PARSE_COMPOSE_FILE_OPTIONS_NONE=0
export gNDR_PARSE_COMPOSE_FILE_OPTIONS_APPEND=0x1 # if set, will append unique services and overwrite existing entries in the service array instead of clearing them first. This allows for multiple calls to the parse function for different compose files while maintaining a cumulative and unique list of services and details across all compose files parsed. If not set, global arrays will be cleared before parsing the compose file.

# Function to parse top-level services and populate global arrays with their details
# Usage: ndr_ParseComposeFileServicesV2 [compose_file_path] [service_array] [container_name_array] [image_name_array] [image_tag_array] <options>"
# note, compose file is standard input variable. All arrays are passed as a name-ref.
function ndr_ParseComposeFileServicesV2 () 
{
  local logSectionDesc="Parsing Compose File Services"
  ndr_logSecStart "$logSectionDesc"  

  if [[ $# -lt 5 ]]; then
    ndr_logWarn "Usage: function <compose_file_path>"
    return 1
  fi

  local compose_file="$1"
  # Pass-by-reference arrays
  local -n services_ref="$2"
  local -n containers_ref="$3"
  local -n images_ref="$4"
  local -n version_tags_ref="$5"
  local options="${6:-$gNDR_PARSE_COMPOSE_FILE_OPTIONS_NONE}"
  
  # if the services array is not empty and append is not set, return success without parsing since we do not want to overwrite existing data. If append is set, we will parse and add to the existing arrays.
  if [[ ${#services_ref[@]} -gt 0 ]] && ! (( "$options" & gNDR_PARSE_COMPOSE_FILE_OPTIONS_APPEND )); then
    ndr_logInfo "Services array is not empty [${#services_ref[@]}] and append option is not set, skipping parsing of compose file [$compose_file]."
    return 0
  fi

  # if the compose file does not exist, return error
  if [[ ! -f "$compose_file" ]]; then
    ndr_logError "Compose file not found: $compose_file"
    return 1
  fi

  if (( "$options" & gNDR_PARSE_COMPOSE_FILE_OPTIONS_APPEND )) ; then
    ndr_logInfo "Append option is set, existing contents of input arrays will be preserved and new services from compose file [$compose_file] will be added to the arrays."
  else
    ndr_logInfo "Append option is not set, existing contents of input arrays will be cleared before parsing compose file [$compose_file]."
    # Clear previous contents
    services_ref=()
    containers_ref=()
    images_ref=()
    version_tags_ref=()
  fi

  # Extract service names using yq (expects yq v4+)
  mapfile -t services_tmp < <(yq eval '.services | keys | .[]' "$compose_file")
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to parse services from $compose_file"
    return 1
  fi

  ndr_logInfo "Found ${#services_tmp[@]} services in the compose file '$compose_file'."

  if [[ ${#services_tmp[@]} -eq 0 ]]; then
    ndr_logWarn "No services found in the compose file '$compose_file'."
    return 0
  fi

  # For each service, call details parser
  for service in "${services_tmp[@]}"; do

    # determine if servive entry already exists in the main array or if its a new entry. If it already exists, we will overwrite the details, if it is a new entry, we will add it to the main array. This allows us to maintain a cumulative list of unique services across multiple compose files while ensuring we have the latest details for each service.
    local found=false
    for svc_search in "${services_ref[@]}"; do
      if [[ "$svc_search" == "$service" ]]; then
          found=true
          break
      fi
    done

    if [[ "$found" == false ]]; then
      ndr_logDebug "Service '$service' is a new entry and will be added to the services array."
      services_ref+=("$service")
    else
      ndr_logDebug "Service '$service' already exists in the services array and will be updated with the latest details from the compose file."
    fi

    local container
    local image
    local version_tag

    ndr_ParseComposeFileServiceDetailsV2 "$compose_file" "$service" container image version_tag
    return_code=$?
    if [[ $return_code != 0 ]]; then
      ndr_logError "Failed to parse service details for '$service' in $compose_file"
      return 1
    fi

    # Save to global associative arrays keyed by service name
    containers_ref["$service"]="$container"
    images_ref["$service"]="$image"
    version_tags_ref["$service"]="$version_tag"
  done

  if [[ "$gDEBUG_MODE" == true ]]; then
    if  [[ ${#services_ref[@]} -ne 0 ]]; then  
      echo "-----------------------------------------------------------------------------------------"
      echo "Parsed Docker Compose Services in [$compose_file]:"
      echo "-----------------------------------------------------------------------------------------"

      for service in "${services_ref[@]}"; do
        # Output
        echo "Service: $service"
        echo "  Container Name: ${containers_ref[$service]}"
        echo "  Image Name    : ${images_ref[$service]}"
        echo "  Image Tag     : ${version_tags_ref[$service]}"
        echo
      done

      echo "-----------------------------------------------------------------------------------------"
    fi
  fi

  ndr_logInfo "Successfully parsed Docker compose file [$compose_file] service entries."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# Function to parse details of a given service
function ndr_ParseComposeFileServiceDetails () 
{
  if [[ $# -ne 2 ]]; then
    ndr_logWarn "Usage: function <compose_file_path> <service_name>"
    return 1
  fi

  local compose_file=$1
  local service=$2

  # Extract container_name, image full string (name:tag)
  local container_name image_full image_name image_tag

  container_name=$(yq eval ".services.\"$service\".container_name // \"\"" "$compose_file")
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to parse container_name for service '$service'"
    return 1
  fi

  image_full=$(yq eval ".services.\"$service\".image // \"\"" "$compose_file")
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to parse image for service '$service'" >&2
    return 1
  fi

  # If no image defined, leave blank
  if [[ -z "$image_full" ]]; then
    image_name=""
    image_tag=""
  else
    # Split image_full into name and tag by ':'
    if [[ "$image_full" == *:* ]]; then
      image_name="${image_full%%:*}"
      image_tag="${image_full##*:}"
    else
      image_name="$image_full"
      image_tag="latest"
    fi
  fi

  # Save to global associative arrays keyed by service name
  ndr_supabase_container_service_container_names["$service"]="$container_name"
  ndr_supabase_container_service_image_names["$service"]="$image_name"
  ndr_supabase_container_service_image_tags["$service"]="$image_tag"

  return 0
}

# Function to parse top-level services and populate global arrays with their details
# Usage: ndr_ParseComposeFileServices [compose_file_path] <options>"
function ndr_ParseComposeFileServices () 
{
  local logSectionDesc="Parsing Compose File Services"
  ndr_logSecStart "$logSectionDesc"  

  if [[ $# -lt 1 ]]; then
    ndr_logWarn "Usage: function [compose_file_path] <options>"
    return 1
  fi

  local compose_file=$1
  local options="${2:-$gNDR_PARSE_COMPOSE_FILE_OPTIONS_NONE}"

  if [[ ! -f "$compose_file" ]]; then
    ndr_logError "Compose file not found: $compose_file"
    return 1
  fi

  # Clear previous contents
  ndr_supabase_container_services=()
  ndr_supabase_container_service_container_names=()
  ndr_supabase_container_service_image_names=()
  ndr_supabase_container_service_image_tags=()

  # use v2 implementation
  ndr_ParseComposeFileServicesV2 "$compose_file" ndr_supabase_container_services ndr_supabase_container_service_container_names ndr_supabase_container_service_image_names ndr_supabase_container_service_image_tags "$options"
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logWarn "Failed to parse compose file [$compose_file] for service details. Reverting to v1 parsing."
  else
    ndr_logDebug "Successfully parsed compose file [$compose_file] for service details using v2 implementation."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # Extract service names using yq (expects yq v4+)
  mapfile -t ndr_supabase_container_services < <(yq eval '.services | keys | .[]' "$compose_file")
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to parse services from $compose_file"
    return 1
  fi

  ndr_logInfo "Found ${#ndr_supabase_container_services[@]} services in the compose file '$compose_file'."

  # For each service, call details parser
  for svc in "${ndr_supabase_container_services[@]}"; do
    ndr_ParseComposeFileServiceDetails "$compose_file" "$svc"
    return_code=$?
    if [[ $return_code != 0 ]]; then
      ndr_logError "Failed to parse service details for '$svc' in $compose_file"
      return 1
    fi
  done

  if [[ "$gDEBUG_MODE" == true ]]; then
    if  [[ ${#ndr_supabase_container_services[@]} -ne 0 ]]; then  
      echo "-----------------------------------------------------------------------------------------"
      echo "Parsed Docker Compose Services in [$compose_file]:"
      echo "-----------------------------------------------------------------------------------------"

      for svc in "${ndr_supabase_container_services[@]}"; do
        # Output
        echo "Service: $svc"
        echo "  Container Name: ${ndr_supabase_container_service_container_names[$svc]}"
        echo "  Image Name    : ${ndr_supabase_container_service_image_names[$svc]}"
        echo "  Image Tag     : ${ndr_supabase_container_service_image_tags[$svc]}"
        echo
      done

      echo "-----------------------------------------------------------------------------------------"
    fi
  fi

  ndr_logInfo "Successfully parsed Docker compose file [$compose_file] service entries."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function [build_mode_options]
function ndr_createDockerBridgeNetwork ()
{
  local logSectionDesc="Create Docker Bridge Network"
  ndr_logSecStart "$logSectionDesc"

  if ! docker network ls --format '{{.Name}}' | grep -q "^${NDR_DOCKER_BRIDGE_NETWORK_NAME}$"; then
    ndr_logInfo "Creating Docker network: ${NDR_DOCKER_BRIDGE_NETWORK_NAME}"
    docker network create "${NDR_DOCKER_BRIDGE_NETWORK_NAME}"
    return_code=$?
    if [[ $return_code != 0 ]]; then
      ndr_logError "Failed to create Docker network '${NDR_DOCKER_BRIDGE_NETWORK_NAME}'. Please check your Docker installation and permissions."
      return 1
    fi
  else
    ndr_logInfo "Docker network '${NDR_DOCKER_BRIDGE_NETWORK_NAME}' already exists"
  fi

  ndr_logInfo "Docker bridge network created."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function <repo_account> <repo_name> <image_base_name> <image_version_tag> [repo_type]
function ndr_DownloadDockerImage ()
{
  local logSectionDesc="Downloading Docker Image"
  ndr_logSecStart "$logSectionDesc"

  local repoAccount="$1"
  local repoName="$2"
  local imageBaseName="$3"
  local imageVersionTag="$4"
  local repoType="${5:-$NDR_DOCKER_REPO_TYPE_CURRENT}"
  
  local localImageTag=""
  
  # Validate argument count
  if [[ $# -lt 4 ]]; then
    ndr_logError "Usage: ndr_DownloadDockerImage <repo_account> <repo_name> <image_base_name> <image_version_tag> [repo_type]"
    return 1
  fi
  
  if false; then
  # DEPRECATED
  if [[ "$repoType" == "$NDR_DOCKER_REPO_TYPE_PRIVATE_NDR" ]]; then
    ndr_logInfo "Docker repo type is private remote repo, performing authentication first."
  
    # decrypt and populate secrets.
    ndr_DecryptPopulateSecrets || { echo "Error: failed to populate secrets"; return 1; }

    if [[ -z "$repoAccount" || -z "$NDR_DOCKER_REPO_ACCESS_TOKEN" ]]; then
      ndr_logError "Docker repo account and/or token empty."
      return 1
    fi

    docker login -u "$repoAccount" -p "$NDR_DOCKER_REPO_ACCESS_TOKEN"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Docker login failed for [$repoAccount]."
      return 1
    fi
    ndr_logInfo "Docker login success for account [$repoAccount]"
  fi
  fi

  
  # Typical dockerhub repo tag format: <repo_account>/<repo_name>:<image_version_tag>
  # Alternate simple hub tag format: <repo_name>:<image_version>
  # NDR repo tag format: <repo_account>/<repo_name>:<{image_base_name}_{image_version_tag}>

  # Image naming convention and variation notes
  # For most images, the typical format will include the account (eg supabase/studio:2025.04.21-sha-173cc56)
  # For some images, the repo account may not be used and the param will be set to "<empty>" (eg kong:2.8.1)
  # For NDR, we also use the image base as part of the tag. (eg nextdr/nextdr-ui:nextdr-ui-img_1.1.2-2c517a2-1770210941)
  
  # set universal local image name format for pulled image to be tagged to after pull
  # repo account is optional for some public repos, so only include if provided and not set to <empty>
  if [[ "$repoAccount" != "$NDR_DOCKER_MODULE_NAME_EMPTY_VALUE" ]]; then
    localImageTag="${localImageTag}${repoAccount}/"
  fi
  localImageTag="${localImageTag}${repoName}:"
  # imageBaseName is only specified for NDR images, so only include if provided and not set to <empty>. For 3rd party public images, the image base name is not included in the tag.
  if [[ "$imageBaseName" != "$NDR_DOCKER_MODULE_NAME_EMPTY_VALUE" ]]; then
    localImageTag="${localImageTag}${imageBaseName}_"
  fi
  localImageTag="${localImageTag}${imageVersionTag}"

  # transform local to remote image format
  local repoImageTag
  if [[ "$repoType" == "$NDR_DOCKER_REPO_TYPE_LOCAL_REGISTRY" ]]; then
    repoImageTag=$(ndr_LocalImageTagToRegistryRepoImageTag "$gNDR_DOCKER_LOCAL_REGISTRY_HOST" "$gNDR_DOCKER_LOCAL_REGISTRY_PORT" "$localImageTag")
  elif [[ "$repoType" == "$NDR_DOCKER_REPO_TYPE_GCP_REGISTRY" ]]; then
    repoImageTag="${gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT}/${localImageTag}"
  else
    # Standard Dockerhub public repo type should already be in the correct format, just use the local image name as the repo tag for pulling.
    repoImageTag="${localImageTag}"
    return_code=0
  fi
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to convert image name [$imageName]."
    return 1
  fi

  ndr_logInfo "Pulling Docker image tag [$repoImageTag] from repo type [$repoType]."

  # pull image from repo
  docker pull "$repoImageTag"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Docker pull failed for [$repoImageTag]."
    return 1
  fi
  ndr_logInfo "Docker pull success for [$repoImageTag]."

  # check if the newly pulled Docker image is present
  ndr_verifyDockerImageExists "$repoImageTag"
  return_code=$?
  #2-error, 1-not found, 0-found
  if [ $return_code -ne 0 ]; then
    ndr_logError "Docker image verification failed for local copy of remote tag [$repoImageTag]."
    return 1
  fi
  ndr_logInfo "Docker remote repo image tag found [$repoImageTag]."

  if [[ "$repoImageTag" != "$localImageTag" ]]; then
    # re tag it from remote format to local.
    docker tag "$repoImageTag" "$localImageTag"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Docker tag failed for [$repoImageTag]."
      return 1
    fi
    ndr_logInfo "Docker tag success for [$repoImageTag] to [$localImageTag]."
    
    # cleanup remote repo tag reference to local image.
    ndr_logInfo "Removing remote repo tag [$repoImageTag] from local image [$localImageTag]"
    docker rmi "$repoImageTag"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Docker rmi failed for [$repoImageTag]."
      #return 1
    fi
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function <fully_qualified_image> <architecture> <repo_type>
function ndr_DownloadDockerImageV2 ()
{
  local logSectionDesc="Downloading Docker Image"
  ndr_logSecStart "$logSectionDesc"

  local image="$1"
  local architecture="$2"
  local repoType="$3"

  # Validate argument count
  if [[ $# -lt 3 ]]; then
    ndr_logError "Usage: ndr_DownloadDockerImageV2 <fully_qualified_image> <architecture> <repo_type>"
    return 1
  fi
  
  # Typical dockerhub repo tag format: <repo_account>/<repo_name>:<image_version_tag>
  # Alternate simple hub tag format: <repo_name>:<image_version>
  # NDR repo tag format: <repo_account>/<repo_name>:<{image_base_name}_{image_version_tag}>

  # Image naming convention and variation notes
  # For most images, the typical format will include the account (eg supabase/studio:2025.04.21-sha-173cc56)
  # For some images, the repo account may not be used and the param will be set to "<empty>" (eg kong:2.8.1)
  # For NDR, we also use the image base as part of the tag. (eg nextdr/nextdr-ui:nextdr-ui-img_1.1.2-2c517a2-1770210941)
  
  # transform local to remote image format if needed.
  # Standard Dockerhub public repo type (eg supabase) should already be in the correct format, continue use the local image name as the repo tag for pulling.
  local repoImageTag="$image"
  if [[ "$repoType" == "$NDR_DOCKER_REPO_TYPE_LOCAL_REGISTRY" ]]; then
    repoImageTag=$(ndr_LocalImageTagToRegistryRepoImageTag "$gNDR_DOCKER_LOCAL_REGISTRY_HOST" "$gNDR_DOCKER_LOCAL_REGISTRY_PORT" "$image")
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to convert image name [$image]."
      return 1
    fi
  elif [[ "$repoType" == "$NDR_DOCKER_REPO_TYPE_GCP_REGISTRY" ]]; then
    repoImageTag="${gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT}/${image}"
  fi
  
  # when pulling from any dockerhub repo, we can explicitly specify the platform architecture to ensure that
  # we pull the correct image for the host architecture, especially for M1/M2 macs which default to arm64 and may pull incompatible images if not specified.
  # if not specified, docker will attempt to auto detect and pull the image for the host architecture.
  local platformOption=""
  if [[ -n "$architecture" && "$architecture" != "$gNDR_DOCKER_ARCHITECTURE_AUTO_DETECT" ]]; then
    platformOption="--platform $architecture"
  fi

  ndr_logInfo "Pulling Docker image tag [$repoImageTag] from repo type [$repoType]."

  # pull image from repo
  local cmd="docker pull $repoImageTag"
  
  if [[ -n "$platformOption" ]]; then
    cmd="docker pull $platformOption $repoImageTag"
  fi

  local maxPullAttempts=3
  local pullAttempt=1
  return_code=1
  while [[ $pullAttempt -le $maxPullAttempts ]]; do
    ndr_logInfo "Docker pull attempt [$pullAttempt/$maxPullAttempts] for [$cmd]."
    $cmd
    return_code=$?
    if [ $return_code -eq 0 ]; then
      break
    fi

    if [[ $pullAttempt -lt $maxPullAttempts ]]; then
      ndr_logWarn "Docker pull attempt [$pullAttempt/$maxPullAttempts] failed for [$cmd]. Retrying in 10 seconds."
      sleep 10
    fi
    pullAttempt=$((pullAttempt + 1))
  done

  if [ $return_code -ne 0 ]; then
    ndr_logError "Docker pull failed for [$cmd]."
    return 1
  fi
  ndr_logInfo "Docker pull success for [$cmd]."

  # check if the newly pulled Docker image is present
  ndr_verifyDockerImageExists "$repoImageTag"
  return_code=$?
  #2-error, 1-not found, 0-found
  if [ $return_code -ne 0 ]; then
    ndr_logError "Docker image verification failed for local copy of remote tag [$repoImageTag]."
    return 1
  fi
  ndr_logInfo "Docker remote repo image tag found [$repoImageTag]."

  if [[ "$repoImageTag" != "$image" ]]; then
    # re tag it from remote format to local.
    docker tag "$repoImageTag" "$image"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Docker tag failed for [$repoImageTag]."
      return 1
    fi
    ndr_logInfo "Docker tag success for [$repoImageTag] to [$image]."
    
    # cleanup remote repo tag reference to local image.
    ndr_logInfo "Removing remote repo tag [$repoImageTag] from local image [$image]"
    docker rmi "$repoImageTag"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Docker rmi failed for [$repoImageTag]."
      #return 1
    fi
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# Converts from raw image base name values: <hostname>, <port>, <image> to local registry encoded base name. 
# format: <hostname>:<port>/<repo_account>/<repo_name>:<version_tag>
# usage: function <repo_hostname> <repo_port> <image>
# outputs converted image name to stdout
function ndr_LocalImageTagToRegistryRepoImageTag ()
{
  local repoHostName="$1"
  local repoPort="$2"
  local image="$3"
  
  # Validate argument count
  if [[ $# -lt 3 || -z "$repoHostName" || -z "$repoPort" || -z "$image" ]]; then
    ndr_logError "Usage: ndr_LocalImageTagToRegistryRepoImageTag [repo_hostname] [repo_port] [image]"
    return 1
  fi

  ndr_logDebug "repoHostName: $repoHostName, repoPort: $repoPort, image: $image"

  # for imagesl like kong that have no repo account, prepend the library string that we use in the local registry path.
  if [[ "$image" != */* ]]; then
    image="library/$image"
    ndr_logDebug "Adjusted image name to include local lregistry repo account placeholder 'library' [$image]"
  fi

  # Universal local registry tag format: <hostname>:<port>/<repo_account>/<repo_name>:<version_tag>
  # Supabase eg [localhost:5150/supabase/gotrue:v2.171.0]
  # Supabase eg2 [localhost:5150/kong:2.8.1] (no repo account)
  
  # NDR specific local registry tag format: <hostname>:<port>/<repo_account>/<repo_name>:<image_base_name>_<version_tag>
  # NDR eg [localhost:5150/nextdr/nextdr-ui:nextdr-ui-img_1.1.2-2c517a2-1770210941]
  
  local repoImageTag="${repoHostName}:${repoPort}/${image}"

  echo "$repoImageTag"

  return 0
}


function ndr_RemoteRepoImageExists ()
{
  local logSectionDesc="Remote Repo Image Check"
  ndr_logSecStart "$logSectionDesc"

  # Validate argument count
  if [[ $# -lt 4 ]]; then
    ndr_logError "Usage: ndr_RemoteRepoImageExists <repo_account> <repo_name> <image_name> <image_version>"
    return 1
  fi

  local repoAccount="$1"
  local repoName="$2"
  local dockerImageBaseName="$3"
  local dockerImageVersion="$4"
  local dockerImageName="${dockerImageBaseName}:${dockerImageVersion}"
  local imageRepoName=$(ndr_ConstructFullImageTagString "$repoAccount" "$repoName" "$dockerImageBaseName" "$dockerImageVersion")
  
  docker manifest inspect "$imageRepoName" >/dev/null 2>&1
  local exists=$?
  if [[ $exists -eq 0 ]]; then
    ndr_logInfo "Image [$imageRepoName] exists"
  else
    ndr_logInfo "Image [$imageRepoName] does not exist"
  fi

  ndr_logSecEnd "$logSectionDesc"

  return $exists
}

function ndr_CheckContainerHealth() 
{
  local logSectionDesc="Container Health Check"
  ndr_logSecStart "$logSectionDesc"

  local container_name="$1"

  if [[ -z "$container_name" ]]; then
    ndr_logWarn "Usage: ndr_CheckContainerHealth <container_name>"
    return 1
  fi

  if ! docker inspect "$container_name" &>/dev/null; then
    ndr_logError "Container '$container_name' not found."
    return 1
  fi

  local status health overallhealth=4
  local start_time
  local current_time
  local elapsed_time
  local timeout=60  # 1 minute timeout

  start_time=$(date +%s)

  while true; do
    # Check if we've exceeded the timeout
    current_time=$(date +%s)
    elapsed_time=$((current_time - start_time))
    
    if [ $elapsed_time -ge $timeout ]; then
      ndr_logWarn "Health check timed out after ${timeout} seconds for container '$container_name'"
      overallhealth=4  # unknown state due to timeout
      break
    fi

    status=$(docker inspect --format '{{.State.Status}}' "$container_name" 2>/dev/null)
    health=$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}no healthcheck{{end}}' "$container_name" 2>/dev/null)

    ndr_logInfo "$container_name: $status - $health"

    case "$status" in
      created)
        if [[ "$health" == "no healthcheck" ]]; then
          overallhealth=0  # success, no healthcheck but container is created
          break
        else
          overallhealth=4  # unknown state, container is created but has no healthcheck status yet. continue polling as it might transition to running with healthy status.
        fi
        ;;
      running)
        if [[ "$health" == "healthy" || "$health" == "no healthcheck" ]]; then
          overallhealth=0  # success
          break
        elif [[ "$health" == "unhealthy" ]]; then
          overallhealth=2  # unhealthy
          # continue polling as it might become healthy
        fi
        ;;
      exited|dead)
        overallhealth=3  # container not running
        break
        ;;
      *)
        # For intermediate states, continue polling
        overallhealth=4  # unknown or intermediate state
        ;;
    esac

    sleep 5  # Wait n seconds before next check
  done

  if [ $overallhealth -eq 0 ]; then
    ndr_logInfo "Container '$container_name' is healthy and running"
  elif [ $overallhealth -eq 2 ]; then
    ndr_logWarn "Container '$container_name' is running but unhealthy"
  elif [ $overallhealth -eq 3 ]; then
    ndr_logError "Container '$container_name' is not running"
  else
    ndr_logWarn "Container '$container_name' status is unknown or in transition"
  fi

  ndr_logSecEnd "$logSectionDesc"

  return $overallhealth
}

function ndr_DockerRemoteRepoLogin ()
{
  local logSectionDesc="Docker Remote Repo Login"
  ndr_logSecStart "$logSectionDesc"

  if [ "$NDR_DOCKER_REMOTE_REPO_AUTHENTICATED" == true ]; then
    ndr_logInfo "Already authenticated to remote Docker repo."
    return 0
  fi

  # decrypt and populate secrets.
  ndr_DecryptPopulateSecrets || { echo "Error: failed to populate secrets"; return 1; }

  if [[ -z "$NDR_DOCKER_REPO_ACCOUNT" || -z "$NDR_DOCKER_REPO_ACCESS_TOKEN" ]]; then
    ndr_logError "Docker repo account and/or token empty."
    return 1
  fi

  docker login -u "$NDR_DOCKER_REPO_ACCOUNT" -p "$NDR_DOCKER_REPO_ACCESS_TOKEN"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Docker login failed for [$NDR_DOCKER_REPO_ACCOUNT]."
    return 1
  fi
  ndr_logInfo "Docker login success for account [$NDR_DOCKER_REPO_ACCOUNT]"

  NDR_DOCKER_REMOTE_REPO_AUTHENTICATED=true
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# updates only the version value within the ndr image tag portion of the full image tag string, keeping the repo account, repo name, NDR image base and other values of the NDR image version tag name intact.
# usage: function <full_image_tag_ref> <new_version_value>
function ndr_UpdateImageTagVersionValue ()
{
  local logSectionDesc="Updating Image Tag Version Value"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <full_image_tag_ref> <new_version_value>"
    return 1
  fi

  local -n fullImageTagRef="$1"
  local newVersionValue="$2"

  local repoAccount=""
  local repoName=""
  local imageBaseName=""
  local imageVersionTag=""

  # full image tag format: <repo_account>/<repo_name>:<image_base_name>_<version_tag>
  # we want to update only the ndr version value within the image tag

  # parse the full image tag into constituent parts to get the docker image version tag
  ndr_ParseNDRFullImageName "$fullImageTagRef" repoAccount repoName imageBaseName imageVersionTag
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to parse full image tag [$fullImageTagRef]."
    return 1
  fi

  # if any of the retrieved parts are empty, log error and return
  if [[ -z "$repoAccount" || -z "$repoName" || -z "$imageBaseName" || -z "$imageVersionTag" ]]; then
    ndr_logError "One or more parts of the full image tag [$fullImageTagRef] are empty."
    return 1
  fi

  local version=""
  local hash=""
  local timestamp=""

  # parse the image version tag into the ndr versioning parts
  ndr_ParseImageTagVersionParts "$imageVersionTag" version hash timestamp
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to parse image version tag [$imageVersionTag]."
    return 1
  fi

  # if any of the retrieved version parts are empty, log error and return
  if [[ -z "$version" || -z "$hash" || -z "$timestamp" ]]; then
    ndr_logError "One or more parts of the image version tag [$imageVersionTag] are empty."
    return 1
  fi

  # Update the NDR version value while keeping the rest of the tag intact
  # imageVersionTag="${newVersionValue}-${hash}-${timestamp}"
  ndr_ConstructImageVersionTagString "$newVersionValue" "$hash" "$timestamp" imageVersionTag
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to construct new image version tag with new version value [$newVersionValue]."
    return 1
  fi

  # update the full image tag with the new version value
  ndr_ConstructFullImageTagStringV2 "$repoAccount" "$repoName" "$imageBaseName" "$imageVersionTag" fullImageTagRef
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to construct full image tag with new version value [$newVersionValue]."
    return 1
  fi

  ndr_logDebug "Updated full image tag to [$fullImageTagRef] with new version value [$newVersionValue]."
  
  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}
# usage: function [image_base_name]
function ndr_ConstructFullImageTagStringFromGlobals ()
{
  if [[ $# -lt 1 ]]; then
    ndr_logError "Usage: function <image_base_name>"
    return 1
  fi

  local imageBaseName="$1"
  local repoAccount="$NDR_DOCKER_REPO_ACCOUNT"
  local repoName=""
  local imageVersionTag=""

  if [[ "$imageBaseName" == "$NDR_SERVICE_IMAGE_NAME" ]]; then
    # use service entries
    repoName="$NDR_DOCKER_SERVICE_PUBLIC_REPO_NAME"
    imageVersionTag="$NDR_SERVICE_IMAGE_VERSION"
  elif [[ "$imageBaseName" == "$NDR_UI_IMAGE_NAME" ]]; then
    # use ui entries
    repoName="$NDR_DOCKER_UI_PUBLIC_REPO_NAME"
    imageVersionTag="$NDR_UI_IMAGE_VERSION"
  else
    ndr_logError "Unsupported image base name [$imageBaseName]."
    return 1
  fi

  
  local fullImageName=$(ndr_ConstructFullImageTagString "$repoAccount" "$repoName" "$imageBaseName" "$imageVersionTag")
  return_code=$?
  if [[ $return_code -ne 0 || -z "$fullImageName" ]]; then
    ndr_logError "Failed to construct full image name for base name [$imageBaseName]."
    return 1
  fi
  
  echo "$fullImageName"
  
  return 0
}

# constructs only the image version tag portion of an NDR image tag in the form if <version number>-<git short hash>-<timestamp>
# usage: function <version> <git_short_hash> <timestamp> <image_version_tag_ref>
function ndr_ConstructImageVersionTagString ()
{
  if [[ $# -lt 4 ]]; then
    ndr_logError "Usage: function <version> <git_short_hash> <timestamp> <image_version_tag_ref>"
    return 1
  fi

  local version="$1"
  local gitShortHash="$2"
  local timestamp="$3"
  local -n imageVersionTagRef="$4"

  imageVersionTagRef="${version}-${gitShortHash}-${timestamp}"

  return 0
}

# constructs a full repo image tag in the format of <repo_account>/<repo_name>:<image_base_name>_<image_version_tag> <full_image_tag_ref>
# useful to ensure consistent image naming convention for image naming and tagging stndardization across scripts and modules, especially for NDR specific images with the image base name as part of the tag.
# usage: function <repo_account> <repo_name> <image_base_name> <image_version_tag> <full_image_tag_ref>
function ndr_ConstructFullImageTagStringV2 ()
{
  if [[ $# -lt 5 ]]; then
    ndr_logError "Usage: function <repo_account> <repo_name> <image_base_name> <image_version_tag> <full_image_tag_ref>"
    return 1
  fi

  local repoAccount="$1"
  local repoName="$2"
  local imageBaseName="$3"
  local imageVersionTag="$4"
  local -n _fullImageTagRef="$5"

  fullImageTagRef="${repoAccount}/${repoName}:${imageBaseName}_${imageVersionTag}"

  return 0
}

# constructs a full repo image tag in the format of <repo_account>/<repo_name>:<image_base_name>_<image_version_tag>
# useful to ensure consistent image naming convention for image naming and tagging stndardization across scripts and modules, especially for NDR specific images with the image base name as part of the tag.
# usage: function <repo_account> <repo_name> <image_base_name> <image_version_tag>
function ndr_ConstructFullImageTagString ()
{
  if [[ $# -lt 4 ]]; then
    ndr_logError "Usage: function <repo_account> <repo_name> <image_base_name> <image_version_tag>"
    return 1
  fi

  local repoAccount="$1"
  local repoName="$2"
  local imageBaseName="$3"
  local imageVersionTag="$4"

  local fullRepoImageTag="${repoAccount}/${repoName}:${imageBaseName}_${imageVersionTag}"

  echo "$fullRepoImageTag"

  return 0
}

function ndr_ValidateFullImageTagFormat ()
{
  local imageTag="$1"
  # regex pattern to match the full image tag format: <account>/<repo_name>:<image_base_name>_<image_version>
  local pattern='^[a-z0-9][a-z0-9_-]*/[a-z0-9][a-z0-9_-]*:[a-z0-9][a-z0-9_-]*_[a-z0-9][a-z0-9._-]*$'
  
  if [[ "$imageTag" =~ $pattern ]]; then
    return 0 # valid format
  else
    ndr_logError "Invalid image tag format: [$imageTag]. Expected format: <account>/<repo_name>:<image_base_name>_<image_version>"
    return 1 # invalid format
  fi
}

# takes a version tag (e.g. v1.0.0) and appends short git commit hash and timestamp to create a full version string
# usage: function <version_tag>
# outputs full version string to stdout
function ndr_ConstructLocalGitRepoImageVersionString ()
{
  local logSectionDesc="Constructing Image Version String"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <version_tag>"
    return 1
  fi

  local versionTag="$1"
  local fullVersionName=""
  local updateinfo=false
  # query for local git hash and timestamp values and update if newer
  
  cd "$gSCRIPT_HOME_DIR" || { ndr_logError "Failed to change directory to [$gSCRIPT_HOME_DIR]"; return 1; }

  local timestamp=$(git show -s --format=%ct 2>/dev/null)
  return_code=$?
  if [[ $return_code -ne 0 || -z "$timestamp" ]]; then
    ndr_logWarn "Unable to retrieve git commit timestamp."
    return 1
  fi

  if [[ "$timestamp" -gt "$NDR_GIT_REPO_COMMIT_TIMESTAMP" ]]; then
    ndr_logInfo "Found git local commit timestamp [$timestamp] newer than script version [$NDR_GIT_REPO_COMMIT_TIMESTAMP], updating."
    NDR_GIT_REPO_COMMIT_TIMESTAMP="$timestamp"
    updateinfo=true
  elif [[ "$timestamp" -eq "$NDR_GIT_REPO_COMMIT_TIMESTAMP" ]]; then
    ndr_logInfo "Found git local commit timestamp [$timestamp] same as script version [$NDR_GIT_REPO_COMMIT_TIMESTAMP]"
  fi
  
  local commit_hash=$(git rev-parse HEAD 2>/dev/null)
  return_code=$?
  if [[ $return_code -ne 0 || -z "$commit_hash" ]]; then
    ndr_logWarn "Unable to retrieve git commit hash."
    return 1
  fi
  
  if [ "$updateinfo" == true ]; then
    ndr_logInfo "Updating git commit hash [$NDR_GIT_REPO_COMMIT_HASH] to latest [$commit_hash]"
    NDR_GIT_REPO_COMMIT_HASH="$commit_hash"
    NDR_GIT_REPO_COMMIT_HASH_SHORT=$(echo "$NDR_GIT_REPO_COMMIT_HASH" | cut -c1-7)
  fi

  if [[ -z "$NDR_GIT_REPO_COMMIT_HASH" || -z "$NDR_GIT_REPO_COMMIT_HASH_SHORT" || -z "$NDR_GIT_REPO_COMMIT_TIMESTAMP" ]]; then
    ndr_logWarn "Invalid git commit hashes."
    return 1
  fi

  fullVersionName="${versionTag}-${NDR_GIT_REPO_COMMIT_HASH_SHORT}-${NDR_GIT_REPO_COMMIT_TIMESTAMP}"
  ndr_logDebug "Constructed image version_commit_timestamp tag [$fullVersionName]"

  ndr_logSecEndDebug "$logSectionDesc"

  echo "$fullVersionName"
  return 0
}

# Given a running container name, performs a docker query to retrieve the image name it was started from
# usage: function <container_name>
# returns image name to stdout, eg "nextdr-ui-img:1.0.0-e373a98-1757443381"
function ndr_QueryContainerImageName ()
{
  local logSectionDesc="Querying Container Image Name"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <container_name>"
    return 1
  fi

  local dockerContainerName="$1"

  ndr_verifyDockerContainerExists "$dockerContainerName"
  return_code=$?
  # 2-error, 1-not found, 0-found
  if [[ $return_code -ne 0 ]]; then
    ndr_logWarn "Docker container [$dockerContainerName] does not exist."
    return 1
  fi

  local dockerImageName=$(docker inspect --format '{{.Config.Image}}' "$dockerContainerName" 2>/dev/null)
  return_code=$?
  if [[ $return_code -ne 0 || -z "$dockerImageName" ]]; then
    ndr_logError "Failed to retrieve image name for container [$dockerContainerName]."
    return 1
  fi

  ndr_logDebug "Found image name [$dockerImageName] for container [$dockerContainerName]"

  ndr_logSecEndDebug "$logSectionDesc"

  echo "$dockerImageName"
  return 0
}

# Given a running container name, performs a docker query to retrieve the image version tag of the full image name it was started from
# usage: function <container_name>
# returns image name to stdout, eg "1.0.0-e373a98-1757443381"
function ndr_QueryContainerImageVersionTag ()
{
  local logSectionDesc="Querying Container Image Version Tag"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <container_name>"
    return 1
  fi

  local dockerContainerName="$1"

  ndr_verifyDockerContainerExists "$dockerContainerName"
  return_code=$?
  # 2-error, 1-not found, 0-found
  if [[ $return_code -ne 0 ]]; then
    ndr_logWarn "Docker container [$dockerContainerName] does not exist."
    return 1
  fi

  local dockerImageName=$(ndr_QueryContainerImageName "$dockerContainerName")
  return_code=$?
  if [[ $return_code -ne 0 || -z "$dockerImageName" ]]; then
    ndr_logError "Failed to retrieve image name for container [$dockerContainerName]."
    return 1
  fi
  
  local dockerImageTag="${dockerImageName#*:}"  # remove everything up to and including ':'
  if [[ -z "$dockerImageTag" ]]; then
    ndr_logError "Failed to parse image tag from image name [$dockerImageName]."
    return 1
  fi

  # and split at the '_' to remove the image base name if it exists, leaving just the version tag. If there is no '_' then this will just return the full tag which is fine for non-NDR images that don't include the image base name in the tag.
  # eg. nextdr-svc-img_1.1.4-2af299f-1771621807 -> 1.1.4-2af299f-1771621807
  dockerImageTag="${dockerImageTag#*_}"  # remove everything up to and including '_', if it exists

  ndr_logDebug "Found image tag [$dockerImageTag] from image name [$dockerImageName] for container [$dockerContainerName]"

  ndr_logSecEndDebug "$logSectionDesc"

  echo "$dockerImageTag"
  return 0
}

# a derivative of ndr_ParseFullImageName that is specifically designed to parse out the individual components from a full NDR image name string in the format of <repo_account>/<repo_name>:<image_base_name>_<version_tag> and return them via reference parameters. 
# will return failure/0 if all any values are missing.
function ndr_ParseNDRFullImageName ()
{
  local logSectionDesc="Parsing Full NDR Image Name"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -ne 5 ]]; then
    ndr_logError "Usage: function [full_image_name] [repo_account_ref] [repo_name_ref] [image_base_name_ref] [image_version_tag_ref]"
    return 1
  fi

  local fullImageName="$1"
  local -n repoAccountRefNDR="$2"
  local -n repoNameRefNDR="$3"
  local -n imageBaseNameRefNDR="$4"
  local -n imageVersionTagRefNDR="$5"

  ndr_ParseFullImageName "$fullImageName" repoAccountRefNDR repoNameRefNDR imageBaseNameRefNDR imageVersionTagRefNDR
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to parse full image name [$fullImageName] using ndr_ParseFullImageName."
    return 1
  fi

  # check if any of the mandatory parsed values are empty, if so return an error
  if [[ -z "$repoAccountRefNDR" || -z "$repoNameRefNDR" || -z "$imageBaseNameRefNDR" || -z "$imageVersionTagRefNDR" ]]; then
    ndr_logError "Failed to parse full NDR image name [$fullImageName]. Parsed values: repoAccount: [$repoAccountRefNDR], repoName: [$repoNameRefNDR], imageBaseName: [$imageBaseNameRefNDR], imageVersionTag: [$imageVersionTagRefNDR]"
    return 1
  fi

  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

# usage function [full_image_name] [repo_account_ref] [repo_name_ref] [image_base_name_ref] [image_version_tag_ref]
# takes a full image name in the format of <repo_account>/<repo_name>:<image_base_name>_<version_tag> and parses out the individual components and returns them via reference parameters. 
# This is useful for parsing out the individual components from a full image name string, especially for NDR specific images with the image base name as part of the tag.
# If used with a non-NDR immage that doesn't include the image base name in the tag (eg MOST 3rd party images), the image base name ref will will be empty and the version tag ref will contain the full tag, so it can still be used to parse out the repo account and repo name for standard images.
# If used with an image that does not contain the repo account (eg kong:2.8.1), the repo account ref will be empty, but the repo name and version tag can still be parsed out, so it can still be used for images without a repo account.
function ndr_ParseFullImageName () 
{
  local logSectionDesc="Parsing Full Image Name"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -ne 5 ]]; then
    ndr_logError "Usage: function [full_image_name] [repo_account_ref] [repo_name_ref] [image_base_name_ref] [image_version_tag_ref]"
    return 1
  fi

  local fullImageName="$1"
  local -n repoAccountRef="$2"
  local -n repoNameRef="$3"
  local -n imageBaseNameRef="$4"
  local -n imageVersionTagRef="$5"

  # full image name format: <repo_account>/<repo_name>:<image_base_name>_<version_tag>
  # example: nextdr/nextdr-ui:nextdr-ui-img_1.1.4-2af299f-1771621807

  # first split the full image name at the ':' to separate the repo part from the tag part. 
  # The repo part is everything before the first ':' and the tag part is everything after the first ':'. 
  # Then we can further split the repo part at '/' to get the optional repo account and repo name
  # Lastly attempt to split the tag part at '_' to get the optional image base name (for NDR specific images) and version tag.
  if [[ "$fullImageName" != *":"* ]]; then
    ndr_logError "Failed to parse full image name [$fullImageName]. Expected image name to include ':' separating repo/name from tag."
    return 1
  fi

  local repoPart="${fullImageName%%:*}"  # everything before the first ':'
  local tagPart="${fullImageName#*:}"    # everything after the first ':'

  if [[ -z "$repoPart" || -z "$tagPart" ]]; then
    ndr_logError "Failed to parse full image name [$fullImageName]. Repo part or tag part is empty. Repo part: [$repoPart], Tag part: [$tagPart]"
    return 1
  fi

  if [[ "$repoPart" == *"/"* ]]; then
    repoAccountRef=$(echo "$repoPart" | cut -d'/' -f1)
    repoNameRef=$(echo "$repoPart" | cut -d'/' -f2)
  else
    repoAccountRef="" # optional
    repoNameRef="$repoPart"
  fi

  if [[ "$tagPart" == *"_"* ]]; then
    imageBaseNameRef=$(echo "$tagPart" | cut -d'_' -f1)
    imageVersionTagRef=$(echo "$tagPart" | cut -d'_' -f2)
  else
    imageBaseNameRef="" # optional for non-NDR images that don't include the image base name in the tag, in which case the full tag will just be the version tag
    imageVersionTagRef="$tagPart"
  fi

  # check if any of the mandatory parsed values are empty, if so return an error
  if [[ -z "$repoNameRef" || -z "$imageVersionTagRef" ]]; then
    ndr_logError "Failed to parse full image name [$fullImageName] required primary values. Parsed values: repoAccount (optional): [$repoAccountRef], repoName (required): [$repoNameRef], imageBaseName (optional): [$imageBaseNameRef], imageVersionTag (required): [$imageVersionTagRef]"
    return 1
  fi

  if [[ -z "$repoAccountRef" || -z "$imageBaseNameRef" ]]; then
    ndr_logWarn "Image name [$fullImageName] did not contain optional values. Parsed values: repoAccount (optional): [$repoAccountRef], repoName (required): [$repoNameRef], imageBaseName (optional): [$imageBaseNameRef], imageVersionTag (required): [$imageVersionTagRef]"
  fi

  ndr_logDebug "Parsed full image name [$fullImageName] into repoAccount: [$repoAccountRef], repoName: [$repoNameRef], imageBaseName: [$imageBaseNameRef], imageVersionTag: [$imageVersionTagRef]"

  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

# usage: function <full_image_tag> <version_ref> <commit_hash_ref> <timestamp_ref>
# input can be a full image name or just the tag portion in NDR format.
# full image name format: <repo_account>/<repo_name>:<image_base_name>_<version_tag>
# tag only format: <image_base_name>_<version_tag>
# returns version tag, commit hash, and timestamp via reference parameters.
function ndr_ParseImageTagVersionParts ()
{
  local logSectionDesc="Parsing Image Tag Version Parts"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -lt 4 ]]; then
    ndr_logError "Usage: function <full_image_tag> <version_ref> <commit_hash_ref> <timestamp_ref>"
    return 1
  fi

  local imageTag="$1"
  local -n _versionRef="$2"
  local -n _commitHashRef="$3"
  local -n _timestampRef="$4"

  # input image format with full image name: <repo_account>/<repo_name>:<image_base_name>_<version_tag>
  # eg: nextdr/nextdr-ui:nextdr-ui-img_1.1.2-e560576-1770379384
  # if full image name format is used, parse out and discard everything up to and including the firsat ':' to obtain just the image details.
  if [[ "$imageTag" == *":"* ]]; then
    imageTag="${imageTag#*:}"  # remove everything up to and including the first ':'
  fi
  
  # input image format with image base name: <image_base_name>_<version>-<git_hash>-<timestamp>
  # eg: nextdr-svc-img_1.1.2-e560576-1770379384

  if [[ "$imageTag" == *"_"* ]]; then
    # remove everything up to and including the first '_' to get just the version and other details, discarding the image base name.
    imageTag="${imageTag#*_}"
  fi

  # basename is everything before the first '_' and version is everything after the first '_'.
  local imageBaseName="${imageTag%%_*}"  # remove everything after the first '_'
  local fullImageVersion="${imageTag#*_}"   # remove everything before and including the first '_'
  
  _versionRef="${fullImageVersion%%-*}"   # remove everything after the first '-'
  _commitHashRef=$(echo "${fullImageVersion#*-}" | cut -d'-' -f1)   # extract the git hash which is between the first and second '-'
  _timestampRef=$(echo "${fullImageVersion#*-}" | cut -d'-' -f2)   # extract the timestamp which is after the second '-'
  
  if [[ -z "$_versionRef" || -z "$_commitHashRef" || -z "$_timestampRef" ]]; then
    ndr_logError "Failed to parse all required parts from image tag [$imageTag]."
    return 1
  fi

  ndr_logDebug "Parsed version [$_versionRef], commit hash [$_commitHashRef], and timestamp [$_timestampRef] from image tag [$imageTag]"

  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

# usage: function <image_tag> <image_version_ref>
# input can be a full image name or just the tag portion in NDR format.
# full image name format: <repo_account>/<repo_name>:<image_base_name>_<version_tag>
# tag only format: <image_base_name>_<version_tag>
# returns version tag parameter by reference.
function ndr_ParseImageTagVersionV2 ()
{
  local logSectionDesc="Parsing Image Tag Version"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <image_tag> <image_version_ref>"
    return 1
  fi

  local imageTag="$1"
  local -n versionRef="$2"
  local commitHash=""
  local timestamp=""

  ndr_ParseImageTagVersionParts "$imageTag" versionRef commitHash timestamp
  return_code=$?
  if [[ $return_code -ne 0 || -z "$versionRef" ]]; then
    ndr_logError "Failed to parse version parts from image tag [$imageTag]."
    return 1
  fi
  
  ndr_logDebug "Found version [$versionRef] from image tag [$imageTag]"

  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

# usage: function <image_tag>
# input can be a full image name or just the tag portion in NDR format.
# full image name format: <repo_account>/<repo_name>:<image_base_name>_<version_tag>
# tag only format: <image_base_name>_<version_tag>
# returns version tag to stdout
function ndr_ParseImageTagVersion ()
{
  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <image_tag>"
    return 1
  fi

  local imageTag="$1"
  local imageVersion=""
  
  ndr_ParseImageTagVersionV2 "$imageTag" imageVersion
  return_code=$?
  if [[ $return_code -ne 0 || -z "$imageVersion" ]]; then
    ndr_logError "Failed to parse version from image tag [$imageTag]."
    return 1
  fi

  echo "$imageVersion"
  
  return 0
}

# usage: function <container_name>
# returns version to stdout
function ndr_QueryContainerImageVersion ()
{
  local logSectionDesc="Querying Container Image Version"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <container_name>"
    return 1
  fi

  local dockerContainerName="$1"

  ndr_verifyDockerContainerExists "$dockerContainerName"
  return_code=$?
  #2-error, 1-not found, 0-found
  if [[ $return_code -ne 0 ]]; then
    ndr_logWarn "Docker container [$dockerContainerName] does not exist."
    return 1
  fi

  local dockerImageTag=$(ndr_QueryContainerImageVersionTag "$dockerContainerName")
  return_code=$?
  if [[ $return_code -ne 0 || -z "$dockerImageTag" ]]; then
    ndr_logError "Failed to retrieve image name for container [$dockerContainerName]."
    return 1
  fi

  local imageVersion=""
  ndr_ParseImageTagVersionV2 "$dockerImageTag" imageVersion
  if [[ -z "$imageVersion" ]]; then
    ndr_logError "Failed to parse version from image tag [$dockerImageTag]."
    return 1
  fi

  ndr_logDebug "Found version [$imageVersion] from image name [$dockerImageTag] for container [$dockerContainerName]"

  ndr_logSecEndDebug "$logSectionDesc"

  echo "$imageVersion"
}

# usage: function <image_tag> <commit_hash_ref>
# input can be a full image name or just the tag portion in NDR format.
# full image name format: <repo_account>/<repo_name>:<image_base_name>_<version_tag>
# tag only format: <image_base_name>_<version_tag>
# returns commit hash parameter by reference.
function ndr_ParseImageTagCommitHashV2 ()
{
  local logSectionDesc="Parsing Image Tag Commit Hash"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <image_tag> <commit_hash_ref>"
    return 1
  fi

  local imageTag="$1"
  local -n imageCommitHashRef="$2"
  local imageVersion=""
  local imageTimestamp=""

  ndr_ParseImageTagVersionParts "$imageTag" imageVersion imageCommitHashRef imageTimestamp
  return_code=$?
  if [[ $return_code -ne 0 || -z "$imageCommitHashRef" ]]; then
    ndr_logError "Failed to parse version parts from image tag [$imageTag]."
    return 1
  fi

  # Ensure the parsed commit hash is exactly 7 characters (short git SHA)
  if [[ ${#imageCommitHashRef} -ne 7 ]]; then
    ndr_logError "Parsed commit hash [$imageCommitHash] is not 7 characters long from image tag [$imageTag]."
    return 1
  fi

  ndr_logDebug "Found commit hash [$imageCommitHashRef] from image tag [$imageTag]"

  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

# usage: function <image_tag>
# returns commit hash to stdout
function ndr_ParseImageTagCommitHash ()
{
  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <image_tag>"
    return 1
  fi

  local imageTag="$1"
  local imageCommitHash=""

  ndr_ParseImageTagCommitHashV2 "$imageTag" imageCommitHash
  return_code=$?
  if [[ $return_code -ne 0 || -z "$imageCommitHash" ]]; then
    ndr_logError "Failed to parse commit hash from image tag [$imageTag]."
    return 1
  fi

  echo "$imageCommitHash"

  return 0
}

# Given a running container name, performs a docker query to retrieve the image name it was started from, parses out the git commit hash portion of the image tag
# usage: function <container_name>
# returns commit hash to stdout
function ndr_QueryContainerImageCommitHash ()
{
  local logSectionDesc="Querying Container Image Commit Hash"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <image_name>"
    return 1
  fi

  local dockerContainerName="$1"

  ndr_verifyDockerContainerExists "$dockerContainerName"
  return_code=$?
  #2-error, 1-not found, 0-found
  if [[ $return_code -ne 0 ]]; then
    ndr_logWarn "Docker container [$dockerContainerName] does not exist."
    return 1
  fi

  local dockerImageTag=$(ndr_QueryContainerImageVersionTag "$dockerContainerName")
  return_code=$?
  if [[ $return_code -ne 0 || -z "$dockerImageTag" ]]; then
    ndr_logError "Failed to retrieve image name for container [$dockerContainerName]."
    return 1
  fi

  local imageCommitHash=$(ndr_ParseImageTagCommitHash "$dockerImageTag")
  if [[ -z "$imageCommitHash" ]]; then
    ndr_logError "Failed to parse commit hash from image name [$dockerImageTag]."
    return 1
  fi

  # Ensure the parsed commit hash is exactly 7 characters (short git SHA)
  if [[ ${#imageCommitHash} -ne 7 ]]; then
    ndr_logError "Parsed commit hash [$imageCommitHash] is not 7 characters long from image name [$dockerImageTag]."
    return 1
  fi

  ndr_logDebug "Found commit hash [$imageCommitHash] from image name [$dockerImageTag] for container [$dockerContainerName]"

  ndr_logSecEndDebug "$logSectionDesc"

  echo "$imageCommitHash"
  return 0
}

# usage: function <image_tag> <timestamp_ref>
# input can be a full image name or just the tag portion in NDR format.
# full image name format: <repo_account>/<repo_name>:<image_base_name>_<version_tag>
# tag only format: <image_base_name>_<version_tag>
# returns timestamp parameter by reference.
function ndr_ParseImageTagTimestampV2 ()
{
  local logSectionDesc="Parsing Image Tag Timestamp"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <image_tag> <timestamp_ref>"
    return 1
  fi

  local imageTag="$1"
  local -n timestampRef="$2"
  local imageVersion=""
  local imageCommitHash=""

  ndr_ParseImageTagVersionParts "$imageTag" imageVersion imageCommitHash timestampRef
  return_code=$?
  if [[ $return_code -ne 0 || -z "$timestampRef" ]]; then
    ndr_logError "Failed to parse version parts from image tag [$imageTag]."
    return 1
  fi

  # Ensure the parsed timestamp looks like an epoch time (10 digits = seconds, 13 digits = milliseconds)
  if ! [[ "$timestampRef" =~ ^[0-9]{10}$ || "$timestampRef" =~ ^[0-9]{13}$ ]]; then
    ndr_logError "Parsed timestamp [$timestampRef] is not a valid epoch time (expected 10 or 13 digit numeric) from image tag [$imageTag]."
    return 1
  fi

  ndr_logDebug "Found timestamp [$timestampRef] from image tag [$imageTag]"

  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}


function ndr_ParseImageTagTimestamp ()
{
  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <image_tag>"
    return 1
  fi

  local imageTag="$1"
  local imageTimestamp=""

  ndr_ParseImageTagTimestampV2 "$imageTag" imageTimestamp
  return_code=$?
  if [[ $return_code -ne 0 || -z "$imageTimestamp" ]]; then
    ndr_logError "Failed to parse timestamp from image tag [$imageTag]."
    return 1
  fi

  echo "$imageTimestamp"
  
  return 0
}

# given a running container name, performs a docker query to retrieve the image name it was started from, parses out the timestamp portion of the image tag
# usage: function <container_name> 
# returns timestamp to stdout
function ndr_QueryContainerImageTimestampUTC ()
{
  local logSectionDesc="Querying Container Image Timestamp UTC"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <image_name>"
    return 1
  fi

  local dockerContainerName="$1"

  ndr_verifyDockerContainerExists "$dockerContainerName"
  return_code=$?
  #2-error, 1-not found, 0-found
  if [[ $return_code -ne 0 ]]; then
    ndr_logWarn "Docker container [$dockerContainerName] does not exist."
    return 1
  fi

  local dockerImageTag=$(ndr_QueryContainerImageVersionTag "$dockerContainerName")
  return_code=$?
  if [[ $return_code -ne 0 || -z "$dockerImageTag" ]]; then
    ndr_logError "Failed to retrieve image tag for container [$dockerContainerName]."
    return 1
  fi

  local imageTimestamp=$(ndr_ParseImageTagTimestamp "$dockerImageTag")
  if [[ -z "$imageTimestamp" ]]; then
    ndr_logError "Failed to parse timestamp from image tag [$dockerImageTag]."
    return 1
  fi

  ndr_logDebug "Found timestamp [$imageTimestamp] from image tag [$dockerImageTag] for container [$dockerContainerName]"

  ndr_logSecEndDebug "$logSectionDesc"

  echo "$imageTimestamp"
  return 0
}

# given a running container name, performs a docker query to retrieve the image name it was started from, parses out the timestamp portion of the image tag, converts to human readable format
# usage: function <container_name>
# returns human readable timestamp to stdout
function ndr_QueryContainerImageTimestampHumanReadable ()
{
  local logSectionDesc="Querying Container Image Timestamp Human Readable"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <image_name>"
    return 1
  fi

  local dockerContainerName="$1"

  ndr_verifyDockerContainerExists "$dockerContainerName"
  return_code=$?
  #2-error, 1-not found, 0-found
  if [[ $return_code -ne 0 ]]; then
    ndr_logWarn "Docker container [$dockerContainerName] does not exist."
    return 1
  fi

  local imageTimestampUTC
  imageTimestampUTC=$(ndr_QueryContainerImageTimestampUTC "$dockerContainerName")
  return_code=$?
  if [[ $return_code -ne 0 || -z "$imageTimestampUTC" ]]; then
    ndr_logError "Failed to retrieve image timestamp for container [$dockerContainerName]."
    return 1
  fi

  local imageTimestampHuman
  #imageTimestampHuman=$(date -u -d @"$imageTimestampUTC" +"%Y-%m-%d %H:%M:%S UTC")
  imageTimestampHuman=$(date -u -d @"$imageTimestampUTC" +"%Y-%m-%d")
  return_code=$?
  if [[ $return_code -ne 0 || -z "$imageTimestampHuman" ]]; then
    ndr_logError "Failed to convert timestamp [$imageTimestampUTC] to human readable format."
    return 1
  fi

  ndr_logDebug "Converted timestamp [$imageTimestampUTC] to human readable format [$imageTimestampHuman] for container [$dockerContainerName]"

  ndr_logSecEndDebug "$logSectionDesc"

  echo "$imageTimestampHuman"
  return 0
}

function ndr_QueryLatestMatchingLocalImage ()
{
  local logSectionDesc="Querying Latest Matching Local Image"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <image_name_pattern>"
    return 1
  fi

  local imageNamePattern="$1"

  ndr_logInfo "Searching for images matching pattern [$imageNamePattern]"
  
  mapfile -t matchingImages < <(docker images --format "{{.Repository}}:{{.Tag}}" | grep "$imageNamePattern")

  ndr_logInfo "Found ${#matchingImages[@]} matching image [$imageNamePattern]"

  if [[ ${#matchingImages[@]} -eq 0 ]]; then
    ndr_logWarn "No images found matching pattern [$imageNamePattern]"
    return 0
  fi

  # loop through each image, parse out the timestamp and determine the latest
  local latestImage=""
  local latestTimestamp=0
  for image_name in "${matchingImages[@]}"; do
    ndr_logInfo "Parsing image [$image_name]..."
    
    local imgTimestamp=$(ndr_ParseImageTagTimestamp "$image_name" 2>/dev/null)
    if [[ -z "$imgTimestamp" ]]; then
      ndr_logWarn "Failed to parse timestamp from image name [$image_name], skipping."
      continue
    fi

    # Compare timestamps and update latestImage if this one is newer
    if (( imgTimestamp > latestTimestamp )); then
      latestImage="$image_name"
      latestTimestamp="$imgTimestamp"
    fi
  done

  ndr_logInfo "Latest image matching pattern [$imageNamePattern] is [$latestImage] with timestamp [$latestTimestamp]"

  ndr_logSecEnd "$logSectionDesc"

  echo "$latestImage"
  return 0
}

function ndr_QueryFullImageString ()
{
  local logSectionDesc="Querying Full Image String"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -ne 2 ]]; then
    ndr_logError "Usage: function <image_name> <image_version>"
    return 1
  fi

  local dockerImageBaseName="$1"
  local dockerImageVersion="$2"
  local dockerImageName="${dockerImageBaseName}:${dockerImageVersion}"
  #+++ incomplete
  ndr_logInfo "Full image string is [$dockerImageName]"

  ndr_logSecEnd "$logSectionDesc"

  echo "$dockerImageName"
  return 0
}

# usage: function <search_image_name> <selected_image_name_ref>
function ndr_PromptRemoteImageTagV2 ()
{
  local logSectionDesc="Prompting for Remote Image Tag"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <search_image_name> <image_tag_ref>"
    return 1
  fi

  local search_image_name="$1"
  local -n selected_image_name_ref="$2"
  local repoAccount=""
  local repoName=""
  local imageBaseName=""
  local imageVersionTag=""
  local image_version="$gPRODUCT_VERSION"

  
  # select private or public repo based on current setting
  local svcRepo="$NDR_DOCKER_SERVICE_PUBLIC_REPO_NAME"
  local uiRepo="$NDR_DOCKER_UI_PUBLIC_REPO_NAME"

  # parse the full image tag into constituent parts to get the docker image version tag
  ndr_ParseNDRFullImageName "$search_image_name" repoAccount repoName imageBaseName imageVersionTag
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to parse full image tag [$search_image_name]."
    return 1
  fi

  # if any of the retrieved parts are empty, log error and return
  if [[ -z "$repoAccount" || -z "$repoName" || -z "$imageBaseName" || -z "$imageVersionTag" ]]; then
    ndr_logError "One or more parts of the full image tag [$search_image_name] are empty."
    return 1
  fi

  local image_tag_list=()

  ndr_QueryMatchingRemoteImageTagListV2 "$repoAccount" "$repoName" "$imageBaseName" "$imageVersionTag" image_tag_list
  local return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to query remote image tag list for [${imageBaseName}_${image_version}] in repo [$repoAccount/$repoName]"
    return 1
  fi

  if [ "${#image_tag_list[@]}" -eq 0 ]; then
    ndr_logWarn "No tags found in repo ${repoAccount}/${repoName}"
    return 1
  fi

  if [ "${#image_tag_list[@]}" -eq 1 ]; then
    #selected_image_name_ref="${image_tag_list[0]}"
    selected_image_name_ref="${repoAccount}/${repoName}:${image_tag_list[0]}"
    ndr_logDebug "Only 1 tag matching [${imageBaseName}_${image_version}] found in repo ${repoAccount}/${repoName}."
    ndr_logDebug "Skipping interactive selection prompt and using image [$selected_image_name_ref]."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  local current_timestampUTC=""
  local module_name="$gREGISTRY_ENTRY_MODULE_STATUS_SERVICE_NAME"
  local container_name="$NDR_SERVICE_CONTAINER_NAME"
  if [[ "$imageBaseName" == "$NDR_UI_IMAGE_NAME" ]]; then
    module_name="$gREGISTRY_ENTRY_MODULE_STATUS_UI_NAME"
    container_name="$NDR_UI_CONTAINER_NAME"
  fi
  
  if ndr_isModuleInstalledReg "$module_name"; then
    current_timestampUTC=$(ndr_QueryContainerImageTimestampUTC "$container_name")
    return_code=$?
    if [[ $return_code -ne 0 || -z "$current_timestampUTC" ]]; then
      ndr_logError "Failed to retrieve image timestamp for container [$container_name]."
      return 1
    fi
    ndr_logInfo "Current installed image timestamp UTC is [$current_timestampUTC]"
  fi

  # build menu items from retrieved tag list
  declare -a menuItem=() # primary array to hold menu item indices and actions
  declare -A menuItemDesc=() # associative array to hold menu item descriptions
  declare -A menuItemTag=()  # associative array to hold menu item tags

  local menuIndex=1
  local search_tag="${image_name}_${image_version}"
  for tag in "${image_tag_list[@]}"; do
    local imageTimestampUTC=$(ndr_ParseImageTagTimestamp "$tag")
    if [[ -z "$imageTimestampUTC" ]]; then
      ndr_logError "Failed to parse timestamp from image tag [$tag]."
      return 1
    fi

    #local imageTimestampHuman=$(date -u -d @"$imageTimestampUTC" +"%Y-%m-%d")
    local imageTimestampHuman=$(date -u -d @"$imageTimestampUTC" +"%Y-%m-%d, %H:%M UTC")
    return_code=$?
    if [[ $return_code -ne 0 || -z "$imageTimestampHuman" ]]; then
      ndr_logError "Failed to convert timestamp [$imageTimestampUTC] to human readable format."
      return 1
    fi
    ndr_logDebug "Found tag [$tag] with timestamp [$imageTimestampHuman]"

    # Check if tag timestamp is less than any currently installed image timestamp.
    # To be a selectable option, timestamp must be newer than currently installed.
    if [ -n "$current_timestampUTC" ] && [ "$current_timestampUTC" -gt 0 ] && [ "$imageTimestampUTC" -lt "$current_timestampUTC" ]; then
      ndr_logInfo "Remote image tag reference timestamp [$imageTimestampUTC] is less than the currently installed timestamp [$current_timestampUTC], skipping item."
      continue
    fi

    menuItem["$menuIndex"]="$menuIndex"
    local desc="$tag (built on $imageTimestampHuman)"
    if [ "$menuIndex" -eq 1 ]; then
      desc="$desc  <-- Latest"
    fi
    if [ -n "$current_timestampUTC" ] && [ "$current_timestampUTC" -gt 0 ] && [ "$imageTimestampUTC" -eq "$current_timestampUTC" ]; then
      desc="$desc  <-- Installed"
    fi
    menuItemDesc["$menuIndex"]="$desc"
    menuItemTag["$menuIndex"]="$tag"
    ((menuIndex++))
  done

  while true; do

    echo "===================================================================="
    echo "Available remote image tags for [$imageBaseName:$image_version] in repo [$repoAccount/$repoName]"
    echo "===================================================================="
    echo "Please select an option:"
    echo ""
    for idx in "${!menuItem[@]}"; do
      echo "$idx. ${menuItemDesc[$idx]}"
    done
    echo "q. Exit/Abort"
    echo ""
    read -p "Enter your choice [1-n]: " choice

    # check for non-numerical choice (exit, test, etc)
    if ! [[ "$choice" =~ ^[0-9]+$ ]]; then
      if [[ "$choice" == "q" || "$choice" == "Q" ]]; then
        ndr_logInfo "Exiting installer."
        return 1
      else
        ndr_logWarn "Invalid selection [$choice], please try again."
        continue
      fi
    fi
        
    # translate numerical choice index to menu item index
    local selectedTag="${menuItemTag[$choice]}"
    ndr_logDebug "User selected menu choice [$choice] -> tag [$selectedTag]"
    if [[ "$choice" -eq 0 || -z "$selectedTag" ]]; then
      ndr_logWarn "Invalid selection [$choice], please try again."
      continue
    fi

    ndr_logInfo "User selected remote image tag [$selectedTag] for image [$imageBaseName:$image_version] in repo [$repoAccount/$repoName]"

    selected_image_name_ref="${repoAccount}/${repoName}:${selectedTag}"

    break
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function <search_image_name> <image_tag_ref>
function ndr_PromptRemoteImageTag ()
{
  local logSectionDesc="Prompting for Remote Image Tag"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <search_image_name> <image_tag_ref>"
    return 1
  fi

  local search_image_name="$1"
  local -n image_tag_ref="$2"
  local repoAccount="$NDR_DOCKER_REPO_ACCOUNT"
  local repo=""
  local image_version="$gPRODUCT_VERSION"

  # select private or public repo based on current setting
  local svcRepo="$NDR_DOCKER_SERVICE_PUBLIC_REPO_NAME"
  local uiRepo="$NDR_DOCKER_UI_PUBLIC_REPO_NAME"
  
  # Further refine repo based on image name
  if [[ "$search_image_name" == "$NDR_SERVICE_IMAGE_NAME" ]]; then
    repo="$svcRepo"
  elif [[ "$search_image_name" == "$NDR_UI_IMAGE_NAME" ]]; then
    repo="$uiRepo"
  else
    ndr_logWarn "Invalid image name [$search_image_name]"
    return 1
  fi
  
  ndr_QueryMatchingRemoteImageTagList "$repoAccount" "$repo" "$search_image_name" "$image_version"
  local return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to query remote image tag list for [$search_image_name:$image_version] in repo [$repoAccount/$repo]"
    return 1
  fi

  if [ "${#NDR_REMOTE_DOCKER_IMAGE_LIST[@]}" -eq 0 ]; then
    ndr_logWarn "No tags found in repo ${repoAccount}/${repo}"
    return 1
  fi

  local current_timestampUTC=""
  local module_name="$gREGISTRY_ENTRY_MODULE_STATUS_SERVICE_NAME"
  local container_name="$NDR_SERVICE_CONTAINER_NAME"
  if [[ "$search_image_name" == "$NDR_UI_IMAGE_NAME" ]]; then
    module_name="$gREGISTRY_ENTRY_MODULE_STATUS_UI_NAME"
    container_name="$NDR_UI_CONTAINER_NAME"
  fi
  if ndr_isModuleInstalledReg "$module_name"; then
    current_timestampUTC=$(ndr_QueryContainerImageTimestampUTC "$container_name")
    return_code=$?
    if [[ $return_code -ne 0 || -z "$current_timestampUTC" ]]; then
      ndr_logError "Failed to retrieve image timestamp for container [$container_name]."
      return 1
    fi
    ndr_logInfo "Current installed image timestamp UTC is [$current_timestampUTC]"
  fi

  # build menu items from retrieved tag list
  declare -a menuItem=() # primary array to hold menu item indices and actions
  declare -A menuItemDesc=() # associative array to hold menu item descriptions
  declare -A menuItemTag=()  # associative array to hold menu item tags

  local menuIndex=1
  local search_tag="${image_name}_${image_version}"
  for tag in "${NDR_REMOTE_DOCKER_IMAGE_LIST[@]}"; do
    local imageTimestampUTC=$(ndr_ParseImageTagTimestamp "$tag")
    if [[ -z "$imageTimestampUTC" ]]; then
      ndr_logError "Failed to parse timestamp from image tag [$tag]."
      return 1
    fi

    #local imageTimestampHuman=$(date -u -d @"$imageTimestampUTC" +"%Y-%m-%d")
    local imageTimestampHuman=$(date -u -d @"$imageTimestampUTC" +"%Y-%m-%d, %H:%M UTC")
    return_code=$?
    if [[ $return_code -ne 0 || -z "$imageTimestampHuman" ]]; then
      ndr_logError "Failed to convert timestamp [$imageTimestampUTC] to human readable format."
      return 1
    fi
    ndr_logDebug "Found tag [$tag] with timestamp [$imageTimestampHuman]"

    # Check if tag timestamp is less than any currently installed image timestamp.
    # To be a selectable option, timestamp must be newer than currently installed.
    if [ -n "$current_timestampUTC" ] && [ "$current_timestampUTC" -gt 0 ] && [ "$imageTimestampUTC" -lt "$current_timestampUTC" ]; then
      ndr_logInfo "Remote image tag reference timestamp [$imageTimestampUTC] is less than the currently installed timestamp [$current_timestampUTC], skipping item."
      continue
    fi

    menuItem["$menuIndex"]="$menuIndex"
    local desc="$tag (built on $imageTimestampHuman)"
    if [ "$menuIndex" -eq 1 ]; then
      desc="$desc  <-- Latest"
    fi
    if [ -n "$current_timestampUTC" ] && [ "$current_timestampUTC" -gt 0 ] && [ "$imageTimestampUTC" -eq "$current_timestampUTC" ]; then
      desc="$desc  <-- Installed"
    fi
    menuItemDesc["$menuIndex"]="$desc"
    menuItemTag["$menuIndex"]="$tag"
    ((menuIndex++))
  done

  while true; do

    echo "===================================================================="
    echo "Available remote image tags for [$search_image_name:$image_version] in repo [$repoAccount/$repo]"
    echo "===================================================================="
    echo "Please select an option:"
    echo ""
    for idx in "${!menuItem[@]}"; do
      echo "$idx. ${menuItemDesc[$idx]}"
    done
    echo "q. Exit/Abort"
    echo ""
    read -p "Enter your choice [1-n]: " choice

    # check for non-numerical choice (exit, test, etc)
    if ! [[ "$choice" =~ ^[0-9]+$ ]]; then
      if [[ "$choice" == "q" || "$choice" == "Q" ]]; then
        ndr_logInfo "Exiting installer."
        return 1
      else
        ndr_logWarn "Invalid selection [$choice], please try again."
        continue
      fi
    fi
        
    # translate numerical choice index to menu item index
    local selectedTag="${menuItemTag[$choice]}"
    ndr_logDebug "User selected menu choice [$choice] -> tag [$selectedTag]"
    if [[ "$choice" -eq 0 || -z "$selectedTag" ]]; then
      ndr_logWarn "Invalid selection [$choice], please try again."
      continue
    fi

    ndr_logInfo "User selected remote image tag [$selectedTag] for image [$search_image_name:$image_version] in repo [$repoAccount/$repo]"

    # update globals. 
    ndr_PopulateImageVersionGlobals "$search_image_name" "$selectedTag"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to populate image version globals for image [$search_image_name] with tag [$selectedTag]"
      return 1
    fi

    break
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# Queries for the latest remote image tags from a specified repo matching an optional image name and updates the associated globals for those images.
# If no image name supplied, queries all image repos.
# usage: function <image_base_name>
function ndr_QueryLatestMatchingRemoteImageTags ()
{
  local logSectionDesc="Querying Latest Matching Remote Image Tags"

  ndr_logSecStartDebug "$logSectionDesc"

  local search_image_name="${1:-}"
  local repoAccount="$NDR_DOCKER_REPO_ACCOUNT"
  local repo=""
  local image_version="$gPRODUCT_VERSION"

  if [ "$gNDR_SKIP_REMOTE_IMAGE_REPO_UPDATE_CHECK" == true ]; then
    ndr_logInfo "Skipping remote Docker repo image tag check per override."
    return 0
  fi

  if [ "$NDR_DOCKER_REMOTE_REPO_QUERIED" == true ]; then
    ndr_logDebug "Already queried remote Docker repo for latest image tags."
    return 0
  fi

  local svcRepo="$NDR_DOCKER_SERVICE_PUBLIC_REPO_NAME"
  local uiRepo="$NDR_DOCKER_UI_PUBLIC_REPO_NAME"
  
  declare -A mapImagesAndRepos=()
  if [ -n "$search_image_name" ]; then
    if [[ "$search_image_name" == "$NDR_SERVICE_IMAGE_NAME" ]]; then
      mapImagesAndRepos["$NDR_SERVICE_IMAGE_NAME"]="$svcRepo"
    elif [[ "$search_image_name" == "$NDR_UI_IMAGE_NAME" ]]; then
      mapImagesAndRepos["$NDR_UI_IMAGE_NAME"]="$uiRepo"
    else
      ndr_logWarn "Invalid image name [$search_image_name]"
    fi
  else
    mapImagesAndRepos["$NDR_SERVICE_IMAGE_NAME"]="$svcRepo"
    mapImagesAndRepos["$NDR_UI_IMAGE_NAME"]="$uiRepo"
  fi

  local retVal=0
  for image_name in "${!mapImagesAndRepos[@]}"; do
    repo="${mapImagesAndRepos[$image_name]}"
    ndr_logInfo "Searching for latest remote image for [$image_name:$image_version] in repo [$repoAccount/$repo]"
    
    local latest_tag=$(ndr_QueryLatestMatchingRemoteImageTag "$repoAccount" "$repo" "$image_name" "$image_version")
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logWarn "No matching remote image found for [$image_name:$image_version] in repo [$repoAccount/$repo]"
      retVal=1
      continue
    fi

    ndr_logDebug "Latest remote image for [$image_name:$image_version] is [$repoAccount/$repo:$latest_tag]"

    # update globals. 
    ndr_PopulateImageVersionGlobals "$image_name" "$latest_tag"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logWarn "Failed to populate image version globals for image [$image_name] with tag [$latest_tag]"
      retVal=1
      continue
    fi

  done

  if [ $retVal -ne 0 ]; then
    ndr_logWarn "One or more images not found in repo."
  else
    ndr_logDebug "All images found in repo."
    # upldate the repo queried flag ONLY if we queried all repo's (not specific single repo)
    if [ -z "$search_image_name" ]; then
      NDR_DOCKER_REMOTE_REPO_QUERIED=true
      ndr_logInfo "All repo's queried, marking queried flag true."
    fi
  fi

  ndr_logSecEndDebug "$logSectionDesc"

  return "$retVal"
}

function ndr_PopulateImageVersionGlobals ()
{
  local logSectionDesc="Populating Image Version Globals"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <image_name> <image_tag>"
    return 1
  fi

  local image_name="$1"
  local image_tag="$2"
  local image_version="$gPRODUCT_VERSION"

  # parse out the git commit hash from the tag
  local commit_hash=$(ndr_ParseImageTagCommitHash "$image_tag")
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logWarn "Failed to parse commit hash from tag [$image_tag]"
    return 1
  fi

  # parse out the timestamp from the tag
  local timestamp=$(ndr_ParseImageTagTimestamp "$image_tag")
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logWarn "Failed to parse timestamp from tag [$image_tag]"
    return 1
  fi

  ndr_logDebug "Latest remote image for [$image_name:$image_tag] has commit hash [$commit_hash] and timestamp [$timestamp]"

  # populate global variables
  while true; do
    local version_tag="${image_tag#*_}"
    if [[ "$image_name" == "$NDR_SERVICE_IMAGE_NAME" ]]; then
      ndr_logDebug "image_version: $image_version, NDR_SERVICE_IMAGE_VERSION: $NDR_SERVICE_IMAGE_VERSION, timestamp: $timestamp, NDR_SERVICE_IMAGE_COMMIT_TIMESTAMP_UTC: $NDR_SERVICE_IMAGE_COMMIT_TIMESTAMP_UTC"
      # To update globals, image version must match expected product version and timestamp must be newer than current
      # Note - we also allow explicit selection of tag that may not be the exact latest for testing purposes.
      if [[ "$image_version" == "$NDR_SERVICE_IMAGE_VERSION" && "$timestamp" -le "$NDR_SERVICE_IMAGE_COMMIT_TIMESTAMP_UTC" ]]; then
        ndr_logInfo "Service image tag reference version/timestamp [$NDR_SERVICE_IMAGE_VERSION_TAG] newer or equal to latest remote repo [$version_tag]."
        #break
      fi

      NDR_SERVICE_IMAGE_VERSION="$image_version"
      NDR_SERVICE_IMAGE_VERSION_TAG="$version_tag"
      NDR_GIT_REPO_COMMIT_HASH_SHORT="$commit_hash"
      NDR_SERVICE_IMAGE_COMMIT_HASH_SHORT="$commit_hash"
      NDR_SERVICE_IMAGE_COMMIT_TIMESTAMP_UTC="$timestamp"
      
      ndr_logInfo "Updated service image version to [$NDR_SERVICE_IMAGE_VERSION], tag to [$NDR_SERVICE_IMAGE_VERSION_TAG], commit hash to [$NDR_SERVICE_IMAGE_COMMIT_HASH_SHORT], timestamp to [$NDR_SERVICE_IMAGE_COMMIT_TIMESTAMP_UTC]"

    elif [[ "$image_name" == "$NDR_UI_IMAGE_NAME" ]]; then
      ndr_logDebug "image_version: $image_version, NDR_UI_IMAGE_VERSION: $NDR_UI_IMAGE_VERSION, timestamp: $latest_timestamp, NDR_UI_IMAGE_COMMIT_TIMESTAMP_UTC: $NDR_UI_IMAGE_COMMIT_TIMESTAMP_UTC"
      # To update globals, image version must match expected product version and timestamp must be newer than current
      # Note - we also allow explicit selection of tag that may not be the exact latest for testing purposes.
      if [[ "$image_version" == "$NDR_UI_IMAGE_VERSION" && "$timestamp" -le "$NDR_UI_IMAGE_COMMIT_TIMESTAMP_UTC" ]]; then
        ndr_logInfo "UI image tag reference version/timestamp [$NDR_UI_IMAGE_VERSION_TAG] newer or equal to latest remote repo [$version_tag]."
        #break
      fi

      NDR_UI_IMAGE_VERSION="$image_version"
      NDR_UI_IMAGE_VERSION_TAG="$version_tag"
      NDR_GIT_REPO_COMMIT_HASH_SHORT="$commit_hash"
      NDR_UI_IMAGE_COMMIT_HASH_SHORT="$commit_hash"
      NDR_UI_IMAGE_COMMIT_TIMESTAMP_UTC="$timestamp"
      
      ndr_logInfo "Updated UI image version to [$NDR_UI_IMAGE_VERSION], tag to [$NDR_UI_IMAGE_VERSION_TAG], commit hash to [$NDR_UI_IMAGE_COMMIT_HASH_SHORT], timestamp to [$NDR_UI_IMAGE_COMMIT_TIMESTAMP_UTC]"

    else
      ndr_logWarn "Invalid image name [$image_name]"
      return 1
    fi

    break
  done

  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

# queries for and constructs a list of remote image tags from a specified repo matching a single image name.
# usage: function <repo_account> <repo_name> <image_base_name> <image_version> <image_list_ref> [optional: max_tags]
function ndr_QueryMatchingRemoteImageTagListV2 ()
{
  if [[ $# -ne 5 ]]; then
    ndr_logError "Usage: function <repo_account> <repo_name> <image_base_name> <image_version> <image_list_ref> [optional: max_tags]"
    return 1
  fi

  local repoAccount="$1"
  local repo="$2"
  local image_base_name="$3"
  local image_version="$4"
  local -n _image_list_ref="$5"
  local max_tags="${6:-$gNDR_MAX_IMAGE_LIST}"

  ndr_logDebug "Searching for max [$max_tags] remote images matching pattern [${image_base_name}_${image_version}] in repo [$repoAccount/$repo]"

  local tags=()
  
  # Fetch tags
  if [[ "$NDR_DOCKER_REPO_TYPE_CURRENT" == "$NDR_DOCKER_REPO_TYPE_LOCAL_REGISTRY" ]]; then
    #http://localhost:5150/v2/nextdr/nextdr-ui/tags/list
    local query_url="http://${gNDR_DOCKER_LOCAL_REGISTRY_HOST}:${gNDR_DOCKER_LOCAL_REGISTRY_PORT}/v2/${repoAccount}/${repo}/tags/list"
    local query_cmd="curl -s $query_url | jq -r '.tags[]'"
    ndr_logDebug "Querying local registry at [$query_url] for tags in repo [$repoAccount/$repo]"

    local response=$(eval "$query_cmd")
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to execute query command [$query_cmd]."
      return 1
    fi
    ndr_logDebug "Response: $response"
    
    mapfile -t tags < <(echo "$response")
  elif [[ "$NDR_DOCKER_REPO_TYPE_CURRENT" == "$NDR_DOCKER_REPO_TYPE_GCP_REGISTRY" ]]; then
    local gcp_images=()
    local gcp_root_prefix="${gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT}/"
    local full_image=""
    local trimmed_image=""
    local parsed_repo_account=""
    local parsed_repo_name=""
    local parsed_image_base_name=""
    local parsed_image_version_tag=""

    ndr_logDebug "Querying GCP registry at [$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT] for tags in repo [$repoAccount/$repo]"
    
    ndr_GCPDockerRegistryQueryTags gcp_images "$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT" "$repoAccount"
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Failed to query GCP registry tags for root [$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT]."
      return 1
    fi

    for full_image in "${gcp_images[@]}"; do
      if [[ "$full_image" == "$gcp_root_prefix"* ]]; then
        trimmed_image="${full_image#${gcp_root_prefix}}"
      else
        trimmed_image="$full_image"
      fi

      #if [[ "$trimmed_image" == "$full_image" ]]; then
      #  ndr_logDebug "Skipping GCP image outside expected root [$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT]: [$full_image]"
      #  continue
      #fi

      ndr_ParseFullImageName "$trimmed_image" parsed_repo_account parsed_repo_name parsed_image_base_name parsed_image_version_tag
      return_code=$?
      if [[ $return_code -ne 0 ]]; then
        ndr_logWarn "Skipping unparsable GCP image [$trimmed_image]"
        continue
      fi

      if [[ "$parsed_repo_account" != "$repoAccount" || "$parsed_repo_name" != "$repo" ]]; then
        continue
      fi

      ndr_logDebug "Matched tag: ${parsed_image_base_name}_${parsed_image_version_tag}"

      tags+=("${parsed_image_base_name}_${parsed_image_version_tag}")
    done
  else
    local query_url="https://hub.docker.com/v2/repositories/${repoAccount}/${repo}/tags/"
    local query_cmd="curl -s \"$query_url\" | jq -r '.results[].name'"
    ndr_logDebug "Querying Docker Hub at [$query_url] for tags in repo [$repoAccount/$repo]"

    local response=$(eval "$query_cmd")
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to execute query command [$query_cmd]."
      return 1
    fi
    ndr_logDebug "Response: $response"
    
    mapfile -t tags < <(echo "$response")
  fi

  if [ "${#tags[@]}" -eq 0 ]; then
    ndr_logWarn "No tags matching pattern [${image_base_name}_${image_version}] found in repo ${repoAccount}/${repo}"
    return 1
  fi

  ndr_logDebug "Found ${#tags[@]} unfiltered tags in repo ${repoAccount}/${repo}"

  # reset list
  _image_list_ref=()

  # sort tag list
  mapfile -t _image_list_ref < <(
    printf '%s\n' "${tags[@]}" \
    | awk -F'-' '{ print $NF "\t" $0 }' \
    | sort -nr \
    | cut -f2- 
  )
  
  # filter tags by image name and NDR version pattern.
  # specifically we want the base name with the NDR version value only since that produces all matches for a given image across all builds (timestamps/commits). 
  # This allows the user to select any build of the image that matches the expected version, not just the latest.

  local imageTagNDRVersion=""
  ndr_ParseImageTagVersionV2 "$image_version" imageTagNDRVersion
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to parse image tag version from image version [$image_version]."
    return 1
  fi

  local pattern="${image_base_name}_${imageTagNDRVersion}"
  local filtered=()

  for img in "${_image_list_ref[@]}"; do
    if [[ "$img" == *"$pattern"* ]]; then
      filtered+=("$img")
    fi
  done

  _image_list_ref=("${filtered[@]}")
  ndr_logDebug "Found ${#_image_list_ref[@]} filtered tags matching pattern [$pattern]."

  # Keep top N tags only
  if [ "${#_image_list_ref[@]}" -gt "$gNDR_MAX_IMAGE_LIST" ]; then
    ndr_logDebug "Trimming tag list to max of [$gNDR_MAX_IMAGE_LIST] entries."
    _image_list_ref=( "${_image_list_ref[@]:0:gNDR_MAX_IMAGE_LIST}" )
  fi
  
  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

# queries for and constructs a list of remote image tags from a specified repo matching a single image name.
function ndr_QueryMatchingRemoteImageTagList ()
{
  if [[ $# -ne 4 ]]; then
    ndr_logError "Usage: function <user> <repo_name> <image_name> <image_version>"
    return 1
  fi

  local repoAccount="$1"
  local repo="$2"
  local image_name="$3"
  local image_version="$4"

  ndr_logDebug "Searching for max [$gNDR_MAX_IMAGE_LIST] remote images matching pattern [${image_name}_${image_version}] in repo [$repoAccount/$repo]"

  local tags=()
  
  # Fetch tags
  if [[ "$NDR_DOCKER_REPO_TYPE_CURRENT" == "$NDR_DOCKER_REPO_TYPE_LOCAL_REGISTRY" ]]; then
    #http://localhost:5150/v2/nextdr/nextdr-ui/tags/list
    local query_url="http://${gNDR_DOCKER_LOCAL_REGISTRY_HOST}:${gNDR_DOCKER_LOCAL_REGISTRY_PORT}/v2/${repoAccount}/${repo}/tags/list"
    local query_cmd="curl -s $query_url | jq -r '.tags[]'"
    ndr_logInfo "Querying local registry at [$query_url] for tags in repo [$repoAccount/$repo]"

    local response=$(eval "$query_cmd")
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to execute query command [$query_cmd]."
      return 1
    fi
    ndr_logDebug "Response: $response"
    
    mapfile -t tags < <(echo "$response")
  elif [[ "$NDR_DOCKER_REPO_TYPE_CURRENT" == "$NDR_DOCKER_REPO_TYPE_GCP_REGISTRY" ]]; then
    local gcp_images=()
    local gcp_root_prefix="${gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT}/"
    local full_image=""
    local trimmed_image=""
    local parsed_repo_account=""
    local parsed_repo_name=""
    local parsed_image_base_name=""
    local parsed_image_version_tag=""

    ndr_GCPDockerRegistryQueryTags gcp_images "$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT" "$repoAccount"
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Failed to query GCP registry tags for root [$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT]."
      return 1
    fi

    for full_image in "${gcp_images[@]}"; do
      if [[ "$full_image" == "$gcp_root_prefix"* ]]; then
        trimmed_image="${full_image#${gcp_root_prefix}}"
      else
        trimmed_image="$full_image"
      fi

      #if [[ "$trimmed_image" == "$full_image" ]]; then
      #  ndr_logDebug "Skipping GCP image outside expected root [$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT]: [$full_image]"
      #  continue
      #fi

      ndr_ParseFullImageName "$trimmed_image" parsed_repo_account parsed_repo_name parsed_image_base_name parsed_image_version_tag
      return_code=$?
      if [[ $return_code -ne 0 ]]; then
        ndr_logWarn "Skipping unparsable GCP image [$trimmed_image]"
        continue
      fi

      if [[ "$parsed_repo_account" != "$repoAccount" || "$parsed_repo_name" != "$repo" ]]; then
        continue
      fi

      ndr_logDebug "Matched tag: ${parsed_image_base_name}_${parsed_image_version_tag}"

      tags+=("${parsed_image_base_name}_${parsed_image_version_tag}")
    done
  else
    local query_url="https://hub.docker.com/v2/repositories/${repoAccount}/${repo}/tags/"
    local query_cmd="curl -s \"$query_url\" | jq -r '.results[].name'"
    ndr_logInfo "Querying Docker Hub at [$query_url] for tags in repo [$repoAccount/$repo]"

    local response=$(eval "$query_cmd")
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to execute query command [$query_cmd]."
      return 1
    fi
    ndr_logDebug "Response: $response"
    
    mapfile -t tags < <(echo "$response")
  fi

  if [ "${#tags[@]}" -eq 0 ]; then
    ndr_logWarn "No tags matching pattern [${image_name}_${image_version}] found in repo ${repoAccount}/${repo}"
    return 1
  fi

  ndr_logDebug "Found ${#tags[@]} unfiltered tags in repo ${repoAccount}/${repo}"

  #reset global list
  NDR_REMOTE_DOCKER_IMAGE_LIST=()

  # sort tag list
  mapfile -t NDR_REMOTE_DOCKER_IMAGE_LIST < <(
    printf '%s\n' "${tags[@]}" \
    | awk -F'-' '{ print $NF "\t" $0 }' \
    | sort -nr \
    | cut -f2- 
  )
  
  # filter tags by image name and version pattern
  local pattern="${image_name}_${image_version}"
  local filtered=()

  for img in "${NDR_REMOTE_DOCKER_IMAGE_LIST[@]}"; do
    if [[ "$img" == *"$pattern"* ]]; then
      filtered+=("$img")
    fi
  done

  NDR_REMOTE_DOCKER_IMAGE_LIST=("${filtered[@]}")
  ndr_logDebug "Found ${#NDR_REMOTE_DOCKER_IMAGE_LIST[@]} filtered tags matching pattern [$pattern]."

  # Keep top N tags only
  if [ "${#NDR_REMOTE_DOCKER_IMAGE_LIST[@]}" -gt "$gNDR_MAX_IMAGE_LIST" ]; then
    ndr_logDebug "Trimming tag list to max of [$gNDR_MAX_IMAGE_LIST] entries."
    NDR_REMOTE_DOCKER_IMAGE_LIST=( "${NDR_REMOTE_DOCKER_IMAGE_LIST[@]:0:gNDR_MAX_IMAGE_LIST}" )
  fi
  
  #printf '%s\n' "${NDR_REMOTE_DOCKER_IMAGE_LIST[@]}"

  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

# usage: function <full_search_image_name> <latest_image_name_ref>
# for a given full image name in the form <repo_account>/<repo_name>:<image_name>_<image_version>, queries the remote docker repo for tags matching the pattern <image_base_name>_<image_version_tag>
function ndr_QueryLatestMatchingRemoteImageTagV2 ()
{
  local logSectionDesc="Querying Latest Matching Remote Image Tag"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <full_search_image_name> <latest_image_name_ref>"
    return 1
  fi

  local full_search_image_name="$1"
  local -n latest_image_name_ref="$2"

  local repoAccount=
  local repo=
  local image_base_name=
  local image_version=
  
  ndr_ParseNDRFullImageName "$full_search_image_name" repoAccount repo image_base_name image_version
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to parse full image name [$full_search_image_name]."
    return 1
  fi

  ndr_logDebug "Searching for remote images matching pattern [${image_base_name}_${image_version}] in repo [$repoAccount/$repo]"

  local image_tag_list=()

  ndr_QueryMatchingRemoteImageTagListV2 "$repoAccount" "$repo" "$image_base_name" "$image_version" image_tag_list
  local return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to query remote image tag list for [${image_base_name}_${image_version}] in repo [$repoAccount/$repo]"
    return 1
  fi

  if [ "${#image_tag_list[@]}" -eq 0 ]; then
    ndr_logWarn "No tags found in repo ${repoAccount}/${repo}"
    return 1
  fi

  local imageTagNDRVersion=""
  ndr_ParseImageTagVersionV2 "$full_search_image_name" imageTagNDRVersion
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to parse image tag version from image version [$image_version]."
    return 1
  fi

  # Parse and find latest timestamp
  local search_tag="${image_base_name}_${imageTagNDRVersion}"
  declare -A tag_ts_map
  for tag in "${image_tag_list[@]}"; do
    if [[ "$tag" =~ ^${search_tag}-[[:alnum:]]+-([0-9]+)$ ]]; then
      ts="${BASH_REMATCH[1]}"
      tag_ts_map["$tag"]="$ts"
      ndr_logDebug "Matched tag: $tag with timestamp: $ts"
    fi
  done

  local latest_tag=""
  local latest_ts=0
  for tag in "${!tag_ts_map[@]}"; do
    ts="${tag_ts_map[$tag]}"
    if (( ts > latest_ts )); then
      latest_ts=$ts
      latest_tag="$tag"
    fi
  done

  if [ -z "$latest_tag" ]; then
    ndr_logError "No matching tags found for version prefix '$search_tag'"
    return 1
  fi
  
  latest_image_name_ref="${repoAccount}/${repo}:${latest_tag}"
  
  ndr_logDebug "Found latest image: ${latest_image_name_ref}"
  
  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

# for a given user/org, repo, image name and version prefix, queries the remote docker repo for tags matching the pattern <image_name>_<image_version>-<git_hash>-<timestamp>
function ndr_QueryLatestMatchingRemoteImageTag ()
{
  local logSectionDesc="Querying Latest Matching Remote Image Tag"
  ndr_logSecStartDebug "$logSectionDesc"

  if [[ $# -ne 4 ]]; then
    ndr_logError "Usage: function <user> <repo_name> <image_name> <image_version>"
    return 1
  fi

  local repoAccount="$1"
  local repo="$2"
  local image_base_name="$3"
  local image_version="$4"

  ndr_logDebug "Searching for remote images matching pattern [${image_base_name}_${image_version}] in repo [$repoAccount/$repo]"

  ndr_QueryMatchingRemoteImageTagList "$repoAccount" "$repo" "$image_base_name" "$image_version"
  local return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to query remote image tag list for [${image_base_name}_${image_version}] in repo [$repoAccount/$repo]"
    return 1
  fi

  if [ "${#NDR_REMOTE_DOCKER_IMAGE_LIST[@]}" -eq 0 ]; then
    ndr_logWarn "No tags found in repo ${repoAccount}/${repo}"
    return 1
  fi

  # Parse and find latest timestamp
  local search_tag="${image_base_name}_${image_version}"
  declare -A tag_ts_map
  for tag in "${NDR_REMOTE_DOCKER_IMAGE_LIST[@]}"; do
    if [[ "$tag" =~ ^${search_tag}-[[:alnum:]]+-([0-9]+)$ ]]; then
      ts="${BASH_REMATCH[1]}"
      tag_ts_map["$tag"]="$ts"
      ndr_logDebug "Matched tag: $tag with timestamp: $ts"
    fi
  done

  local latest_tag=""
  local latest_ts=0
  for tag in "${!tag_ts_map[@]}"; do
    ts="${tag_ts_map[$tag]}"
    if (( ts > latest_ts )); then
      latest_ts=$ts
      latest_tag="$tag"
    fi
  done

  local retVal=0
  if [ -n "$latest_tag" ]; then
    ndr_logInfo "Found latest tag: ${repoAccount}/${repo}:${latest_tag}"
  else
    ndr_logError "No matching tags found for version prefix '$search_tag'"
    retVal=1
  fi

  ndr_logSecEndDebug "$logSectionDesc"

  if [ $retVal -eq 0 ]; then
    echo "$latest_tag"
  fi
  return "$retVal"
}

function ndr_LocalDockerRegistryPromptName ()
{
  local logSectionDesc="Prompting for Local Docker Registry Container Name"
  ndr_logSecStart "$logSectionDesc"

  local value_desc="$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME_DESC"

  value=$(ndr_PromptInputValue "$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME" "$value_desc")
  return_code=$?
  if [[ $return_code -ne 0 || -z "$value" ]]; then
    ndr_logError "Failed to get user input for $value_desc"
    ndr_logSecEnd "$logSectionDesc"
    return 1
  fi

  gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME="$value"
  ndr_logInfo "$value_desc set to [$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME]"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_LocalDockerRegistryPromptPort ()
{
  local logSectionDesc="Prompting for Local Docker Registry Port"
  ndr_logSecStart "$logSectionDesc"

  local value_desc="$gNDR_DOCKER_LOCAL_REGISTRY_PORT_DESC"

  value=$(ndr_PromptInputValue "$gNDR_DOCKER_LOCAL_REGISTRY_PORT" "$value_desc")
  return_code=$?
  if [[ $return_code -ne 0 || -z "$value" ]]; then
    ndr_logError "Failed to get user input for $value_desc"
    ndr_logSecEnd "$logSectionDesc"
    return 1
  fi

  gNDR_DOCKER_LOCAL_REGISTRY_PORT="$value"
  ndr_logInfo "$value_desc set to [$gNDR_DOCKER_LOCAL_REGISTRY_PORT]"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_LocalDockerRegistryPromptHost ()
{
  local logSectionDesc="Prompting for Local Docker Registry Host"
  ndr_logSecStart "$logSectionDesc"

  if [[ "$gNDR_DOCKER_LOCAL_REGISTRY_HOST" == "" ]]; then
    local queryHostAddress=$(curl -fsSL https://ifconfig.me)
    if [[ -n "$queryHostAddress" ]]; then
      gNDR_DOCKER_LOCAL_REGISTRY_HOST=$(printf "%s" "$queryHostAddress") # do this to trim out any line breaks that seem to come embedded in the output from this curl query.
      ndr_logInfo "Found possible address from network query [$queryHostAddress]"
    fi
  fi
  
  local value_desc="$gNDR_DOCKER_LOCAL_REGISTRY_HOST_DESC"

  value=$(ndr_PromptInputValue "$gNDR_DOCKER_LOCAL_REGISTRY_HOST" "$value_desc")
  return_code=$?
  if [[ $return_code -ne 0 || -z "$value" ]]; then
    ndr_logError "Failed to get user input for $value_desc"
    ndr_logSecEnd "$logSectionDesc"
    return 1
  fi

  gNDR_DOCKER_LOCAL_REGISTRY_HOST="$value"
  ndr_logInfo "$value_desc set to [$gNDR_DOCKER_LOCAL_REGISTRY_HOST]"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_LocalDockerRegistryPromptDir ()
{
  local logSectionDesc="Prompting for Local Docker Registry Data Directory"
  ndr_logSecStart "$logSectionDesc"

  local value_desc="$gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR_DESC"

  value=$(ndr_PromptInputValue "$gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR" "$value_desc")
  return_code=$?
  if [[ $return_code -ne 0 || -z "$value" ]]; then
    ndr_logError "Failed to get user input for $value_desc"
    ndr_logSecEnd "$logSectionDesc"
    return 1
  fi

  gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR="$value"
  ndr_logInfo "$value_desc set to [$gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR]"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_LocalDockerRegistryCreate ()
{
  local logSectionDesc="Creating Local Docker Registry"
  ndr_logSecStart "$logSectionDesc"

  # init with localhost as the default valuu to show user.
  gNDR_DOCKER_LOCAL_REGISTRY_HOST="localhost"

  # ----------------------------------------------------------------
  # collect basic registry info and validate
  ndr_LocalDockerRegistryPromptName
  local return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Local Docker Registry container name prompt failed or was aborted by user."
    return 1
  fi

  ndr_LocalDockerRegistryPromptHost
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Local Docker Registry host prompt failed or was aborted by user."
    return 1
  fi

  # If user has specified an IP other than localhost for registry creation, Docker will automatically perform images push using HTTPS instead of HTTP.
  # Log a warning that this may cause image push issues if the registry is using a non-localhost IP that it must be configured with TLS or docker be configured to allow insecure registries.
  if [[ "$gNDR_DOCKER_LOCAL_REGISTRY_HOST" != "localhost" && "$gNDR_DOCKER_LOCAL_REGISTRY_HOST" != "127.0.0.1" && "$gNDR_DOCKER_LOCAL_REGISTRY_HOST" != "0.0.0.0" ]]; then
    ndr_logWarn "You have specified a registry host IP of [$gNDR_DOCKER_LOCAL_REGISTRY_HOST]. If this is not localhost, ensure the registry is configured with TLS or docker is configured to allow insecure registries or else image pushes may fail."
  fi

  ndr_LocalDockerRegistryPromptPort
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Local Docker Registry port prompt failed or was aborted by user."
    return 1
  fi

  ndr_LocalDockerRegistryPromptDir
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Local Docker Registry data directory prompt failed or was aborted by user."
    return 1
  fi

  # ----------------------------------------------------------------
  # container pre-checks
  local containerRunning=false
  
  # in create mode, container should not previously exist.
  ndr_verifyDockerContainerExists "$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME" >/dev/null
  return_code=$?
  #2-error, 1-not found, 0-found
  if [[ $return_code == 0 ]]; then
    ndr_logError "Docker container '$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME' already exists."
    return 1
  fi

  # ----------------------------------------------------------------
  # if data directory exists, ensure its empty. If not empty, we assume its being used by an existing registry instance and we should not proceed with creation to avoid conflicts.
  if [ -d "$gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR" ]; then
    if [ "$(ls -A "$gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR")" ]; then
      ndr_logError "Local Docker Registry data directory [$gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR] is not empty. Please ensure the directory is empty or specify a different directory and try again."
      return 1
    fi
  fi

  # create data directory if it doesn't exist
  if [ ! -d "$gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR" ]; then
    mkdir -p "$gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR"
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Failed to create Local Docker Registry data directory [$gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR]."
      return 1
    fi
  fi

  # ----------------------------------------------------------------
  # port availability check - if port is in use, we assume registry or some other service is already running and we should not proceed with creation to avoid conflicts.
  if ss -tuln | grep -q ":$gNDR_DOCKER_LOCAL_REGISTRY_PORT "; then
    ndr_logError "Port $gNDR_DOCKER_LOCAL_REGISTRY_PORT is in use."
    return 1
  fi

  # ----------------------------------------------------------------
  # create registry

  local host_port_mapping="${gNDR_DOCKER_LOCAL_REGISTRY_PORT}:5000" # default mapping for localhost configured registries.
  if [[ "$gNDR_DOCKER_LOCAL_REGISTRY_HOST" != "localhost" && "$gNDR_DOCKER_LOCAL_REGISTRY_HOST" != "127.0.0.1" && "$gNDR_DOCKER_LOCAL_REGISTRY_HOST" != "0.0.0.0" ]]; then
    host_port_mapping="${gNDR_DOCKER_LOCAL_REGISTRY_HOST}:${gNDR_DOCKER_LOCAL_REGISTRY_PORT}:5000"
  fi

  docker run -d \
  --name "${gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME}" \
  --restart=unless-stopped \
  -p "${host_port_mapping}" \
  -v "${gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR}:/var/lib/registry" \
  -e REGISTRY_STORAGE_DELETE_ENABLED=true \
  registry:2
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to start Local Docker Registry container."
    return 1
  fi

  # ----------------------------------------------------------------
  # verify registry is running
  ndr_verifyDockerContainerRunning "$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Docker container [$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME] is not running."
    return 1
  fi

  ndr_logInfo "Local Docker Registry container [$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME] is running."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function <private_registry_type> <private_registry_repo_prefix> <image_list_ref>
function ndr_BuildCompletePopulationImageList ()
{
  local logSectionDesc="Building complete Docker image list"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 3 ]]; then
    ndr_logError "Usage: function <private_registry_type> <private_registry_repo_prefix> <image_list_ref>"
    return 1
  fi

  local regType="$1"
  local regPrefix="$2"
  local -n image_list_ref="$3"
  
  # hack: temporarily switch to dockerhub for ndr image queries. We have to do this because the tag query api's can't take in repo type yet. the actual reg type is in regType to restore it to later.
  NDR_DOCKER_REPO_TYPE_CURRENT="$NDR_DOCKER_REPO_TYPE_PUBLIC_NDR"

  # ----------------------------------------------------------------
  # query for supabase image list from compose file
  local install_image_list=()
  
  local tmpPath="/tmp"

  cd "$tmpPath" || { ndr_logError "Failed to cd into dir [$tmpPath]"; return 1; }

  local checkoutTag=$gNDR_SUPABASE_GIT_VERSION_TAG

  local -a compose_file_urls=(
    "https://raw.githubusercontent.com/supabase/supabase/$checkoutTag/docker/docker-compose.yml"
    "https://raw.githubusercontent.com/supabase/supabase/$checkoutTag/docker/docker-compose.pg17.yml"
  )
  local curlErrorFile="$tmpPath/ndr-supabase-compose-curl.err"

  local -a excluded_service_names=("${NDR_SUPABASE_APP_OPTIONAL_SERVICES[@]}")
  local -A excluded_service_lookup=()
  
  for excluded_service_name in "${excluded_service_names[@]}"; do
    excluded_service_lookup["$excluded_service_name"]=1
  done

  local COMPOSE_FILE

  for composeFileUrl in "${compose_file_urls[@]}"; do
    local composeFileName=$(basename "$composeFileUrl")
    COMPOSE_FILE="$tmpPath/$composeFileName"

    rm -f "$curlErrorFile" "$COMPOSE_FILE"
    curl --fail --location --retry 5 --retry-delay 2 --retry-connrefused "$composeFileUrl" -o "$composeFileName" 2>"$curlErrorFile"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to download Supabase compose file from [$composeFileUrl]."
      if [ -s "$curlErrorFile" ]; then
        ndr_logError "curl error output: $(tr '\n' ' ' < "$curlErrorFile")"
      fi
      return 1
    fi
    ndr_logInfo "Downloaded Supabase compose file [$composeFileName]."
    rm -f "$curlErrorFile"

    # Get list of services
    mapfile -t services < <(yq eval '.services | keys | .[]' "$COMPOSE_FILE")
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to retrieve services from compose file [$COMPOSE_FILE]."
      return 1
    fi

    if [[ ${#services[@]} -eq 0 ]]; then
      echo "No services found in compose file [$COMPOSE_FILE]."
      return 1
    fi

    ndr_logInfo "Read ${#services[@]} service entries from compose file [$COMPOSE_FILE]."

    for service_name in "${services[@]}"; do
      if [[ -v excluded_service_lookup["$service_name"] ]]; then
        ndr_logInfo "Skipping excluded service [$service_name]."
        continue
      fi

      local container_name=$(yq eval ".services.$service_name.container_name" "$COMPOSE_FILE")
      local image=$(yq eval ".services.$service_name.image" "$COMPOSE_FILE")

      if [[ -z "$image" || "$image" == "null" ]]; then
        ndr_logInfo "Service [$service_name] does not define an image in compose file [$COMPOSE_FILE], skipping."
        continue
      fi

      local image_base_name=$image
      local image_version

      if [[ "$image" == *:* ]]; then
        image_base_name="${image%%:*}"
        image_version="${image##*:}"
      fi

      ndr_AddSupabaseServiceMapEntry $service_name $container_name $image_base_name $image_version

      install_image_list+=("$image")

      ndr_logInfo "Added image [$image] to local registry images array."

    done
  done

  # ----------------------------------------------------------------
  # build list of NDR images

  # service
  local ndrImageBaseName=$NDR_SERVICE_IMAGE_NAME
  
  ndr_QueryLatestMatchingRemoteImageTags "$ndrImageBaseName"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to query remote repo for image tag details."
    return 1
  fi

  local ndrImageVersion=$NDR_SERVICE_IMAGE_VERSION_TAG
  local ndrRepoName="$NDR_DOCKER_SERVICE_PUBLIC_REPO_NAME"
  
  local repoImageName=$(ndr_ConstructFullImageTagString "$NDR_DOCKER_REPO_ACCOUNT" "$ndrRepoName" "$ndrImageBaseName" "$ndrImageVersion")

  install_image_list+=("$repoImageName")
  ndr_logInfo "Added image [$repoImageName] to local registry images array."

  # UI
  ndrImageBaseName=$NDR_UI_IMAGE_NAME
  
  ndr_QueryLatestMatchingRemoteImageTags "$ndrImageBaseName"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to query remote repo for image tag details."
    return 1
  fi

  ndrImageVersion=$NDR_UI_IMAGE_VERSION_TAG
  ndrRepoName="$NDR_DOCKER_UI_PUBLIC_REPO_NAME"
  
  repoImageName=$(ndr_ConstructFullImageTagString "$NDR_DOCKER_REPO_ACCOUNT" "$ndrRepoName" "$ndrImageBaseName" "$ndrImageVersion")

  install_image_list+=("$repoImageName")
  ndr_logInfo "Added image [$repoImageName] to local registry images array."

  # end hack: we can switch back now to the buffered global repo type
  NDR_DOCKER_REPO_TYPE_CURRENT="$regType"

  # caddy
  COMPOSE_FILE="${gSCRIPT_HOME_DIR}/$NDR_CLIENT_APP_CADDY_COMPOSEFILE_FILENAME"
  if [[ ! -f "$COMPOSE_FILE" ]]; then
    ndr_logError "Caddy compose file not found at expected location [$COMPOSE_FILE]."
    return 1
  fi
  local service_name="caddy"
  repoImageName=$(yq eval ".services.$service_name.image" "$COMPOSE_FILE")
  if [[ -z "$repoImageName" ]]; then
    ndr_logError "Failed to retrieve service [$service_name] details from compose file [$COMPOSE_FILE]."
    return 1
  fi
  install_image_list+=("$repoImageName")
  ndr_logInfo "Added image [$repoImageName] to local registry images array."


  # ----------------------------------------------------------------
  # check for any existing local registry image tags that match the current list, prune out any unchanged ones and keep only the newer ones.
  local existing_priv_repo_images=()
  if [[ "$regType" == "$NDR_DOCKER_REPO_TYPE_LOCAL_REGISTRY" ]]; then
    ndr_LocalDockerRegistryQueryTags existing_priv_repo_images "$gNDR_DOCKER_LOCAL_REGISTRY_HOST" "$gNDR_DOCKER_LOCAL_REGISTRY_PORT"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to query existing images from registry [$gNDR_DOCKER_LOCAL_REGISTRY_HOST:$gNDR_DOCKER_LOCAL_REGISTRY_PORT]."
      return 1
    fi
  elif [[ "$regType" == "$NDR_DOCKER_REPO_TYPE_GCP_REGISTRY" ]]; then
    ndr_GCPDockerRegistryQueryTags existing_priv_repo_images "$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to query existing images from registry [$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT]."
      return 1
    fi
  else
    ndr_logError "Invalid registry type: $regType"
    return 1
  fi

  if [ "${#existing_priv_repo_images[@]}" -eq 0 ]; then
    ndr_logInfo "No existing images found in private registry [$regPrefix]."
  else
    ndr_logInfo "Found ${#existing_priv_repo_images[@]} existing images in private registry [$regPrefix]."
  fi
  
  for image in "${existing_priv_repo_images[@]}"; do
    ndr_logDebug "Existing image in registry: ${image}"
  done

  local uptodate_images=() # represents images already present in registry that already match current images we would have added (no need to re-add these images).
  local new_images=() # represents new images or versions that do not already exist in registry that will need to be added.
  local other_images=() # represents images present in registry that are not part of the current list we would add (could be older versions of same images or other products altogether).

  for image in "${install_image_list[@]}"; do
    local found=false

    for existing_image in "${existing_priv_repo_images[@]}"; do
      # if current image is same as new image, we consider it up-to-date.
      if [[ "$existing_image" == "$image" ]]; then
        #ndr_logInfo "Image [$image] already exists in local registry with same tag. It will not be retagged or pushed again since its the same image, and it will not be pruned since it may be shared with other services."
        # remove from array so we don't retag and push again
        ndr_logDebug "Adding image [$image] to up-to-date images array."
        uptodate_images+=("$image")
        found=true
        break
      elif [[ "$existing_image" == *"$image"* ]]; then
        ndr_logDebug "Image [$image] matched as substring of existing image [$existing_image]."
        uptodate_images+=("$image")
        found=true
        break
      fi
    done

    # image must be new
    if [ "$found" == false ]; then
      ndr_logDebug "Adding image [$image] to new images array."
      new_images+=("$image")
    fi
  done

  # new reverse search through existing images to find images NOT in the install_image_list to-add list.
  for existing_image in "${existing_priv_repo_images[@]}"; do
    local found=false
    for image in "${install_image_list[@]}"; do
      if [[ "$existing_image" == "$image" ]]; then
        # existing image is in the to-add list.
        #ndr_logDebug "Image [$existing_imagee] is already in to-add list"
        found=true
        break
      elif [[ "$existing_image" == *"$image"* ]]; then
        ndr_logDebug "Image [$image] matched as substring of existing image [$existing_image]."
        found=true
        break
      fi
    done

    # image must be older or for other purpose
    if [ "$found" == false ]; then
      ndr_logDebug "Adding image [$existing_image] to other images array."
      other_images+=("$existing_image")
    fi
  done

  # reset install images array to only include new and updated images that need to be pulled, retagged and pushed to registry. We will keep any existing images that are the same since they may be shared with other services and we want to avoid breaking them by pruning them, and we will add the new images that need to be pulled, retagged and pushed.
  install_image_list=("${new_images[@]}")
 
  # ----------------------------------------------------------------
  # prepare report to show user before pulling and pushing images to registry
  echo "================ Private Registry Image Population ================"
  echo "Private registry at [$regPrefix]"
  echo ""
  if [ ${#uptodate_images[@]} -ne 0 ]; then
    echo "The following images are already up-to-date in the local registry and will be retained without changes since they may be shared with other services."
    for image_name in "${uptodate_images[@]}"; do
      echo "UP TO DATE - $image_name"
    done
    echo ""
  fi

  if [ ${#other_images[@]} -ne 0 ]; then
    echo "The following images are either not part of this product/version or may be out of date."
    for image_name in "${other_images[@]}"; do
      echo "OTHER - $image_name"
    done
    echo ""
  fi

  if [ ${#install_image_list[@]} -ne 0 ]; then
    echo "The following new images are available to be pushed to the local registry."
    for image_name in "${install_image_list[@]}"; do
      echo "NEW - $image_name"
    done
  fi

  echo "====================================================="

  # check for situation where existing image array uptodate_images is empty and install_image_list existing image array is not.
  # in this situation, there is nothing to update.
  if [[ ${#uptodate_images[@]} -ne 0 && ${#install_image_list[@]} -eq 0 ]]; then
    ndr_logInfo "The list of existing images is up to date and there are no new images to populate."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi
  
  # There are images to populate so copy the final image list to the ref list
  image_list_ref=()
  for image in "${install_image_list[@]}"; do
    image_list_ref+=("$image")
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function <private_registry_type> <private_registry_repo_prefix> <image_list_ref>
function ndr_PushPopulationImageList ()
{
  local logSectionDesc="Pushing Docker image list"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 3 ]]; then
    ndr_logError "Usage: function <private_registry_type> <private_registry_repo_prefix> <image_list_ref>"
    return 1
  fi

  local regType="$1"
  local regPrefix="$2"
  local -n image_list_ref="$3"
 
  declare -A local_registry_images_tagged=()

  # supplemental array to track if the image already was present locally or not so we can prune or not prune accordingly after retag and push to registry. 
  # Prune if does not exist, skip prune if it does exist since it may be shared with other services in the compose file.
  declare -A local_registry_images_status=() 
  
  # ----------------------------------------------------------------
  # create retag array and note any preexisting images for pruning purposes.
  for image in "${image_list_ref[@]}"; do
    # Some images need to be "adjusted" like kong that lacks the repo account field. Images like that cause problems when pushing to GCP.
    # parse image apart, fill in the blanks and reform.
    local parsed_repo_account
    local parsed_repo_name
    local parsed_image_base_name
    local parsed_image_version_tag
    
    ndr_ParseFullImageName "$image" parsed_repo_account parsed_repo_name parsed_image_base_name parsed_image_version_tag
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Failed to parse image [$image]"
      return 1
    fi

    # Docker Hub treats unscoped images as belonging to the implicit "library" namespace.
    if [[ -z "$parsed_repo_account" ]]; then
      parsed_repo_account="library"
    fi

    local image_name_tagged="${regPrefix}/${parsed_repo_account}/${parsed_repo_name}:"

    if [[ -n "$parsed_image_base_name" ]]; then
      image_name_tagged="${image_name_tagged}${parsed_image_base_name}_"
    fi

    image_name_tagged="${image_name_tagged}${parsed_image_version_tag}"

    local_registry_images_tagged["$image"]="$image_name_tagged"

    local image_status="not_exists"
    ndr_verifyDockerImageExists "$image"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logInfo "Image [$image] not found locally. It WILL be pruned after registry population complete."
    else
      ndr_logInfo "Image [$image] found locally. It will NOT be pruned locally after since it may be shared with other containers."
      image_status="exists"
    fi
    local_registry_images_status["$image"]="$image_status"
  done

  # ----------------------------------------------------------------
  # Pull images

  ndr_logInfo "Pulling all images."
  for image_name in "${image_list_ref[@]}"; do
    ndr_logInfo "Pulling docker image [$image_name]."
    
    # force amd64 architecture for registry population since that's our only currently supported platform.
    local architecture="$gNDR_DOCKER_ARCHITECTURE_LINUX_AMD64"
    ndr_DownloadDockerImageV2 "$image_name" "$architecture" "$NDR_DOCKER_REPO_TYPE_PUBLIC_NDR"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Docker pull failed for image [$image_name]"
      return 1
    fi
    ndr_logInfo "Docker image download succeeded for [$image_name]."
  done

  # ----------------------------------------------------------------
  # retag all images
  for image_name in "${image_list_ref[@]}"; do
    
    local image_name_tagged="${local_registry_images_tagged[$image_name]}"

    docker tag "$image_name" "$image_name_tagged"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to retag image [$image_name] to [$image_name_tagged]."
      return 1
    fi

    ndr_logInfo "Retagged image [$image_name] to [$image_name_tagged]."
  done

  # ----------------------------------------------------------------
  # push all images to registry
  for image_name in "${image_list_ref[@]}"; do
    local image_name_tagged="${local_registry_images_tagged[$image_name]}"
    docker push "$image_name_tagged"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to push image [$image_name_tagged] to local registry."
      return 1
    fi
    ndr_logInfo "Pushed image [$image_name_tagged] to local registry."
  done

  # ----------------------------------------------------------------
  # verify images in registry

  # Fetch all repo images
  local existing_priv_repo_images=()
  if [[ "$regType" == "$NDR_DOCKER_REPO_TYPE_LOCAL_REGISTRY" ]]; then
    ndr_LocalDockerRegistryQueryTags existing_priv_repo_images "$gNDR_DOCKER_LOCAL_REGISTRY_HOST" "$gNDR_DOCKER_LOCAL_REGISTRY_PORT"
    return_code=$?
    if [ $return_code -ne 0 ]; then
        ndr_logError "Failed to query existing images from registry [$gNDR_DOCKER_LOCAL_REGISTRY_HOST:$gNDR_DOCKER_LOCAL_REGISTRY_PORT]."
        return 1
    fi
  elif [[ "$regType" == "$NDR_DOCKER_REPO_TYPE_GCP_REGISTRY" ]]; then
    ndr_GCPDockerRegistryQueryTags existing_priv_repo_images "$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT"
    return_code=$?
    if [ $return_code -ne 0 ]; then
        ndr_logError "Failed to query existing images from registry [$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT]."
        return 1
    fi
  else
    ndr_logError "Invalid registry type: $regType"
    return 1
  fi

  if [ "${#existing_priv_repo_images[@]}" -eq 0 ]; then
    ndr_logInfo "No existing images found in registry [$regPrefix]."
  else
    ndr_logInfo "Found ${#existing_priv_repo_images[@]} existing images in registry [$regPrefix]."
  fi

  for image in "${image_list_ref[@]}"; do
    local found=false

    for existing_image in "${existing_priv_repo_images[@]}"; do
      # if image to populate is found in existing images, its good.
      if [[ "$existing_image" == "$image" ]]; then
        ndr_logDebug "Image [$image] to be populated was found in currrent image inventory."
        found=true
        break
      elif [[ "$existing_image" == *"$image"* ]]; then
        ndr_logDebug "Image [$image] matched as substring of existing image [$existing_image]."
        found=true
        break
      fi
    done

    # image must be new
    if [ "$found" == false ]; then
      ndr_logError "Image [$image] to be populated not found in current image inventory."
      return 1
    fi
  done

  ndr_logInfo "All images to be populated were found in local registry after push. Verification succeeded."
  
  # ----------------------------------------------------------------
  # prune/cleanup local images
  local retVal=0
  for image_name in "${image_list_ref[@]}"; do
    
    local image_name_tagged="${local_registry_images_tagged[$image_name]}"
    
    # always remove extra image tag since it is specific to the registry and retag we created.
    ndr_logInfo "Removing image tag [$image_name_tagged]..."
    docker image rm "$image_name_tagged"
    return_code=$?
    if [[ $return_code != 0 ]]; then
      ndr_logError "Failed to remove image tag [$image_name_tagged]."
      retVal=1
    else
      ndr_logInfo "Docker image tag [$image_name_tagged] removal succeeded."
    fi

    # only remove original image if it did not exist locally prior to retag and push since if it did exist prior, it may be shared with other services in the compose file and we want to avoid breaking them by pruning the shared image.
    local image_status="${local_registry_images_status[$image_name]}"

    if [[ "$image_status" == "exists" ]]; then
      ndr_logInfo "Image [$image_name] was found locally before retag and push, skipping prune since it may be shared with other components on this host."
      continue
    fi

    ndr_logInfo "Removing image [$image_name]..."
    docker image rm -f "$image_name"
    return_code=$?
    if [[ $return_code != 0 ]]; then
      ndr_logError "Failed to remove image [$image_name]."
      retVal=1
    else
      ndr_logInfo "Docker image [$image_name] removal succeeded."
    fi
  done

  if [[ $retVal -ne 0 ]]; then
    ndr_logError "One or more errors occurred during cleanup of tagged images. Please review the log for details."
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_LocalDockerRegistryPopulate ()
{
  local logSectionDesc="Populating Local Docker Registry"
  ndr_logSecStart "$logSectionDesc"

  # ----------------------------------------------------------------
  # collect basic registry info and validate
  ndr_LocalDockerRegistryPromptName
  local return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Local Docker Registry container name prompt failed or was aborted by user."
    return 1
  fi

  # verify registry container exists and if so, pull basic info like host and port to seed values and bypass additional queries.
  local host_address_discovered=false
  local port_discovered=false
  ndr_verifyDockerContainerExists "$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME" >/dev/null
  return_code=$?
  #2-error, 1-not found, 0-found
  if [[ $return_code == 0 ]]; then
    ndr_logInfo "Docker container '$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME' found."
    
    local portInfo=$(docker inspect "$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME" --format '{{json .NetworkSettings.Ports}}')
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Failed to inspect Local Docker Registry container for port information."
    else
      ndr_logInfo "Local Docker Registry container port info: $portInfo"
    fi

    if [[ -n "$portInfo" ]]; then
      # parse out the host
      local hostAddress=$(echo "$portInfo" | jq -r 'to_entries[] | select(.key | startswith("5000/tcp")) | .value[0].HostIp')
      if [[ -n "$hostAddress" ]]; then
        if [[ "$hostAddress" == "localhost" || "$hostAddress" == "127.0.0.1" || "$hostAddress" == "0.0.0.0" ]]; then
          ndr_logInfo "Discovered local registry configured host IP [$hostAddress] from container inspect. Remapping to 'localhost'."
          hostAddress="localhost"
        fi
        gNDR_DOCKER_LOCAL_REGISTRY_HOST="$hostAddress"
        ndr_logInfo "Discovered Local Docker Registry host value from container inspect: $gNDR_DOCKER_LOCAL_REGISTRY_HOST"
        host_address_discovered=true
      fi

      # parse out the port
      local hostPort=$(echo "$portInfo" | jq -r 'to_entries[] | select(.key | startswith("5000/tcp")) | .value[0].HostPort')
      if [[ -n "$hostPort" ]]; then
        gNDR_DOCKER_LOCAL_REGISTRY_PORT="$hostPort"
        ndr_logInfo "Discovered Local Docker Registry port value from container inspect: $gNDR_DOCKER_LOCAL_REGISTRY_PORT"
        port_discovered=true
      fi
    fi
  fi

  if [[ "$host_address_discovered" == false ]]; then
    ndr_LocalDockerRegistryPromptHost
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Local Docker Registry host prompt failed or was aborted by user."
      return 1
    fi
  fi
  
  if [[ "$port_discovered" == false ]]; then
    ndr_LocalDockerRegistryPromptPort
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Local Docker Registry port prompt failed or was aborted by user."
      return 1
    fi
  fi

  # ----------------------------------------------------------------
  # verify registry is running
  ndr_verifyDockerContainerRunning "$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logWarn "Docker container '$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME' exists but was not running. Starting container..."
  
    docker start "$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME"
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Failed to start Local Docker Registry container [$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME]."
      return 1
    fi
  fi
  ndr_logInfo "Local Docker Registry container [$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME] is running."

  # ----------------------------------------------------------------
  # Build inital docker image list
  local registry_images=()
  
  ndr_BuildCompletePopulationImageList "$NDR_DOCKER_REPO_TYPE_LOCAL_REGISTRY" "${gNDR_DOCKER_LOCAL_REGISTRY_HOST}:${gNDR_DOCKER_LOCAL_REGISTRY_PORT}" registry_images
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to build docker image list."
    return 1
  fi
  ndr_logInfo "Built list of ${#registry_images[@]} docker images required for population."

  # if list is empty but query did not fail, there are no images or no new images to populate
  if [[ ${#registry_images[@]} -eq 0 ]]; then
    echo "The list of existing images is up to date and/or there are no new images to populate. Nothing more to do."
    echo -n "Press any key to return without updating..."
    read -n 1 -s
    echo    # move to a new line after key press
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi
  
  local prompt_message="Do you want to proceed with populating the registry with these images?"
  ndr_PromptYesNo "$prompt_message" "$NDR_PROMPT_DEFAULT_INPUT_YES"
  return_code=$?
  if [ $return_code != $NDR_PROMPT_RETURN_YES ]; then
    ndr_logWarn "Operation cancelled, returning to main menu."
    return 1
  fi

  # ----------------------------------------------------------------
  # tag, push and cleanup images
  ndr_PushPopulationImageList "$NDR_DOCKER_REPO_TYPE_LOCAL_REGISTRY" "${gNDR_DOCKER_LOCAL_REGISTRY_HOST}:${gNDR_DOCKER_LOCAL_REGISTRY_PORT}" registry_images
  return_code=$?
  if [ $return_code != $NDR_PROMPT_RETURN_YES ]; then
    ndr_logError "Failed to push image list."
    return 1
  fi

  # ----------------------------------------------------------------
  # show summary info of registry contents

  # get registry bind mount and disk usage
  while true; do
    gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR=$(docker inspect ${gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME} --format '{{ range .Mounts }}{{ .Source }}{{ "\n" }}{{ end }}')
    if [[ -z "$gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR" ]]; then
      ndr_logError "Failed to retrieve Local Docker Registry data directory from container inspect."
      break
    fi
    if [[ ! -d "$gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR" ]]; then
      ndr_logError "Retrieved Local Docker Registry data directory [$gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR] does not exist or is not a directory."
      break
    fi

    local registryDataDirSize=$(du -sh "$gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR" 2>/dev/null | cut -f1)

    ndr_logInfo "Local Docker Registry data directory [$gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR] is $registryDataDirSize in size."

    break
  done
  

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_LocalDockerRegistryQuery ()
{
  local logSectionDesc="Querying Local Docker Registry"
  ndr_logSecStart "$logSectionDesc"

  # ----------------------------------------------------------------
  # collect basic registry info and validate
  ndr_LocalDockerRegistryPromptName
  local return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Local Docker Registry container name prompt failed or was aborted by user."
    return 1
  fi

  # verify registry container exists and if so, pull basic info like host and port to seed values and bypass additional queries.
  local host_address_discovered=false
  local port_discovered=false
  ndr_verifyDockerContainerExists "$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME" >/dev/null
  return_code=$?
  #2-error, 1-not found, 0-found
  if [[ $return_code == 0 ]]; then
    ndr_logInfo "Docker container '$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME' found."
    
    local portInfo=$(docker inspect "$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME" --format '{{json .NetworkSettings.Ports}}')
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Failed to inspect Local Docker Registry container for port information."
    else
      ndr_logInfo "Local Docker Registry container port info: $portInfo"
    fi

    if [[ -n "$portInfo" ]]; then
      # parse out the host
      local hostAddress=$(echo "$portInfo" | jq -r 'to_entries[] | select(.key | startswith("5000/tcp")) | .value[0].HostIp')
      if [[ -n "$hostAddress" ]]; then
        if [[ "$hostAddress" == "localhost" || "$hostAddress" == "127.0.0.1" || "$hostAddress" == "0.0.0.0" ]]; then
          ndr_logInfo "Discovered local registry configured host IP [$hostAddress] from container inspect. Remapping to 'localhost'."
          hostAddress="localhost"
        fi
        gNDR_DOCKER_LOCAL_REGISTRY_HOST="$hostAddress"
        ndr_logInfo "Discovered Local Docker Registry host value from container inspect: $gNDR_DOCKER_LOCAL_REGISTRY_HOST"
        host_address_discovered=true
      fi

      # parse out the port
      local hostPort=$(echo "$portInfo" | jq -r 'to_entries[] | select(.key | startswith("5000/tcp")) | .value[0].HostPort')
      if [[ -n "$hostPort" ]]; then
        gNDR_DOCKER_LOCAL_REGISTRY_PORT="$hostPort"
        ndr_logInfo "Discovered Local Docker Registry port value from container inspect: $gNDR_DOCKER_LOCAL_REGISTRY_PORT"
        port_discovered=true
      fi
    fi
  fi

  if [[ "$host_address_discovered" == false ]]; then
    ndr_LocalDockerRegistryPromptHost
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Local Docker Registry host prompt failed or was aborted by user."
      return 1
    fi
  fi
  
  if [[ "$port_discovered" == false ]]; then
    ndr_LocalDockerRegistryPromptPort
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Local Docker Registry port prompt failed or was aborted by user."
      return 1
    fi
  fi

  # ----------------------------------------------------------------
  # query registry for catalog of repositories and tags and display results

  local images=()
  ndr_LocalDockerRegistryQueryTags images "$gNDR_DOCKER_LOCAL_REGISTRY_HOST" "$gNDR_DOCKER_LOCAL_REGISTRY_PORT"
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to query existing images from local registry [$gNDR_DOCKER_LOCAL_REGISTRY_HOST:$gNDR_DOCKER_LOCAL_REGISTRY_PORT]."
    return 1
  fi

  for image in "${images[@]}"; do
    echo "Image present in local registry: ${image}"
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_LocalDockerRegistryQueryTags ()
{
  local logSectionDesc="Querying Local Docker Registry for Image Tags"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <registry_host> <registry_port>"
    return 1
  fi

  local -n outImages=$1
  local regHost="$2"
  local regPort="$3"

  # query registry for catalog of repositories and tags and build results array
  local catalogQueryURL="http://${regHost}:${regPort}/v2/_catalog"
  repos=$(curl -s $catalogQueryURL | jq -r '.repositories[]')
  if [[ -z "$repos" ]]; then
    ndr_logWarn "No repositories found in registry [$catalogQueryURL]."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  for repo in $repos; do
    local tagsQueryURL="http://${regHost}:${regPort}/v2/$repo/tags/list"
    tags=$(curl -s $tagsQueryURL | jq -r '.tags[]')
    if [[ -z "$tags" ]]; then
      ndr_logInfo "No tags found in repo [$repo]"
      continue
    fi
    
    for tag in $tags; do
      local image="${repo}:${tag}"
      ndr_logDebug "Added existing fully qualified registry image: ${regHost}:${regPort}/${image}"
      outImages+=("$image")
    done
  done

  if [[ ${#outImages[@]} -eq 0 ]]; then
    ndr_logWarn "No images found in registry [$catalogQueryURL]."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  ndr_logDebug "Found ${#outImages[@]} existing images in registry [$catalogQueryURL]."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_LocalDockerRegistryDeleteImage ()
{
  local logSectionDesc="Delete Local Docker Registry Image"
  ndr_logSecStart "$logSectionDesc"

  # ----------------------------------------------------------------
  # collect basic registry info and validate
  ndr_LocalDockerRegistryPromptName
  local return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Local Docker Registry container name prompt failed or was aborted by user."
    return 1
  fi

  # verify registry container exists and if so, pull basic info like host and port to seed values and bypass additional queries.
  local host_address_discovered=false
  local port_discovered=false
  ndr_verifyDockerContainerExists "$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME" >/dev/null
  return_code=$?
  #2-error, 1-not found, 0-found
  if [[ $return_code == 0 ]]; then
    ndr_logInfo "Docker container '$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME' found."
    
    local portInfo=$(docker inspect "$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME" --format '{{json .NetworkSettings.Ports}}')
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Failed to inspect Local Docker Registry container for port information."
    else
      ndr_logInfo "Local Docker Registry container port info: $portInfo"
    fi

    if [[ -n "$portInfo" ]]; then
      # parse out the host
      local hostAddress=$(echo "$portInfo" | jq -r 'to_entries[] | select(.key | startswith("5000/tcp")) | .value[0].HostIp')
      if [[ -n "$hostAddress" ]]; then
        if [[ "$hostAddress" == "localhost" || "$hostAddress" == "127.0.0.1" || "$hostAddress" == "0.0.0.0" ]]; then
          ndr_logInfo "Discovered local registry configured host IP [$hostAddress] from container inspect. Remapping to 'localhost'."
          hostAddress="localhost"
        fi
        gNDR_DOCKER_LOCAL_REGISTRY_HOST="$hostAddress"
        ndr_logInfo "Discovered Local Docker Registry host value from container inspect: $gNDR_DOCKER_LOCAL_REGISTRY_HOST"
        host_address_discovered=true
      fi

      # parse out the port
      local hostPort=$(echo "$portInfo" | jq -r 'to_entries[] | select(.key | startswith("5000/tcp")) | .value[0].HostPort')
      if [[ -n "$hostPort" ]]; then
        gNDR_DOCKER_LOCAL_REGISTRY_PORT="$hostPort"
        ndr_logInfo "Discovered Local Docker Registry port value from container inspect: $gNDR_DOCKER_LOCAL_REGISTRY_PORT"
        port_discovered=true
      fi
    fi
  fi

  if [[ "$host_address_discovered" == false ]]; then
    ndr_LocalDockerRegistryPromptHost
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Local Docker Registry host prompt failed or was aborted by user."
      return 1
    fi
  fi
  
  if [[ "$port_discovered" == false ]]; then
    ndr_LocalDockerRegistryPromptPort
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Local Docker Registry port prompt failed or was aborted by user."
      return 1
    fi
  fi

  # ----------------------------------------------------------------
  # verify registry container is running before we attempt to push images
  
  ndr_verifyDockerContainerRunning "$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logWarn "Docker container '$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME' exists but was not running. Starting container..."
  
    docker start "$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME"
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Failed to start Local Docker Registry container [$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME]."
      return 1
    fi
  fi
  ndr_logInfo "Local Docker Registry container [$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME] is running."

  # ----------------------------------------------------------------

  # verify deletion is supported
  if docker inspect "$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME" \
    --format '{{json .Config.Env}}' \
    | jq -e 'any(.[]; . == "REGISTRY_STORAGE_DELETE_ENABLED=true")' >/dev/null; then
    ndr_logInfo "Docker registry [$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME] allows delete."
  else
    ndr_logWarn "Docker registry [$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME] does not allow delete."
    return 0
  fi

  local images=()
  local refresh_tags=true

  while true; do
    # query list of existing images
    
    if [[ "$refresh_tags" == true ]]; then
      images=()
      ndr_LocalDockerRegistryQueryTags images "$gNDR_DOCKER_LOCAL_REGISTRY_HOST" "$gNDR_DOCKER_LOCAL_REGISTRY_PORT"
      return_code=$?
      if [[ $return_code -ne 0 ]]; then
        ndr_logError "Failed to query existing images from local registry [$gNDR_DOCKER_LOCAL_REGISTRY_HOST:$gNDR_DOCKER_LOCAL_REGISTRY_PORT]."
        return 1
      fi
      refresh_tags=false
    fi  
  
    if [[ ${#images[@]} -eq 0 ]]; then
      ndr_logInfo "No existing images found in local registry [$gNDR_DOCKER_LOCAL_REGISTRY_HOST:$gNDR_DOCKER_LOCAL_REGISTRY_PORT]."
      ndr_logSecEnd "$logSectionDesc"
      return 0
    fi

    # present image list as menu
    echo "Existing images in local registry available for deletion [$gNDR_DOCKER_LOCAL_REGISTRY_HOST:$gNDR_DOCKER_LOCAL_REGISTRY_PORT]"
    echo "Please select an option:"
    echo ""
    local idx=1
    for image in "${images[@]}"; do
        echo "$idx -> $image"
        idx=$((idx + 1))
      done
    echo "q. Exit"
    echo ""
    read -p "Enter your choice [1-n]: " choice

    # check for non-numerical choice (exit, test, etc)
    if ! [[ "$choice" =~ ^[0-9]+$ ]]; then
      if [[ "$choice" == "q" || "$choice" == "Q" ]]; then
        ndr_logInfo "Exiting."
        break
      fi
    fi

    # translate numerical choice index to menu item index
    if [[ "$choice" -eq 0 || "$choice" -gt ${#images[@]} ]]; then
      ndr_logWarn "Invalid selection [$choice], please try again."
      continue
    fi

    local selected_image="${images[$choice-1]}"
    
    # confirm selection
    local value_desc="Docker Local Registry Image Deletion"
    local value=$(ndr_PromptInputValue "$selected_image" "$value_desc")
    return_code=$?
    if [[ $return_code -ne 0 || -z "$value" ]]; then
      ndr_logWarn "Failed to get user input for $value_desc"
      continue
    fi
    
    ndr_logDebug "User selected image to delete [$choice] -> [$selected_image]"
    
    # parse selected image into repo and tag
    local repo="${selected_image%%:*}"
    local tag="${selected_image##*:}"
    # parse image, get digest and execute delete command
    DIGEST=$(curl -sI -H "Accept: application/vnd.docker.distribution.manifest.v2+json" \
    http://$gNDR_DOCKER_LOCAL_REGISTRY_HOST:$gNDR_DOCKER_LOCAL_REGISTRY_PORT/v2/$repo/manifests/$tag \
    | awk -F': ' '/Docker-Content-Digest/ {print $2}' | tr -d $'\r')

    if [[ -z "$DIGEST" ]]; then
      ndr_logError "Failed to retrieve digest for image [$selected_image]. Cannot proceed with deletion."
      continue
    fi
    ndr_logDebug "Retrieved digest for image [$selected_image]: $DIGEST"

    curl -X DELETE http://$gNDR_DOCKER_LOCAL_REGISTRY_HOST:$gNDR_DOCKER_LOCAL_REGISTRY_PORT/v2/$repo/manifests/$DIGEST
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Failed to delete image [$selected_image] from local registry."
    else
      ndr_logInfo "Deleted image [$selected_image] from local registry."
      # refresh tags after deletion
      refresh_tags=true
    fi
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_LocalDockerRegistryRemove ()
{
  local logSectionDesc="Removing Local Docker Registry"
  ndr_logSecStart "$logSectionDesc"

  local retCode=0
  ndr_LocalDockerRegistryPromptName
  local return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Local Docker Registry container name prompt failed or was aborted by user."
    return 1
  fi

  local containerExists=false
  # if container doesn't exist, skip it.
  ndr_verifyDockerContainerExists "$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME" >/dev/null
  return_code=$?
  #2-error, 1-not found, 0-found
  if [[ $return_code == 0 ]]; then
    ndr_logInfo "Docker container '$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME' found."
    containerExists=true
  fi

  local containerRunning=false
  # if container not running, skip it.
  ndr_verifyDockerContainerRunning "$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME"
  return_code=$?
  if [ $return_code -eq 0 ]; then
    ndr_logInfo "Docker container [$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME] is running."
    containerRunning=true
  fi
    
  if [ "$containerRunning" == true ]; then
    docker stop ${gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME}
    local return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Failed to stop Local Docker Registry container [$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME]."
      retCode=1
    else
      ndr_logInfo "Stopped Local Docker Registry container [$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME]."
    fi
  fi
  
  if [ "$containerExists" == true ]; then
    docker rm ${gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME}
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Failed to remove Local Docker Registry container [$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME]."
      retCode=1
    else
      ndr_logInfo "Removed Local Docker Registry container [$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME]."
    fi
  fi

  if [ -d "$gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR" ]; then
    ndr_logInfo "Removing Local Docker Registry data directory [$gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR]."
    sudo rm -rf ${gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR}
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Failed to remove Local Docker Registry data directory [${gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR}]."
      retCode=1
    else
      ndr_logInfo "Removed Local Docker Registry data directory [${gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR}]."
    fi
  fi

  if [[ $retCode -ne 0 ]]; then
    ndr_logError "One or more errors occurred while removing the Local Docker Registry. Please review the log for details."
  fi

  ndr_logSecEnd "$logSectionDesc"

  return $retCode
}

function ndr_GCPDockerRegistryPromptRoot ()
{
  local logSectionDesc="Prompting for GCP Docker Registry Root"
  ndr_logSecStart "$logSectionDesc"

  local value_desc="$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT_DESC"

  # seed input value with this as example
  gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT="us-east5-docker.pkg.dev/nextdr2"

  value=$(ndr_PromptInputValue "$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT" "$value_desc")
  return_code=$?
  if [[ $return_code -ne 0 || -z "$value" ]]; then
    ndr_logError "Failed to get user input for $value_desc"
    ndr_logSecEnd "$logSectionDesc"
    return 1
  fi

  local region_url=""
  local region=""
  local project=""
  ndr_GCPDockerRegistryParseRoot "$value" region_url region project
  return_code=$?
  if [[ $return_code -ne 0 || -z "$value" ]]; then
    ndr_logError "Invalid repo path format: $value"
    ndr_logSecEnd "$logSectionDesc"
    return 1
  fi

  gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT="$value"
  ndr_logInfo "$value_desc set to [$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT]"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}


function ndr_GCPDockerRegistryParseRoot ()
{
  local logSectionDesc="Parsing GCP Docker Registry Root"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 4 ]]; then
    ndr_logError "Usage: function <repo_path> <out_region_url> <out_region> <out_project>"
    ndr_logSecEnd "$logSectionDesc"
    return 1
  fi

  local repoRoot="$1"
  local -n outRegionURL="$2"
  local -n outRegion="$3"
  local -n outProject="$4"
  
  if [[ -z "$repoRoot" ]]; then
    ndr_logError "Repo root cannot be empty."
    ndr_logSecEnd "$logSectionDesc"
    return 1
  fi

  local extraPart=""
  IFS='/' read -r outRegionURL outProject extraPart <<< "$repoRoot"

  if [[ -n "$extraPart" ]]; then
    ndr_logError "Invalid repo root format [$repoRoot]. Expected format: <REGION>-docker.pkg.dev/<PROJECT>."
    return 1
  fi

  if [[ -z "$outRegionURL" || -z "$outProject" ]]; then
    ndr_logError "Invalid repo root format [$repoRoot]. One or more required path items are empty."
    return 1
  fi

  if [[ "$outRegionURL" != *"-docker.pkg.dev" ]]; then
    ndr_logError "Invalid region URL [$outRegionURL]. Expected format: <REGION>-docker.pkg.dev."
    return 1
  fi

  outRegion="${outRegionURL%-docker.pkg.dev}"
  if [[ -z "$outRegion" ]]; then
    ndr_logError "Failed to parse region from region URL [$outRegionURL]."
    return 1
  fi

  ndr_logInfo "Parsed repo root into region URL [$outRegionURL], region [$outRegion], project [$outProject]."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}


function ndr_GCPDockerRegistryQuery ()
{
  local logSectionDesc="Querying GCP Docker Registry"
  ndr_logSecStart "$logSectionDesc"

  ndr_GCPDockerRegistryPromptRoot
  local return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "GCP Docker Registry root prompt failed or was aborted by user."
    return 1
  fi

  ndr_GCPDockerRegistryVerifyAccess "$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT"
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to verify access to repo root: $gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT"
    return 1
  fi

  echo "Please wait, performing full GCP registry inventory query of [$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT]..."

  local outImages=()
  
  ndr_GCPDockerRegistryQueryTags outImages "$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT"
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to query GCP Docker Registry [$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT]."
    return 1
  fi

  if [[ ${#outImages[@]} -eq 0 ]]; then
    ndr_logWarn "No images found in registry [$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT]."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  ndr_logDebug "Found ${#outImages[@]} existing images in registry [$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT]."

  for image in "${outImages[@]}"; do
    echo "GCP remote tag: $image"
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# Performs a simple check to verify that the remote repo is currently accessible. 
# Useful to call before getting too deep into other functions.
function ndr_GCPDockerRegistryVerifyAccess ()
{
  local logSectionDesc="Verifying GCP Docker Registry access"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 1 ]]; then
    ndr_logError "Usage: function <repo_root>"
    return 1
  fi

  local repo_root="$1"
  
  local GCP_LOCATION_URL=""
  local GCP_LOCATION="" #"${repo_root%%-docker.pkg.dev*}"
  local GCP_PROJECT="" #"${repo_root#*/}"

  ndr_GCPDockerRegistryParseRoot "$repo_root" GCP_LOCATION_URL GCP_LOCATION GCP_PROJECT
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to parse registry repo root: $repoRoot"
    return 1
  fi

  active_account=$(gcloud auth list --filter=status:ACTIVE --format="value(account)" 2>/dev/null)

  if [[ -z "$active_account" ]]; then
    ndr_logError "gcloud is not authenticated. Run 'gcloud auth login' to authenticate before running further GCP repo operations."
    return 1
  fi

  echo "Authenticated as: $active_account"

  if ! gcloud --quiet artifacts repositories list \
        --location="$GCP_LOCATION" \
        --project="$GCP_PROJECT" \
        >/dev/null 2>&1
  then
    ndr_logError "Cannot access Artifact Registry in project [$GCP_PROJECT]. Check IAM permissions or login again with 'gcloud auth login'."
    return 1
  fi

  docker_config="$HOME/.docker/config.json"
  need_configure=false

  # Check if docker config exists
  if [[ ! -f "$docker_config" ]]; then
    ndr_logInfo "Docker config file [$docker_config] not found, will run auth configure-docker for GCP location [$GCP_LOCATION_URL]."
    need_configure=true
  fi

  if [[ "$need_configure" == false ]]; then
    # Check if registry host exists in credential helpers
    if ! grep -q "\"$GCP_LOCATION_URL\"" "$docker_config"; then
      ndr_logInfo "Docker config file [$docker_config] did not contain GCP location [$GCP_LOCATION_URL]. Running auth configure-docker."
      need_configure=true
    fi
  fi

  # Configure docker if needed
  if [[ "$need_configure" == true ]]; then
    echo "Configuring Docker authentication for: $GCP_LOCATION_URL"
    if ! gcloud auth configure-docker "$GCP_LOCATION_URL" --quiet; then
      ndr_logError "Failed to run auth configure-docker for: $GCP_LOCATION_URL"
      return 1
    fi
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_GCPDockerRegistryQueryTags ()
{
  local logSectionDesc="Querying GCP Docker Registry for Image Tags"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <image_list_ref> <repo root> [target_repo]"
    return 1
  fi

  local -n outImagesRef=$1
  local repoRoot="$2"
  local targetRepo="$3"

  # parse the repo root into its parts
  # full repo path format: <LOCATION_URL>/<PROJECT_ID>
  local regionURL=""
  local region=""
  local project=""
  ndr_GCPDockerRegistryParseRoot "$repoRoot" regionURL region project
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to parse registry repo root: $repoRoot"
    return 1
  fi

  # In Artifact Registry, the registry root is really just: <REGION>-docker.pkg.dev/<PROJECT>
  # parse out the region

  # Get all repository names in the project/location
  mapfile -t REPOS < <(gcloud --quiet artifacts repositories list --project="$project" --location="$region" --format="json" 2>/dev/null | jq -r '.[].name | split("/") | .[-1]' )

  if [[ ${#REPOS[@]} -eq 0 ]]; then
    ndr_logWarn "No repos found in registry [$repoRoot]."
    return 0
  fi

  ndr_logInfo "Discovered repositories: ${#REPOS[@]}"
  
  # Iterate through each repository
  outImagesRef=()

  for REPO in "${REPOS[@]}"; do
    if [[ -n "$targetRepo" && "$targetRepo" != "$REPO" ]]; then
      ndr_logDebug "Repo [$REPO] does not match supplied target repo [$targetRepo], skipping."
      continue
    fi

    ndr_logInfo "Processing repository: $REPO"

    # List all images in this repository
    mapfile -t IMAGES < <(gcloud --quiet artifacts docker images list \
        ${regionURL}/${project}/${REPO} \
        --format="json" 2>/dev/null \
        | jq -r '.[].package | split("/") | .[-1]' )

    ndr_logInfo "Discovered images: ${#IMAGES[@]}"

    for IMAGE in "${IMAGES[@]}"; do
      ndr_logInfo "Processing image: $IMAGE"

      # List all tags for this image
      mapfile -t TAGS < <(gcloud --quiet artifacts docker tags list \
          ${regionURL}/${project}/${REPO}/${IMAGE} \
          --format="json" 2>/dev/null | jq -r ".[].tag")

      ndr_logInfo "Discovered tags: ${#TAGS[@]}"

      # construct full image:tag names
      for TAG_PATH in "${TAGS[@]}"; do
        ndr_logInfo "Processing tag: $TAG_PATH"

        local TAG=$(echo "$TAG_PATH" | awk -F'/tags/' '{print $2}')
        #local FULL_IMAGE="${regionURL}/${project}/${REPO}/${IMAGE}:${TAG}"
        local FULL_IMAGE="${REPO}/${IMAGE}:${TAG}"
        outImagesRef+=("$FULL_IMAGE")
        
      done  
    done
  done

  ndr_logDebug "Found ${#outImagesRef[@]} existing images in registry [$repoRoot]."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# created any missing repo level items in the remote registry
function ndr_GCPDockerRegistryCreateRepos ()
{
  local logSectionDesc="Creating GCP Docker Registry Image Repositories"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <repo_root> <image_list_ref>"
    return 1
  fi

  local repo_root="$1"
  local -n image_list_ref="$2"
  
  local -A existingRepos=()
  local GCP_LOCATION="${repo_root%%-docker.pkg.dev*}"
  local GCP_PROJECT="${repo_root#*/}"

  # loop through image list
  for image_name in "${image_list_ref[@]}"; do

    local parsed_repo_account
    local parsed_repo_name
    local parsed_image_base_name
    local parsed_image_version_tag
    local gcp_repo_name

    ndr_ParseFullImageName "$image_name" parsed_repo_account parsed_repo_name parsed_image_base_name parsed_image_version_tag
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logWarn "Skipping unparsable GCP image [$image_name]"
      continue
    fi

    # Docker Hub treats unscoped images as belonging to the implicit "library" namespace.
    gcp_repo_name="${parsed_repo_account:-library}"

    if [[ -n "${existingRepos[$gcp_repo_name]}" ]]; then
      ndr_logInfo "GCP repo [$gcp_repo_name] already processed this session, skipping repo query."
      continue
    fi

    # In GCP registrues, the "repo" level item is equivalent to the docker hub repo account.
    ndr_logInfo "Checking GCP repo: $gcp_repo_name"

    gcloud artifacts repositories describe "$gcp_repo_name" --location="$GCP_LOCATION" --project="$GCP_PROJECT" >/dev/null 2>&1
    return_code=$?
    if [[ $return_code -eq 0 ]]; then
      ndr_logInfo "GCP repo already exists: $repo_root/$gcp_repo_name"
      existingRepos["$gcp_repo_name"]=1
      continue
    fi
    
    ndr_logInfo "Creating repo: $repo_root/$gcp_repo_name"
    
    gcloud artifacts repositories create "$gcp_repo_name" --repository-format=docker --location="$GCP_LOCATION" --project="$GCP_PROJECT" --description="Imported DockerHub images"
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logError "Failed to create GCP repo: $repo_root/$gcp_repo_name"
      return 1
    fi

    ndr_logInfo "Created GCP repo: $repo_root/$gcp_repo_name"

    existingRepos["$gcp_repo_name"]=1

  done
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_GCPDockerRegistryPopulate ()
{
  local logSectionDesc="Populating GCP Docker Registry"
  ndr_logSecStart "$logSectionDesc"

   ndr_GCPDockerRegistryPromptRoot
  local return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "GCP Docker Registry root prompt failed or was aborted by user."
    return 1
  fi

  ndr_GCPDockerRegistryVerifyAccess "$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT"
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to verify access to repo root: $gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT"
    return 1
  fi

  # ----------------------------------------------------------------
  # Build inital docker image list
  local registry_images=()
  
  ndr_BuildCompletePopulationImageList "$NDR_DOCKER_REPO_TYPE_GCP_REGISTRY" "$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT" registry_images
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to build docker image list."
    return 1
  fi
  ndr_logInfo "Built list of ${#registry_images[@]} docker images required for population."

  # if list is empty but query did not fail, there are no images or no new images to populate
  if [[ ${#registry_images[@]} -eq 0 ]]; then
    echo "The list of existing images is up to date and/or there are no new images to populate. Nothing more to do."
    echo -n "Press any key to return without updating..."
    read -n 1 -s
    echo    # move to a new line after key press
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi
  
  local prompt_message="Do you want to proceed with populating the registry with these images?"
  ndr_PromptYesNo "$prompt_message" "$NDR_PROMPT_DEFAULT_INPUT_YES"
  return_code=$?
  if [ $return_code != $NDR_PROMPT_RETURN_YES ]; then
    ndr_logInfo "Operation cancelled, returning to main menu."
    return 1
  fi

  # ----------------------------------------------------------------
  # create any missing GCP repo containers in teh cloud
  ndr_GCPDockerRegistryCreateRepos "$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT" registry_images
   return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to create GCP cloud repo's."
    return 1
  fi
  ndr_logInfo "All GCP cloud repo's have been created."

  # ----------------------------------------------------------------
  # tag, push and cleanup images
  ndr_PushPopulationImageList "$NDR_DOCKER_REPO_TYPE_GCP_REGISTRY" "$gNDR_GCP_DOCKER_ARTIFACT_REGISTRY_ROOT" registry_images
  return_code=$?
  if [ $return_code != $NDR_PROMPT_RETURN_YES ]; then
    ndr_logError "Failed to push image list."
    return 1
  fi
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ndr_logWarn "This is a bash module--there is no direct execution capabilities in this file."
  exit 0
fi
