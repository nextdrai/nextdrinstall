#!/bin/bash
# ndrCommon.sh - A Bash module providing common definitions and functions

# company/product naming
export gCOMPANY_NAME="NextDR"
export gPRODUCT_NAME="NextDR"
export gPRODUCT_NAME_SHORT="ndr"

# versioning
export gPRODUCT_VERSION_MAJOR="1"
export gPRODUCT_VERSION_MINOR="0"
export gPRODUCT_VERSION_PATCH="0"
export gPRODUCT_VERSION="${gPRODUCT_VERSION_MAJOR}.${gPRODUCT_VERSION_MINOR}.${gPRODUCT_VERSION_PATCH}"

# upgrade
export gUPGRADE_MODE=false # used for major upgrades
export gUPDATE_MODE=false # used for minor, patch or image updates.
export gINSTALLED_VERSION=""

# globals influencing various common and shared script behaviors
export gTRACELOG_TO_STDOUT=true # global flag to indicate if logging should be sent to stdout in addition to the log file.
export gTRACELOG_TO_FILE=true # global flag to indicate if logging should be sent to a log file.
export gGUI_MODE=false
export gNDR_DEVOPS_MODE=false
export gNDR_INSTALL_MODE=false
export gNDR_ADMIN_MODE=false
export gNDR_RETAIN_DOCKER_IMAGES=false # flag to retain docker images after uninstalling module. Can save time when performing repeated uninstall/reinstalls in various test/integration scenarios.
export gNDR_USE_LOCAL_IMAGE_FOR_APP_INSTALL=false # flag to enable the use of local images for container creation during install. Useful for integration of apps in installed invironment with integration builds.
export gNDR_BUILD_LOCAL_IMAGE_FOR_APP_INSTALL=true # additional flag to indicate whether we should build the image or not when using local image.
export gNDR_RECREATE_DOCKER_CONTAINERS=false # flag to re-create docker containers via docker compose CLI during admin script start (vs start existing container). Useful for pulling in new environment changes.
export gNDR_SKIP_REMOTE_IMAGE_REPO_UPDATE_CHECK=false # flag to skip the remote image repo update check. Useful for installing the tagged installer version without checking for a newer version in remote docker hub repo.

# common
export gPrereqCheckComplete=0 # flag to indicate if prereq checks have been completed and not needed to be run again on subsequent interactive commands
export gNEXTDR_HOME_DIR="/opt/$gPRODUCT_NAME_SHORT"
export gSCRIPT_HOME_DIR="$PWD"
export gLOG_FILE=""
export gExpressMode=0
export gExpressOption=""
export gDebugMode=0
export gNDR_SERVER_HOST_ADDRESS="localhost" # default address, can be updated to actual ip or host address of the server.

#secrets
export gNDR_SECRETS_LOADED=false
export gNDR_SECRETS_FILENAME=".secrets"
export gNDR_SECRETS_GPG_FILENAME=".secrets.gpg"
export gNDR_SECRETS_PASSPHRASE=""

export gNDR_CONSOLE_ADMIN_ACCOUNT_USER=""
export gNDR_CONSOLE_ADMIN_ACCOUNT_PASSWORD=""

# env files
export gNDR_MODULE_ENV_SOURCE_VAR_FILENAME=".env.nextdr" # master environment file for NextDR modules (not Supabase).
export gNDR_SUPABASE_ENV_TEMPLATE_VAR_FILENAME=".env.example" # the supabase template env file.
export gNDR_SUPABASE_ENV_SOURCE_VAR_FILENAME=".env.supabase" # contains all pre customized values to be created or updated in the offical Supabase home env file.
export gNDR_ENV_TARGET_FILENAME=".env"

# supabase
export gSUPABASE_CLI_CMD="npx supabase"
export gNDR_SUPABASE_DB_SCHEMA_FILE=""

# Global arrays
declare -a ndr_supabase_container_services=()
declare -A ndr_supabase_container_service_container_names=()
declare -A ndr_supabase_container_service_image_names=()
declare -A ndr_supabase_container_service_image_tags=()

# package prereq versions
NDR_MIN_REQUIRED_VERSION_DEFAULT="0.0.0"
NDR_MIN_REQUIRED_YQ_VERSION="1.0.0"

# git
export NDR_GITHUB_REPO_USERNAME="kamlad"
export NDR_GITHUB_REPO_NAME="nextdr"
export NDR_GIT_REPO_BRANCH_OR_TAG="master" # could be a branch or tag
export NDR_GITHUB_PUBLIC_REPO_NAME="nextdrinstall"
export NDR_GIT_PUBLIC_REPO_BRANCH_OR_TAG="main" # could be a branch or tag
export NDR_GIT_LOCAL_REPO_DEST_DIR="" #"$HOME/dev/$NDR_GITHUB_REPO_NAME"
export NDR_GITHUB_REPO_URL="git@github.com:$NDR_GITHUB_REPO_USERNAME/$NDR_GITHUB_REPO_NAME.git"
export NDR_GITHUB_PUBLIC_REPO_URL="git@github.com:$NDR_GITHUB_REPO_USERNAME/$NDR_GITHUB_PUBLIC_REPO_NAME.git"
export NDR_GIT_SSH_KEY_USER_EMAIL="" #SECRETS
export NDR_GIT_REPO_COMMIT_HASH="e373a982899991115df627f7d6b45747c4309646"
export NDR_GIT_REPO_COMMIT_HASH_SHORT="e373a98"
export NDR_GIT_REPO_COMMIT_TIMESTAMP="1757443381" # in epoch format

export NDR_GIT_LOCAL_REPO_USER_NAME="" #SECRETS
export NDR_GIT_LOCAL_REPO_USER_EMAIL="" #SECRETS

# ssh
export gSSH_Passphrase="" #SECRETS
export SSH_KEY_FILE_NAME="id_ed25519"
export SSH_KEY_DIR="$HOME/.ssh"
export SSH_KEY_FILE="$SSH_KEY_DIR/$SSH_KEY_FILE_NAME"
export SSH_PUB_KEY_FILE="${SSH_KEY_FILE}.pub"
export SSH_PUBLIC_KEY=""
export gSSH_KEY_AUTHENTICATED=0

# Os type
export osTypeMajor=""
export distroFamily=""
export distroId=""

# docker repo
export NDR_DOCKER_REPO_ACCOUNT="nextdr" #SECRETS
export NDR_DOCKER_REPO_ACCESS_TOKEN="" #SECRETS
export NDR_DOCKER_SERVICE_PRIVATE_REPO_NAME="nextdr-priv" #"orkestrate-svc"
export NDR_DOCKER_UI_PRIVATE_REPO_NAME="nextdr-priv" #"orkestrate-ui"
export NDR_DOCKER_SERVICE_PUBLIC_REPO_NAME="nextdr-svc"
export NDR_DOCKER_UI_PUBLIC_REPO_NAME="nextdr-ui"

# export NDR_DOCKER_REPO_TYPE_UNKNOWN=0 # type needed?
export NDR_DOCKER_REPO_TYPE_PRIVATE="PRIVATE"
export NDR_DOCKER_REPO_TYPE_PUBLIC="PUBLIC"
export NDR_DOCKER_REPO_TYPE_CURRENT=$NDR_DOCKER_REPO_TYPE_PUBLIC # default for now, need a more robust way to handle the type and switching depending on operational context.

# docker bridge network
export NDR_DOCKER_BRIDGE_NETWORK_NAME="ndr_bridge_net"

# docker app build enum
export NDR_DOCKER_APP_MANAGE_OPTIONS_NONE=0x0
export NDR_DOCKER_APP_MANAGE_OPTIONS_IMAGE=0x1 # build/remove image only.
export NDR_DOCKER_APP_MANAGE_OPTIONS_CONTAINER=0x2 # build/remove container only. In build mode, does not interactively prompt for container creation.
export NDR_DOCKER_APP_MANAGE_OPTIONS_CONTAINER_OPTIONAL=0x4 # Optional flag for container. In build mode, this triggers an interactive prompt for container creation.
export NDR_DOCKER_APP_MANAGE_OPTIONS_REMOVE_NO_PROMPT=0x8 # remove existing container without prompting.
export NDR_DOCKER_APP_MANAGE_OPTIONS_UPLOAD_NO_PROMPT=0x10 # upload container without prompting.
export NDR_DOCKER_APP_MANAGE_OPTIONS_NO_CLEANUP=0x20 # do NOT remove any existing containers (used for container starting).
export NDR_DOCKER_APP_MANAGE_OPTIONS_BUILD_IMAGE_AND_CONTAINER=$(( NDR_DOCKER_APP_MANAGE_OPTIONS_IMAGE | NDR_DOCKER_APP_MANAGE_OPTIONS_CONTAINER )) # build image and container (does not prompt for container creation).
export NDR_DOCKER_APP_MANAGE_OPTIONS_REMOVE_ALL=$(( NDR_DOCKER_APP_MANAGE_OPTIONS_IMAGE | NDR_DOCKER_APP_MANAGE_OPTIONS_CONTAINER | NDR_DOCKER_APP_MANAGE_OPTIONS_REMOVE_NO_PROMPT )) # everything.
export NDR_DOCKER_APP_MANAGE_OPTIONS_DEFAULT=$(( NDR_DOCKER_APP_MANAGE_OPTIONS_IMAGE | NDR_DOCKER_APP_MANAGE_OPTIONS_CONTAINER_OPTIONAL )) # standard behavior of create image, then prompt for optional operations such as module preclean and continer build/start.

# docker service app
export NDR_SERVICE_APPLICATION_NAME="Service Application" # friendly applications display name
export NDR_SERVICE_HOME_LOC="nextdr-svc"
export NDR_SERVICE_IMAGE_NAME="nextdr-svc-img"
export NDR_SERVICE_IMAGE_VERSION=$gPRODUCT_VERSION
export NDR_SERVICE_IMAGE_VERSION_TAG="$NDR_SERVICE_IMAGE_VERSION-$NDR_SERVICE_IMAGE_COMMIT_HASH_SHORT-$NDR_SERVICE_IMAGE_COMMIT_TIMESTAMP_UTC" # full image tag syntax "version-commithashshort-UTCdatetime"
export NDR_SERVICE_CONTAINER_NAME="nextdr-svc-app"
export NDR_SERVICE_CONTAINER_PORT="8081"
export NDR_SERVICE_DOCKERFILE_FILENAME="Dockerfile-svc"
export NDR_SERVICE_DOCKER_COMPOSE_SERVICE_NAME="nextdr-svc"
export NDR_SERVICE_COMPOSEFILE_FILENAME="docker-compose-svc.yml"
export NDR_SERVICE_IMAGE_COMMIT_HASH="$NDR_GIT_REPO_COMMIT_HASH" # git commit hash of the image. Collected during build time.
export NDR_SERVICE_IMAGE_COMMIT_HASH_SHORT="$NDR_GIT_REPO_COMMIT_HASH_SHORT" # short form of the commit hash, used for image tagging.
export NDR_SERVICE_IMAGE_COMMIT_TIMESTAMP_UTC="$NDR_GIT_REPO_COMMIT_TIMESTAMP" # UTC epoch timestamp of the image build time, collected during build time.

# docker ui app
export NDR_UI_APPLICATION_NAME="UI Application" # friendly applications display name
export NDR_UI_HOME_LOC="nextdr-ui"
export NDR_UI_IMAGE_NAME="nextdr-ui-img"
export NDR_UI_IMAGE_VERSION=$gPRODUCT_VERSION
export NDR_UI_IMAGE_VERSION_TAG="$NDR_UI_IMAGE_VERSION-$NDR_UI_IMAGE_COMMIT_HASH_SHORT-$NDR_UI_IMAGE_COMMIT_TIMESTAMP_UTC" # full image tag syntax "version-commithashshort-UTCdatetime"
export NDR_UI_CONTAINER_NAME="nextdr-ui-app"
export NDR_UI_CONTAINER_PORT="80"
export NDR_UI_DOCKERFILE_FILENAME="Dockerfile-ui"
export NDR_UI_DOCKER_COMPOSE_SERVICE_NAME="nextdr-ui"
export NDR_UI_COMPOSEFILE_FILENAME="docker-compose-ui.yml"
export NDR_UI_IMAGE_COMMIT_HASH="$NDR_GIT_REPO_COMMIT_HASH" # git commit hash of the image. Collected during build time.
export NDR_UI_IMAGE_COMMIT_HASH_SHORT="$NDR_GIT_REPO_COMMIT_HASH_SHORT" # short form of the commit hash, used for image tagging.
export NDR_UI_IMAGE_COMMIT_TIMESTAMP_UTC="$NDR_GIT_REPO_COMMIT_TIMESTAMP" # UTC epoch timestamp of the image build time, collected during build time.

export NDR_STANDARD_DOCKER_COMPOSEFILE_FILENAME="docker-compose.yml"

export NDR_DOCKER_MODULE_NAME_DELIMITER_RAW="/"
export NDR_DOCKER_MODULE_NAME_DELIMITER_MONIKER="_NDR_DELIM_"

# docker supabase app
export NDR_SUPABASE_HOME_LOC="$gSUPABASE_NEXTDR_SUB"
#export NDR_SUPABASE_IMAGE_NAME="nextdr-supabase-img"
#export NDR_SUPABASE_IMAGE_VERSION="1.0.0"
export NDR_SUPABASE_CONTAINER_NAME="ndr-supabase"
export NDR_SUPABASE_CONTAINER_PORT="8000"

# systemd service names and descriptions
export NDR_SYSTEMD_SUPABASE_SVC_NAME="ndr-supabase"
export NDR_SYSTEMD_SUPABASE_SVC_DESC="$gPRODUCT_NAME Supabase Docker Container Service"
export NDR_SYSTEMD_SUPABASE_SVC_START_CMD="ndrAdmin.sh --express startdb"
export NDR_SYSTEMD_SUPABASE_SVC_STOP_CMD="ndrAdmin.sh --express stopdb"

export NDR_SYSTEMD_SERVICE_SVC_NAME="ndr-service"
export NDR_SYSTEMD_SERVICE_SVC_DESC="$gPRODUCT_NAME Service Docker Container Service"
export NDR_SYSTEMD_SERVICE_SVC_START_CMD="ndrAdmin.sh --express startservice"
export NDR_SYSTEMD_SERVICE_SVC_STOP_CMD="ndrAdmin.sh --express stopservice"

export NDR_SYSTEMD_UI_SVC_NAME="ndr-ui"
export NDR_SYSTEMD_UI_SVC_DESC="$gPRODUCT_NAME UI Docker Container Service"
export NDR_SYSTEMD_UI_SVC_START_CMD="ndrAdmin.sh --express startui"
export NDR_SYSTEMD_UI_SVC_STOP_CMD="ndrAdmin.sh --express stopui"

# older version of Docker
export dockerRemovePkgs=(
  docker.io
  docker-doc
  docker-compose
  docker-compose-v2
  podman-docker
  containerd
  runc
)

# newer version of Docker
export dockerInstallPackages=(
  "docker-ce" \
  "docker-ce-cli" \
  "containerd.io" \
  "docker-buildx-plugin" \
  "docker-compose-plugin"
)
  
  
# ANSI color codes or logging
RESET="\033[0m"
BOLD="\033[1m"
RED="\033[31m"
YELLOW="\033[33m"
TEAL="\033[36m"
GREEN="\033[32m"
BLUE="\033[34m"

# log modes
export NDR_LOG_POLICY_MODE_NORMAL=0 # alternate mode for production, logs tracelog to file, stdout to file, stdout to terminal.
export NDR_LOG_POLICY_MODE_QUIET=1 # default mode for production, logs tracelog to file, stdout to file, keep terminal clean with TEE redirecting to file.
export NDR_LOG_POLICY_MODE_GUI=2
export NDR_LOG_POLICY_MODE_CURRENT=$NDR_LOG_POLICY_MODE_NORMAL

export NDR_LOG_POLICY_FORCE_PRINT_NONE=0x0 # no force print option
export NDR_LOG_POLICY_FORCE_PRINT_TERMINAL=0x1
export NDR_LOG_POLICY_FORCE_PRINT_FILE=0x2

# similar to C pragma once, put at end of all declarations.
[[ -n "$_NDR_COMMON_LOADED" ]] && return
_NDR_COMMON_LOADED=1


# ----------------------

# --- FUNCTIONS ---

ndr_SetLogPolicy() 
{
  if [[ $# -lt 1 ]]; then
    return 1
  fi

  local newPolicy="$1"
  NDR_LOG_POLICY_MODE_CURRENT=$newPolicy

  # Save original stdout/stderr if not already done
  local NDR_STD_FDS_SAVED=false
  [[ -z "$NDR_STD_FDS_SAVED" ]] && exec 3>&1 4>&2 && NDR_STD_FDS_SAVED=true

  case "$newPolicy" in
    "$NDR_LOG_POLICY_MODE_NORMAL")
      # Echo to screen and log file via tee
      exec &> >(tee -a "$gLOG_FILE")
      gTRACELOG_TO_STDOUT=true
      gTRACELOG_TO_FILE=true
      ;;
    "$NDR_LOG_POLICY_MODE_QUIET")
      # Echo to terminal only (no tee/logfile for stdout)
      exec &> /dev/tty
      gTRACELOG_TO_STDOUT=false
      gTRACELOG_TO_FILE=true
      ;;
    "$NDR_LOG_POLICY_MODE_GUI")
      exec 1>/dev/null 2>/dev/null        # suppress all stdout/stderr
      gTRACELOG_TO_STDOUT=false
      gTRACELOG_TO_FILE=true
      ;;
    *)
      ndr_logError "Invalid log mode: $newPolicy" >&2
      return 1
      ;;
  esac

  ndr_logInfo "Log policy set to $NDR_LOG_POLICY_MODE_CURRENT"

  return 0
}

function ndr_logSecStartDebug ()
{
  if [[ "$gDebugMode" -eq 1 ]]; then
    ndr_logSecStart "$1"
  fi
}

function ndr_logSecEndDebug ()
{
  if [[ "$gDebugMode" -eq 1 ]]; then
    ndr_logSecEnd "$1"
  fi
}

function ndr_logSecStart () 
{
  local logLine="${BLUE}+++ START [${RESET} $1 ${BLUE}] +++${RESET}"
  local plainLogLine="+++ START [ $1 ] +++"
      
  if [[ "$gTRACELOG_TO_STDOUT" == true ]]; then
    echo -e "${logLine}" > /dev/tty
  fi

  if [[ "$gTRACELOG_TO_FILE" == true ]]; then
    echo "${plainLogLine}" >> "$gLOG_FILE"
  fi
}

function ndr_logSecEnd () 
{
  local logLine="${GREEN}--- COMPLETE [${RESET} $1 ${GREEN}] ---${RESET}"
  local plainLogLine="--- COMPLETE [ $1 ] ---"

  if [[ "$gTRACELOG_TO_STDOUT" == true ]]; then
    echo -e "${logLine}" > /dev/tty
  fi
  
  if [[ "$gTRACELOG_TO_FILE" == true ]]; then    
    echo "${plainLogLine}" >> "$gLOG_FILE"
  fi
}

function _log_format () 
{
  local caller="$1" # optional, can be blank.
  local color="$2" # required
  local level="$3" # required
  local message="$4" # required
  local forcePrint="${5:-NDR_LOG_POLICY_FORCE_PRINT_NONE}" # optional, if value set, forces printing even if global flags are diabled. Useful for forcing a notification to reach the user in quiet mode

  local datetime="[$(date '+%Y-%m-%d %H:%M:%S')]"
  
  if [[ -n "$caller" ]]; then
    caller=" $caller"
  fi

  local logLine="${datetime}${caller} ${color}${level}${RESET} ${message}"
  local plainLogLine="${datetime}${caller} ${level} ${message}"

  if [[ "$gTRACELOG_TO_STDOUT" == true || $(( forcePrint & NDR_LOG_POLICY_FORCE_PRINT_TERMINAL )) -ne 0 ]]; then
    echo -e "${logLine}" > /dev/tty # send only to terminal, not to STDOUT since STDOUT is sometimes redirected to a file with tee and the color codes do not translate in file.
  fi

  if [[ "$gTRACELOG_TO_FILE" == true || $(( forcePrint & NDR_LOG_POLICY_FORCE_PRINT_FILE )) -ne 0 ]]; then
    echo -e "${plainLogLine}" >> "$gLOG_FILE"
  fi

  # Log file rotation: if log file >= 5MB, rename with datetime
  if [[ -f "$gLOG_FILE" ]]; then
    local log_size_bytes
    log_size_bytes=$(stat -c%s "$gLOG_FILE")
    local max_size_bytes=$((5 * 1024 * 1024))
    if (( log_size_bytes >= max_size_bytes )); then
      local base_name ext_name datetime_stamp rotated_name
      base_name="${gLOG_FILE%.*}"
      ext_name="${gLOG_FILE##*.}"
      datetime_stamp="$(date '+%Y%m%d_%H%M%S')"
      if [[ "$gLOG_FILE" == *.* ]]; then
        rotated_name="${base_name}_${datetime_stamp}.${ext_name}"
      else
        rotated_name="${gLOG_FILE}_${datetime_stamp}"
      fi
      mv "$gLOG_FILE" "$rotated_name"
    fi
  fi
}

# only logs at info level if debug mode is enabled.
function ndr_logDebug ()
{
  if [[ "$gDebugMode" -eq 1 ]]; then
    ndr_logInfo "$1" "$2"
  fi
}

function ndr_logInfo () 
{
  local caller_info=""
  if [[ "$gDebugMode" -eq 1 ]]; then
    caller_info="${BASH_SOURCE[1]}::${FUNCNAME[1]:-main}(${BASH_LINENO[0]})"
  fi
  
  _log_format "$caller_info" "$TEAL" "ℹ️ INFO" "$1" "$2"
}

function ndr_logWarn () 
{
  local caller_info=""
  if [[ "$gDebugMode" -eq 1 ]]; then
    caller_info="${BASH_SOURCE[1]}::${FUNCNAME[1]:-main}(${BASH_LINENO[0]})"
  fi
  
  _log_format "$caller_info" "$YELLOW" "⚠️ WARNING" "$1" "$2"
}

function ndr_logError () 
{
  local caller_info=""
  if [[ "$gDebugMode" -eq 1 ]]; then
    caller_info="${BASH_SOURCE[1]}::${FUNCNAME[1]:-main}(${BASH_LINENO[0]})"
  fi
  
  _log_format "$caller_info" "$RED" "❌ ERROR" "$1" "$2"
}

# Takes a single prompt string argument
# Returns 0 for yes, 1 for no, 2 for error
# Ensures the prompt is visible even with stdout redirected (via /dev/tty)
export NDR_PROMPT_DEFAULT_INPUT_YES=0
export NDR_PROMPT_DEFAULT_INPUT_NO=1

export NDR_PROMPT_RETURN_YES=0
export NDR_PROMPT_RETURN_NO=1
export NDR_PROMPT_RETURN_ERROR=2

function ndr_PromptYesNo() 
{
  local prompt="$1"
  local defaultInput="$2"

  # Validate argument count
  if [[ -z "$prompt" || -z "$defaultInput" ]]; then
    echo "Usage: ndr_PromptYesNo \"Prompt text\" <default (0=yes, 1=no)>" >&2
    return $NDR_PROMPT_RETURN_ERROR
  fi

  # Determine prompt label and default return logic
  local promptSuffix defaultChoice
  if [[ "$defaultInput" -eq "$NDR_PROMPT_DEFAULT_INPUT_YES" ]]; then
    promptSuffix="[Y/n]"
    defaultChoice="yes"
  elif [[ "$defaultInput" -eq "$NDR_PROMPT_DEFAULT_INPUT_NO" ]]; then
    promptSuffix="[y/N]"
    defaultChoice="no"
  else
    echo "Error: Invalid default input option: '$defaultInput'" >&2
    return $NDR_PROMPT_RETURN_ERROR
  fi

  if [[ "$gGUI_MODE" == true ]]; then
    # In dialog mode, simulate default by pre-selecting
    if [[ "$defaultChoice" == "yes" ]]; then
      dialog --yes-label "Yes" --no-label "No" --yesno "$prompt" 8 60 < /dev/tty > /dev/tty 2> /dev/tty
      [[ $? -eq 0 ]] && return $NDR_PROMPT_RETURN_YES || return $NDR_PROMPT_RETURN_NO
    else
      dialog --yes-label "Yes" --no-label "No" --defaultno --yesno "$prompt" 8 60 < /dev/tty > /dev/tty 2> /dev/tty
      [[ $? -eq 0 ]] && return $NDR_PROMPT_RETURN_YES || return $NDR_PROMPT_RETURN_NO
    fi
  else
    # Terminal mode with read
    while true; do
      read -p "$prompt $promptSuffix: " yn < /dev/tty > /dev/tty
      yn="${yn,,}"  # normalize to lowercase
      case "$yn" in
        y|yes) return $NDR_PROMPT_RETURN_YES ;;
        n|no)  return $NDR_PROMPT_RETURN_NO ;;
        "")    [[ "$defaultChoice" == "yes" ]] && return $NDR_PROMPT_RETURN_YES || return $NDR_PROMPT_RETURN_NO ;;
        *)     echo "Please answer yes or no." < /dev/tty > /dev/tty ;;
      esac
    done
  fi
}

# Usage: function <value> <flag>
# Returns 0 (true) if the flag is set, 1 (false) otherwise
function ndr_checkFlag () 
{
  local value="$1"
  local flag="$2"

  if (( (value & flag) != 0 )); then
    return 0  # flag is set
  else
    return 1  # flag is not set
  fi
}

function ndr_osTypeCheck () 
{
  local logSectionDesc="Operating system type check"
  ndr_logSecStartDebug "$logSectionDesc"

  os_type=$(uname -s)
  case "$os_type" in
    Linux)
      osTypeMajor="Linux"
      gSUPABASE_CLI_CMD="sudo npx supabase"
      ;;
    unix*)
      osTypeMajor="Unix"
      gSUPABASE_CLI_CMD="sudo npx supabase"
      ;;
    Windows*)
      osTypeMajor="Windows"
      gSUPABASE_CLI_CMD="npx supabase"
      ;;
    *NT*)
      osTypeMajor="Windows"
      gSUPABASE_CLI_CMD="sudo npx supabase"
      ;;
    *)
      osTypeMajor="Unknown"
      ;;
  esac

  ndr_logInfo "Operating system is [$osTypeMajor], type [$os_type | $OSTYPE]"
  
  if [[ "$osTypeMajor" == "Windows" ]]; then
    distroFamily="Windows"
    distroId="Windows"
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # Try to read from /etc/*release
  if grep -q "^ID=" /etc/*release 2>/dev/null; then
    distroId=$(grep "^ID=" /etc/*release | head -n1 | cut -d= -f2 | tr -d '"' | tr '[:upper:]' '[:lower:]')
  elif [[ "$(uname)" == "Darwin" ]]; then
    distroFamily="osx"
    distroId="Darwin"
  else
    ndr_logError "Unable to detect distribution."
    return 1
  fi

  # Map to main distro families
  case "$distroId" in
    ubuntu|debian|linuxmint|elementary|pop|zorin)
      distroFamily="debian"
      ;;
    rhel|redhat|centos|fedora|rocky|almalinux|scientific)
      distroFamily="redhat"
      ;;
    arch|manjaro|endeavouros)
      distroFamily="arch"
      ;;
    opensuse|suse|sles|opensuse-tumbleweed|suse-leap|opensuse-leap|suse-sles)
      distroFamily="suse"
      ;;
    alpine)
      distroFamily="alpine"
      ;;
    osx|darwin)
      distroFamily="osx"
      ;;
    *)
      distroFamily="unknown"
      ;;
  esac

  ndr_logInfo "Detected distro: $distroId, family: $distroFamily."

  # set os/disto specific commands

  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

function ndr_UpgradeModeCheck ()
{
  local logSectionDesc="Checking upgrade mode"
  ndr_logSecStartDebug "$logSectionDesc"

  gINSTALLED_VERSION=$(ndr_getVersionReg)
  gUPGRADE_MODE=false

  # check overall product version first.
  if [ ! -z "$gINSTALLED_VERSION" ]; then
    if [[ "$gINSTALLED_VERSION" == "$gPRODUCT_VERSION" ]]; then
      # versions equal, no upgrade needed.
      ndr_logDebug "Current installed version [$gINSTALLED_VERSION] matches product installer version [$gPRODUCT_VERSION]."
    elif [[ "$(printf '%s\n%s\n' "$gINSTALLED_VERSION" "$gPRODUCT_VERSION" | sort -V | head -n1)" == "$gINSTALLED_VERSION" ]]; then
      ndr_logInfo "Upgrade detected (installer: $gPRODUCT_VERSION > current: $gINSTALLED_VERSION)"
      gUPGRADE_MODE=true
    else
      ndr_logError "Downgrade detected (current: $gINSTALLED_VERSION > installer: $gPRODUCT_VERSION). Downgrades are not supported."
      return 1
    fi
  fi

  # check individual module versions and set upgrade mode if any module needs upgrade.
  ndr_logDebug "Checking individual module versions for upgrade..."
 
  # Check each module's installed version against the product version
  for module in "${gREGISTRY_ENTRY_MODULE_STATUS_NAME_LIST[@]}"; do
    local installedVersion=$(ndr_getModuleVersionReg "$module")
    if [[ -n "$installedVersion" && "$installedVersion" != "$gPRODUCT_VERSION" ]]; then
      ndr_logInfo "Module [$module] requires upgrade (current: $installedVersion, installer required: $gPRODUCT_VERSION)"
      gUPGRADE_MODE=true
    fi
  done
  
  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

function ndr_UpdateProductVersion ()
{
  local logSectionDesc="Updating product version in registry"
  ndr_logSecStart "$logSectionDesc"

  # Check each module's installed version against the product version
  local upgradeRequired=false
  for module in "${gREGISTRY_ENTRY_MODULE_STATUS_NAME_LIST[@]}"; do
    local installedVersion=$(ndr_getModuleVersionReg "$module")
    if [[ -n "$installedVersion" && "$installedVersion" != "$gPRODUCT_VERSION" ]]; then
      ndr_logInfo "Module [$module] requires upgrade (installed: $installedVersion, required: $gPRODUCT_VERSION)"
      upgradeRequired=true
    fi
  done

  if [ "$upgradeRequired" == true ]; then
    ndr_logInfo "One or more modules require upgrade, cannot update main product version."
  else
    ndr_logInfo "All modules are up to date, updating main product version from $gINSTALLED_VERSION to $gPRODUCT_VERSION."
  
    # Update overall product version
    ndr_RegistryAddKey "$gREGISTRY_ENTRY_VERSION" "$gPRODUCT_VERSION"
  fi
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_parseCommandLineArgs ()
{
  local logSectionDesc="Parsing common command line arguments"
  ndr_logSecStartDebug "$logSectionDesc"

  # Parse arguments
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --express|-e)
        if [[ -n "$2" && "$2" != --* ]]; then
          gExpressMode=1
          gExpressOption="$2"
          ndr_logInfo "Express option set to [$gExpressOption]"
          shift 2
        else
          ndr_logError "--express requires a value."
          return 1
        fi
        ;;
      --admin-user|--au)
        if [[ -n "$2" && "$2" != --* ]]; then
          gNDR_CONSOLE_ADMIN_ACCOUNT_USER="$2"
          ndr_logInfo "Console admin account user set to [$gNDR_CONSOLE_ADMIN_ACCOUNT_USER]"
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --admin-password|--ap)
        if [[ -n "$2" && "$2" != --* ]]; then
          gNDR_CONSOLE_ADMIN_ACCOUNT_PASSWORD="$2"
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --dashboard-user|--dashuser|--du)
        if [[ -n "$2" && "$2" != --* ]]; then
          gSUPABASE_ENV_VAL_DASHBOARD_USERNAME="$2"
          ndr_logInfo "Supabase Dashboard account user set to [$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME]"
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --dashboard-password|--dashpass|--dp)
        if [[ -n "$2" && "$2" != --* ]]; then
          gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD="$2"
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --gpg-secret)
        if [[ -n "$2" && "$2" != --* ]]; then
          gNDR_SECRETS_PASSPHRASE="$2"
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --logpolicy)
        if [[ -n "$2" && "$2" != --* ]]; then
          NDR_LOG_POLICY_MODE_CURRENT="$2"
          ndr_logInfo "Setting log policy to [$NDR_LOG_POLICY_MODE_CURRENT]"
          ndr_SetLogPolicy "$NDR_LOG_POLICY_MODE_CURRENT"
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --schemafile|--sf)
        if [[ -n "$2" && "$2" != --* ]]; then
          gNDR_SUPABASE_DB_SCHEMA_FILE="$2"
          ndr_logInfo "Supabase schema file [$gNDR_SUPABASE_DB_SCHEMA_FILE]"
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --retain-docker-images|--retainimages)
        gNDR_RETAIN_DOCKER_IMAGES=true
        ndr_logInfo "Docker image retention option enabled."
        shift
        ;;
      --privaterepo)
        NDR_DOCKER_REPO_TYPE_CURRENT=$NDR_DOCKER_REPO_TYPE_PRIVATE
        ndr_logInfo "Docker repo type set to [$NDR_DOCKER_REPO_TYPE_CURRENT]."
        shift
        ;;
      --publicrepo)
        NDR_DOCKER_REPO_TYPE_CURRENT=$NDR_DOCKER_REPO_TYPE_PUBLIC
        ndr_logInfo "Docker repo type set to [$NDR_DOCKER_REPO_TYPE_CURRENT]."
        shift
        ;;
      --debug)
        gDebugMode=1
        shift
        ;;
      *)
        #ndr_logError "Unknown option: $1"
        shift
        ;;
    esac
  done

  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

# Function to compare semantic versions
# Returns 0 (true) if $1 < $2
# Returns 1 (false) if $1 >= $2
function version_lt() 
{
  [ "$(printf '%s\n' "$1" "$2" | sort -V | head -n1)" != "$2" ]
}

function ndr_checkAndInstallPrerequisites () 
{
  local logSectionDesc="Checking prerequisites"
  ndr_logSecStart "$logSectionDesc"

  if [[ $gPrereqCheckComplete -eq 1 ]]; then
    ndr_logInfo "Prerequesite check complete, skipping."
    return 0
  fi

  local checkOnlyFlag=false
  if [[ "$1" == "checkOnly" ]]; then
    checkOnlyFlag=true
  fi

  declare -A mapPackageAndVersions=()

  if [[ "$gNDR_DEVOPS_MODE" == true ]]; then
    mapPackageAndVersions["makeself"]="$NDR_MIN_REQUIRED_YQ_VERSION"
    mapPackageAndVersions["npm"]="$NDR_MIN_REQUIRED_VERSION_DEFAULT"
    mapPackageAndVersions["postgresql-client"]="$NDR_MIN_REQUIRED_VERSION_DEFAULT"
  fi
  mapPackageAndVersions["yq"]="$NDR_MIN_REQUIRED_YQ_VERSION"
  mapPackageAndVersions["git"]="$NDR_MIN_REQUIRED_VERSION_DEFAULT"
  mapPackageAndVersions["docker"]="$NDR_MIN_REQUIRED_VERSION_DEFAULT"
  #mapPackageAndVersions["$gSUPABASE_CLI_CMD"]="$NDR_MIN_REQUIRED_VERSION_DEFAULT"
  
  local packageInstalled=false

  # Execute a preliminary install cache update appropriate to the distro.
  # this is useful on fresh vm's where the cache has never been init'd.
  if [[ "$distroFamily" == "debian" ]]; then
    cmd="sudo apt-get update"
  fi
  if [[ -n "$cmd" ]]; then
    $cmd
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "[$cmd] failure"
    fi
  fi
  
  for pkg in "${!mapPackageAndVersions[@]}"; do
    local minPkgVersion="${mapPackageAndVersions[$pkg]}"
    
    # assume all packages are not installed by default, then check one by one.
    packageInstalled=false
    local removeRequired=false

    while true; do
      if ! command -v "$pkg" &> /dev/null; then
        ndr_logWarn "$pkg requires installation."
        break
      fi
      
      # some version of package is least installed, check version independently below.
      packageInstalled=true # package is installed
      
      # only check version if min required version for package is populated with valid value.
      if [[ "$minPkgVersion" == "$NDR_MIN_REQUIRED_VERSION_DEFAULT" ]]; then
        # package is installed and version check is not required.
        break
      fi

      local pkgOutput=$("$pkg" --version)
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logWarn "Error scraping $pkg version output [$return_code -> $pkgOutput]"
        packageInstalled=false
        break
      fi
      
      # parse the installed numerical version from the command output. If version number not present, skip version checks.
      local pkgInstalledVersion=$(echo "$pkgOutput" | sed -nE 's/.*([0-9]+\.[0-9]+\.[0-9]+).*/\1/p')
      if [[ -z $pkgInstalledVersion ]]; then
        # unable to parse out specific version info, skip further processing.
        ndr_logWarn "Version info not found for package [$pkg], [$pkgOutput]"
        packageInstalled=false
        break
      fi
      ndr_logInfo "Found [$pkg] package version installed [$pkgInstalledVersion] compared to min reqd version [$minPkgVersion]"
      
      version_lt "$pkgInstalledVersion" "$minPkgVersion"
      return_code=$?
      if [ $return_code -eq 0 ]; then
        ndr_logInfo "Older version of [$pkg] detected. Replacing with latest..."
        removeRequired=true # removal of old version will be required.
        packageInstalled=false # then installation of new version.
      else
        ndr_logInfo "✅ Package [$pkg] is up to date."
      fi
      
      break
    done

    if [ $packageInstalled == true ]; then
      # package is installed and version is matching, nothing more to do.
      ndr_logInfo "✅ $pkg is installed."
      continue;
    fi

    if [ $checkOnlyFlag == true ]; then
      # executed in check only mode, do not actually install any packages.
      continue
    fi

    # skip individual package prompts in express mode.
    if [[ "$gExpressMode" -eq 0 ]]; then
      read -p "Would you like to install/update $pkg now? [Y/n] " REPLY
      if [[ $REPLY =~ ^[Nn]$ ]]; then
        ndr_logWarn "Skipping installation of $pkg."
        continue;
      fi
    fi

    ndr_logInfo "Installing [$pkg] package..."
    case "$pkg" in
      postgresql-client)
        packageURL="https://www.postgresql.org/download/linux/ubuntu/"
        
        if [[ "$distroFamily" == "debian" ]]; then
          cmd="sudo apt-get install --assume-yes postgresql-client"
        elif [[ "$distroFamily" == "redhat" ]]; then
          cmd="sudo dnf install postgresql"
        elif [[ "$distroFamily" == "suse" ]]; then
          cmd="sudo zypper install --no-confirm postgresql-client"
        elif [[ "$distroFamily" == "osx" ]]; then
          cmd="brew install postgresql-client"
        fi
        
        $cmd
        return_code=$?
        if [ $return_code != 0 ]; then
          ndr_logError "[$cmd] failure, $pkg package not installed, please manually install package before proceeding ($packageURL)"
          return 1
        fi
        ndr_logInfo "$pkg package installed successfully."
        ;;

      yq)
        packageURL="https://github.com/mikefarah/yq"

        if [ $removeRequired == true ]; then
          if [[ "$distroFamily" == "debian" ]]; then
            cmd="sudo apt-get remove --assume-yes yq"
          elif [[ "$distroFamily" == "redhat" ]]; then
            cmd="sudo dnf remove yq"
          elif [[ "$distroFamily" == "suse" ]]; then
            cmd="sudo zypper remove --no-confirm yq"
          elif [[ "$distroFamily" == "osx" ]]; then
            cmd="brew remove yq"
          fi

           $cmd
          return_code=$?
          if [ $return_code != 0 ]; then
            ndr_logError "[$cmd] failure, $pkg package not removed, please manually remove package before proceeding"
            return 1
          fi
        fi

        cmd="wget https://github.com/mikefarah/yq/releases/latest/download/yq_linux_amd64 -O /usr/local/bin/yq"
        $cmd
        return_code=$?
        if [ $return_code != 0 ]; then
          ndr_logError "[$cmd] failure, $pkg package not installed, please manually install package before proceeding ($packageURL)"
          return 1
        fi
        sudo chmod +x /usr/local/bin/yq

        ndr_logInfo "$pkg package installed successfully."
        ;;

      makeself)
        packageURL="https://makeself.io/"
        
        if [[ "$distroFamily" == "debian" ]]; then
          cmd="sudo apt-get install --assume-yes makeself"
        elif [[ "$distroFamily" == "redhat" ]]; then
          cmd="sudo dnf install makeself"
        elif [[ "$distroFamily" == "suse" ]]; then
          cmd="sudo zypper install --no-confirm makeself"
        elif [[ "$distroFamily" == "osx" ]]; then
          cmd="brew install makeself"
        fi
        
        $cmd
        return_code=$?
        if [ $return_code != 0 ]; then
          ndr_logError "[$cmd] failure, $pkg package not installed, please manually install package before proceeding ($packageURL)"
          return 1
        fi
        ndr_logInfo "$pkg package installed successfully."
        ;;

      awk|gawk)
        packageURL="https://www.gnu.org/software/gawk/manual/gawk.html"
        
        if [[ "$distroFamily" == "debian" ]]; then
          cmd="sudo apt-get install --assume-yes gawk"
        elif [[ "$distroFamily" == "redhat" ]]; then
          cmd="sudo dnf install gawk"
        elif [[ "$distroFamily" == "suse" ]]; then
          cmd="sudo zypper install --no-confirm gawk"
        elif [[ "$distroFamily" == "osx" ]]; then
          cmd="brew install gawk"
        fi
        
        $cmd
        return_code=$?
        if [ $return_code != 0 ]; then
          ndr_logError "[$cmd] failure, $pkg package not installed, please manually install package before proceeding ($packageURL)"
          return 1
        fi
        ndr_logInfo "$pkg package installed successfully."
        ;;

      npm|npx)
        packageURL="https://docs.npmjs.com/downloading-and-installing-node-js-and-npm"
        
        if [[ "$distroFamily" == "debian" ]]; then
          cmd="sudo apt install --assume-yes npm"
        elif [[ "$distroFamily" == "redhat" ]]; then
          cmd="sudo dnf install nodejs"
        elif [[ "$distroFamily" == "suse" ]]; then
          cmd="sudo zypper install --no-confirm nodejs"
        elif [[ "$distroFamily" == "osx" ]]; then
          cmd="brew install node"
        fi
        
        $cmd
        return_code=$?
        if [ $return_code != 0 ]; then
          ndr_logError "[$cmd] failure, $pkg package not installed, please manually install package before proceeding ($packageURL)"
          return 1
        fi
        ndr_logInfo "$pkg package installed successfully."
        ;;

      git)
        packageURL="https://git-scm.com/downloads"
        
        if [[ "$distroFamily" == "debian" ]]; then
          cmd="sudo apt install --assume-yes git"
        elif [[ "$distroFamily" == "redhat" ]]; then
          cmd="sudo dnf install git"
        elif [[ "$distroFamily" == "suse" ]]; then
          cmd="sudo zypper install --no-confirm git"
        elif [[ "$distroFamily" == "osx" ]]; then
          cmd="brew install git"
        fi

        $cmd
        return_code=$?
        if [ $return_code != 0 ]; then
          ndr_logError "[$cmd] failure, $pkg package not installed, please manually install package before proceeding ($packageURL)"
          return 1
        fi
        ndr_logInfo "$pkg package installed successfully."
        ;;

      docker)
        packageURL="https://docs.docker.com/engine/install/"
        if [[ "$distroFamily" == "debian" ]]; then
          local installCmds=(
            ndr_checkAndInstallDocker
          )
        elif [[ "$distroFamily" == "debianOLD" ]]; then
          local installCmds=(
                "sudo apt-get install --assume-yes gnome-terminal"
                "sudo apt-get update" \
                "sudo apt-get install --assume-yes ca-certificates" \
                "sudo apt-get install --assume-yes curl" \
                "sudo install -m 0755 -d /etc/apt/keyrings" \
                "sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc" \
                "sudo chmod a+r /etc/apt/keyrings/docker.asc" \
                #"echo deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo ${UBUNTU_CODENAME:-$VERSION_CODENAME}) stable | sudo tee /etc/apt/sources.list.d/docker.list"
                # Step 1: Get system architecture
                "arch=$(dpkg --print-architecture)" \
                # Step 2: Get Ubuntu codename (e.g., focal, jammy)
                ". /etc/os-release" \
                "codename=\"${UBUNTU_CODENAME:-$VERSION_CODENAME}\"" \
                # Step 3: Construct the deb line
                "deb_line=\"deb [arch=$arch signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu $codename stable\"" \
                # Step 4: Write to APT sources list with sudo
                "echo \"$deb_line\" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null" \
                "sudo apt-get update" \
                "sudo apt-get install --assume-yes docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin")
        elif [[ "$distroFamily" == "redhat" ]]; then
          local installCmds=(
                "sudo dnf install gnome-terminal" \
                "sudo dnf -y install dnf-plugins-core" \
                "sudo dnf-3 config-manager --add-repo https://download.docker.com/linux/fedora/docker-ce.repo" \
                "sudo dnf install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin" \
                "sudo systemctl enable --now docker")
        elif [[ "$distroFamily" == "suse" ]]; then
          local installCmds=(
                "sudo zypper addrepo https://download.opensuse.org/repositories/Virtualization:containers/openSUSE_Tumbleweed_and_d_l_g/Virtualization:containers.repo" \
                "sudo zypper addrepo https://download.docker.com/linux/sles/docker-ce.repo" \
                "sudo zypper refresh" \
                "sudo zypper install docker-compose" \
                "sudo systemctl enable docker.service" \
                "sudo usermod -aG docker $USER" \
                "sudo systemctl start docker.service" \
                "sudo zypper install docker")
        fi

        for installCmd in "${installCmds[@]}"; do
        ndr_logInfo "Executing installation command [$installCmd]..."
          $installCmd
          return_code=$?
          if [ $return_code != 0 ]; then
            ndr_logError "[$installCmd] failure, $pkg package not installed, please manually install package before proceeding ($packageURL)"
            # skip apt-get command failures
            if [[ "$installCmd" == *"apt-get update"* || "$installCmd" == *addrepo* ]]; then
              continue
            fi
            return 1
          fi
        done
        
        getent group docker || sudo groupadd docker
        return_code=$?
        if [ $return_code -ne 0 ]; then
          ndr_logError "Failed to create docker group. Please check your system configuration."
          return 1
        fi
        ndr_logInfo "Created docker group if it did not exist."

        sudo usermod -aG docker "$USER"
        return_code=$?
        if [ $return_code -ne 0 ]; then
          ndr_logError "Failed to add user $USER to docker group. Please check your system configuration."
          return 1
        fi
        ndr_logInfo "User $USER added to docker group. You may need to log out and back in for this change to take effect."

        if systemctl is-active --quiet docker; then
          ndr_logInfo "Docker is running."
        else
          # Optional: try to start it
          ndr_logInfo "Docker is NOT running, attempting to start Docker..."
          
          sudo systemctl start docker

          # Check again after attempt
          if systemctl is-active --quiet docker; then
              ndr "Docker started successfully."
          else
              ndr_logError "Failed to start Docker. Check logs with: journalctl -u docker. A reboot may be required to complete the installation."
              return 1
          fi
        fi
        
        ndr_logInfo "$pkg package installed successfully."            
        ;;

      supabase)
        packageURL="https://supabase.com/docs/guides/local-development"

        cmd="sudo npm install supabase --save-dev"
        
        $cmd
        return_code=$?
        if [ $return_code != 0 ]; then
          ndr_logError "[$cmd] failure, $pkg package not installed, please manually install package before proceeding ($packageURL)"
          return 1
        fi
        ndr_logInfo "$pkg package installed successfully."
        ;;
      
      *)
        ndr_logWarn "Unknown package [$pkg] "
        continue
        ;;
    esac

    packageInstalled=true

  done

  # the prereq check complete flag needs to be qualfied by all packages installed before setting
  if [ $packageInstalled == true ]; then
    ndr_logInfo "All required packages are installed."
    gPrereqCheckComplete=1
  else
    ndr_logError "Some required packages are not installed. Please install them before proceeding."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}


function ndr_checkAndInstallDocker ()
{
  # -------------------------------------
  # cleanup old docker packages

  local logSectionDesc="Conflicting Docker package removal"
  ndr_logSecStart "$logSectionDesc"

  # Loop through each package and remove it
  for pkg in "${dockerRemovePkgs[@]}"; do
    if dpkg -l | grep -q "$pkg"; then
      ndr_logInfo "🗑️ Removing $pkg..."
      sudo apt-get remove --assume-yes "$pkg"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "$pkg package not removed, please manually remove package before proceeding."
        return 1
      fi
    else
      ndr_logInfo "$pkg is not installed, skipping."
    fi
  done

  ndr_logSecEnd "$logSectionDesc"
  
  # -------------------------------------
  # 🚮 Remove any stale Docker APT source files

  local logSectionDesc="🧹 Cleaning up old Docker APT source entries"
  ndr_logSecStart "$logSectionDesc"

  # Remove docker.list if it exists
  docker_list="/etc/apt/sources.list.d/docker.list"
  if [[ -f "$docker_list" ]]; then
    sudo rm -f "$docker_list"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "file $docker_list not removed, please manually remove file before proceeding."
      return 1
    fi
    ndr_logInfo "🗑️ Removed stale Docker source file."
  fi

  # Optional: grep and warn about any other Docker-related entries
  if grep -r "download.docker.com" /etc/apt/sources.list.d/ > /dev/null; then
    ndr_logWarn "Found other Docker source entries in [/etc/apt/sources.list.d/]."
  fi

  if grep -q "download.docker.com" /etc/apt/sources.list; then
    ndr_logWarn "Found Docker source entry in [/etc/apt/sources.list]  You may want to clean that manually.033[0m"
  fi

  ndr_logSecEnd "$logSectionDesc"

  # -------------------------------------
  # Add Docker's official GPG key:

  local logSectionDesc="Adding Official Docker GPG Key"
  ndr_logSecStart "$logSectionDesc"

  sudo apt-get update
  pkgs=(
    ca-certificates
    curl
  )
  # Loop through each package and install it
  for pkg in "${pkgs[@]}"; do
    ndr_logInfo "💾 Installing $pkg..."
    sudo apt-get install --assume-yes "$pkg"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "$pkg package not installed, please manually install package before proceeding."
      return 1
    fi
  done

  local cmds=(
    "sudo install -m 0755 -d /etc/apt/keyrings" \
    "sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc" \
    "sudo chmod a+r /etc/apt/keyrings/docker.asc"
    )
  
  for cmd in "${cmds[@]}"; do
    ndr_logInfo "💾 Executing command [$cmd]..."
    $cmd
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Command [$cmd] failure, please run manually before proceeding."
      return 1
    fi
  done

  ndr_logSecEnd "$logSectionDesc"

  # -------------------------------------
  # add deb line to apt sources list

  local logSectionDesc="Adding Docker APT source entries"
  ndr_logSecStart "$logSectionDesc"
  
  # single line execution
  #echo deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo ${UBUNTU_CODENAME:-$VERSION_CODENAME}) stable | sudo tee /etc/apt/sources.list.d/docker.list

  # multi line execution
  # Step 1: Get system architecture
  arch=$(dpkg --print-architecture)

  # Step 2: Get Ubuntu codename (e.g., focal, jammy)
  . /etc/os-release
  codename="${UBUNTU_CODENAME:-$VERSION_CODENAME}"

  # Step 3: Construct the deb line
  deb_line="deb [arch=$arch signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu $codename stable"

  # Step 4: Write to APT sources list with sudo 
  apt_source_file="/etc/apt/sources.list.d/docker.list"
  echo "$deb_line" | sudo tee "$apt_source_file" > /dev/null
  
  ndr_logInfo "Adding deb line [$deb_line] to list file [$apt_source_file]."

  sudo apt-get update

  ndr_logSecEnd "$logSectionDesc"

  # -------------------------------------
  # verify apt sources

  local logSectionDesc="Verifying Docker APT source entries"
  ndr_logSecStart "$logSectionDesc"

  # Step 1: Verify the deb line exists
  if [[ ! -f "$apt_source_file" ]]; then
    ndr_logError "APT source file not found: [$apt_source_file]."
    return 1
  fi

  if grep -Fxq "$deb_line" "$apt_source_file"; then
    ndr_logInfo "Docker APT source entry is present."
  else
    ndr_logError "Docker APT source entry is missing or incorrect."
    return 1
  fi

  # Step 2: Update APT
  ndr_logInfo "🔄 Running apt-get update..."
  sudo apt-get update -qq
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "apt-get update failed."
    return 1
  fi

  # Step 3: Check for Docker packages
  for pkg in "${dockerInstallPackages[@]}"; do
    ndr_logInfo "🔍 Checking if Docker package [$pkg] is available..."
    repo_line=$(apt-cache policy "$pkg" 2>/dev/null | grep "https://download.docker.com/linux/ubuntu $codename")
    return_code=$?
    if [[ $return_code -eq 0 && -n "$repo_line" ]]; then
      ndr_logInfo "✅ Docker package [$pkg] is available from Docker's APT repository."
    else
      ndr_logError "Docker package [$pkg] not found in the expected repository."
      return 1
    fi
  done

  ndr_logSecEnd "$logSectionDesc"

  # -------------------------------------
  # install docker packages
  
  local logSectionDesc="Installing Docker packages"
  ndr_logSecStart "$logSectionDesc"

  #sudo apt-get install --assume-yes docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
  for pkg in "${dockerInstallPackages[@]}"; do
    ndr_logInfo "🔍 Installing Docker engine package [$pkg]..."
    cmd="sudo apt-get install --assume-yes $pkg"
    $cmd
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to install Docker package [$pkg]."
      return 1
    else
      ndr_logInfo "✅ Docker package [$pkg] installed successfully."
    fi
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}


# Running Supabase locally in a Docker container
# to create build env prerequsiites, some prerequisites must be interactively installed before the scripting can proceed.
# https://supabase.com/docs/guides/self-hosting/docker
# 1. install NPM/NPX (https://docs.npmjs.com/downloading-and-installing-node-js-and-npm)
# 2. install GIT (https://git-scm.com/downloads)
# 3. install docker (https://docs.docker.com/desktop/setup/install/windows-install/ or https://docs.docker.com/desktop/setup/install/linux-install/)
# 4. create docker account and log in (docker desktop and pulls will not function without this). With the Docker UI open, you can observe the images and containers getting created and onlined in real time.
function ndr_packagePrereqCheck ()
{
  local logSectionDesc="Checking package prerequisites"
  ndr_logSecStart "$logSectionDesc"

  ndr_checkAndInstallPrerequisites checkOnly
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Package prereq only check failed."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

NDR_ModuleContainerEnvVars=(
  "SITE_URL" \
  "POSTGRES_PASSWORD" \
  "ANON_KEY" \
  "NDR_SUPABASE_URL" \
  "NDR_SUPABASE_ANON_KEY" \
  "NDR_API_SERVER_URL" \
  "NDR_LICENSE_SERVER_URL" \
  "NDR_SUPABASE_SERVICE_KEY" \
  "NDR_PASSWORD_ENC_SECRET"
  )
  
# Usage: ndr_BuildModuleEnvFile <folder>
function ndr_BuildModuleEnvFile () 
{
  local logSectionDesc="Constructing module env file"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 1 ]]; then
    ndr_logError "Usage: ndr_BuildModuleEnvFile <folder>"
    return 1
  fi

  local containerFolder="$1"
  local sourceEnvFile="${gSCRIPT_HOME_DIR}/${gNDR_MODULE_ENV_SOURCE_VAR_FILENAME}"
  
  # Check source file
  if [[ ! -f "$sourceEnvFile" ]]; then
    ndr_logError "Source env file '$sourceEnvFile' not found."
    return 1
  fi

  # check destination folder
  local destFolder="$containerFolder"
  if [[ ! -d "$destFolder" ]]; then
    ndr_logError "Destination folder '$destFolder' does not exist."
    return 1
  fi
  local destEnvFile="${destFolder}/${gNDR_ENV_TARGET_FILENAME}"
  
  if [[ -z "$gNDR_SERVER_HOST_ADDRESS" || "$gNDR_SERVER_HOST_ADDRESS" == "localhost" ]]; then
    local hostAddress=$(ndr_getHostAddressReg)
    if [[ -n "$hostAddress" && "$hostAddress" != "localhost" ]]; then
      gNDR_SERVER_HOST_ADDRESS="$hostAddress"
      ndr_logInfo "Using host address [$gNDR_SERVER_HOST_ADDRESS] from registry for $gPRODUCT_NAME specific target server addresses".
    fi
  fi

  
  if false; then
  # Empty or create output file
  rm -f "$destEnvFile"
  > "$destEnvFile"

  # Copy specified variables
  for var in "${NDR_ModuleContainerEnvVars[@]}"; do
    line=$(grep -E "^${var}=" "$sourceEnvFile" | head -n1)
    if [[ -n "$line" ]]; then
      echo "$line" >> "$destEnvFile"
    else
      ndr_logError "Warning: Variable '$var' not found in $sourceEnvFile"
      return 1
    fi
  done
  fi

  # Load source env into a map
  declare -A source_map
  while IFS='=' read -r key value; do
    [[ -z "$key" || "$key" == \#* ]] && continue
    source_map["$key"]="$value"
  done < "$sourceEnvFile"
  ndr_logInfo "Read [${#source_map[@]}] entries from source env file [$sourceEnvFile]."

  # Load destination env into a map (if exists)
  declare -A dest_map
  if [[ -f "$destEnvFile" ]]; then
    while IFS='=' read -r key value; do
      [[ -z "$key" || "$key" == \#* ]] && continue
      dest_map["$key"]="$value"
    done < "$destEnvFile"
    ndr_logInfo "Read [${#dest_map[@]}] entries from existing dest env file [$destEnvFile]."
  else
    ndr_logInfo "Dest env file [$destEnvFile] does not exist, will create new."
  fi

  # Update dest_map with resolved values from source_map
  for var in "${NDR_ModuleContainerEnvVars[@]}"; do
    if [[ -z "${source_map[$var]+_}" ]]; then
      ndr_logWarn "Variable '$var' not found in source env file. Skipping."
      continue
    fi

    raw_value="${source_map[$var]}"
    if [[ "$raw_value" =~ ^\$\{([A-Za-z_][A-Za-z0-9_]*)\}$ ]]; then
      ref_key="${BASH_REMATCH[1]}"
      if [[ -z "${source_map[$ref_key]+_}" ]]; then
        ndr_logWarn "Referenced variable '$ref_key' (in $var) not found. Skipping."
        continue
      fi
      resolved_value="${source_map[$ref_key]}"
    else
      resolved_value="$raw_value"
    fi

    # If variable is prefixed with NDR_ and contains 'localhost' and $gNDR_SERVER_HOST_ADDRESS is valid, substitute $gNDR_SERVER_HOST_ADDRESS
    if [[ "$var" == NDR_* && "$resolved_value" == *localhost* && "$gNDR_SERVER_HOST_ADDRESS" != "localhost" ]]; then
      resolved_value="${resolved_value//localhost/$gNDR_SERVER_HOST_ADDRESS}"
      ndr_logInfo "Updating [$var -> $resolved_value] to reflect target IP [$gNDR_SERVER_HOST_ADDRESS]"
    fi

    dest_map["$var"]="$resolved_value"
  done

  # Write merged map to destination file
  {
    for key in "${!dest_map[@]}"; do
      echo "$key=${dest_map[$key]}"
    done | sort
  } > "$destEnvFile"
  ndr_logInfo "Wrote [${#dest_map[@]}] entries to dest env file [$destEnvFile]."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# Usage: function <folder>
function ndr_BuildModuleEnvFileV2 () 
{
  local logSectionDesc="Constructing module env file"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 1 ]]; then
    ndr_logError "Usage: function <folder>"
    return 1
  fi

  local containerFolder="$1"
  local sourceEnvFile="${gSCRIPT_HOME_DIR}/${gNDR_MODULE_ENV_SOURCE_VAR_FILENAME}" # Source env file (references + comments)

  # Check source file
  if [[ ! -f "$sourceEnvFile" ]]; then
    ndr_logError "Source env file '$sourceEnvFile' not found."
    return 1
  fi

  if [ -z "$gSUPABASE_NEXTDR_HOME" ]; then
    gSUPABASE_NEXTDR_HOME="${gNEXTDR_HOME_DIR}/${gSUPABASE_NEXTDR_SUB}"
  fi
  if [ ! -d "$gSUPABASE_NEXTDR_HOME" ]; then
    ndr_logError "Unable to determine Supabase home directory or directory doesn't exist."
    return 1
  fi

  local supabaseEnvFile="${gSUPABASE_NEXTDR_HOME}/${gNDR_ENV_TARGET_FILENAME}"   # Supabase env file (lookup values from here)

  # Check supabase file
  if [[ ! -f "$supabaseEnvFile" ]]; then
    ndr_logError "Supabase env file '$supabaseEnvFile' not found."
    return 1
  fi

  # check destination folder
  local destFolder="$containerFolder"
  if [[ ! -d "$destFolder" ]]; then
    ndr_logError "Destination folder '$destFolder' does not exist."
    return 1
  fi
  local destEnvFile="${destFolder}/${gNDR_ENV_TARGET_FILENAME}" # Destination env file to generate
  local destEnvFileTmp="${destEnvFile}.tmp"

  # check if dest and temp env files exist and remove
  if [[ -f "$destEnvFile" ]]; then
    ndr_logInfo "Removing existing dest env file [$destEnvFile] before regenerating."
    rm -f "$destEnvFile"
  fi
  if [[ -f "$destEnvFileTmp" ]]; then
    ndr_logInfo "Removing existing temp env file [$destEnvFileTmp] before regenerating."
    rm -f "$destEnvFileTmp"
  fi

  # --- Load Supabase env vars into a lookup map ---
  declare -A supabase_map
  while IFS='=' read -r key value; do
    [[ -z "$key" || "$key" == \#* ]] && continue
    supabase_map["$key"]="$value"
  done < "$supabaseEnvFile"

  # --- Read the entire source file into lines (preserving comments & spaces) ---
  mapfile -t lines < "$sourceEnvFile"
  if [[ $? -ne 0 ]]; then
    ndr_logError "Failed to read $sourceEnvFile"
    return 1
  fi

  linesCustomValues=0
  for line in "${lines[@]}"; do
    # Preserve comments and empty lines as-is
    if [[ -z "$line" || "$line" =~ ^[[:space:]]*# ]]; then
      continue
    else
      linesCustomValues=$((linesCustomValues += 1))
    fi
  done
  ndr_logInfo "Read [$linesCustomValues] custom values from source file [$sourceEnvFile] to update in module env file [$destEnvFile]."

  local new_lines=()

  local linesWritten=0

  # --- Process source lines one by one ---
  for line in "${lines[@]}"; do
    # Preserve comments and empty lines as-is
    if [[ -z "$line" || "$line" =~ ^[[:space:]]*# ]]; then
      new_lines+=("$line")
      continue
    fi

    # Match VAR=VALUE pairs
    if [[ "$line" =~ ^([A-Za-z_][A-Za-z0-9_]*)=(.*)$ ]]; then
      key="${BASH_REMATCH[1]}"
      value="${BASH_REMATCH[2]}"

      # Detect value reference like $OTHER_VAR or ${OTHER_VAR}
      if [[ "$value" =~ ^\$\{?([A-Za-z_][A-Za-z0-9_]*)\}?$ ]]; then
        ref="${BASH_REMATCH[1]}"
        if [[ -n "${supabase_map[$ref]+_}" ]]; then
          value="${supabase_map[$ref]}"
          ndr_logInfo "Resolved reference $key from $ref"
        else
          ndr_logError "Reference $ref for $key not found in $supabaseEnvFile"
          return 1
        fi
      fi

      if [[ "$value" == *"localhost"* ]]; then
        value="${value//localhost/$gNDR_SERVER_HOST_ADDRESS}"
        ndr_logInfo "Updating host address key with actual value [$key=$value]"
        linesUpdated=$((linesUpdated += 1))
      fi

      linesWritten=$((linesWritten += 1))

      # Append resolved key=value pair
      new_lines+=("$key=$value")
    else
      # For any non-standard lines, keep as-is
      new_lines+=("$line")
    fi
  done

  # --- Open temp file for writing ---
  exec 3> "$destEnvFileTmp" || {
    ndr_logError "Failed to open $destEnvFileTmp for writing"
    return 1
  }

  # --- Write processed lines one by one ---
  for l in "${new_lines[@]}"; do
    if ! printf '%s\n' "$l" >&3; then
      ndr_logError "Failed to write line to $destEnvFileTmp: $l"
      exec 3>&-
      return 1
    fi
  done

  # --- Build list of additional environment variables ---
  NDR_SUPABASE_CONTAINER_PORT=$(grep -E '^KONG_HTTP_PORT=' "$supabaseEnvFile" | cut -d '=' -f2-)
  NDR_DOCKER_SUPABASE_URL="http://${NDR_SUPABASE_APP_SERVICE_NAME_KONG}:${NDR_SUPABASE_CONTAINER_PORT}"
  
  declare -A additional_vars
  additional_vars=(
    ["NDR_HOME_DIR"]="${gNEXTDR_HOME_DIR}"
    ["NDR_LOGS_DIR"]="${gNEXTDR_HOME_DIR}/logs"
    ["NDR_SUPABASE_HOME_DIR"]="${gSUPABASE_NEXTDR_HOME}"
    ["NDR_SUPABASE_DB_BACKUP_DIR"]="${gSUPABASE_NEXTDR_HOME}/ndr_db_backups"
    ["NDR_VERSION"]="${gPRODUCT_VERSION}"
    ["NDR_COMMIT_HASH"]="${NDR_GIT_REPO_COMMIT_HASH_SHORT}"
    ["NDR_COMMIT_TIMESTAMP"]="${NDR_GIT_REPO_COMMIT_TIMESTAMP}"
    ["NDR_DOCKER_SUPABASE_URL"]="${NDR_DOCKER_SUPABASE_URL}"
  )

  # write additional vars to dest env file temp
  for key in "${!additional_vars[@]}"; do
    value="${additional_vars[$key]}"
    if ! printf '%s=%s\n' "$key" "$value" >&3; then
      ndr_logError "Failed to write additional var to $destEnvFileTmp: $key=$value"
      exec 3>&-
      return 1
    fi
    linesWritten=$((linesWritten += 1))
  done

  # --- Close temp file ---
  exec 3>&-

  # --- Move temp file into final location ---
  if ! mv "$destEnvFileTmp" "$destEnvFile"; then
    ndr_logError "Failed to replace $destEnvFile with updated content"
    return 1
  fi

  ndr_logInfo "Module env file [$destEnvFile] successfully generated with [$linesWritten] entries"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_BuildModuleComposeFile ()
{
  local logSectionDesc="Building module compose file"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: ndr_BuildModuleComposeFile <folder> <docker_image_base_name>"
    return 1
  fi

  # the compose file is directly linked to the module's env file because the env file will have
  # the explicit name/value pairs that the compose file implicitly references.
  local containerFolder="$1"
  local dockerImageBaseName="$2"
  local ENV_FILE="${containerFolder}/${gNDR_ENV_TARGET_FILENAME}"
  
  # Check for env file
  if [[ ! -f "$ENV_FILE" ]]; then
    ndr_logError "env file '$ENV_FILE' not found."
    return 1
  fi

  # copy the app specific compose file to app home dir.
  # hack
  local sourceFileName
  local serviceName
  local imageNameVersion
  if [ "$dockerImageBaseName" == "$NDR_SERVICE_IMAGE_NAME" ]; then
    sourceFileName="$NDR_SERVICE_COMPOSEFILE_FILENAME"
    serviceName=$NDR_SERVICE_DOCKER_COMPOSE_SERVICE_NAME
    imageNameVersion="${dockerImageBaseName}:${NDR_SERVICE_IMAGE_VERSION_TAG}"
  elif [ "$dockerImageBaseName" == "$NDR_UI_IMAGE_NAME" ]; then
    sourceFileName="$NDR_UI_COMPOSEFILE_FILENAME"
    serviceName=$NDR_UI_DOCKER_COMPOSE_SERVICE_NAME
    imageNameVersion="${dockerImageBaseName}:${NDR_UI_IMAGE_VERSION_TAG}"
  else
    ndr_logError "Unknown docker image base name."
    return 1
  fi

  local sourceFile="${gSCRIPT_HOME_DIR}/${sourceFileName}"
  local destFile="${containerFolder}/${NDR_STANDARD_DOCKER_COMPOSEFILE_FILENAME}" # rename the module specific compose file to the common name
  cp -f $sourceFile $destFile
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to copy [$sourceFile] to [$destFile]"
    return 1
  fi
  ndr_logInfo "Successfully copied [$sourceFile] to [$destFile]"

  # check for compose file
  local COMPOSE_FILE="${destFile}"
  if [[ ! -f "$COMPOSE_FILE" ]]; then
    ndr_logError "Compose file '$COMPOSE_FILE' not found."
    return 1
  fi

  # update image name with current version.
  #local imageNameVersion="${dockerImageBaseName}:${gPRODUCT_VERSION}"
  yq eval -i ".services.\"${serviceName}\".image = \"${imageNameVersion}\"" "$COMPOSE_FILE"
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logWarn "Failed to update image name with version in [$COMPOSE_FILE] to [$imageNameVersion]"
  fi
  ndr_logInfo "Updated image name with version [$imageNameVersion] in [$COMPOSE_FILE]"

  # --- Load env vars into a lookup map ---
  declare -A env_map
  while IFS='=' read -r key value; do
    [[ -z "$key" || "$key" == \#* ]] && continue
    env_map["$key"]="$value"
  done < "$ENV_FILE"

  linesAdded=0
  # Add each env var from env file to the environment: section of the compose file using yq
  for var in "${!env_map[@]}"; do
    # Add or update the environment variable in the compose file
    yq eval -i ".services.*.environment.${var} = \"\${${var}}\"" "$COMPOSE_FILE"
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logWarn "Failed to add $var to environment section in $COMPOSE_FILE"
    else
      ndr_logInfo "Added $var: \${$var} to environment section in $COMPOSE_FILE"
      linesAdded=$((linesAdded += 1))
    fi
  done

  ndr_logInfo "Compose file [$COMPOSE_FILE] successfully updated with [$linesAdded] environment values"

  # Add bridge network
  ndr_CustomizeDockerComposeFileAddBridgeNetwork "$COMPOSE_FILE"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to add bridge network to compose file [$COMPOSE_FILE]."
    return 1
  fi

  # Add bind mounts
  ndr_CreateDockerBindMounts "$COMPOSE_FILE"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to add bind mounts to compose file [$COMPOSE_FILE]."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function <compose_file>
function ndr_CustomizeDockerComposeFileAddBridgeNetwork () 
{
  local logSectionDesc="Customizing Docker compose file to add bridge network"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 1 ]]; then
    ndr_logError "Usage: ndr_CustomizeDockerComposeFileAddBridgeNetwork <compose_file>"
    return 1
  fi

  local COMPOSE_FILE="$1"
  
  if [[ ! -f $COMPOSE_FILE ]]; then
    ndr_logError "Docker compose file [$COMPOSE_FILE] not found."
    return 1
  fi

  # Add the root-level external network if it doesn't exist
  # Check if the network 'ndr_bridge_net' is already defined
  local network_check=$(yq eval ".networks.${NDR_DOCKER_BRIDGE_NETWORK_NAME}" "$COMPOSE_FILE")
  
  # Now check if it's null or empty
  if [[ "$network_check" == "null" || -z "$network_check" ]]; then
    yq eval ".networks.${NDR_DOCKER_BRIDGE_NETWORK_NAME}.external = true" "$COMPOSE_FILE" -i
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to add root-level network '$NDR_DOCKER_BRIDGE_NETWORK_NAME'."
      return 1
    else
      ndr_logInfo "Root-level network '$NDR_DOCKER_BRIDGE_NETWORK_NAME' added."
    fi
  else
    ndr_logInfo "Root-level network '$NDR_DOCKER_BRIDGE_NETWORK_NAME' already exists in compose file."
  fi
  
  # Get list of services
  mapfile -t services < <(yq eval '.services | keys | .[]' "$COMPOSE_FILE")
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to retrieve services from compose file [$COMPOSE_FILE]."
    return 1
  fi

  if [[ ${#services[@]} -eq 0 ]]; then
    echo "No services found in compose file."
    return 1
  fi

  # Iterate over services and add network assignment
  for service_name in "${services[@]}"; do
    # Check if service includes the bridge network
    yq eval ".services.${service_name}.networks[]" "$COMPOSE_FILE" | grep -qx "$NDR_DOCKER_BRIDGE_NETWORK_NAME"
    return_code=$?
    if [ $return_code -eq 0 ]; then
      ndr_logInfo "Service '$service_name' already uses network '$NDR_DOCKER_BRIDGE_NETWORK_NAME', skipping."
      continue
    fi

    yq eval ".services.\"$service_name\".networks += [\"$NDR_DOCKER_BRIDGE_NETWORK_NAME\"]" "$COMPOSE_FILE" -i
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Error adding network '$NDR_DOCKER_BRIDGE_NETWORK_NAME' to service '$service_name'. Aborting."
      return 1
    else
      ndr_logInfo "Network '$NDR_DOCKER_BRIDGE_NETWORK_NAME' added to service '$service_name'."
    fi
  done

  ndr_logInfo "All services updated successfully in compose file [$COMPOSE_FILE]."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_CreateDockerBindMounts ()
{
  local logSectionDesc="Create Docker Bind Mounts"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 1 ]]; then
    ndr_logError "Usage: ndr_CreateDockerBindMounts <compose_file>"
    return 1
  fi

  local compose_file=$1
  local vol_entry="$gNEXTDR_HOME_DIR:$gNEXTDR_HOME_DIR:rw"

  # Get list of services
  mapfile -t services < <(yq eval '.services | keys | .[]' "$compose_file")
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to retrieve services from compose file [$compose_file]."
    return 1
  fi

  if [[ ${#services[@]} -eq 0 ]]; then
    echo "No services found in compose file."
    return 1
  fi

  # Iterate over services and add volume entry
  for service in "${services[@]}"; do
    # Check if service includes the volume entry
    local has_volumes_section=false
    yq eval ".services.${service}.volumes[]" "$compose_file" | grep -qx "$vol_entry"
    return_code=$?
    if [ $return_code -eq 0 ]; then
      ndr_logInfo "Service '$service' already contains volume entry '$vol_entry'"
      has_volumes_section=true
    fi

    # --- Step 2: Add volumes section if missing ---
    if [ "$has_volumes_section" = false ]; then
      yq eval -i ".services[\"$service\"].volumes = []" "$compose_file"
      return_code=$?
      if [[ $return_code -ne 0 ]]; then
        ndr_logError "Failed to add volumes section for service '$service'"
        return 1
      fi
      ndr_logInfo "Added volumes section for service $service"
    fi

    # --- Step 3: Check if desired entry exists ---
    if yq eval ".services[\"$service\"].volumes[]" "$compose_file" 2>/dev/null | grep -Fxq "$vol_entry"; then
      ndr_logInfo "Volume entry already exists for $service: $vol_entry"
    else
      yq eval -i ".services[\"$service\"].volumes += [\"$vol_entry\"]" "$compose_file"
      return_code=$?
      if [[ $return_code -ne 0 ]]; then
        ndr_logError "Failed to add volume entry for service '$service'"
        return 1
      fi
      ndr_logInfo "Adding volume entry for $service: $vol_entry"
    fi
  done

  ndr_logInfo "Docker bind mounts [$vol_entry] created."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_CleanupModuleEnvFile ()
{
  local logSectionDesc="Cleaning up module environment file"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -lt 1 ]]; then
    ndr_logError "Usage: ndr_CleanupModuleEnvFile <folder>"
    return 1
  fi

  local containerFolder="$1"
  local destEnvFile="${containerFolder}/${gNDR_ENV_TARGET_FILENAME}"

  # Check destination file
  if [[ ! -f "$destEnvFile" ]]; then
    ndr_logError "Destination env file '$destEnvFile' not found."
    return 1
  fi

  # Remove the file
  rm -f "$destEnvFile"
  ndr_logInfo "Module environment file '$destEnvFile' removed."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_InstallHomeCheck ()
{
  local logSectionDesc="$gCOMPANY_NAME install home check"
  ndr_logSecStart "$logSectionDesc"
  
  # if some package is already installed, read from registry. home dir cannot be modified once a package is installed.
  local homeDir=""
  homeDir=$(ndr_getHomeDirReg)
  return_code=$?
  if [[ $return_code -eq 0 && -n "$homeDir" ]]; then
    ndr_logInfo "Found home directory entry [$homeDir] in registry from prior package installation."
    gNEXTDR_HOME_DIR="$homeDir"
    return 0
  fi

  if [ "$gExpressMode" -eq 1 ]; then
    if [ -z "$gNEXTDR_HOME_DIR" ]; then
      ndr_logError "gNEXTDR_HOME_DIR is not set in express mode. Please set it before proceeding."
      return 1
    fi
    
    # we should also create if it does not exist
    if [ ! -d "$gNEXTDR_HOME_DIR" ]; then
      ndr_logInfo "Creating directory [$gNEXTDR_HOME_DIR] for product and container installation."
      
      mkdir -p "$gNEXTDR_HOME_DIR"
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Failed to create directory [$gNEXTDR_HOME_DIR]. Please check permissions and try again."
        return 1
      fi
    fi

    #ndr_logInfo "Skipping install home check in express mode to directory [$gNEXTDR_HOME_DIR]."
    return 0
  fi

  echo "This will install $gCOMPANY_NAME and its application containers under the directory [default: $gNEXTDR_HOME_DIR]."
  echo "If this is not the desired installation location, please select No and enter the correct location or select quit to return to the main menu."
  
  read -p "Are you sure you want to proceed? (Yes/no/quit) " -n 1 -r
  echo    # Move to a new line
  if [[ $REPLY =~ ^[Qq]$ ]]; then
      ndr_logWarn "Operation cancelled."
      return 1

  elif [[ $REPLY =~ ^[Nn]$ ]]; then

    while true; do
      inputDir=""
      read -r -p "Enter the directory where you want to install the softare package: " inputDir
      if [ -z "$inputDir" ]; then
        ndr_logError "No directory entered. Please enter a valid directory."
        continue;
      fi
      
      confirm=""
      read -r -p "You entered: [$inputDir], is this correct? (Y/n)" confirm
      if [[ "$confirm" =~ ^[Nn]$ ]]; then
        ndr_logInfo "Please re-enter the directory."
        continue
      fi

      if [ ! -d "$inputDir" ]; then
        ndr_logWarn "Directory [$inputDir] does not exist, creating..."
        mkdir -p "$inputDir"
        return_code=$?
        if [ $return_code -ne 0 ]; then
          ndr_logError "Failed to create directory [$inputDir]. Please check permissions and try again."
          continue
        fi
        ndr_logInfo "Directory [$inputDir] created successfully."
      fi

      # Check if the directory is writable
      if [ ! -w "$inputDir" ]; then
        ndr_logError "Directory [$inputDir] is not writable. Please choose a different directory."
        continue
      fi

      # If we reach here, the directory is valid and writable
      ndr_logInfo "Using directory [$inputDir] for $gCOMPANY_NAME installation."
      gNEXTDR_HOME_DIR="$inputDir"
      
      break
    done
  else

    if [ ! -d "$gNEXTDR_HOME_DIR" ]; then
      ndr_logWarn "Directory [$gNEXTDR_HOME_DIR] does not exist, creating..."
      mkdir -p "$gNEXTDR_HOME_DIR"
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Failed to create directory [$gNEXTDR_HOME_DIR]. Please check permissions and try again."
        return 1
      fi
      ndr_logInfo "Directory [$gNEXTDR_HOME_DIR] created successfully."
    fi

    # Check if the directory is writable
    if [ ! -w "$gNEXTDR_HOME_DIR" ]; then
      ndr_logError "Directory [$gNEXTDR_HOME_DIR] is not writable. Please choose a different directory."
      return 1
    fi

    # If we reach here, the directory is valid and writable
    ndr_logInfo "Using directory [$gNEXTDR_HOME_DIR] for $gCOMPANY_NAME installation."

  fi
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_CleanupApplicationFolders ()
{
  local logSectionDesc="Cleaning up application folders"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: ndr_CleanupApplicationFolders <application_folder>"
    return 1
  fi

  local applicationFolder=$1

  # remove this applications specific home dir
  local applicationHomeDir="${gNEXTDR_HOME_DIR}/${applicationFolder}"
  if [[ ! -d "$applicationHomeDir" ]]; then
    ndr_logInfo "Application home dir [$applicationHomeDir] does not exist, nothing to remove."
  else
    rm -rf "$applicationHomeDir"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to remove application home dir [$applicationHomeDir]"
      return 1
    else
      ndr_logInfo "Removed application home dir [$applicationHomeDir]"
    fi
  fi

  # if all applications are being removed, then also remove the company home dir
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
  local dbInstalled=$?
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SERVICE_NAME"
  local svcInstalled=$?
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_UI_NAME"
  local uiInstalled=$?

  while true; do
    # if all modules are not installed, then remove the company home dir
    if [[ "$dbInstalled" -eq 0 || "$svcInstalled" -eq 0 || "$uiInstalled" -eq 0 ]]; then
      ndr_logInfo "Not removing company home dir [$gNEXTDR_HOME_DIR] since some modules are still installed."
      break;
    fi
    ndr_logInfo "All modules are uninstalled, removing company home dir [$gNEXTDR_HOME_DIR]."

    if [[ ! -d "$gNEXTDR_HOME_DIR" ]]; then
      ndr_logInfo "Company home dir [$gNEXTDR_HOME_DIR] does not exist, nothing to remove."
      break
    fi

    # remove the company home dir
    rm -rf "$gNEXTDR_HOME_DIR"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to remove company home dir [$gNEXTDR_HOME_DIR]"
      break
    fi
      
    ndr_logInfo "Removed company home dir [$gNEXTDR_HOME_DIR]"
    break
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# ====================================================
# Create systemd service unit file
# usage: ndr_CreateSystemdServiceUnit <service_name> <description> <exec_start_command> <exec_stop_command>
# ====================================================
function ndr_CreateSystemdServiceUnit() 
{
  local logSectionDesc="Creating systemd service unit file"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -ne 4 ]]; then
    ndr_logError "Usage: <service_name> <description> <exec_start_command> <exec_stop_command>"
    return 1
  fi

  if [[ -z "$gNEXTDR_HOME_DIR" ]]; then
    ndr_logError "Invalid home directory."
    return 1
  fi

  local serviceName="$1"
  local description="$2"
  local execStart="$gNEXTDR_HOME_DIR/$3"
  local execStop="$gNEXTDR_HOME_DIR/$4"

  local systemdPath="/etc/systemd/system/${serviceName}.service"

  # Check if the unit file already exists
  if [ -f "$systemdPath" ]; then
    ndr_logInfo "Systemd unit already exists: $systemdPath — skipping creation."
    return 0
  fi

  sudo tee "$systemdPath" > /dev/null <<EOF
[Unit]
Description=$description
After=docker.service
Requires=docker.service

[Service]
Type=oneshot
RemainAfterExit=true
ExecStart=$execStart
ExecStop=$execStop
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to write unit file: $systemdPath (code $return_code)"
    return 1
  fi
  ndr_logInfo "Unit file created: $systemdPath"
  
  # Reload systemd and enable the service
  sudo systemctl daemon-reload
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to reload systemd: (code $return_code)"
    return 1
  fi
  ndr_logInfo "Reloaded systemd daemon."

  sudo systemctl enable "$serviceName"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to enable systemd service: $serviceName (code $return_code)"
    return 1
  fi
  ndr_logInfo "Enabled systemd service: $serviceName"

  ndr_logSecEnd "$logSectionDesc"
  return 0
}

function ndr_InstallSystemdUnit_Supabase() 
{
  local logSectionDesc="Installing systemd unit for Supabase"
  ndr_logSecStart "$logSectionDesc"

  local svc="$NDR_SYSTEMD_SUPABASE_SVC_NAME"
  local desc="$NDR_SYSTEMD_SUPABASE_SVC_DESC"
  local startCmd="$NDR_SYSTEMD_SUPABASE_SVC_START_CMD"
  local stopCmd="$NDR_SYSTEMD_SUPABASE_SVC_STOP_CMD"

  ndr_CreateSystemdServiceUnit "$svc" "$desc" "$startCmd" "$stopCmd"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create systemd unit for $svc"
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"
  return 0
}

function ndr_InstallSystemdUnit_Service() 
{
  local logSectionDesc="Installing systemd unit for Service"
  ndr_logSecStart "$logSectionDesc"

  local svc="$NDR_SYSTEMD_SERVICE_SVC_NAME"
  local desc="$NDR_SYSTEMD_SERVICE_SVC_DESC"
  local startCmd="$NDR_SYSTEMD_SERVICE_SVC_START_CMD"
  local stopCmd="$NDR_SYSTEMD_SERVICE_SVC_STOP_CMD"

  ndr_CreateSystemdServiceUnit "$svc" "$desc" "$startCmd" "$stopCmd"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create systemd unit for $svc"
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"
  return 0
}

function ndr_InstallSystemdUnit_UI() 
{
  local logSectionDesc="Installing systemd unit for UI"
  ndr_logSecStart "$logSectionDesc"
  
  local svc="$NDR_SYSTEMD_UI_SVC_NAME"
  local desc="$NDR_SYSTEMD_UI_SVC_DESC"
  local startCmd="$NDR_SYSTEMD_UI_SVC_START_CMD"
  local stopCmd="$NDR_SYSTEMD_UI_SVC_STOP_CMD"

  ndr_CreateSystemdServiceUnit "$svc" "$desc" "$startCmd" "$stopCmd"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create systemd unit for $svc"
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"
  return 0
}

function ndr_UninstallSystemdUnit() 
{
  local logSectionDesc="Uninstalling systemd unit"
  ndr_logSecStart "$logSectionDesc"

  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: ndr_UninstallSystemdUnit <service_name>"
    return 1
  fi

  local svc="$1"
  local systemdUnitRemoved=true


  # Check if the systemd unit exists before disabling
  systemctl list-unit-files | grep -q "^${svc}\.service"
  return_code=$?
  if [ $return_code -eq 0 ]; then
    sudo systemctl disable "$svc"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to disable systemd service: $svc (code $return_code)"
      systemdUnitRemoved=false
    else
      ndr_logInfo "Disabled systemd service: $svc"
    fi
  else
    ndr_logInfo "Systemd service $svc does not exist or is not installed. Skipping disable."
  fi

  local serviceFile="/etc/systemd/system/${svc}.service"
  if [[ -f "$serviceFile" ]]; then
    sudo rm -f "$serviceFile"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to remove systemd service file: $serviceFile (code $return_code)"
      systemdUnitRemoved=false
    else
      ndr_logInfo "Removed systemd service file: $serviceFile"
    fi
  else
    ndr_logWarn "Systemd file [$serviceFile] does not exist, skipping removal."
  fi

  sudo systemctl daemon-reload
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to reload systemd daemon: (code $return_code)"
    systemdUnitRemoved=false
  else
    ndr_logInfo "Removed systemd service: $svc"
  fi

  if [[ "$systemdUnitRemoved" == false ]]; then
    ndr_logError "Errors encountered removing systemd for service [$svc]"
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"
  return 0
}

function ndr_UninstallSystemdUnit_Supabase() 
{
  local logSectionDesc="Uninstalling systemd unit for Supabase"
  ndr_logSecStart "$logSectionDesc"

  ndr_UninstallSystemdUnit "$NDR_SYSTEMD_SUPABASE_SVC_NAME"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to uninstall systemd unit for Supabase"
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"
  return 0
}

function ndr_UninstallSystemdUnit_Service() 
{
  local logSectionDesc="Uninstalling systemd unit for Service"
  ndr_logSecStart "$logSectionDesc"

  ndr_UninstallSystemdUnit "$NDR_SYSTEMD_SERVICE_SVC_NAME"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to uninstall systemd unit for Service"
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"
  return 0
}

function ndr_UninstallSystemdUnit_UI() 
{
  local logSectionDesc="Uninstalling systemd unit for UI"
  ndr_logSecStart "$logSectionDesc"

  ndr_UninstallSystemdUnit "$NDR_SYSTEMD_UI_SVC_NAME"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to uninstall systemd unit for UI"
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"
  return 0
}

function ndr_QueryHostAddress ()
{
  local logSectionDesc="Query for product host address"
  ndr_logSecStart "$logSectionDesc"

  local hostAddress=""

  # express mode check where user specified ip address as cmdline arg
  if [[ "$gExpressMode" -eq 1 && -n "$gNDR_SERVER_HOST_ADDRESS" && "$gNDR_SERVER_HOST_ADDRESS" != "localhost" ]]; then
    ndr_logInfo "Using host address [$gNDR_SERVER_HOST_ADDRESS] cmdline option in express mode"
    hostAddress="$gNDR_SERVER_HOST_ADDRESS"
  fi

  # Get current address from registry, if any.
  local bVerifyQueryAddress=false
  if [[ -z "$hostAddress" || "$hostAddress" == "localhost" ]]; then
    hostAddress=$(ndr_getHostAddressReg)
    if [[ -z "$hostAddress" || "$hostAddress" == "localhost" ]]; then
      ndr_logWarn "Unable to retrieve host address from registry, trying other options."
    else
      ndr_logInfo "Pulled host address [$hostAddress] from registry."
    fi
  fi

  # Get IP if nothing currently provided.
  if [[ -z "$hostAddress" || "$hostAddress" == "localhost" ]]; then
    # no ip in registry, attempt to get from the system
    local queryHostAddress=$(curl -fsSL https://ifconfig.me)
    if [[ -n "$queryHostAddress" ]]; then
      hostAddress=$(printf "%s" "$queryHostAddress") # do this to trim out any line breaks that seem to come embedded in the output from this curl query.
      ndr_logInfo "Found possible external address from network query [$queryHostAddress]"
      bVerifyQueryAddress=true
    fi
  fi

  # if in express mode, we have to skip all interactive prompts and run with the value we have.
  if [ "$gExpressMode" -ne 1 ]; then
    # we *may* have an address, verify with user this is the correct one.
    if [[ -z "$hostAddress" || "$hostAddress" == "localhost" || $bVerifyQueryAddress == true ]]; then
      echo -e "The host address currently set for $gPRODUCT_NAME is [$hostAddress]. Is this the correct external host address where the application modules will be hosted on and accessible from?" >&2
      read -p "Choose YES to continue with this address or NO to be prompted to enter a new one [Y|n]" -n 1 -r
      echo >&2   # Move to a new line
      if [[ $REPLY =~ ^[Nn]$ ]]; then
        # clear it and we will prompt below to enter
        hostAddress=""
      fi
    fi

    # still invalid from curl query failure, no reg entry or user indicating entry is required, prompt user to enter now.
    if [[ -z "$hostAddress" ]]; then
      while true; do
        read -p "No host address is currently set for the $gPRODUCT_NAME application modules. Please enter the host address of this server: " -r hostAddress
        #echo >&2   # Move to a new line
        if [[ -n "$hostAddress" ]]; then
          read -p "The host address entered is [$hostAddress]. Is this the correct external host address where the application modules will be accessible from (Yes|no|abort)? [Y|n|a]" -n 1 -r
          echo  >&2  # Move to a new line
          if [[ $REPLY =~ ^[Nn]$ ]]; then
            # clear it and we will prompt below to enter
            hostAddress=""
            echo    # Move to a new line
            continue
          elif [[ $REPLY =~ ^[Aa]$ ]]; then
            # abort
            hostAddress=""
            break
          else
            # answered yes, accept value and continue.
            break
          fi
        fi
        echo "No host address provided, please enter a valid address"
        continue
      done  
    fi
  fi

  if [[ -z "$hostAddress" ]]; then
    ndr_logWarn "Warning, no host address found or specified."
  else
    ndr_logInfo "Using specified host address [$hostAddress]."
  fi

  ndr_logSecEnd "$logSectionDesc"

  local nRet=1
  if [[ -n "$hostAddress" ]]; then
    nRet=0
    echo "$hostAddress"
  fi
  return $nRet
}

function ndr_PopulateHostAddress ()
{
  local logSectionDesc="Populating Host Address"
  ndr_logSecStart "$logSectionDesc"

  # if address empty or set to localhost, query for current.
  if [[ -z "$gNDR_SERVER_HOST_ADDRESS" || "$gNDR_SERVER_HOST_ADDRESS" == "localhost" ]]; then
    local hostAddress=$(ndr_QueryHostAddress)
    return_code=$?
    if [[ $return_code -ne 0 || -z $hostAddress ]]; then
      ndr_logError "Failed to retrieve IP address."
      return 1
    fi
    gNDR_SERVER_HOST_ADDRESS="$hostAddress"
  fi
  ndr_logInfo "Host address set to [$gNDR_SERVER_HOST_ADDRESS]"

  # populate registry value. Check for reg existance to handle devops mode where no reg is installed.
  ndr_RegistryExists
  return_code=$?
  if [ "$return_code" -eq 0 ]; then
    local regHostAddress=$(ndr_getHostAddressReg)
    if [[ "$regHostAddress" != "$gNDR_SERVER_HOST_ADDRESS" ]]; then
      ndr_setHostAddressReg "$gNDR_SERVER_HOST_ADDRESS"
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Failed to set host address [$gNDR_SERVER_HOST_ADDRESS] in registry."
        return 1
      fi
    else
      ndr_logInfo "Existing host address in registry [$regHostAddress] same as set value [$gNDR_SERVER_HOST_ADDRESS], skipping update."
    fi
  else
    ndr_logInfo "Registry not present, not updating host address in registry."
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_DecryptPopulateSecrets ()
{
  local logSectionDesc="Decrypting and Populating Secrets"
  ndr_logSecStart "$logSectionDesc"

  if [ "$gNDR_SECRETS_LOADED" == true ]; then
    ndr_logInfo "Secrets already loaded"
    return 0
  fi

  local encSecretsFile="${gSCRIPT_HOME_DIR}/$gNDR_SECRETS_GPG_FILENAME"
  
  if [ ! -f "$encSecretsFile" ]; then
    ndr_logError "Secrets file not found [$encSecretsFile]"
    return 1
  fi

  set +H  # Disable history expansion for passwords (!)

  # use local secrets file. It is encrypted so it will require user interaction to decript.
  local decSecretsFile=$gNDR_SECRETS_FILENAME
  local DECRYPTED=""

  max_retries=3
  attempt=1
  while true; do
    #gpgconf --kill gpg-agent
    if [ -z "$gNDR_SECRETS_PASSPHRASE" ]; then
      ndr_logInfo "Secrets key empty, prompting interactively"
      echo "Please (re)enter the GPG passphrase to decrypt the $gCOMPANY_NAME secrets file:"
      DECRYPTED=$(gpg --pinentry-mode loopback --decrypt "$encSecretsFile")
    else
      DECRYPTED=$(gpg --batch --yes --passphrase "$gNDR_SECRETS_PASSPHRASE" --decrypt "$encSecretsFile")
    fi
    return_code=$?
    if [ $return_code -eq 0 ]; then
      ndr_logInfo "Decrypted secrets file [$encSecretsFile]"
      break;
    fi

    if [[ $attempt -ge $max_retries ]]; then
      ndr_logError "Max decrypt retries reached. Exiting."
      return 1
    fi

    ndr_logWarn "Failed to decrypt secrets file [$encSecretsFile], retrying..."
    rm -f "$decSecretsFile"
    attempt=$((attempt + 1))
    gNDR_SECRETS_PASSPHRASE=""
    sleep 1  # Optional: wait before retrying
  done

  # immediately clean up decrypted file
  rm -f "$decSecretsFile"

  if [ -z "$DECRYPTED" ]; then
    ndr_logError "Decrypted secrets empty."
    return 1
  fi

  # Load into environment
  eval "$DECRYPTED"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to load secrets into local environment."
    return 1
  fi

  gNDR_SECRETS_LOADED=true

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_CopyInstallHomeFiles ()
{
  local logSectionDesc="Copying Installation Home Files"
  ndr_logSecStart "$logSectionDesc"

  export copyFileList=(
    "ndrInstall.sh" \
    "ndrAdmin.sh" \
    "ndrInterface.sh" \
    "ndrCommon.sh" \
    "ndrDocker.sh" \
    "ndrRegistry.sh" \
    "ndrSupabase.sh"
  )

  for filename in "${copyFileList[@]}"; do
    local sourceFile="${gSCRIPT_HOME_DIR}/$filename"
    local destFile="${gNEXTDR_HOME_DIR}/$filename"
    
    if [ ! -f "$sourceFile" ]; then
      ndr_logError "File not found [$sourceFile]"
      return 1
    fi

    cp -f $sourceFile $destFile
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to copy file [$sourceFile] to [$destFile]"
      return 1
    fi
    ndr_logInfo "Successfully copied file [$sourceFile] to [$destFile]"

    chmod +x "$destFile"
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_getRegistryNameForImageName ()
{
  if [[ $# -ne 1 ]]; then
    ndr_logError "Usage: function <image_name>"
    return 1
  fi

  local imageName="$1"
  local registryName=""

  if [ "$imageName" == "$NDR_SERVICE_IMAGE_NAME" ]; then
    registryName="$gREGISTRY_ENTRY_MODULE_STATUS_SERVICE_NAME"
  elif [ "$imageName" == "$NDR_SERVICE_IMAGE_NAME" ]; then
    registryName="$gREGISTRY_ENTRY_MODULE_STATUS_UI_NAME"
  fi

  if [ -z "$registryName" ]; then
    ndr_logError "Unable to translate image name [$imageName]."
    return 1
  fi
  
  echo "$registryName"

  return 0
}

function ndr_getHomeDirForImageName ()
{
  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <image_name> <module_subfolder>"
    return 1
  fi

  local imageName="$1"
  local containerFolder="$2"
  local appHomeDir=""

  local registryName=$(ndr_getRegistryNameForImageName "$imageName")
  if [ -z "$registryName" ]; then
    ndr_logError "Failed to translate image name [$imageName] to registry name fo home dir lookup."
    return 1
  fi

  ndr_isModuleInstalledReg "$registryName"
  local moduleInstalled=$?
  if [ "$moduleInstalled" -ne 0 ]; then
    # module not installed, home dir can only be a local devops style path.
    local relPath="${gSCRIPT_HOME_DIR}/../${containerFolder}"
    # try to resolve relative to absolute path
    appHomeDir=$(realpath "$relPath")
    if [ -z "$relPath" ]; then
      # fall back to relative path.
      appHomeDir="${relPath}"
    fi
    echo "$appHomeDir"
    return 0
  fi
  
  # module is installed, get home folder from reg
  local homeDir=$(ndr_getHomeDirReg)
  return_code=$?
  if [[ $return_code -ne 0 || -z "$homeDir" ]]; then
    ndr_logError "Failed to retrieve home dir from registry."
    return 1
  fi
  gNEXTDR_HOME_DIR=$(ndr_getHomeDirReg)

  appHomeDir="${gNEXTDR_HOME_DIR}/${containerFolder}"
  echo "$appHomeDir"

  return 0
}

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ndr_logWarn "This is a bash module--there is no direct execution capabilities in this file."
  exit 0
fi
