#!/bin/bash

source "$(dirname "${BASH_SOURCE[0]}")/ndrInterface.sh"
source "$(dirname "${BASH_SOURCE[0]}")/ndrRegistry.sh"
source "$(dirname "${BASH_SOURCE[0]}")/ndrDocker.sh"
source "$(dirname "${BASH_SOURCE[0]}")/ndrSupabase.sh"

# --- CONFIGURATION ---

gLOG_FILE="/var/log/ndrInstall.log"


EXPRESS_MENU_OPTIONS="installprerequisites | installsupabase | installservice | installui | installall | removesupabase | removeservice | removeui | removeall | backupdb | restoredb | createaccount"

# ----------------------

# --- FUNCTIONS ---

# ====================================================
# Main script execution
# ====================================================

function mainInstallSupabaseApplication ()
{
  local logSectionDesc="Installing Supabase Application"
  ndr_logSecStart "$logSectionDesc"

  # +++ upgrade not currently supported for supabase. Remove below when it is.
  if [ "$gUPGRADE_MODE" == true ]; then
    ndr_logWarn "Upgrade mode is not currently supported for the Supabase application."
    return 0
  fi

  local appBuildOptions="$NDR_SUPABASE_APP_BUILD_OPTIONS_INSTALL"

  ndr_BuildSupabaseApplication "$appBuildOptions"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi
  
  ndr_logInfo "Supabase application install completed."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainInstallServiceApplication ()
{
  local logSectionDesc="Installing service application"
  ndr_logSecStart "$logSectionDesc"

  ndr_InstallHomeCheck
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi
  
  local regName="$gREGISTRY_ENTRY_MODULE_STATUS_SERVICE_NAME"
  ndr_isModuleInstalledReg "$regName"
  local thisInstalled=$?
    
  if [ "$gExpressMode" -ne 1 ]; then
    # prereq module check
    ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
    local dbInstalled=$?
    if [[ "$dbInstalled" -ne 0 ]]; then
      read -p "The prerequisite $gCOMPANY_NAME Supabase database module does not appear to be currently installed. This module has an operational dependency on that module and may not be fully operable until that prerequisite is also installed. Would you like continue installing this module? (Y|n)" -n 1 -r
      echo    # Move to a new line
      if [[ $REPLY =~ ^[Nn]$ ]]; then
        ndr_logInfo "Operation cancelled, returning to main menu."
        return 1
      fi
      ndr_logInfo "Proceeding with installation."
    fi

    if [ "$gUPGRADE_MODE" == false ]; then
      # already installed/upgrade/overlay check
      if [[ thisInstalled -eq 0 ]]; then
        read -p "The $gCOMPANY_NAME Service module is already installed. Would you like to upgrade or overlay the existing installation? (Y|n)" -n 1 -r
        echo    # Move to a new line
        if [[ $REPLY =~ ^[Nn]$ ]]; then
          ndr_logInfo "Operation cancelled, returning to main menu."
          return 1
        fi
        ndr_logInfo "Proceeding with installation."
      fi
    fi
  fi

  if [ "$gUPGRADE_MODE" == true ]; then
    # if product is not installed, do not upgrade or install.
    if [[ thisInstalled -ne 0 ]]; then
      ndr_logInfo "The $gCOMPANY_NAME Service module does not appear to be currently installed. Upgrade mode can only be used when the product is already installed. After all currently install modules are upgraded, please use install mode to perform a new installation of this module."
      return 0
    fi

    # version check to see if module is already at current version.
    local moduleVersion=$(ndr_getModuleVersionReg "$regName")
    if [ "$moduleVersion" == "$gPRODUCT_VERSION" ]; then
      ndr_logInfo "The $gCOMPANY_NAME Service module is already at the current product version [$gPRODUCT_VERSION]. No upgrade required."
      return 0
    fi
  fi

  # query for latest image tag details.
  ndr_QueryLatestMatchingRemoteImageTags "$NDR_SERVICE_IMAGE_NAME"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to query remote repo for latest image tag details."
    return 1
  fi

  local dockerImageBaseName=$NDR_SERVICE_IMAGE_NAME
  local dockerImageVersion=$NDR_SERVICE_IMAGE_VERSION_TAG
  local dockerImageVersionCleanup=$gINSTALLED_VERSION
  local dockerImageName="$dockerImageBaseName:$dockerImageVersion"
  local dockerRepoName="$NDR_DOCKER_SERVICE_PUBLIC_REPO_NAME"
  if [ "$NDR_DOCKER_REPO_TYPE_CURRENT" == "$NDR_DOCKER_REPO_TYPE_PRIVATE" ]; then
    dockerRepoName="$NDR_DOCKER_SERVICE_PRIVATE_REPO_NAME"
  fi
  local containerFolder="$NDR_SERVICE_HOME_LOC"
  local containerHomeDir="${gNEXTDR_HOME_DIR}/${containerFolder}"
  local dockerContainerName="$NDR_SERVICE_CONTAINER_NAME"
  local dockerContainerPort="$NDR_SERVICE_CONTAINER_PORT"

  local dockerAppManageOptions="$NDR_DOCKER_APP_MANAGE_OPTIONS_REMOVE_ALL"

  if [ "$gExpressMode" -ne 1 ]; then
    # check if the a previously built Docker image exists
    ndr_verifyDockerImageExists "$dockerImageName"
    return_code=$?
    #2-error, 1-not found, 0-found
    if [ "$return_code" -eq 0 ]; then
      ndr_logInfo "Docker image [$dockerImageName] already present on host. Prompting user for use as source image for install."

      read -p "A local Docker image [$dockerImageName] matching this application is already present on this host. Would you like to use this local image to construct the application container? Choose Yes to use local image or No to use remote image. (Y|n)" -n 1 -r
      echo    # Move to a new line
      if [[ $REPLY =~ ^[Nn]$ ]]; then
        ndr_logInfo "Local Docker image [$dockerImageName] refused, continuing installation with remote repo Docker image."
      else
        ndr_logInfo "Local Docker image [$dockerImageName] accepted, continuing installation with local Docker image."
        gNDR_USE_LOCAL_IMAGE_FOR_APP_INSTALL=true
      fi
    fi
  fi

  if [ "$gNDR_USE_LOCAL_IMAGE_FOR_APP_INSTALL" == true ]; then
    ndr_logInfo "Option to use local Docker image is set, skipping Docker image cleanup."
    dockerAppManageOptions=$(( dockerAppManageOptions & ~NDR_DOCKER_APP_MANAGE_OPTIONS_IMAGE ))
  fi

  ndr_cleanupDockerApplication "$containerHomeDir" "$dockerImageBaseName" "$dockerImageVersionCleanup" "$dockerContainerName" "$dockerAppManageOptions"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Docker application cleanup failed for [$dockerImageName]."
    return 1
  fi
  ndr_logInfo "Docker application cleanup success for image [$dockerImageName]"

  # create container folder in install location.

  mkdir -p "$containerHomeDir"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create application directory [$containerHomeDir]. Please check permissions and try again."
    return 1
  fi
  ndr_logInfo "Created application directory [$containerHomeDir]."

  # if local images is enabled AND local building is enabled, we can use whats there or build if needed.
  if [[ "$gNDR_USE_LOCAL_IMAGE_FOR_APP_INSTALL" == true && "$gNDR_BUILD_LOCAL_IMAGE_FOR_APP_INSTALL" == true ]]; then
    ndr_logInfo "Using local docker image for container construction."

    # check if the newly built Docker image exists
    ndr_verifyDockerImageExists "$dockerImageName"
    return_code=$?
    #2-error, 1-not found, 0-found
    if [ $return_code -ne 0 ]; then
      ndr_logWarn "Local Docker image [$dockerImageName] not found."
      
      if [ "$gExpressMode" -ne 1 ]; then
        # Prompt to build it
        read -p "Local Docker image [$dockerImageName] does not exist. Would you like to attempt to build this now? (Y|n)" -n 1 -r
        echo    # Move to a new line
        if [[ $REPLY =~ ^[Nn]$ ]]; then
          ndr_logInfo "Operation cancelled."
          return 1
        fi
      fi
      ndr_logInfo "Proceeding with image [$dockerImageName] build."
      
      cd "$gSCRIPT_HOME_DIR" || { ndr_logError "Failed to cd into install dir"; return 1; }
      cmd=(env -i PATH="$PATH" bash "${gSCRIPT_HOME_DIR}/ndrDevops.sh" --express buildsvc --imageonly --debug)
      "${cmd[@]}" # >/var/log/ndrDevops.log 2>&1
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "Failed to build image [$dockerImageName]"
        return 1
      fi
      ndr_logInfo "Successfully built image [$dockerImageName]"
    fi
  else
    # pull image from repo
    ndr_DownloadDockerImage "$dockerImageBaseName" "$dockerImageVersion" "$dockerRepoName"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Docker image download failed for [$dockerImageName]."
      return 1
    fi
    ndr_logInfo "Docker image download succeeded for [$dockerImageName]."
  fi

  cd "$containerHomeDir" || { ndr_logError "Failed to cd into application dir [$containerHomeDir]"; return 1; }

  # build container from image
  ndr_ComposeDockerApplicationContainer "$containerHomeDir" "$dockerImageBaseName" "$dockerImageVersion" "$dockerContainerName" "$dockerContainerPort"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to build Docker container for [$dockerContainerName]."
    return 1
  fi
  ndr_logInfo "Docker container [$dockerContainerName] successfully built."

  ndr_RegistryCreate "$gPRODUCT_VERSION" "$gNEXTDR_HOME_DIR" "$gREGISTRY_ENTRY_MODULE_STATUS_SERVICE_NAME" "$NDR_SERVICE_IMAGE_COMMIT_HASH_SHORT" "$NDR_SERVICE_IMAGE_COMMIT_TIMESTAMP_UTC"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create application registry."
    return 1
  fi
  
  ndr_CopyInstallHomeFiles
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to copy install home files"
    return 1
  fi

  ndr_InstallSystemdUnit_Service
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create systemd service unit"
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainInstallUIApplication ()
{
  local logSectionDesc="Installing UI application"
  ndr_logSecStart "$logSectionDesc"

  ndr_InstallHomeCheck
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  local regName="$gREGISTRY_ENTRY_MODULE_STATUS_UI_NAME"
  ndr_isModuleInstalledReg "$regName"
  local thisInstalled=$?
    
  if [ "$gExpressMode" -ne 1 ]; then
    # prereq module check
    ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SERVICE_NAME"
    local svcInstalled=$?
    if [[ "$svcInstalled" -ne 0 ]]; then
      read -p "The prerequisite $gCOMPANY_NAME service module does not appear to be currently installed. This module has an operational dependency on that module and may not be fully operable until that prerequisite is also installed. Would you like continue installing this module? (Y|n)" -n 1 -r
      echo    # Move to a new line
      if [[ $REPLY =~ ^[Nn]$ ]]; then
        ndr_logInfo "Operation cancelled, returning to main menu."
        return 1
      fi
      ndr_logInfo "Proceeding with installation."
    fi

    if [[ "$gUPGRADE_MODE" == false && "$gUPDATE_MODE" == false ]]; then
      # already installed/upgrade/overlay check
      if [[ thisInstalled -eq 0 ]]; then
        read -p "The $gCOMPANY_NAME UI module is already installed. Would you like to upgrade or overlay the existing installation? (Y|n)" -n 1 -r
        echo    # Move to a new line
        if [[ $REPLY =~ ^[Nn]$ ]]; then
          ndr_logInfo "Operation cancelled, returning to main menu."
          return 1
        fi
        ndr_logInfo "Proceeding with installation."
      fi
    fi
  fi

  if [ "$gUPGRADE_MODE" == true ]; then
    # if product is not installed, do not upgrade or install.
    if [[ thisInstalled -ne 0 ]]; then
      ndr_logInfo "The $gCOMPANY_NAME UI module does not appear to be currently installed. Upgrade mode can only be used when the product is already installed. After all currently install modules are upgraded, please use install mode to perform a new installation of this module."
      return 0
    fi

    # version check to see if module is already at current version.
    local moduleVersion=$(ndr_getModuleVersionReg "$gREGISTRY_ENTRY_MODULE_STATUS_UI_NAME")
    if [ "$moduleVersion" == "$gPRODUCT_VERSION" ]; then
      ndr_logInfo "The $gCOMPANY_NAME UI module is already at the current product version [$gPRODUCT_VERSION]. No upgrade required."
      return 0
    fi
  fi

  # query for latest image tag details.
  ndr_QueryLatestMatchingRemoteImageTags "$NDR_UI_IMAGE_NAME"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to query remote repo for latest image tag details."
    return 1
  fi

  local dockerImageBaseName=$NDR_UI_IMAGE_NAME
  local dockerImageVersionCleanup=$gINSTALLED_VERSION
  local dockerImageVersion=$NDR_UI_IMAGE_VERSION_TAG
  local dockerImageName="$dockerImageBaseName:$dockerImageVersion"
  local dockerRepoName="$NDR_DOCKER_UI_PUBLIC_REPO_NAME"
  if [ "$NDR_DOCKER_REPO_TYPE_CURRENT" == "$NDR_DOCKER_REPO_TYPE_PRIVATE" ]; then
    dockerRepoName="$NDR_DOCKER_UI_PRIVATE_REPO_NAME"
  fi
  local containerFolder="$NDR_UI_HOME_LOC"
  local containerHomeDir="${gNEXTDR_HOME_DIR}/${containerFolder}"
  local dockerContainerName="$NDR_UI_CONTAINER_NAME"
  local dockerContainerPort="$NDR_UI_CONTAINER_PORT"

  local dockerAppManageOptions="$NDR_DOCKER_APP_MANAGE_OPTIONS_REMOVE_ALL"

  if [ "$gExpressMode" -ne 1 ]; then
    # check if the a previously built Docker image exists
    ndr_verifyDockerImageExists "$dockerImageName"
    return_code=$?
    #2-error, 1-not found, 0-found
    if [ "$return_code" -eq 0 ]; then
      ndr_logInfo "Docker image [$dockerImageName] already present on host. Prompting user for use as source image for install."

      read -p "A local Docker image [$dockerImageName] matching this application is already present on this host. Would you like to use this local image to construct the application container? Choose Yes to use local image or No to use remote image. (Y|n)" -n 1 -r
      echo    # Move to a new line
      if [[ $REPLY =~ ^[Nn]$ ]]; then
        ndr_logInfo "Local Docker image [$dockerImageName] refused, continuing installation with remote repo Docker image."
      else
        ndr_logInfo "Local Docker image [$dockerImageName] accepted, continuing installation with local Docker image."
        gNDR_USE_LOCAL_IMAGE_FOR_APP_INSTALL=true
      fi
    fi
  fi

  if [ "$gNDR_USE_LOCAL_IMAGE_FOR_APP_INSTALL" == true ]; then
    ndr_logInfo "Option to use local Docker image is set, skipping Docker image cleanup."
    dockerAppManageOptions=$(( dockerAppManageOptions & ~NDR_DOCKER_APP_MANAGE_OPTIONS_IMAGE ))
  fi

  ndr_cleanupDockerApplication "$containerHomeDir" "$dockerImageBaseName" "$dockerImageVersionCleanup" "$dockerContainerName" "$dockerAppManageOptions"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Docker application cleanup failed for [$dockerImageName]."
    return 1
  fi
  ndr_logInfo "Docker application cleanup success for image [$dockerImageName]"

  # create container folder in install location.
  mkdir -p "$containerHomeDir"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create application directory [$containerHomeDir]. Please check permissions and try again."
    return 1
  fi
  ndr_logInfo "Created application directory [$containerHomeDir]."

  # if local images is enabled AND local building is enabled, we can use whats there or build if needed.
  if [[ "$gNDR_USE_LOCAL_IMAGE_FOR_APP_INSTALL" == true && "$gNDR_BUILD_LOCAL_IMAGE_FOR_APP_INSTALL" == true ]]; then
    ndr_logInfo "Using local docker image for container construction."

    # check if the newly built Docker image exists
    ndr_verifyDockerImageExists "$dockerImageName"
    return_code=$?
    #2-error, 1-not found, 0-found
    if [ $return_code -ne 0 ]; then
      ndr_logWarn "Local Docker image [$dockerImageName] not found."
      
      if [ "$gExpressMode" -ne 1 ]; then
        # Prompt to build it
        read -p "Local Docker image [$dockerImageName] does not exist. Would you like to attempt to build this now? (Y|n)" -n 1 -r
        echo    # Move to a new line
        if [[ $REPLY =~ ^[Nn]$ ]]; then
          ndr_logInfo "Operation cancelled."
          return 1
        fi
      fi
      ndr_logInfo "Proceeding with image [$dockerImageName] build."
      
      cd "$gSCRIPT_HOME_DIR" || { ndr_logError "Failed to cd into install dir"; return 1; }
      cmd=(env -i PATH="$PATH" bash "${gSCRIPT_HOME_DIR}/ndrDevops.sh" --express buildui --imageonly --debug)
      "${cmd[@]}" # >/var/log/ndrDevops.log 2>&1
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "Failed to build image [$dockerImageName]"
        return 1
      fi
      ndr_logInfo "Successfully built image [$dockerImageName]"
    fi
  else
    # pull image from repo
    ndr_DownloadDockerImage "$dockerImageBaseName" "$dockerImageVersion" "$dockerRepoName"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Docker image download failed for [$dockerImageName]."
      return 1
    fi
    ndr_logInfo "Docker image download succeeded for [$dockerImageName]."
  fi

  cd "$containerHomeDir" || { ndr_logError "Failed to cd into application dir [$containerHomeDir]"; return 1; }

  # build container from image
  ndr_ComposeDockerApplicationContainer "$containerHomeDir" "$dockerImageBaseName" "$dockerImageVersion" "$dockerContainerName" "$dockerContainerPort"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to build Docker container for [$dockerContainerName]."
    return 1
  fi
  ndr_logInfo "Docker container [$dockerContainerName] successfully built."
  
  ndr_RegistryCreate "$gPRODUCT_VERSION" "$gNEXTDR_HOME_DIR" "$gREGISTRY_ENTRY_MODULE_STATUS_UI_NAME" "$NDR_UI_IMAGE_COMMIT_HASH_SHORT" "$NDR_UI_IMAGE_COMMIT_TIMESTAMP_UTC"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create application registry."
    return 1
  fi
  
  ndr_CopyInstallHomeFiles
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to copy install home files"
    return 1
  fi

  ndr_InstallSystemdUnit_UI
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create systemd service unit"
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainInstallAllApplications ()
{
  local logSectionDesc="Installing all applications"
  ndr_logSecStart "$logSectionDesc"

  mainInstallSupabaseApplication
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi
  
  mainInstallServiceApplication
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi
  
  mainInstallUIApplication
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  if [ "$gUPGRADE_MODE" == true ]; then
    ndr_logInfo "All currently installed modules have been upgraded."
    ndr_UpdateProductVersion
    ndr_setRegistryUpdateDate
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainCheckandInstallUpdates ()
{
  local logSectionDesc="Checking and installing product updates"
  ndr_logSecStart "$logSectionDesc"

  if [ "$gNDR_SKIP_REMOTE_IMAGE_REPO_UPDATE_CHECK" == true ]; then
    ndr_logWarn "Warning, remote image update check is disabled via command line option, update is not possible in this mode."
    ndr_logInfo "Please exit the installer and re-launch without the update check disabled."
    return 1
  fi

  # query current version tags
  local imageTagSvc=""
  local containerName="$NDR_SERVICE_CONTAINER_NAME"
  local moduleName="$gREGISTRY_ENTRY_MODULE_STATUS_SERVICE_NAME"
  #if ndr_verifyDockerContainerExists "$containerName" >/dev/null; then
  if ndr_isModuleInstalledReg "$moduleName" >/dev/null; then
    imageTagSvc=$(ndr_QueryContainerImageVersionTag "$containerName")
    if [[ -z "$imageTagSvc" ]]; then
      ndr_logError "Failed to retrieve image version tag for container [$containerName]"
      return 1
    fi
  fi

  local imageTagUI=""
  containerName="$NDR_UI_CONTAINER_NAME"
  moduleName="$gREGISTRY_ENTRY_MODULE_STATUS_UI_NAME"
  #if ndr_verifyDockerContainerExists "$containerName" >/dev/null; then
  if ndr_isModuleInstalledReg "$moduleName" >/dev/null; then
    imageTagUI=$(ndr_QueryContainerImageVersionTag "$containerName")
    if [[ -z "$imageTagUI" ]]; then
      ndr_logError "Failed to retrieve image version tag for container [$containerName]"
      return 1
    fi
  fi

  # query for latest remote repo image tag details.
  ndr_QueryLatestMatchingRemoteImageTags
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to query remote repo for latest image tag details."
    return 1
  fi

  local svcUpdateAvailable=false
  local uiUpdateAvailable=false
  
  local updateReport="  ${NDR_SERVICE_APPLICATION_NAME}:"
  if [[ -n "$imageTagSvc" && "$imageTagSvc" != "$NDR_SERVICE_IMAGE_VERSION_TAG" ]]; then
    updateReport="${updateReport} Currently installed version [$imageTagSvc], Update version available [$NDR_SERVICE_IMAGE_VERSION_TAG]"
    svcUpdateAvailable=true
  elif [[ -z "$imageTagSvc" ]]; then
    updateReport="${updateReport} Not currently installed."
  else
    updateReport="${updateReport} Currently installed version [$imageTagSvc] is up to date."
  fi

  updateReport="${updateReport}\n  ${NDR_UI_APPLICATION_NAME}:"
  if [[ -n "$imageTagUI" && "$imageTagUI" != "$NDR_UI_IMAGE_VERSION_TAG" ]]; then
    updateReport="${updateReport} Currently installed version [$imageTagUI], Update version available [$NDR_UI_IMAGE_VERSION_TAG]"
    uiUpdateAvailable=true
  elif [[ -z "$imageTagUI" ]]; then
    updateReport="${updateReport} Not currently installed."
  else
    updateReport="${updateReport} Currently installed version [$imageTagUI] is up to date."
  fi

  local reportHeader="======[ Application Update Report ]=============================="
  local reportFooter="================================================================="

  # check for no updates
  if [[ "$svcUpdateAvailable" == false && "$uiUpdateAvailable" == false ]]; then
    ndr_logInfo "No updates found for the installed modules."
    ndr_logInfo "\n${reportHeader}\n${updateReport}\n${reportFooter}"
    echo -n "Press any key to return without updating..."
    # Turn off echo, read one character silently, then restore settings
    read -n 1 -s
    echo    # move to a new line after key press

    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # some updates are available. Display, prompt and execute.
  ndr_logInfo "Some updates found for the installed modules."
  ndr_logInfo "\n${reportHeader}\n${updateReport}\n${reportFooter}"
  read -p "Do you wish to proceed with updating these modules? (Y|n)" -n 1 -r
  echo    # Move to a new line
  if [[ $REPLY =~ ^[Nn]$ ]]; then
    ndr_logInfo "Update cancelled."
    return 0
  fi
  ndr_logInfo "Proceeding with module update."
  gUPDATE_MODE=true

  if [ "$uiUpdateAvailable" == true ]; then
    mainInstallUIApplication
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to update application."
      return 1
    fi
  fi

  if [ "$svcUpdateAvailable" == true ]; then
    mainInstallServiceApplication
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to update application."
      return 1
    fi
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainRemoveSupabaseApplication ()
{
  local logSectionDesc="Removing Supabase Application"
  ndr_logSecStart "$logSectionDesc"

  local regName="$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
  ndr_isModuleInstalledReg "$regName"
  local dbInstalled=$?
  if [[ dbInstalled -ne 0 ]]; then
    if [ "$gExpressMode" -ne 1 ]; then
      read -p "This product does not currently appear to be installed. Would you like to force remove any partial or existing installation? (Y|n)" -n 1 -r
      echo    # Move to a new line
      if [[ $REPLY =~ ^[Nn]$ ]]; then
        ndr_logInfo "Operation cancelled, returning to main menu."
        return 1
      fi
      ndr_logInfo "Proceeding with forced removal."
    fi
  fi

  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SERVICE_NAME"
  local svcInstalled=$?
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_UI_NAME"
  local uiInstalled=$?
  if [[ "$svcInstalled" -eq 0 || "$uiInstalled" -eq 0 ]]; then
    read -p "Some dependent $gCOMPANY_NAME product modules appear to be currently installed. Removing this module may adversely affect the operation of these dependencies. Would you like continue removing this module? (Y|n)" -n 1 -r
    echo    # Move to a new line
    if [[ $REPLY =~ ^[Nn]$ ]]; then
      ndr_logInfo "Operation cancelled, returning to main menu."
      return 1
    else
      ndr_logInfo "Proceeding with removal."
    fi
  fi

  ndr_SupabaseContainerCleanup
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  ndr_RegistryAddKey "$regName" "$gREGISTRY_ENTRY_MODULE_STATUS_NOT_INSTALLED"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to update registry entry [$regName -> $gREGISTRY_ENTRY_MODULE_STATUS_NOT_INSTALLED]."
    #return 1
  fi

  ndr_UninstallSystemdUnit_Supabase
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to remove systemd service unit"
    return 1
  fi

  ndr_RegistryRemoveServiceEntries
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to remove Supabase registry services."
    #return 1
  fi

  ndr_RegistryUninstall
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  ndr_CleanupApplicationFolders "$gSUPABASE_NEXTDR_SUB"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}


function mainRemoveServiceApplication ()
{
  local logSectionDesc="Removing Service Application"
  ndr_logSecStart "$logSectionDesc"

  local regName="$gREGISTRY_ENTRY_MODULE_STATUS_SERVICE_NAME"
  ndr_isModuleInstalledReg "$regName"
  return_code=$?
  if [[ return_code -ne 0 ]]; then
    if [ "$gExpressMode" -ne 1 ]; then
      read -p "This product does not currently appear to be installed. Would you like to force remove any partial or existing installation? (Y|n)" -n 1 -r
      echo    # Move to a new line
      if [[ $REPLY =~ ^[Nn]$ ]]; then
        ndr_logInfo "Operation cancelled, returning to main menu."
        return 1
      fi
      ndr_logInfo "Proceeding with forced removal."
    fi
  fi

  ndr_mainCleanupServiceApplication
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  ndr_UninstallSystemdUnit_Service
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to remove systemd service unit"
    return 1
  fi
  
  ndr_RegistryAddKey "$regName" "$gREGISTRY_ENTRY_MODULE_STATUS_NOT_INSTALLED"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to update registry entry [$regName -> $gREGISTRY_ENTRY_MODULE_STATUS_NOT_INSTALLED]."
    #return 1
  fi
  ndr_RegistryDeleteKey "$gREGISTRY_ENTRY_MODULE_STATUS_SERVICE_COMMIT_HASH"
  ndr_RegistryDeleteKey "$gREGISTRY_ENTRY_MODULE_STATUS_SERVICE_COMMIT_TIMESTAMP"

  ndr_RegistryUninstall
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  ndr_CleanupApplicationFolders "$NDR_SERVICE_HOME_LOC"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainRemoveUIApplication ()
{
  local logSectionDesc="Removing UI Application"
  ndr_logSecStart "$logSectionDesc"

  local regName="$gREGISTRY_ENTRY_MODULE_STATUS_UI_NAME"
  ndr_isModuleInstalledReg "$regName"
  return_code=$?
  if [[ return_code -ne 0 ]]; then
    if [ "$gExpressMode" -ne 1 ]; then
      read -p "This product does not currently appear to be installed. Would you like to force remove any partial or existing installation? (Y|n)" -n 1 -r
      echo    # Move to a new line
      if [[ $REPLY =~ ^[Nn]$ ]]; then
        ndr_logInfo "Operation cancelled, returning to main menu."
        return 1
      fi
      ndr_logInfo "Proceeding with forced removal."
    fi
  fi

  ndr_mainCleanupUIApplication
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  ndr_UninstallSystemdUnit_UI
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to remove systemd service unit"
    return 1
  fi

  ndr_RegistryAddKey "$regName" "$gREGISTRY_ENTRY_MODULE_STATUS_NOT_INSTALLED"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to update registry entry [$regName -> $gREGISTRY_ENTRY_MODULE_STATUS_NOT_INSTALLED]."
    #return 1
  fi
  ndr_RegistryDeleteKey "$gREGISTRY_ENTRY_MODULE_STATUS_UI_COMMIT_HASH"
  ndr_RegistryDeleteKey "$gREGISTRY_ENTRY_MODULE_STATUS_UI_COMMIT_TIMESTAMP"

  ndr_RegistryUninstall
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  ndr_CleanupApplicationFolders "$NDR_UI_HOME_LOC"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainRemoveAllApplications ()
{
  local logSectionDesc="Removing all applications"
  ndr_logSecStart "$logSectionDesc"

  mainRemoveUIApplication
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  mainRemoveServiceApplication
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi
  
  mainRemoveSupabaseApplication
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainBackupSupabaseDB ()
{
  local logSectionDesc="Backup Supabase Database"
  ndr_logSecStart "$logSectionDesc"

  ndr_BackupPostgresDB
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainRestoreSupabaseDB ()
{
  local logSectionDesc="Restore Supabase Database"
  ndr_logSecStart "$logSectionDesc"

  ndr_RestorePostgresDB
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainUpgradeSupabaseDB ()
{
  local logSectionDesc="Upgrade Supabase Database"
  ndr_logSecStart "$logSectionDesc"

  ndr_RestorePostgresDB "upgrade"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainCreateNDRConsoleAdminAccount ()
{
  local logSectionDesc="Creating $gPRODUCT_NAME Console Admin Account"
  ndr_logSecStart "$logSectionDesc"

  ndr_CreateNDRConsoleAdminAccount
  return_code=$?
  if [ $return_code -ne 0 ]; then
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainSeedLocalDockerImages ()
{
  local logSectionDesc="Seeding All $gPRODUCT_NAME Local Docker Images"
  ndr_logSecStart "$logSectionDesc"

  local tmpDir="$PWD/seed_tmp"
  if [ ! -d "$tmpDir" ]; then
    mkdir "$tmpDir"
  fi

  cd "$tmpDir" || { ndr_logError "Failed to cd into temp dir [$tmpDir]"; return 1; }

  local compose_file="https://raw.githubusercontent.com/supabase/supabase/refs/heads/master/docker/docker-compose.yml"
  curl -O "$compose_file"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to download Supabase compose file [$compose_file]"
    return 1
  fi

  if [ ! -f "docker-compose.yml" ]; then
    ndr_logError "Local downloaded Supabase compose file not found."
    return 1
  fi
  ndr_logInfo "Downloaded Supabase compose file [$compose_file]"

  local env_file="https://raw.githubusercontent.com/supabase/supabase/refs/heads/master/docker/.env.example"
  curl -o ".env" "$env_file"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to download Supabase env file [$env_file]"
    return 1
  fi

  if [ ! -f ".env" ]; then
    ndr_logError "Local downloaded Supabase env file not found."
    return 1
  fi
  ndr_logInfo "Downloaded Supabase env file."

  docker compose pull --quiet
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Docker compose pull failed"
    return 1
  fi
  ndr_logInfo "Pulled Supabase Docker Images"

  # cleanup
  rm -f "docker-compose.yml"
  rm -f ".env"

  local dockerImageBaseName=$NDR_SERVICE_IMAGE_NAME
  local dockerImageVersion=$NDR_SERVICE_IMAGE_VERSION
  local dockerImageName="$dockerImageBaseName:$dockerImageVersion"
  local dockerRepoName="$NDR_DOCKER_SERVICE_PUBLIC_REPO_NAME"
  
  ndr_DownloadDockerImage "$dockerImageBaseName" "$dockerImageVersion" "$dockerRepoName"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Docker image download failed for [$dockerImageName]."
    return 1
  fi
  ndr_logInfo "Docker image download succeeded for [$dockerImageName]."

  dockerImageBaseName=$NDR_UI_IMAGE_NAME
  dockerImageVersion=$NDR_UI_IMAGE_VERSION
  dockerImageName="$dockerImageBaseName:$dockerImageVersion"
  dockerRepoName="$NDR_DOCKER_UI_PUBLIC_REPO_NAME"
  
  ndr_DownloadDockerImage "$dockerImageBaseName" "$dockerImageVersion" "$dockerRepoName"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Docker image download failed for [$dockerImageName]."
    return 1
  fi
  ndr_logInfo "Docker image download succeeded for [$dockerImageName]."

  cd ".."
  rm -rf "$tmpDir"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}


# ====================================================
# command line parsing
# ====================================================
function mainParseCommandLineArgs ()
{
  local logSectionDesc="Parsing command line arguments"
  ndr_logSecStartDebug "$logSectionDesc"

  # Default values
  
  ndr_parseCommandLineArgs "$@"

  # Parse arguments
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --dest|-d)
        if [[ -n "$2" && "$2" != --* ]]; then
          gNEXTDR_HOME_DIR="$2"
          ndr_logInfo "Home directory set to [$gNEXTDR_HOME_DIR]"
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --ip|--hostaddress)
        if [[ -n "$2" && "$2" != --* ]]; then
          gNDR_SERVER_HOST_ADDRESS="$2"
          ndr_logInfo "Host address set to [$gNDR_SERVER_HOST_ADDRESS]"
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --noupdatecheck|--noupdate)
        gNDR_SKIP_REMOTE_IMAGE_REPO_UPDATE_CHECK=true
        ndr_logInfo "Skip remote image repo update check option enabled."
        shift
        ;;
      --uselocalimage|--localimage)
        gNDR_USE_LOCAL_IMAGE_FOR_APP_INSTALL=true
        ndr_logInfo "Use local Docker images for application containers option enabled."
        shift
        ;;
      --nobuildlocalimage|--nobuild)
        gNDR_BUILD_LOCAL_IMAGE_FOR_APP_INSTALL=false
        ndr_logInfo "Option to NOT BUILD local Docker images when installing application modules is set."
        shift
        ;;
      --help|-h)
        ndr_logWarn "Usage: $0 --express <$EXPRESS_MENU_OPTIONS> [--debug]."
        return 1
        ;;
      *)
        #ndr_logError "Unknown option: $1"
        shift
        ;;
    esac
  done

  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

# ====================================================
# Express install mode
# ====================================================
function mainExpressInstallMode ()
{
  local logSectionDesc="Executing express install mode"
  ndr_logSecStart "$logSectionDesc"

  # Check if express mode is enabled and an option is provided
  if [ "$gExpressMode" != 1 ]; then
    ndr_logError "Express mode is not enabled. Use --express to enable."
    return 1
  fi
  if [ -z "$gExpressOption" ]; then
    ndr_logError "No express option provided. Use --express <option>."
    return 1
  fi

  if [ "$gUPGRADE_MODE" == true ]; then
    ndr_logInfo "Upgrade mode is enabled, all installed applications will be upgraded at once."
    gExpressOption="installall"
  fi

  case "$gExpressOption" in
    installprerequisites|installprereq)
      ndr_checkAndInstallPrerequisites
      ;;
    installsupabase|installdb)
      mainInstallSupabaseApplication
      ;;
    installservice|installsvc)
      mainInstallServiceApplication
      ;;
    installui)
      mainInstallUIApplication
      ;;
    installall|upgradeall|upgrade)
      mainInstallAllApplications
      ;;
    removesupabaseapp|removesupabase|removedb|uninstalldb)
      mainRemoveSupabaseApplication
      ;;
    removeserviceapp|removeservice|removesvc|uninstallsvc)
      mainRemoveServiceApplication
      ;;
    removeuiapp|removeui|uninstallui)
      mainRemoveUIApplication
      ;;
    removeall|uninstallall)
      mainRemoveAllApplications
      ;;
    backupdb)
      mainBackupSupabaseDB
      ;;
    restoredb)
      mainRestoreSupabaseDB
      ;;
    upgradedb)
      mainUpgradeSupabaseDB
      ;;
    update|checkupdates)
      mainCheckandInstallUpdates
      ;;
    createadminaccount|createaccount)
      mainCreateNDRConsoleAdminAccount
      ;;
    seedlocalimages|seedimages)
      mainSeedLocalDockerImages
      ;;
    *)
      # print usage and exit
      ndr_logWarn "Invalid option. Please use one of the following options: $EXPRESS_MENU_OPTIONS."
      return 1
      ;;
  esac
  
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to execute selection."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# ====================================================
# Interactive menu mode
# ====================================================
function mainInteractiveMenuMode ()
{
  local logSectionDesc="Executing interactive menu mode"
  ndr_logSecStartDebug "$logSectionDesc"
  
  MENU_ITEM_1="Check and install software package prerequisites"
  MENU_ITEM_2="Install the $gCOMPANY_NAME Supabase database application in a local Docker container"
  MENU_ITEM_3="Install the $gCOMPANY_NAME Service application in a local Docker container"
  MENU_ITEM_4="Install the $gCOMPANY_NAME UI application in a local Docker container"
  MENU_ITEM_5="Install all modules"
  MENU_ITEM_6="Check for updates for all currently installed applications"
  MENU_ITEM_7="Remove existing $gCOMPANY_NAME Supabase Docker application"
  MENU_ITEM_8="Remove existing $gCOMPANY_NAME Service Docker application"
  MENU_ITEM_9="Remove existing $gCOMPANY_NAME UI Docker application"
  MENU_ITEM_10="Remove all modules"
  
  local refreshModuleStatus=true
  
  while true; do
    if [[ "$refreshModuleStatus" == true ]]; then
      ndr_UpgradeModeCheck
      ndr_UpdateModuleInstallStatus
    fi
  
    echo "===================================================================="
    echo "$gCOMPANY_NAME $gPRODUCT_VERSION Software Installation and Package Management Menu"
    ndr_DisplayModuleInstallStatus
    echo "===================================================================="

    local choice=""
    if [ "$gUPGRADE_MODE" == true ]; then
      echo "  ------ VERSION [$gPRODUCT_VERSION] UPGRADE MODE ENABLED ------"
      echo "  Install has detected that a previous version of one or more applications is currently installed."
      echo "  Upgrade of all of currently installed applications to version [$gPRODUCT_VERSION] will be performed."
      read -p "  Are you sure you want to proceed? (Y|n) " -n 1 -r
        echo    # Move to a new line
        echo "===================================================================="
        # default YES logic
        if [[ $REPLY =~ ^[Nn]$ ]]; then
          ndr_logInfo "Operation cancelled, aborting."
          break
        fi
        choice="5"
        echo "Proceeding with upgrade of all currently installed applications."
    else
      echo "Please select an option:"
      echo ""
      echo "1. $MENU_ITEM_1"
      echo "2. $MENU_ITEM_2"
      echo "3. $MENU_ITEM_3"
      echo "4. $MENU_ITEM_4"
      echo "5. $MENU_ITEM_5"
      echo "6. $MENU_ITEM_6"
      echo "7. $MENU_ITEM_7"
      echo "8. $MENU_ITEM_8"
      echo "9. $MENU_ITEM_9"
      echo "10. $MENU_ITEM_10"
      echo "q. Exit"
      echo ""
      read -p "Enter your choice [1-n]: " choice
    fi

    refreshModuleStatus=false

    case $choice in
      1)
        echo "$MENU_ITEM_1. This will check for NPM/NPX, GIT, Docker, etc and prompt for interactive install."
        read -p "Are you sure you want to proceed? (Y|n) " -n 1 -r
        echo    # Move to a new line
        # default YES logic
        if [[ $REPLY =~ ^[Nn]$ ]]; then
          ndr_logInfo "Operation cancelled, returning to main menu."
          continue
        else
          ndr_checkAndInstallPrerequisites
        fi
        ;;
      2)
        echo "$MENU_ITEM_2. Warning, this will overwrite any existing instance and install a clean copy. This action cannot be undone!"
        read -p "Are you sure you want to proceed? (Y|n) " -n 1 -r
        echo    # Move to a new line
        if [[ $REPLY =~ ^[Nn]$ ]]; then
          ndr_logInfo "Operation cancelled, returning to main menu."
          continue
        else
          mainInstallSupabaseApplication
        fi
        ;;
      3)
        echo "$MENU_ITEM_3. Warning, this will overwrite any existing instances and install a clean copy. This action cannot be undone!"
        read -p "Are you sure you want to proceed? (Y|n) " -n 1 -r
        echo    # Move to a new line
        if [[ $REPLY =~ ^[Nn]$ ]]; then
          ndr_logInfo "Operation cancelled, returning to main menu."
          continue
        else
          mainInstallServiceApplication
        fi
        ;;
      4)
        echo "$MENU_ITEM_4. Warning, this will overwrite any existing instances and install a clean copy. This action cannot be undone!"
        read -p "Are you sure you want to proceed? (Y|n) " -n 1 -r
        echo    # Move to a new line
        if [[ $REPLY =~ ^[Nn]$ ]]; then
          ndr_logInfo "Operation cancelled, returning to main menu."
          continue
        else
          mainInstallUIApplication
        fi
        ;;
      5)
        echo "$MENU_ITEM_5. Warning, this will overwrite any existing instances and install a clean copy. This action cannot be undone!"
        read -p "Are you sure you want to proceed? (Y|n) " -n 1 -r
        echo    # Move to a new line
        if [[ $REPLY =~ ^[Nn]$ ]]; then
          ndr_logInfo "Operation cancelled, returning to main menu."
          continue
        else
          mainInstallAllApplications
        fi
        ;;
      6)
        echo "$MENU_ITEM_6. Warning, this will overwrite any existing instances and install an updated copy. This action cannot be undone!"
        read -p "Are you sure you want to proceed? (Y|n) " -n 1 -r
        echo    # Move to a new line
        if [[ $REPLY =~ ^[Nn]$ ]]; then
          ndr_logInfo "Operation cancelled, returning to main menu."
          continue
        else
          mainCheckandInstallUpdates
        fi
        ;;
      7)
        echo "$MENU_ITEM_7. Warning, this will completely remove any existing instance. This action cannot be undone!"
        read -p "Are you sure you want to proceed? (y|N) " -n 1 -r
        echo    # Move to a new line
        # default NO logic
        if [[ $REPLY =~ ^[Yy]$ ]]; then
          mainRemoveSupabaseApplication
        else
          ndr_logInfo "Operation cancelled, returning to main menu."
          continue
        fi
        ;;
      8)
        echo "$MENU_ITEM_8. Warning, this will completely remove any existing instance. This action cannot be undone!"
        read -p "Are you sure you want to proceed? (y|N) " -n 1 -r
        echo    # Move to a new line
        # default NO logic
        if [[ $REPLY =~ ^[Yy]$ ]]; then
          mainRemoveServiceApplication
        else
          ndr_logInfo "Operation cancelled, returning to main menu."
          continue
        fi
        ;;
      9)
        echo "$MENU_ITEM_9. Warning, this will completely remove any existing instance. This action cannot be undone!"
        read -p "Are you sure you want to proceed? (y|N) " -n 1 -r
        echo    # Move to a new line
        # default NO logic
        if [[ $REPLY =~ ^[Yy]$ ]]; then
          mainRemoveUIApplication
        else
          ndr_logInfo "Operation cancelled, returning to main menu."
          continue
        fi
        ;;
      10)
        echo "$MENU_ITEM_10. Warning, this will completely remove any existing instance. This action cannot be undone!"
        read -p "Are you sure you want to proceed? (y|N) " -n 1 -r
        echo    # Move to a new line
        # default NO logic
        if [[ $REPLY =~ ^[Yy]$ ]]; then
          mainRemoveAllApplications
        else
          ndr_logInfo "Operation cancelled, returning to main menu."
          continue
        fi
        ;;
      Q|q)
        echo "Exiting..."
        break
        ;;
      t)
        # unit test - remove for production
        ndr_SupabaseQueryLatestCommit
        break
        ;;
      *)
        echo "Invalid option. Please try again."
        continue
        ;;
    esac

    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to execute selection."
      return 1
    fi

    echo ""

    refreshModuleStatus=true
  done

  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

function main ()
{
  echo "🕓 Started at $(date)"
  
  gNDR_INSTALL_MODE=true
  ndr_SetLogPolicy $NDR_LOG_POLICY_MODE_NORMAL
  
  mainParseCommandLineArgs "$@"
  return_code=$?
  if [ $return_code != 0 ]; then
    return 1
  fi

  ndr_osTypeCheck

  ndr_UpgradeModeCheck
  return_code=$?
  if [ $return_code != 0 ]; then
    return 1
  fi

  local operation_return_code=0

  if [[ "$gExpressMode" -eq 1  && -n "$gExpressOption" ]]; then
    ndr_logInfo "Express install option selected. Skipping all prompts and running with supplied values."
    mainExpressInstallMode
    operation_return_code=$?
    echo "🕓 Finished at $(date)"
    return $operation_return_code
  fi

  mainInteractiveMenuMode
  operation_return_code=$?

  echo "🕓 Finished at $(date)"

  return $operation_return_code
}

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  main "$@"
  return_code=$?
  exit $return_code
fi
