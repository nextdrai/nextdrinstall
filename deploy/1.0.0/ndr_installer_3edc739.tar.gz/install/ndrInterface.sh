#!/bin/bash
# ndrInterface.sh - A Bash module providing UI/menu definitions and functions

#source "$(dirname "${BASH_SOURCE[0]}")/ndrCommon.sh"
source "$(dirname "${BASH_SOURCE[0]}")/ndrSupabase.sh"
source "$(dirname "${BASH_SOURCE[0]}")/ndrRegistry.sh"

# docker container and image module menu status definitions
export gCLI_MENU_IMAGE_STATUS_NOT_PRESENT="No image"
export gCLI_MENU_IMAGE_STATUS_PRESENT="Present"

export gCLI_MENU_CONTAINER_STATUS_NOT_PRESENT="No container"
export gCLI_MENU_CONTAINER_STATUS_PRESENT="Present"
export gCLI_MENU_CONTAINER_STATUS_RUNNING="Running"
export gCLI_MENU_CONTAINER_STATUS_STOPPED="Stopped"

export gCLI_GIT_REPO_STATUS_NOT_FOUND="Repo not available"

# git repo revision details
export gCLI_GIT_REPO_STATUS="$gCLI_GIT_REPO_STATUS_NOT_FOUND"
export gCLI_GIT_REPO_COMMIT_HASH_LONG=""
export gCLI_GIT_REPO_COMMIT_HASH_SHORT=""
export gCLI_GIT_REPO_COMMIT_TIMESTAMP=""

# docker module status
export gCLI_MODULE_DOCKER_IMAGE_STATUS_DB="$gCLI_MENU_IMAGE_STATUS_NOT_PRESENT"
export gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC="$gCLI_MENU_IMAGE_STATUS_NOT_PRESENT"
export gCLI_MODULE_DOCKER_IMAGE_STATUS_UI="$gCLI_MENU_IMAGE_STATUS_NOT_PRESENT"

export gCLI_MODULE_DOCKER_CONTAINER_STATUS_DB="$gCLI_MENU_CONTAINER_STATUS_NOT_PRESENT"
export gCLI_MODULE_DOCKER_CONTAINER_STATUS_SVC="$gCLI_MENU_CONTAINER_STATUS_NOT_PRESENT"
export gCLI_MODULE_DOCKER_CONTAINER_STATUS_UI="$gCLI_MENU_CONTAINER_STATUS_NOT_PRESENT"

# installed module menu status defintions
export gCLI_MENU_INSTALL_STATUS_INSTALLED="Installed"
export gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED="Not Installed"

# installed module status
export gCLI_MODULE_INSTALL_STATUS_DB="$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED"
export gCLI_MODULE_INSTALL_STATUS_SVC="$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED"
export gCLI_MODULE_INSTALL_STATUS_UI="$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED"

# misc status items
export gCLI_NDR_INSTALLED_VERSION="$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED"
export gCLI_NDR_HOST_ADDRESS="$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED"

# updates the status of all docker modules
function ndr_UpdateModuleDockerStatus ()
{
  local logSectionDesc="Updating Module Docker Status"
  ndr_logSecStartDebug "$logSectionDesc"

  local imageName=""
  
  # Git Repo ------------------------------
  ndr_PopulateLocalGitRepoDetails

  # Supabase ------------------------------
  #gCLI_MODULE_DOCKER_IMAGE_STATUS_DB=$(if ndr_verifyDockerImageExists "$NDR_SUPABASE_APP_SERVICE_NAME_DB_IMAGE_NAME" >/dev/null; then echo "$gCLI_MENU_IMAGE_STATUS_PRESENT"; fi)
  gCLI_MODULE_DOCKER_IMAGE_STATUS_DB="$gCLI_MENU_IMAGE_STATUS_NOT_PRESENT"
  if ndr_verifyDockerImageExists "$NDR_SUPABASE_APP_SERVICE_NAME_DB_IMAGE_NAME" >/dev/null; then gCLI_MODULE_DOCKER_IMAGE_STATUS_DB="$NDR_SUPABASE_APP_SERVICE_NAME_DB_IMAGE_NAME | $gCLI_MENU_IMAGE_STATUS_PRESENT"; fi

  #gCLI_MODULE_DOCKER_CONTAINER_STATUS_DB=$(if ndr_verifyDockerContainerExists "$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME" >/dev/null; then echo "$gCLI_MENU_CONTAINER_STATUS_PRESENT"; fi)
  if ndr_verifyDockerContainerExists "$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME" >/dev/null; then
    # build container status
    gCLI_MODULE_DOCKER_CONTAINER_STATUS_DB="$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME"
    #local supabaseContainerRunning=$(if ndr_verifyDockerContainerRunning "$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME" >/dev/null; then echo "$gCLI_MENU_CONTAINER_STATUS_RUNNING"; fi)
    if ndr_verifyDockerContainerRunning "$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME" >/dev/null; then gCLI_MODULE_DOCKER_CONTAINER_STATUS_DB="$gCLI_MODULE_DOCKER_CONTAINER_STATUS_DB | $gCLI_MENU_CONTAINER_STATUS_RUNNING"; else gCLI_MODULE_DOCKER_CONTAINER_STATUS_DB="$gCLI_MODULE_DOCKER_CONTAINER_STATUS_DB | $gCLI_MENU_CONTAINER_STATUS_STOPPED"; fi
  fi
  
  # Service -------------------------------
  # query image details first. init image name with local repo tag.
  gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC="$gCLI_MENU_IMAGE_STATUS_NOT_PRESENT"
  if imageName=$(ndr_verifyDockerImageExists "$NDR_SERVICE_IMAGE_NAME" 2>/dev/null); then gCLI_MODULE_DOCKER_IMAGE_STATUS_UI="$imageName"; fi

  # query container details second, if container exists, override image name with actual image name used by container.
  gCLI_MODULE_DOCKER_CONTAINER_STATUS_SVC="$gCLI_MENU_CONTAINER_STATUS_NOT_PRESENT"
  if ndr_verifyDockerContainerExists "$NDR_SERVICE_CONTAINER_NAME" >/dev/null; then
    # build container status
    gCLI_MODULE_DOCKER_CONTAINER_STATUS_SVC="$NDR_SERVICE_CONTAINER_NAME | $gCLI_MENU_CONTAINER_STATUS_PRESENT"
    if ndr_verifyDockerContainerRunning "$NDR_SERVICE_CONTAINER_NAME" "$NDR_SERVICE_CONTAINER_PORT" >/dev/null; then 
      gCLI_MODULE_DOCKER_CONTAINER_STATUS_SVC="$gCLI_MODULE_DOCKER_CONTAINER_STATUS_SVC | $gCLI_MENU_CONTAINER_STATUS_RUNNING"; 
    else 
      gCLI_MODULE_DOCKER_CONTAINER_STATUS_SVC="$gCLI_MODULE_DOCKER_CONTAINER_STATUS_SVC | $gCLI_MENU_CONTAINER_STATUS_STOPPED"; 
    fi
    
    # rebuild image status
    gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC=$(ndr_QueryContainerImageName "$NDR_SERVICE_CONTAINER_NAME")
    local commitHash=$(ndr_QueryContainerImageCommitHash "$NDR_SERVICE_CONTAINER_NAME")
    if [[ -n "$commitHash" ]]; then gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC="$gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC | Commit: $commitHash"; fi
    local timestampUTC=$(ndr_QueryContainerImageTimestampHumanReadable "$NDR_SERVICE_CONTAINER_NAME")
    if [[ -n "$timestampUTC" ]]; then gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC="$gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC | Built: $timestampUTC"; fi
  fi
  
  # UI -----------------------------------
  # query image details first. init image name with local repo tag.
  gCLI_MODULE_DOCKER_IMAGE_STATUS_UI="$gCLI_MENU_IMAGE_STATUS_NOT_PRESENT"
  if imageName=$(ndr_verifyDockerImageExists "$NDR_UI_IMAGE_NAME" 2>/dev/null); then gCLI_MODULE_DOCKER_IMAGE_STATUS_UI="$imageName"; fi
  
  # query container details second, if container exists, override image name with actual image name used by container.
  gCLI_MODULE_DOCKER_CONTAINER_STATUS_UI="$gCLI_MENU_CONTAINER_STATUS_NOT_PRESENT"
  if ndr_verifyDockerContainerExists "$NDR_UI_CONTAINER_NAME" >/dev/null; then
    # build container status
    gCLI_MODULE_DOCKER_CONTAINER_STATUS_UI="$NDR_UI_CONTAINER_NAME | $gCLI_MENU_CONTAINER_STATUS_PRESENT"
    if ndr_verifyDockerContainerRunning "$NDR_UI_CONTAINER_NAME" "$NDR_UI_CONTAINER_PORT" >/dev/null; then 
      gCLI_MODULE_DOCKER_CONTAINER_STATUS_UI="$gCLI_MODULE_DOCKER_CONTAINER_STATUS_UI | $gCLI_MENU_CONTAINER_STATUS_RUNNING"; 
    else
      gCLI_MODULE_DOCKER_CONTAINER_STATUS_UI="$gCLI_MODULE_DOCKER_CONTAINER_STATUS_UI | $gCLI_MENU_CONTAINER_STATUS_STOPPED"; 
    fi
    
    # rebuild image status
    gCLI_MODULE_DOCKER_IMAGE_STATUS_UI=$(ndr_QueryContainerImageName "$NDR_UI_CONTAINER_NAME")
    local commitHash=$(ndr_QueryContainerImageCommitHash "$NDR_UI_CONTAINER_NAME")
    if [[ -n "$commitHash" ]]; then gCLI_MODULE_DOCKER_IMAGE_STATUS_UI="$gCLI_MODULE_DOCKER_IMAGE_STATUS_UI | Commit: $commitHash"; fi
    local timestampUTC=$(ndr_QueryContainerImageTimestampHumanReadable "$NDR_UI_CONTAINER_NAME")
    if [[ -n "$timestampUTC" ]]; then gCLI_MODULE_DOCKER_IMAGE_STATUS_UI="$gCLI_MODULE_DOCKER_IMAGE_STATUS_UI | Built: $timestampUTC"; fi
  fi

  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

function ndr_DisplayModuleDockerStatus ()
{
  echo "Current Docker image/container module status:"
  echo "  Local git repo revision [ $gCLI_GIT_REPO_STATUS ]"
  echo "  Supabase DB module [ Image: $gCLI_MODULE_DOCKER_IMAGE_STATUS_DB ], [ Container: $gCLI_MODULE_DOCKER_CONTAINER_STATUS_DB ]"
  echo "  Service module [ Image: $gCLI_MODULE_DOCKER_IMAGE_STATUS_SVC ], [ Container: $gCLI_MODULE_DOCKER_CONTAINER_STATUS_SVC ]"
  echo "  UI module [ Image: $gCLI_MODULE_DOCKER_IMAGE_STATUS_UI ], [ Container: $gCLI_MODULE_DOCKER_CONTAINER_STATUS_UI ]"

  return 0
}

# updates the status of all installed modules
function ndr_UpdateModuleInstallStatus ()
{
  local logSectionDesc="Updating Module Install Status"
  ndr_logSecStartDebug "$logSectionDesc"

  # only check these reg vars if something is installed and registry exists or else error messages will get printed.
  ndr_RegistryExists
  return_code=$?
  if [ $return_code -eq 1 ]; then
    return 0
  fi
  
  gCLI_MODULE_INSTALL_STATUS_DB=$(version=$(ndr_getModuleVersionReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME") && echo "$gCLI_MENU_INSTALL_STATUS_INSTALLED" || echo "$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED")
  if [ "$gCLI_MODULE_INSTALL_STATUS_DB" == "$gCLI_MENU_INSTALL_STATUS_INSTALLED" ]; then
    local version=$(ndr_getModuleVersionReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME")
    if [[ -n "$version" ]]; then gCLI_MODULE_INSTALL_STATUS_DB="$gCLI_MODULE_INSTALL_STATUS_DB | Version: $version"; fi
  fi
  
  gCLI_MODULE_INSTALL_STATUS_SVC=$(if version=$(ndr_getModuleVersionReg "$gREGISTRY_ENTRY_MODULE_STATUS_SERVICE_NAME"); then echo "$gCLI_MENU_INSTALL_STATUS_INSTALLED"; else echo "$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED"; fi)
  if [ "$gCLI_MODULE_INSTALL_STATUS_SVC" == "$gCLI_MENU_INSTALL_STATUS_INSTALLED" ]; then
    local imageVersion=$(ndr_QueryContainerImageVersion "$NDR_SERVICE_CONTAINER_NAME")
    if [[ -n "$imageVersion" ]]; then gCLI_MODULE_INSTALL_STATUS_SVC="$gCLI_MODULE_INSTALL_STATUS_SVC | Version: $imageVersion"; fi
    local commitHash=$(ndr_QueryContainerImageCommitHash "$NDR_SERVICE_CONTAINER_NAME")
    if [[ -n "$commitHash" ]]; then gCLI_MODULE_INSTALL_STATUS_SVC="$gCLI_MODULE_INSTALL_STATUS_SVC | Commit: $commitHash"; fi
    local timestampUTC=$(ndr_QueryContainerImageTimestampHumanReadable "$NDR_SERVICE_CONTAINER_NAME")
    if [[ -n "$timestampUTC" ]]; then gCLI_MODULE_INSTALL_STATUS_SVC="$gCLI_MODULE_INSTALL_STATUS_SVC | Built: $timestampUTC"; fi
  fi

  gCLI_MODULE_INSTALL_STATUS_UI=$(if version=$(ndr_getModuleVersionReg "$gREGISTRY_ENTRY_MODULE_STATUS_UI_NAME"); then echo "$gCLI_MENU_INSTALL_STATUS_INSTALLED"; else echo "$gCLI_MENU_INSTALL_STATUS_NOT_INSTALLED"; fi)
  if [ "$gCLI_MODULE_INSTALL_STATUS_UI" == "$gCLI_MENU_INSTALL_STATUS_INSTALLED" ]; then
    local imageVersion=$(ndr_QueryContainerImageVersion "$NDR_UI_CONTAINER_NAME")
    if [[ -n "$imageVersion" ]]; then gCLI_MODULE_INSTALL_STATUS_UI="$gCLI_MODULE_INSTALL_STATUS_UI | Version: $imageVersion"; fi
    local commitHash=$(ndr_QueryContainerImageCommitHash "$NDR_UI_CONTAINER_NAME")
    if [[ -n "$commitHash" ]]; then gCLI_MODULE_INSTALL_STATUS_UI="$gCLI_MODULE_INSTALL_STATUS_UI | Commit: $commitHash"; fi
    local timestampUTC=$(ndr_QueryContainerImageTimestampHumanReadable "$NDR_UI_CONTAINER_NAME")
    if [[ -n "$timestampUTC" ]]; then gCLI_MODULE_INSTALL_STATUS_UI="$gCLI_MODULE_INSTALL_STATUS_UI | Built: $timestampUTC"; fi
  fi
  
  gCLI_NDR_INSTALLED_VERSION=$(ndr_getVersionReg)
  gCLI_NDR_HOST_ADDRESS=$(ndr_getHostAddressReg)

  ndr_logSecEndDebug "$logSectionDesc" 

  return 0
}

function ndr_DisplayModuleInstallStatus ()
{
  echo "Current module installation status:"
  echo "  Supabase application [ $gCLI_MODULE_INSTALL_STATUS_DB ]"
  echo "  Service application [ $gCLI_MODULE_INSTALL_STATUS_SVC ]"
  echo "  UI application [ $gCLI_MODULE_INSTALL_STATUS_UI ]"
  #echo "  Installed Product Version [ $gCLI_NDR_INSTALLED_VERSION ]"
  echo "  Host Address [ $gCLI_NDR_HOST_ADDRESS ]"
  return 0
}

function ndr_PopulateLocalGitRepoDetails ()
{
  local logSectionDesc="Populating Local Git Repo Details"
  ndr_logSecStartDebug "$logSectionDesc"

  local commit_hash=$(git rev-parse HEAD 2>/dev/null)
  return_code=$?
  if [[ $return_code -ne 0 || -z "$commit_hash" ]]; then
    ndr_logWarn "Unable to retrieve git commit hash."
    return 1
  fi
  
  if [[ -n "$gCLI_GIT_REPO_COMMIT_HASH_LONG" && "$commit_hash" == "$gCLI_GIT_REPO_COMMIT_HASH_LONG" ]];then
    # already up to date
    ndr_logDebug "Local git repo details up to date."
    ndr_logSecEndDebug "$logSectionDesc"
    return 0
  fi

  gCLI_GIT_REPO_COMMIT_HASH_LONG="$commit_hash"

  gCLI_GIT_REPO_COMMIT_HASH_SHORT=$(echo "$gCLI_GIT_REPO_COMMIT_HASH_LONG" | cut -c1-7)
  
  gCLI_GIT_REPO_COMMIT_TIMESTAMP=$(git show -s --format=%ct 2>/dev/null)
  return_code=$?
  if [[ $return_code -ne 0 || -z "$gCLI_GIT_REPO_COMMIT_TIMESTAMP" ]]; then
    ndr_logWarn "Unable to retrieve git commit timestamp."
    return 1
  fi

  local tsHR=$(date -u -d @"$gCLI_GIT_REPO_COMMIT_TIMESTAMP" +"%Y-%m-%d")

  gCLI_GIT_REPO_STATUS="Commit: $gCLI_GIT_REPO_COMMIT_HASH_LONG ($gCLI_GIT_REPO_COMMIT_HASH_SHORT) | Timestamp: $tsHR ($gCLI_GIT_REPO_COMMIT_TIMESTAMP)"
  
  ndr_logDebug "Built full repo details [$gCLI_GIT_REPO_STATUS]"

  ndr_logSecEndDebug "$logSectionDesc"

  return 0
}

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ndr_logWarn "This is a bash module--there is no direct execution capabilities in this file."
  exit 0
fi
