# NextDR Software Build, Test, Installation and Management Script Suite

These scripts facilitate the building, testing, installation and management of the entire NextDR software suite. For all operations, it supports both **interactive mode** and **express mode** for flexibility and ease of use.

---

## Scripts

- **ndrDevops.sh**  
  Handles DevOps automation tasks such as building, cleaning, and managing Docker images and containers for all NextDR components. Includes advanced options for image upload, resource scrubbing, and CI/CD support.

- **ndrInstall.sh**  
  Orchestrates the installation and configuration of the NextDR software suite, including prerequisites, Supabase, service, and UI components. Supports both interactive and express (automated) modes.

- **ndrTest.sh**  
  Automates testing routines for installation, service, and UI components. Provides command sequence execution, health checks, logging, reporting, and supports both continuous and single-run test modes.

- **ndrAdmin.sh**  
  Allows for starting and stopping the currently installed NextDR modules.

## Features

- **Interactive Mode**: Provides an interactive, menu-driven interface for step-by-step installation and management.
- **Express Mode**: Allows for quick, automated operation of all interactive options with predefined options. Additional advanced options are also available in Express mode that are not visisble in Interactive mode.
- **Secure Secret Management**: For operations requiring sensitive company account passphrases and secrets, this information is encrypted in a secrets file that will be securely decrypted on-the-fly as needed and only for the duration of the action requiring this sensitive information.

---

## Prerequisites


Before running most operations, several packages are required. These can be interactively installed by the scripts if missing, or you may install them manually in advance. The scripts will check for and install any missing prerequisites as needed.

**Required for all operations:**

- **Node.js and NPM/NPX**  
   JavaScript runtime and package manager. Required for running Node-based tools and the Supabase CLI.  
- **Git**  
   Version control system. Used for pulling code and managing repositories.  
- **Docker**  
   Containerization platform. Required for running Supabase, service, and UI containers.  
- **yq**  
   YAML processor. Used for parsing and editing YAML configuration files.  
   Install via your package manager (e.g., `sudo apt-get install yq` or `brew install yq`).

**Required for DevOps/advanced operations:**

- **makeself**  
   Utility for creating self-extracting archives. Used in packaging and deployment workflows.
- **postgresql-client**  
   PostgreSQL command-line client tools. Used for database management and schema operations.

- **Supabase CLI:**
   The Supabase CLI is invoked via `npx supabase` and does not require a global install, but Node.js/NPM must be present.

---

## Usage

### Running the Script

To execute the script, open a bash terminal in the directory containing the script and run with sudo.

- **Interactive Mode**: Simply execute the script without any options. User will be interactively guided through all operations.

- **Express Mode**: Express mode implies limited to no interaction from the user--all mandatory options should be provided by the user via thier corresponding command line parameters. For non-essential options, defaults will be automatically used in the absence of its corresponding command line option.

Below are some example usages of common script operations in express mode:

### Install Script

**Install an application:**
ndrInstall.sh --express <installsupabase | installservice | installui> --admin-user local_admin_user --admin-password local_admin_password [--dest install_folder] [--ip NDR_Host_IPV4] [--localimage] [--debug]

**Parameters:**
- `--dest` : The location where the software package will be installed.
- `--hostaddress` : The IPV4 address or FQDN of the host. Used for internal communication. If omitted, the default address is chosen in a multi-homed scenario.
- `--admin-user` : The administrative account to access the software (must be in email format).
- `--admin-password` : The password for the administrative account.
- `--localimage` : Use a pre-existing local Docker image if available; otherwise, pull from the remote repository.

**Uninstall an application:**

ndrInstall.sh --express <removesupabase | removeservice | removeui> [--retainimages] [--debug]
**Parameters:**
- `--retainimages` : Keep Docker images after uninstalling the application/container. Useful for later reinstalls without re-downloading images.

Backup the Supabase database schema (produces a backup SQL file with the NextDR Supabase DB schema):
ndrInstall.sh --express backupdb [--debug]

Restore the Supabase database schema (restores the NextDR Supabase DB schema via a backup SQL schema file):
ndrInstall.sh --express restoredb [--schemafile path_to_schema_file] [--debug]

Create additional administrative account : 
ndrInstall.sh --express createadminaccount --admin-user local_admin_user --admin-password local_admin_password [--debug]
**Parameters:**
- `--admin-user` : The administrative account that will be created to access the software once installed. Must be in email format.
- `--admin-password` : The password for the administrative account.

- **Devops Script**

Install prerequisites :
ndrDevops.sh --express installprerequisites  [--debug]

Pull the database schema from a remote instance (will interactively prompt for password):
ndrDevops.sh --express pullschema [--gpg-secret passphrase] [--debug]
**Parameters:**
- `--gpg-secret passphrase` : Supply the GPG passphrase to decrypt the secrets file.

Build Supabase Application Module :
ndrDevops.sh --express builddb [--debug]

Build Service Application Module :
ndrDevops.sh --express buildsvc [--debug]

Build UI Application Module :
ndrDevops.sh --express buildui [--debug]

Remove/Cleanup Supabase Application Module :
ndrDevops.sh --express cleanupdb [--debug]

Remove/Cleanup Service Application Module :
ndrDevops.sh --express cleanupsvc [--debug]

Remove/Cleanup UI Application Module :
ndrDevops.sh --express cleanupui [--debug]

Upload Application Module Docker Images to Hub : 
ndrDevops.sh --express uploadimages [--privaterepo] [--publicrepo] [--gpg-secret passphrase] [--debug]
**Parameters:**
- `--privaterepo` : Directs the image upload to the PRIVATE Docker Hub remote repository. Mutually exclusive to the public repo option.
- `--publicrepo` : Directs the image upload to the PUBLIC Docker Hub remote repository. Mutually exclusive to the private repo option.
- `--gpg-secret passphrase` : Supply the GPG passphrase to decrypt the secrets file.

Build self extracting archive of install package :
ndrDevops.sh --express buildpackage [--debug]

Uninstall Docker engine : 
ndrDevops.sh --express removedocker [--debug]

Scrub all Docker resources from host : 
ndrDevops.sh --express scrubdocker [--debug]
**Description:**
Scrubs all Docker resources from host (containers, images, volumes, networks and caches), WARNING - Everything will be removed without prejudice, proceed with caution.

- **Test Script**

Devops Test Sequence : 
ndrTest.sh --express testdevops [--continuous] [--maxruns max_run_loop_sequences] [--retainimages] [--debug]

Install Test Sequence :
ndrTest.sh --express testinstall [--continuous] [--maxruns max_run_loop_sequences] [--retainimages] [--debug]

**Parameters:**
- `--continuous` : Will run the test loop sequence continuously until interrrupted by a failure or other external reason.
- `--maxruns max_run_loop_sequences` : Will run the test loop sequence for N number of loop cycles until interrrupted by a failure or other external reason.
- `--retainimages` : Keep Docker images after uninstalling the application/container. Useful for later reinstalls without re-downloading images.

- **Admin Script**

Start a module : 
ndrAdmin.sh --express <startdb | startsvc | startui> [--recreate] [--debug]
**Parameters:**
- `--recreate` : Recreates/recomposes the docker container during the module start. Useful for pulling in new environment variable changes.

Stop a module :
ndrAdmin.sh --express <startdb | startsvc | startui> [--debug]

Query current module status :
ndrAdmin.sh --express status [--debug]


**General Parameters for all Scripts:**
- `--debug` : Enables pass through verbose output for 3rd party commands for troubleshooting and enables timestamping of all command executions.
- `--logpolicy <0|1|2>` : Adjusts script logging verbosity to silent, normal, verbose.