#!/bin/bash

source "$(dirname "${BASH_SOURCE[0]}")/ndrInterface.sh"
source "$(dirname "${BASH_SOURCE[0]}")/ndrRegistry.sh"
source "$(dirname "${BASH_SOURCE[0]}")/ndrDocker.sh"
source "$(dirname "${BASH_SOURCE[0]}")/ndrSupabase.sh"

# --- CONFIGURATION ---

gLOG_FILE="/var/log/ndrAdmin.log"


EXPRESS_MENU_OPTIONS="startsupabase | startservice | startui | startall | stopsupabase | stopservice | stopui | stopall | status"

# ----------------------

# --- FUNCTIONS ---

function mainStartSupabaseApplication ()
{
  local logSectionDesc="Starting Supabase application"
  ndr_logSecStart "$logSectionDesc"

  # check that app is installed, if not, abort?
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
  local isInstalled=$?
  if [[ "$isInstalled" -ne 0 ]]; then
    if [ "$gExpressMode" -ne 1 ]; then
      ndr_PromptYesNo "The $gCOMPANY_NAME Supabase database application module does not appear to be officially installed. Would you like to attempt to start the application containers with any local images that may be present?" "$NDR_PROMPT_DEFAULT_INPUT_YES"
      return_code=$?
      if [ $return_code != $NDR_PROMPT_RETURN_YES ]; then
        ndr_logInfo "Operation cancelled, returning to main menu."
        return 1
      fi
    fi
    ndr_logInfo "Proceeding with start."

  else
    ndr_logInfo "Supabase application is currently installed."
  fi

  ndr_PopulateSupabaseServiceMap
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to populate Supabase service map."
    return 1
  fi
  
  if [ ${#ndr_supabase_container_services[@]} -eq 0 ]; then
    ndr_logError "No service entries found in compose or registry to act on."
    return 0
  fi

  # check that images are present
  local allImagesPresent=true
  for service_name in "${ndr_supabase_container_services[@]}"; do
    
    local image_base_name="${ndr_supabase_container_service_image_names[$service_name]}"
    local image_tag="${ndr_supabase_container_service_image_tags[$service_name]}"
    local image_name="$image_base_name:$image_tag"

    ndr_verifyDockerImageExists "$image_base_name" >/dev/null
    return_code=$?
    #2-error, 1-not found, 0-found
    if [ $return_code -ne 0 ]; then
      ndr_logError "Docker image [$image_name] not found."
      allImagesPresent=false
      #return 1
    fi
  done

  if [[ "$allImagesPresent" == false ]]; then
    ndr_logInfo "One ore more images required for this application were not found, exiting."
    return 1
  fi

  # check if containers are already running
  local allContainersPresent=true
  local allContainersRunning=true
  for service_name in "${ndr_supabase_container_services[@]}"; do
    local container_name="${ndr_supabase_container_service_container_names[$service_name]}"
    
    # first check if its running. if so, skip it.
    ndr_verifyDockerContainerRunning "$container_name"
    return_code=$?
    if [ $return_code -eq 0 ]; then
      ndr_logInfo "Docker container [$container_name] is already running."
      continue
    fi
    allContainersRunning=false
    
    # for containers not running, quick sanity check that it exists.
    ndr_verifyDockerContainerExists "$container_name" >/dev/null
    return_code=$?
    #2-error, 1-not found, 0-found
    if [[ $return_code != 0 ]]; then
      # skip if not found
      ndr_logWarn "Docker container '$container_name' not found."
      allContainersPresent=false
    fi
  done

  if [[ "$allContainersRunning" == true ]]; then
    ndr_logInfo "All containers are currently running, exiting."
    return 0
  fi

  if [[ "$allContainersPresent" == false ]]; then
    ndr_logInfo "Once or more required appllication containers not found, exiting."
    return 1
  fi

  # if supabase app is officially installed, we can start it with the compose file from its install dir
  # alternately we can look for it in the devops location.
  # lastly we can try using the hard coded list
  while true; do
    local homeDir

    if [[ "$isInstalled" -eq 0 ]]; then
      ndr_logInfo "Starting Supabase from install location."

      homeDir=$(ndr_getHomeDirReg)
      return_code=$?
      if [[ $return_code -ne 0 || -z "$homeDir" ]]; then
        ndr_logError "Failed to retrieve home dir from registry."
        return 1
      fi
      gNEXTDR_HOME_DIR="$homeDir"
      gSUPABASE_NEXTDR_HOME="${gNEXTDR_HOME_DIR}/${gSUPABASE_NEXTDR_SUB}"
      ndr_logInfo "$gNEXTDR_HOME_DIR $gSUPABASE_NEXTDR_HOME"
      #gSUPABASE_TEMPLATE_HOME="${gNEXTDR_HOME_DIR}/${gSUPABASE_TEMPLATE_SUB}"
      break
    fi

    # check for a supabase home dir under the pwd/script dir. This is common when running it from the devops script.
    homeDir="${gSCRIPT_HOME_DIR}"
    local supabaseHomeDir="${homeDir}/${gSUPABASE_NEXTDR_SUB}"
    local DEVOPS_COMPOSE_FILE="${supabaseHomeDir}/docker-compose.yml"
    if [[ -d "$supabaseHomeDir" && -f "$DEVOPS_COMPOSE_FILE" ]]; then
      ndr_logInfo "Starting Supabase from devops location."

      gNEXTDR_HOME_DIR="$homeDir"
      gSUPABASE_NEXTDR_HOME="${supabaseHomeDir}"
      break
    fi

    break
  done

  if [[ -z "$gNEXTDR_HOME_DIR" || -z "$gSUPABASE_NEXTDR_HOME" ]]; then
    ndr_logError "Invalid home or project directory."
    return 1
  fi

  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }

  # start them
  ndr_StartSupabaseDockerContainers #"$NDR_START_SUPABASE_DOCKER_CONTAINER_OPTION_NO_RECREATE"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to start Supabase $gCOMPANY_NAME Docker containers."
    return 1
  fi

  # check if the newly built Docker containers exist
  ndr_verifySupabaseContainersExist
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Docker container verification failed."
    return 1
  fi
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainStartServiceApplication ()
{
  local logSectionDesc="Starting Service application"
  ndr_logSecStart "$logSectionDesc"

  local moduleRegistryName="$gREGISTRY_ENTRY_MODULE_STATUS_SERVICE_NAME"
  local containerFolder="$NDR_SERVICE_HOME_LOC"
  local dockerImageBaseName="$NDR_SERVICE_IMAGE_NAME"
  local dockerImageVersion="$NDR_SERVICE_IMAGE_VERSION"
  local dockerContainerName="$NDR_SERVICE_CONTAINER_NAME"
  local dockerContainerPort="$NDR_SERVICE_CONTAINER_PORT"
  local dockerImageName="$dockerImageBaseName:$dockerImageVersion"

  dockerImageVersion=$(ndr_QueryContainerImageVersionTag "$dockerContainerName")
  return_code=$?
  if [[ $return_code -ne 0 || -z "$dockerImageVersion" ]]; then
    ndr_logError "Failed to retrieve image name for container [$dockerContainerName]."
    return 1
  fi

  ndr_StartApplication "$moduleRegistryName" "$containerFolder" "$dockerImageBaseName" "$dockerImageVersion" "$dockerContainerName" "$dockerContainerPort"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to start Docker container application [$dockerContainerName]."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainStartUIApplication ()
{
  local logSectionDesc="Starting UI application"
  ndr_logSecStart "$logSectionDesc"
  
  local moduleRegistryName="$gREGISTRY_ENTRY_MODULE_STATUS_UI_NAME"
  local containerFolder="$NDR_UI_HOME_LOC"
  local dockerImageBaseName="$NDR_UI_IMAGE_NAME"
  local dockerImageVersion="$NDR_UI_IMAGE_VERSION"
  local dockerContainerName="$NDR_UI_CONTAINER_NAME"
  local dockerContainerPort="$NDR_UI_CONTAINER_PORT"
  
  dockerImageVersion=$(ndr_QueryContainerImageVersionTag "$dockerContainerName")
  return_code=$?
  if [[ $return_code -ne 0 || -z "$dockerImageVersion" ]]; then
    ndr_logError "Failed to retrieve image name for container [$dockerContainerName]."
    return 1
  fi
  
  ndr_StartApplication "$moduleRegistryName" "$containerFolder" "$dockerImageBaseName" "$dockerImageVersion" "$dockerContainerName" "$dockerContainerPort"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to start Docker container application [$dockerContainerName]."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function <module_registry_name> <folder> <image_name> <image_version> <container_name> <container_port>
function ndr_StartApplication ()
{
  local logSectionDesc="Starting application"
  ndr_logSecStart "$logSectionDesc"

  local moduleRegistryName="$1"
  local containerFolder="$2"
  local dockerImageBaseName="$3"
  local dockerImageVersion="$4"
  local dockerImageName="$dockerImageBaseName:$dockerImageVersion"
  local dockerContainerName="$5"
  local dockerContainerPort="$6"
  local dockerContainerURL="http://localhost:$dockerContainerPort"
  
  # Validate argument count
  if [[ $# -lt 6 ]]; then
    ndr_logError "Usage: function <module_registry_name> <folder> <image_name> <image_version> <container_name> <container_port>"
    return 1
  fi

  # check that app is installed, if not, abort?
  ndr_isModuleInstalledReg "$moduleRegistryName"
  local isInstalled=$?
  if [[ "$isInstalled" -ne 0 ]]; then
    if [ "$gExpressMode" -ne 1 ]; then
      ndr_PromptYesNo "The $gCOMPANY_NAME application module $dockerContainerName does not appear to be officially installed. Would you like to attempt to start the application containers with any local images that may be present?" "$NDR_PROMPT_DEFAULT_INPUT_YES"
      return_code=$?
      if [ $return_code != $NDR_PROMPT_RETURN_YES ]; then
        ndr_logInfo "Operation cancelled, returning to main menu."
        return 1
      fi
    fi
    ndr_logInfo "Proceeding with start."

  else
    ndr_logInfo "Application is currently installed."
  fi

  ndr_verifyDockerContainerRunning "$dockerContainerName" "$dockerContainerPort"
  return_code=$?
  if [ $return_code -eq 0 ]; then
    ndr_logInfo "Docker container [$dockerContainerName] is already running."
    return 0
  fi
  
  # check if the Docker image exists. This must exist to perform any further actions.
  ndr_verifyDockerImageExists "$dockerImageName"
  return_code=$?
  #2-error, 1-not found, 0-found
  if [ $return_code -ne 0 ]; then
    ndr_logError "Docker image [dockerImageName] not found."
    return 1
  fi
  
  # check if the Docker container exists and is running
  local containerExists=true
  ndr_verifyDockerContainerExists "$dockerContainerName"
  return_code=$?
  #2-error, 1-not found, 0-found
  if [ $return_code -ne 0 ]; then
    # if the container no longer exists, we would need to rebuild
    containerExists=false
  fi

  if [ "$gNDR_RECREATE_DOCKER_CONTAINERS" == true ]; then
    ndr_logInfo "Option to recreate Docker containers is enabled. Will recreate [$dockerContainerName] instead of starting existing."
    # flag this container to be rebuilt
    containerExists=false
  fi

  if [[ "$containerExists" == true ]]; then
    # container is present, but not running, we simply do a container start.
    ndr_logInfo "Docker container [$dockerContainerName] already exists, starting..."
    docker container start "$dockerContainerName"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to start Docker container [$dockerContainerName]."
      return 1
    fi
  else
    if [ "$gExpressMode" -ne 1 ]; then
      ndr_PromptYesNo "The application module container $dockerContainerName requires rebuilding. Would you like to attempt to rebuild the application container with any local images that may be present?" "$NDR_PROMPT_DEFAULT_INPUT_YES"
      return_code=$?
      if [ $return_code != $NDR_PROMPT_RETURN_YES ]; then
        ndr_logInfo "Operation cancelled, returning to main menu."
        return 1
      fi
    fi

    # container does not exist, need to recreate
    ndr_logInfo "Docker container [$dockerContainerName] does not exist or requires rebuilding. Recomposing containers..."
    
    local containerHomeDir=$(ndr_getHomeDirForImageName "$dockerImageBaseName" "$containerFolder")
    
    # run container from image
    ndr_ComposeDockerApplicationContainer "$containerHomeDir" "$dockerImageBaseName" "$dockerImageVersion" "$dockerContainerName" "$dockerContainerPort"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to start Docker container [$dockerContainerName]."
      return 1
    fi
  fi

  ndr_logInfo "Docker container [$dockerContainerName] successfully started."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainStartAllApplications ()
{
  local logSectionDesc="Starting all applications"
  ndr_logSecStart "$logSectionDesc"

  local allApplicationsStarted=true
  while true; do
    mainStartSupabaseApplication
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to start Supabase application."
      allApplicationsStarted=false
    fi

    mainStartServiceApplication
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to start Service application."
      allApplicationsStarted=false
    fi

    mainStartUIApplication
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to start UI application."
      allApplicationsStarted=false
    fi

    break
  done

  if [[ "$allApplicationsStarted" == false ]]; then
    ndr_logError "Unable to start one or more of the required application containers."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainStopSupabaseApplication ()
{
  local logSectionDesc="Stopping Supabase application"
  ndr_logSecStart "$logSectionDesc"

  # check that app is installed, if not, abort?
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
  local isInstalled=$?
  if [[ "$isInstalled" -ne 0 ]]; then
    if [ "$gExpressMode" -ne 1 ]; then
      ndr_PromptYesNo "The $gCOMPANY_NAME Supabase database application module does not appear to be officially installed. Would you like to attempt to stop any local application containers that may be present?" "$NDR_PROMPT_DEFAULT_INPUT_YES"
      return_code=$?
      if [ $return_code != $NDR_PROMPT_RETURN_YES ]; then
        ndr_logInfo "Operation cancelled, returning to main menu."
        return 1
      fi
    fi
    ndr_logInfo "Proceeding with stop."

  else
    ndr_logInfo "Supabase application is currently installed."
  fi

  ndr_PopulateSupabaseServiceMap
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to populate Supabase service map."
    return 1
  fi
  
  if [ ${#ndr_supabase_container_services[@]} -eq 0 ]; then
    ndr_logError "No service entries found in compose or registry to act on."
    return 0
  fi

  # Check all containers
  local allContainersStopped=true
  for service_name in "${ndr_supabase_container_services[@]}"; do
    local dockerContainerName="${ndr_supabase_container_service_container_names[$service_name]}"
    
    # first verify container exists
    ndr_verifyDockerContainerExists "$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME" >/dev/null
    return_code=$?
    #2-error, 1-not found, 0-found
    if [[ $return_code != 0 ]]; then
      # skip if not found
      ndr_logWarn "Docker container '$dockerContainerName' not found."
      allContainersStopped=false
      continue
    fi

    # determine if container is already stopped
    ndr_verifyDockerContainerRunning "$dockerContainerName"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logInfo "Docker container [$dockerContainerName] is already stopped."
      continue
    fi
    
    # container is present, but not running, we simply do a container stop.
    ndr_logInfo "Stopping Docker container [$dockerContainerName]..."
    docker container stop "$dockerContainerName"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logWarn "Docker container [$dockerContainerName] failed to stop."
      allContainersStopped=false
      continue
    fi
    
    ndr_verifyDockerContainerRunning "$dockerContainerName" "$dockerContainerPort"
    return_code=$?
    if [ $return_code -eq 0 ]; then
      ndr_logWarn "Docker container [$dockerContainerName] is still running."
      allContainersStopped=false
      continue
    fi

    ndr_logInfo "Docker container [$dockerContainerName] successfully stopped."
  done

  if [[ "$allContainersStopped" == false ]]; then
    ndr_logInfo "Unable to stop one or more of the required application containers."
    return 1
  fi
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainStopServiceApplication ()
{
  local logSectionDesc="Stopping Service application"
  ndr_logSecStart "$logSectionDesc"

  local moduleRegistryName="$gREGISTRY_ENTRY_MODULE_STATUS_SERVICE_NAME"
  local dockerContainerName="$NDR_SERVICE_CONTAINER_NAME"
  local dockerContainerPort="$NDR_SERVICE_CONTAINER_PORT"

  ndr_StopApplication "$moduleRegistryName" "$dockerContainerName" "$dockerContainerPort"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to stop Docker container application [$dockerContainerName]."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainStopUIApplication ()
{
  local logSectionDesc="Stopping UI application"
  ndr_logSecStart "$logSectionDesc"

  local moduleRegistryName="$gREGISTRY_ENTRY_MODULE_STATUS_UI_NAME"
  local dockerContainerName="$NDR_UI_CONTAINER_NAME"
  local dockerContainerPort="$NDR_UI_CONTAINER_PORT"

  ndr_StopApplication "$moduleRegistryName" "$dockerContainerName" "$dockerContainerPort"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to stop Docker container application [$dockerContainerName]."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function <module_registry_name> <container_name> <container_port>
function ndr_StopApplication ()
{
  local logSectionDesc="Stopping application"
  ndr_logSecStart "$logSectionDesc"

  local moduleRegistryName="$1"
  local dockerContainerName="$2"
  local dockerContainerPort="$3"
  local dockerContainerURL="http://localhost:$dockerContainerPort"
  
  # Validate argument count
  if [[ $# -lt 3 ]]; then
    ndr_logError "Usage: function <module_registry_name> <container_name> <container_port>"
    return 1
  fi

  # check that app is installed, if not, abort?
  ndr_isModuleInstalledReg "$moduleRegistryName"
  local isInstalled=$?
  if [[ "$isInstalled" -ne 0 ]]; then
    if [ "$gExpressMode" -ne 1 ]; then
      ndr_PromptYesNo "The $gCOMPANY_NAME application module $dockerContainerName does not appear to be officially installed. Would you like to attempt to stop any matching local application containers that may be present?" "$NDR_PROMPT_DEFAULT_INPUT_YES"
      return_code=$?
      if [ $return_code != $NDR_PROMPT_RETURN_YES ]; then
        ndr_logInfo "Operation cancelled, returning to main menu."
        return 1
      fi
    fi
    ndr_logInfo "Proceeding with stop."

  else
    ndr_logInfo "Application is currently installed."
  fi

  # check if the Docker container exists and is running
  ndr_verifyDockerContainerExists "$dockerContainerName"
  return_code=$?
  #2-error, 1-not found, 0-found
  if [ $return_code -ne 0 ]; then
    # if the container no longer exists, nothing to do
    ndr_logWarn "Docker container [$dockerContainerName] not found."
    return 1
  fi

  ndr_verifyDockerContainerRunning "$dockerContainerName" "$dockerContainerPort"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logInfo "Docker container [$dockerContainerName] is already stopped."
    return 0
  fi
  
  # container is present, but not running, we simply do a container stop.
  ndr_logInfo "Stopping Docker container [$dockerContainerName]..."
  docker container stop "$dockerContainerName"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logWarn "Docker container [$dockerContainerName] failed to stop."
    return 1
  fi
  ndr_logInfo "Docker container [$dockerContainerName] stopped."

  ndr_verifyDockerContainerRunning "$dockerContainerName" "$dockerContainerPort"
  return_code=$?
  if [ $return_code -eq 0 ]; then
    ndr_logWarn "Docker container [$dockerContainerName] is still running."
    return 1
  fi

  ndr_logInfo "Docker container [$dockerContainerName] successfully stopped."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainStopAllApplications ()
{
  local logSectionDesc="Stopping all applications"
  ndr_logSecStart "$logSectionDesc"

  local allApplicationsStopped=true
  while true; do
    mainStopUIApplication
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to stop UI application."
      allApplicationsStopped=false
    fi

    mainStopServiceApplication
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to stop Service application."
      allApplicationsStopped=false
    fi

    mainStopSupabaseApplication
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to stop Supabase application."
      allApplicationsStopped=false
    fi

    break
  done

  if [[ "$allApplicationsStopped" == false ]]; then
    ndr_logError "Unable to stop one or more of the required application containers."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainQueryStatusAll ()
{
  if [ "$gGUI_MODE" == true ]; then
    g_supabaseImageStatus=$(if ndr_verifyDockerImageExists "$NDR_SUPABASE_APP_SERVICE_NAME_DB_IMAGE_NAME" >/dev/null; then echo "image present"; else echo "no image"; fi)
    g_supabaseContainerStatus=$(if ndr_verifyDockerContainerExists "$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME" >/dev/null; then echo "container present"; else echo "no container"; fi)
    g_supabaseContainerRunning=$(if ndr_verifyDockerContainerRunning "$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME" >/dev/null; then echo "container running"; else echo "container stopped"; fi)

    g_serviceImageStatus=$(if ndr_verifyDockerImageExists "$NDR_SERVICE_IMAGE_NAME:$NDR_SERVICE_IMAGE_VERSION" >/dev/null; then echo "image present"; else echo "no image"; fi)
    g_serviceContainerStatus=$(if ndr_verifyDockerContainerExists "$NDR_SERVICE_CONTAINER_NAME" >/dev/null; then echo "container present"; else echo "no container"; fi)
    g_serviceContainerRunning=$(if ndr_verifyDockerContainerRunning "$NDR_SERVICE_CONTAINER_NAME" "$NDR_SERVICE_CONTAINER_PORT" >/dev/null; then echo "container running"; else echo "container stopped"; fi)

    g_uiImageStatus=$(if ndr_verifyDockerImageExists "$NDR_UI_IMAGE_NAME:$NDR_UI_IMAGE_VERSION" >/dev/null; then echo "image present"; else echo "no image"; fi)
    g_uiContainerStatus=$(if ndr_verifyDockerContainerExists "$NDR_UI_CONTAINER_NAME" >/dev/null; then echo "container present"; else echo "no container"; fi)
    g_uiContainerRunning=$(if ndr_verifyDockerContainerRunning "$NDR_UI_CONTAINER_NAME" "$NDR_UI_CONTAINER_PORT" >/dev/null; then echo "container running"; else echo "container stopped"; fi)

    g_appVersion=$(version=$(ndr_getVersionReg 2>/dev/null) && echo "$version" || echo "(not installed)")
    g_hostAddress=$(address=$(ndr_getHostAddressReg 2>/dev/null) &&  echo "$address" || echo "localhost")
    g_supabaseAppInstalled=$(if ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME" >/dev/null; then echo "(installed)"; else echo "(not installed)"; fi)
    g_serviceAppInstalled=$(if ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SERVICE_NAME" >/dev/null; then echo "(installed)"; else echo "(not installed)"; fi)
    g_uiAppInstalled=$(if ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_UI_NAME" >/dev/null; then echo "(installed)"; else echo "(not installed)"; fi)
  else
    ndr_UpdateModuleInstallStatus
    ndr_UpdateModuleDockerStatus
  fi
  
  return 0
}

function mainPrintStatusAll ()
{
  echo "===================================================================="
  echo "$gCOMPANY_NAME $gPRODUCT_VERSION Software Module Management Menu"
  if [ "$gGUI_MODE" == true ]; then
    echo "Current Docker image/container module status:"
    echo "  Supabase module ($NDR_SUPABASE_APP_SERVICE_NAME_DB_IMAGE_NAME | $NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME): $g_supabaseImageStatus, $g_supabaseContainerStatus, $g_supabaseContainerRunning"
    echo "  Service module ($NDR_SERVICE_IMAGE_NAME:$NDR_SERVICE_IMAGE_VERSION | $NDR_SERVICE_CONTAINER_NAME): $g_serviceImageStatus, $g_serviceContainerStatus, $g_serviceContainerRunning"
    echo "  UI module ($NDR_UI_IMAGE_NAME:$NDR_UI_IMAGE_VERSION | $NDR_UI_CONTAINER_NAME): $g_uiImageStatus, $g_uiContainerStatus, $g_uiContainerRunning"
    echo "Current module installation status:"
    echo "  Supabase: $g_supabaseAppInstalled"
    echo "  Service: $g_serviceAppInstalled"
    echo "  UI: $g_uiAppInstalled"
    echo "  Version: $g_appVersion"
    echo "  Host Address: $g_hostAddress"
  else
    ndr_DisplayModuleDockerStatus
    ndr_DisplayModuleInstallStatus
  fi
  echo "===================================================================="

  return 0
}

# ====================================================
# command line parsing
# ====================================================
function mainParseCommandLineArgs ()
{
  local logSectionDesc="Parsing command line arguments"
  ndr_logSecStart "$logSectionDesc"

  # Default values
  
  ndr_parseCommandLineArgs "$@"

  # Parse arguments
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --help|-h)
        ndr_logWarn "Usage: $0 --express <$EXPRESS_MENU_OPTIONS> --password <password> [--debug]."
        return 1
        ;;
      --gui)
        gGUI_MODE=true
        ndr_logInfo "Graphical interactive menu mode enabled."
        shift
        ;;
      --tui)
        gGUI_MODE=false
        ndr_logInfo "Graphical interactive menu mode disabled."
        shift
        ;;
      --recreate|--recreate-container)
        gNDR_RECREATE_DOCKER_CONTAINERS=true
        ndr_logInfo "Option to recreate Docker containers on module start is enabled."
        shift
        ;;
      *)
        #ndr_logError "Unknown option: $1"
        shift
        ;;
    esac
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# ====================================================
# Express install mode
# ====================================================
function mainExpressInstallMode ()
{
  local logSectionDesc="Executing express install mode"
  ndr_logSecStart "$logSectionDesc"

  # Check if express mode is enabled and an option is provided
  if [ "$gExpressMode" != 1 ]; then
    ndr_logError "Express mode is not enabled. Use --express to enable."
    return 1
  fi
  if [ -z "$gExpressOption" ]; then
    ndr_logError "No express option provided. Use --express <option>."
    return 1
  fi

  case "$gExpressOption" in
    startsupabase|startdb)
      mainStartSupabaseApplication
      ;;
    startservice|startsvc)
      mainStartServiceApplication
      ;;
    startui)
      mainStartUIApplication
      ;;
    startall)
      mainStartAllApplications
      ;;
    stopsupabase|stopdb)
      mainStopSupabaseApplication
      ;;
    stopservice|stopsvc)
      mainStopServiceApplication
      ;;
    stopui)
      mainStopUIApplication
      ;;
    stopall)
      mainStopAllApplications
      ;;
    status)
      mainQueryStatusAll
      mainPrintStatusAll
      ;;
    *)
      # print usage and exit
      ndr_logWarn "Invalid option. Please use one of the following options: $EXPRESS_MENU_OPTIONS"
      return 1
      ;;
  esac
  
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to execute selection."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

ADMIN_MENU_ITEM_1="Start the $gCOMPANY_NAME Supabase database application container"
ADMIN_MENU_ITEM_2="Start the $gCOMPANY_NAME Service application container"
ADMIN_MENU_ITEM_3="Start the $gCOMPANY_NAME UI application container"
ADMIN_MENU_ITEM_4="Start all module containers"
ADMIN_MENU_ITEM_5="Stop the $gCOMPANY_NAME Supabase database application container"
ADMIN_MENU_ITEM_6="Stop the $gCOMPANY_NAME Service application container"
ADMIN_MENU_ITEM_7="Stop the $gCOMPANY_NAME UI application container"
ADMIN_MENU_ITEM_8="Stop all module containers"
ADMIN_MENU_ITEM_LAST="8"

function getAdminMenuTextByNumber() 
{
  local itemNum="$1"

  # Validate input is 1–8 and numeric
  if ! [[ "$itemNum" =~ ^[1-$ADMIN_MENU_ITEM_LAST]$ ]]; then
    echo "Error: Invalid item number '$itemNum'. Must be 1–$ADMIN_MENU_ITEM_LAST." >&2
    return 1
  fi

  local varName="ADMIN_MENU_ITEM_${itemNum}"
  local itemText

  # Use indirect expansion via eval to read the dynamic variable
  eval "itemText=\"\${$varName}\""

  if [[ -z "$itemText" ]]; then
    echo "Error: No text found for $varName" >&2
    return 2
  fi

  echo "$itemText"
  return 0
}

# ====================================================
# Graphical based interactive menu mode
# ====================================================
function mainGraphicalInteractiveMenuMode ()
{
  local logSectionDesc="Executing graphical based interactive menu mode"
  ndr_logSecStart "$logSectionDesc"

  pkg="dialog"
  if ! command -v "$pkg" &> /dev/null; then
    apt-get install --assume-yes "$pkg"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to run graphical based menu, reverting to text based menu."
      mainInteractiveMenuMode
      return 0
    fi
  fi

  hostname=$(hostname)
  ip=$(hostname -I | awk '{print $1}')
  local dialogTitle="$gCOMPANY_NAME Software Module Management Menu"
  
  reset
  ndr_SetLogPolicy $NDR_LOG_POLICY_MODE_GUI
  local refreshModuleStatus=true

  while true; do
    # Temp file
    local tempfile=$(mktemp)
    if [[ "$refreshModuleStatus" == true ]]; then
      mainQueryStatusAll
    fi

    local dialogRadioListText="Current Docker image/container module status:\n\
  Supabase module ($NDR_SUPABASE_APP_SERVICE_NAME_DB_IMAGE_NAME | $NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME):\n\
    $g_supabaseImageStatus, $g_supabaseContainerStatus, $g_supabaseContainerRunning\n\
  Service module ($NDR_SERVICE_IMAGE_NAME:$NDR_SERVICE_IMAGE_VERSION | $NDR_SERVICE_CONTAINER_NAME):\n\
    $g_serviceImageStatus, $g_serviceContainerStatus, $g_serviceContainerRunning\n\
  UI module ($NDR_UI_IMAGE_NAME:$NDR_UI_IMAGE_VERSION | $NDR_UI_CONTAINER_NAME):\n\
    $g_uiImageStatus, $g_uiContainerStatus, $g_uiContainerRunning\n\
Choose one item: (Use arrow keys to move, SPACE to select, ENTER to confirm)"

    local dialogBackTitle="$hostname Installation Status | Supabase: $g_supabaseAppInstalled | Service: $g_serviceAppInstalled | UI: $g_uiAppInstalled | Version: $g_appVersion | IP: $g_hostAddress"
  
    dialog --clear \
    --backtitle "$dialogBackTitle" \
    --title "$dialogTitle" \
    --radiolist "$dialogRadioListText" \
    22 90 8 \
    1 "$ADMIN_MENU_ITEM_1" on \
    2 "$ADMIN_MENU_ITEM_2" off \
    3 "$ADMIN_MENU_ITEM_3" off \
    4 "$ADMIN_MENU_ITEM_4" off \
    5 "$ADMIN_MENU_ITEM_5" off \
    6 "$ADMIN_MENU_ITEM_6" off \
    7 "$ADMIN_MENU_ITEM_7" off \
    8 "$ADMIN_MENU_ITEM_8" off \
    < /dev/tty > /dev/tty 2> "$tempfile" # dialog output to tempfile for selection
    
    local dialog_return_code=$?
    local choice=$(<"$tempfile")
    rm -f "$tempfile"
    
    refreshModuleStatus=false
    
    # Check result
    if [ $dialog_return_code -eq 0 ]; then  
      ndr_logInfo "Dialog option selected: $choice"
    else
      ndr_logInfo "Cancelled."
      reset
      break
    fi
    
    # Validate input
    if ! [[ "$choice" =~ ^[1-$ADMIN_MENU_ITEM_LAST]$ ]]; then
      echo -e "Invalid input, please try again."
      dialog --msgbox "Invalid input, please try again." 6 40 < /dev/tty > /dev/tty 2> /dev/tty
      continue
    fi

    # execute selection
    mainExecuteMenuSelection "$choice"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to execute menu selection."
      dialog --msgbox "Failed to execute menu selection.\nSee log file for details.\n[$gLOG_FILE]" 7 40 < /dev/tty > /dev/tty 2> /dev/tty
      continue
    fi
    #dialog --msgbox "Operation complete, press the Any key to continue..." 6 40 < /dev/tty > /dev/tty 2> /dev/tty
    dialog --ok-label "Any" --msgbox "Operation complete, press the Any key to continue..." 6 40 < /dev/tty > /dev/tty 2> /dev/tty

    refreshModuleStatus=true
  done

  clear

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# ====================================================
# Text based interactive menu mode
# ====================================================
function mainInteractiveMenuMode ()
{
  local logSectionDesc="Executing text based interactive menu mode"
  ndr_logSecStart "$logSectionDesc"
  
  local refreshModuleStatus=true
  while true; do
    if [[ "$refreshModuleStatus" == true ]]; then
      mainQueryStatusAll
    fi
    mainPrintStatusAll
    echo "Please select an option:"
    echo ""
    echo "1. $ADMIN_MENU_ITEM_1"
    echo "2. $ADMIN_MENU_ITEM_2"
    echo "3. $ADMIN_MENU_ITEM_3"
    echo "4. $ADMIN_MENU_ITEM_4"
    echo "5. $ADMIN_MENU_ITEM_5"
    echo "6. $ADMIN_MENU_ITEM_6"
    echo "7. $ADMIN_MENU_ITEM_7"
    echo "8. $ADMIN_MENU_ITEM_8"
    echo "q. Exit"
    echo ""
    read -p "Enter your choice [1-n]: " choice

    refreshModuleStatus=false

    # Validate input
    if ! [[ "$choice" =~ ^[1-$ADMIN_MENU_ITEM_LAST]$ || "$choice" =~ ^[qQ]$ ]]; then
      echo -e "Invalid input, please try again."
      continue
    fi
    if [[ $choice =~ ^[Qq]$ ]]; then
      echo -e "Operation cancelled."
      break
    fi

    mainExecuteMenuSelection "$choice"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to execute menu selection." "$NDR_LOG_POLICY_FORCE_PRINT_TERMINAL"
      continue
    fi

    refreshModuleStatus=true
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainExecuteMenuSelection ()
{
  local logSectionDesc="Executing menu selection"
  ndr_logSecStart "$logSectionDesc"

  # Validate argument count
  if [[ $# -lt 1 ]]; then
    ndr_logError "Usage: function <menu_selection>"
    return 1
  fi

  local choice="$1"
  
  ndr_logInfo "Executing menu selection: $choice"

  local menuItemText=$(getAdminMenuTextByNumber "$choice")
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to translate menu item text."
    return 1
  fi

  ndr_PromptYesNo "$menuItemText. Are you sure you want to proceed?" "$NDR_PROMPT_DEFAULT_INPUT_YES"
  return_code=$?
  if [ $return_code -eq $NDR_PROMPT_RETURN_NO ]; then
    ndr_logInfo "Operation cancelled, returning to main menu."
    return 1
  elif [ $return_code -eq $NDR_PROMPT_RETURN_ERROR ]; then
    ndr_logError "Failed to get user confirmation."
    return 1
  fi

  while true; do
    case $choice in
      1)
        mainStartSupabaseApplication
        ;;
      2)
        mainStartServiceApplication
        ;;
      3)
        mainStartUIApplication
        ;;
      4)
        mainStartAllApplications
        ;;
      5)
        mainStopSupabaseApplication
        ;;
      6)
        mainStopServiceApplication
        ;;
      7)
        mainStopUIApplication
        ;;
      8)
        mainStopAllApplications
        ;;
      *)
        echo "Invalid option. Please try again."
        break
        ;;
    esac
    
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to execute menu selection."
      return 1
    fi

    break
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function main ()
{
  gNDR_ADMIN_MODE=true
  gGUI_MODE=false
  ndr_SetLogPolicy $NDR_LOG_POLICY_MODE_QUIET
  
  mainParseCommandLineArgs "$@"
  return_code=$?
  if [ $return_code != 0 ]; then
    return 1
  fi

  #ndr_osTypeCheck >/dev/null

  if [[ "$gExpressMode" -eq 1  && "$gGUI_MODE" == true ]]; then
    ndr_logWarn "Express install mode is not compatible with graphical mode. Disabling graphical mode and proceeding with express mode."
    gGUI_MODE=false
  fi

  local operation_return_code=0

  if [[ "$gExpressMode" -eq 1  && -n "$gExpressOption" ]]; then
    ndr_logInfo "🕓 Started at $(date)"
    ndr_logInfo "Express install option selected. Skipping all prompts and running with supplied values."
    mainExpressInstallMode
    operation_return_code=$?
    ndr_logInfo "🕓 Finished at $(date)"
    return $operation_return_code
  fi

  if [[ "$gGUI_MODE" == true ]]; then
    mainGraphicalInteractiveMenuMode
    operation_return_code=$?
  else
    ndr_logInfo "🕓 Started at $(date)"
    mainInteractiveMenuMode
    operation_return_code=$?
  fi

  ndr_logInfo "🕓 Finished at $(date)"

  return $operation_return_code
}

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  main "$@"
  return_code=$?
  exit $return_code
fi
