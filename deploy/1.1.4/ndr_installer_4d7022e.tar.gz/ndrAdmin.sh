#!/bin/bash

source "$(dirname "${BASH_SOURCE[0]}")/ndrInterface.sh"
source "$(dirname "${BASH_SOURCE[0]}")/ndrRegistry.sh"
source "$(dirname "${BASH_SOURCE[0]}")/ndrDocker.sh"
source "$(dirname "${BASH_SOURCE[0]}")/ndrSupabase.sh"

# --- CONFIGURATION ---

gLOG_FILE="/var/log/ndrAdmin.log"


EXPRESS_MENU_OPTIONS="startsupabase | startservice | startui | startall | stopsupabase | stopservice | stopui | stopall | status"

# ----------------------

# --- FUNCTIONS ---

function mainStartSupabaseApplication ()
{
  local logSectionDesc="Starting Supabase application"
  ndr_logSecStart "$logSectionDesc"

  # check that app is installed, if not, abort?
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
  local isInstalled=$?
  if [[ "$isInstalled" -ne 0 ]]; then
    if [ "$gEXPRESS_MODE" == false ]; then
      ndr_PromptYesNo "The $gCOMPANY_NAME Supabase database application module does not appear to be officially installed. Would you like to attempt to start the application containers with any local images that may be present?" "$NDR_PROMPT_DEFAULT_INPUT_YES"
      return_code=$?
      if [ $return_code != $NDR_PROMPT_RETURN_YES ]; then
        ndr_logInfo "Operation cancelled, returning to main menu."
        return 1
      fi
    fi
    ndr_logInfo "Proceeding with start."

  else
    ndr_logInfo "Supabase application is currently installed."
  fi

  ndr_PopulateSupabaseServiceMap
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to populate Supabase service map."
    return 1
  fi
  
  if [ ${#ndr_supabase_container_services[@]} -eq 0 ]; then
    ndr_logError "No service entries found in compose or registry to act on."
    return 0
  fi

  # check that images are present
  local allImagesPresent=true
  for service_name in "${ndr_supabase_container_services[@]}"; do
    
    local image_base_name="${ndr_supabase_container_service_image_names[$service_name]}"
    local image_tag="${ndr_supabase_container_service_image_tags[$service_name]}"
    local image_name="$image_base_name:$image_tag"

    ndr_verifyDockerImageExists "$image_base_name" >/dev/null
    return_code=$?
    #2-error, 1-not found, 0-found
    if [ $return_code -ne 0 ]; then
      ndr_logError "Docker image [$image_name] not found."
      allImagesPresent=false
      #return 1
    fi
  done

  if [[ "$allImagesPresent" == false ]]; then
    ndr_logInfo "One ore more images required for this application were not found, exiting."
    return 1
  fi

  # check if containers are already running
  local allContainersPresent=true
  local allContainersRunning=true
  for service_name in "${ndr_supabase_container_services[@]}"; do
    local container_name="${ndr_supabase_container_service_container_names[$service_name]}"
    
    # first check if its running. if so, skip it.
    ndr_verifyDockerContainerRunning "$container_name"
    return_code=$?
    if [ $return_code -eq 0 ]; then
      ndr_logInfo "Docker container [$container_name] is already running."
      continue
    fi
    allContainersRunning=false
    
    # for containers not running, quick sanity check that it exists.
    ndr_verifyDockerContainerExists "$container_name" >/dev/null
    return_code=$?
    #2-error, 1-not found, 0-found
    if [[ $return_code != 0 ]]; then
      # skip if not found
      ndr_logWarn "Docker container '$container_name' not found."
      allContainersPresent=false
    fi
  done

  if [[ "$allContainersRunning" == true ]]; then
    ndr_logInfo "All containers are currently running, exiting."
    return 0
  fi

  if [[ "$allContainersPresent" == false ]]; then
    ndr_logInfo "Once or more required appllication containers not found, exiting."
    return 1
  fi

  # if supabase app is officially installed, we can start it with the compose file from its install dir
  # alternately we can look for it in the devops location.
  # lastly we can try using the hard coded list
  while true; do
    local homeDir

    if [[ "$isInstalled" -eq 0 ]]; then
      ndr_logInfo "Starting Supabase from install location."

      homeDir=$(ndr_getHomeDirReg)
      return_code=$?
      if [[ $return_code -ne 0 || -z "$homeDir" ]]; then
        ndr_logError "Failed to retrieve home dir from registry."
        return 1
      fi
      gNEXTDR_HOME_DIR="$homeDir"
      gSUPABASE_NEXTDR_HOME="${gNEXTDR_HOME_DIR}/${gSUPABASE_NEXTDR_SUB}"
      ndr_logInfo "$gNEXTDR_HOME_DIR $gSUPABASE_NEXTDR_HOME"
      #gSUPABASE_TEMPLATE_HOME="${gNEXTDR_HOME_DIR}/${gSUPABASE_TEMPLATE_SUB}"
      break
    fi

    # check for a supabase home dir under the pwd/script dir. This is common when running it from the devops script.
    homeDir="${gSCRIPT_HOME_DIR}"
    local supabaseHomeDir="${homeDir}/${gSUPABASE_NEXTDR_SUB}"
    local DEVOPS_COMPOSE_FILE="${supabaseHomeDir}/docker-compose.yml"
    if [[ -d "$supabaseHomeDir" && -f "$DEVOPS_COMPOSE_FILE" ]]; then
      ndr_logInfo "Starting Supabase from devops location."

      gNEXTDR_HOME_DIR="$homeDir"
      gSUPABASE_NEXTDR_HOME="${supabaseHomeDir}"
      break
    fi

    break
  done

  if [[ -z "$gNEXTDR_HOME_DIR" || -z "$gSUPABASE_NEXTDR_HOME" ]]; then
    ndr_logError "Invalid home or project directory."
    return 1
  fi

  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }

  # start them
  ndr_ComposeSupabaseDockerContainers #"$NDR_START_SUPABASE_DOCKER_CONTAINER_OPTION_NO_RECREATE"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to start Supabase $gCOMPANY_NAME Docker containers."
    return 1
  fi

  # check if the newly built Docker containers exist
  ndr_verifySupabaseContainersExist
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Docker container verification failed."
    return 1
  fi
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainStartServiceApplication ()
{
  local logSectionDesc="Starting Service application"
  ndr_logSecStart "$logSectionDesc"

  local moduleRegistryName="$gREGISTRY_ENTRY_MODULE_STATUS_SERVICE_NAME"
  local containerFolder="$NDR_SERVICE_HOME_LOC"
  local repoName="$NDR_DOCKER_SERVICE_PUBLIC_REPO_NAME"
  local dockerImageBaseName="$NDR_SERVICE_IMAGE_NAME"
  local dockerImageVersion="$NDR_SERVICE_IMAGE_VERSION"
  local dockerContainerName="$NDR_SERVICE_CONTAINER_NAME"
  local dockerContainerPort="$NDR_SERVICE_CONTAINER_PORT"
  
  dockerImageVersion=$(ndr_QueryContainerImageVersionTag "$dockerContainerName")
  return_code=$?
  if [[ $return_code -ne 0 || -z "$dockerImageVersion" ]]; then
    ndr_logError "Failed to retrieve image name for container [$dockerContainerName]."
    return 1
  fi

  ndr_StartApplication "$moduleRegistryName" "$containerFolder" "$repoName" "$dockerImageBaseName" "$dockerImageVersion" "$dockerContainerName" "$dockerContainerPort"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to start Docker container application [$dockerContainerName]."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainStartUIApplication ()
{
  local logSectionDesc="Starting UI application"
  ndr_logSecStart "$logSectionDesc"
  
  local moduleRegistryName="$gREGISTRY_ENTRY_MODULE_STATUS_UI_NAME"
  local containerFolder="$NDR_UI_HOME_LOC"
  local repoName="$NDR_DOCKER_UI_PUBLIC_REPO_NAME"
  local dockerImageBaseName="$NDR_UI_IMAGE_NAME"
  local dockerImageVersion="$NDR_UI_IMAGE_VERSION"
  local dockerContainerName="$NDR_UI_CONTAINER_NAME"
  local dockerContainerPort="$NDR_UI_CONTAINER_PORT"
  
  dockerImageVersion=$(ndr_QueryContainerImageVersionTag "$dockerContainerName")
  return_code=$?
  if [[ $return_code -ne 0 || -z "$dockerImageVersion" ]]; then
    ndr_logError "Failed to retrieve image name for container [$dockerContainerName]."
    return 1
  fi
  
  ndr_StartApplication "$moduleRegistryName" "$containerFolder" "$repoName" "$dockerImageBaseName" "$dockerImageVersion" "$dockerContainerName" "$dockerContainerPort"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to start Docker container application [$dockerContainerName]."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function <module_registry_name> <folder> <repo_name> <image_base_name> <image_version> <container_name> <container_port>
function ndr_StartApplication ()
{
  local logSectionDesc="Starting application"
  ndr_logSecStart "$logSectionDesc"

  local moduleRegistryName="$1"
  local containerFolder="$2"
  local repoAccount="$NDR_DOCKER_REPO_ACCOUNT"
  local repoName="$3"
  local dockerImageBaseName="$4"
  local dockerImageVersion="$5"
  #local dockerImageName="${dockerImageBaseName}_${dockerImageVersion}"
  local dockerImageName="${repoAccount}/${repoName}:${dockerImageBaseName}_${dockerImageVersion}"
  local dockerContainerName="$6"
  local dockerContainerPort="$7"
  local dockerContainerURL="http://localhost:$dockerContainerPort"
  
  # Validate argument count
  if [[ $# -lt 7 ]]; then
    ndr_logError "Usage: function <module_registry_name> <folder> <repo_name> <image_base_name> <image_version> <container_name> <container_port>"
    return 1
  fi

  # check that app is installed, if not, abort?
  ndr_isModuleInstalledReg "$moduleRegistryName"
  local isInstalled=$?
  if [[ "$isInstalled" -ne 0 ]]; then
    if [ "$gEXPRESS_MODE" == false ]; then
      ndr_PromptYesNo "The $gCOMPANY_NAME application module $dockerContainerName does not appear to be officially installed. Would you like to attempt to start the application containers with any local images that may be present?" "$NDR_PROMPT_DEFAULT_INPUT_YES"
      return_code=$?
      if [ $return_code != $NDR_PROMPT_RETURN_YES ]; then
        ndr_logInfo "Operation cancelled, returning to main menu."
        return 1
      fi
    fi
    ndr_logInfo "Proceeding with start."

  else
    ndr_logInfo "Application is currently installed."
  fi

  ndr_verifyDockerContainerRunning "$dockerContainerName" "$dockerContainerPort"
  return_code=$?
  if [ $return_code -eq 0 ]; then
    ndr_logInfo "Docker container [$dockerContainerName] is already running."
    return 0
  fi
  
  # check if the Docker image exists. This must exist to perform any further actions.
  ndr_verifyDockerImageExists "$dockerImageName"
  return_code=$?
  #2-error, 1-not found, 0-found
  if [ $return_code -ne 0 ]; then
    ndr_logError "Docker image [$dockerImageName] not found."
    return 1
  fi
  
  # check if the Docker container exists and is running
  local containerExists=true
  ndr_verifyDockerContainerExists "$dockerContainerName"
  return_code=$?
  #2-error, 1-not found, 0-found
  if [ $return_code -ne 0 ]; then
    # if the container no longer exists, we would need to rebuild
    containerExists=false
  fi

  if [ "$gNDR_RECREATE_DOCKER_CONTAINERS" == true ]; then
    ndr_logInfo "Option to recreate Docker containers is enabled. Will recreate [$dockerContainerName] instead of starting existing."
    # flag this container to be rebuilt
    containerExists=false
  fi

  if [[ "$containerExists" == true ]]; then
    # container is present, but not running, we simply do a container start.
    ndr_logInfo "Docker container [$dockerContainerName] already exists, starting..."
    docker container start "$dockerContainerName"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to start Docker container [$dockerContainerName]."
      return 1
    fi
  else
    if [ "$gEXPRESS_MODE" == false ]; then
      ndr_PromptYesNo "The application module container $dockerContainerName requires rebuilding. Would you like to attempt to rebuild the application container with any local images that may be present?" "$NDR_PROMPT_DEFAULT_INPUT_YES"
      return_code=$?
      if [ $return_code != $NDR_PROMPT_RETURN_YES ]; then
        ndr_logInfo "Operation cancelled, returning to main menu."
        return 1
      fi
    fi

    # container does not exist, need to recreate
    ndr_logInfo "Docker container [$dockerContainerName] does not exist or requires rebuilding. Recomposing containers..."
    
    local containerHomeDir=$(ndr_getHomeDirForImageName "$dockerImageBaseName" "$containerFolder")
    
    # run container from image
    ndr_ComposeDockerApplicationContainer "$containerHomeDir" "$dockerImageBaseName" "$dockerImageVersion" "$dockerContainerName" "$dockerContainerPort"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to start Docker container [$dockerContainerName]."
      return 1
    fi
  fi

  ndr_logInfo "Docker container [$dockerContainerName] successfully started."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainStartAllApplications ()
{
  local logSectionDesc="Starting all applications"
  ndr_logSecStart "$logSectionDesc"

  local allApplicationsStarted=true
  while true; do
    mainStartSupabaseApplication
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to start Supabase application."
      allApplicationsStarted=false
    fi

    mainStartServiceApplication
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to start Service application."
      allApplicationsStarted=false
    fi

    mainStartUIApplication
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to start UI application."
      allApplicationsStarted=false
    fi

    break
  done

  if [[ "$allApplicationsStarted" == false ]]; then
    ndr_logError "Unable to start one or more of the required application containers."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainStopSupabaseApplication ()
{
  local logSectionDesc="Stopping Supabase application"
  ndr_logSecStart "$logSectionDesc"

  # check that app is installed, if not, abort?
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
  local isInstalled=$?
  if [[ "$isInstalled" -ne 0 ]]; then
    if [ "$gEXPRESS_MODE" == false ]; then
      ndr_PromptYesNo "The $gCOMPANY_NAME Supabase database application module does not appear to be officially installed. Would you like to attempt to stop any local application containers that may be present?" "$NDR_PROMPT_DEFAULT_INPUT_YES"
      return_code=$?
      if [ $return_code != $NDR_PROMPT_RETURN_YES ]; then
        ndr_logInfo "Operation cancelled, returning to main menu."
        return 1
      fi
    fi
    ndr_logInfo "Proceeding with stop."

  else
    ndr_logInfo "Supabase application is currently installed."
  fi

  ndr_PopulateSupabaseServiceMap
  return_code=$?
  if [[ $return_code -ne 0 ]]; then
    ndr_logError "Failed to populate Supabase service map."
    return 1
  fi
  
  if [ ${#ndr_supabase_container_services[@]} -eq 0 ]; then
    ndr_logError "No service entries found in compose or registry to act on."
    return 0
  fi

  # Check all containers
  local allContainersStopped=true
  for service_name in "${ndr_supabase_container_services[@]}"; do
    local dockerContainerName="${ndr_supabase_container_service_container_names[$service_name]}"
    
    # first verify container exists
    ndr_verifyDockerContainerExists "$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME" >/dev/null
    return_code=$?
    #2-error, 1-not found, 0-found
    if [[ $return_code != 0 ]]; then
      # skip if not found
      ndr_logWarn "Docker container '$dockerContainerName' not found."
      allContainersStopped=false
      continue
    fi

    # determine if container is already stopped
    ndr_verifyDockerContainerRunning "$dockerContainerName"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logInfo "Docker container [$dockerContainerName] is already stopped."
      continue
    fi
    
    # container is present, but not running, we simply do a container stop.
    ndr_logInfo "Stopping Docker container [$dockerContainerName]..."
    docker container stop "$dockerContainerName"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logWarn "Docker container [$dockerContainerName] failed to stop."
      allContainersStopped=false
      continue
    fi
    
    ndr_verifyDockerContainerRunning "$dockerContainerName" "$dockerContainerPort"
    return_code=$?
    if [ $return_code -eq 0 ]; then
      ndr_logWarn "Docker container [$dockerContainerName] is still running."
      allContainersStopped=false
      continue
    fi

    ndr_logInfo "Docker container [$dockerContainerName] successfully stopped."
  done

  if [[ "$allContainersStopped" == false ]]; then
    ndr_logInfo "Unable to stop one or more of the required application containers."
    return 1
  fi
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainStopServiceApplication ()
{
  local logSectionDesc="Stopping Service application"
  ndr_logSecStart "$logSectionDesc"

  local moduleRegistryName="$gREGISTRY_ENTRY_MODULE_STATUS_SERVICE_NAME"
  local dockerContainerName="$NDR_SERVICE_CONTAINER_NAME"
  local dockerContainerPort="$NDR_SERVICE_CONTAINER_PORT"

  ndr_StopApplication "$moduleRegistryName" "$dockerContainerName" "$dockerContainerPort"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to stop Docker container application [$dockerContainerName]."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainStopUIApplication ()
{
  local logSectionDesc="Stopping UI application"
  ndr_logSecStart "$logSectionDesc"

  local moduleRegistryName="$gREGISTRY_ENTRY_MODULE_STATUS_UI_NAME"
  local dockerContainerName="$NDR_UI_CONTAINER_NAME"
  local dockerContainerPort="$NDR_UI_CONTAINER_PORT"

  ndr_StopApplication "$moduleRegistryName" "$dockerContainerName" "$dockerContainerPort"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to stop Docker container application [$dockerContainerName]."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function <module_registry_name> <container_name> <container_port>
function ndr_StopApplication ()
{
  local logSectionDesc="Stopping application"
  ndr_logSecStart "$logSectionDesc"

  local moduleRegistryName="$1"
  local dockerContainerName="$2"
  local dockerContainerPort="$3"
  local dockerContainerURL="http://localhost:$dockerContainerPort"
  
  # Validate argument count
  if [[ $# -lt 3 ]]; then
    ndr_logError "Usage: function <module_registry_name> <container_name> <container_port>"
    return 1
  fi

  # check that app is installed, if not, abort?
  ndr_isModuleInstalledReg "$moduleRegistryName"
  local isInstalled=$?
  if [[ "$isInstalled" -ne 0 ]]; then
    if [ "$gEXPRESS_MODE" == false ]; then
      ndr_PromptYesNo "The $gCOMPANY_NAME application module $dockerContainerName does not appear to be officially installed. Would you like to attempt to stop any matching local application containers that may be present?" "$NDR_PROMPT_DEFAULT_INPUT_YES"
      return_code=$?
      if [ $return_code != $NDR_PROMPT_RETURN_YES ]; then
        ndr_logInfo "Operation cancelled, returning to main menu."
        return 1
      fi
    fi
    ndr_logInfo "Proceeding with stop."

  else
    ndr_logInfo "Application is currently installed."
  fi

  # check if the Docker container exists and is running
  ndr_verifyDockerContainerExists "$dockerContainerName"
  return_code=$?
  #2-error, 1-not found, 0-found
  if [ $return_code -ne 0 ]; then
    # if the container no longer exists, nothing to do
    ndr_logWarn "Docker container [$dockerContainerName] not found."
    return 1
  fi

  ndr_verifyDockerContainerRunning "$dockerContainerName" "$dockerContainerPort"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logInfo "Docker container [$dockerContainerName] is already stopped."
    return 0
  fi
  
  # container is present, but not running, we simply do a container stop.
  ndr_logInfo "Stopping Docker container [$dockerContainerName]..."
  docker container stop "$dockerContainerName"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logWarn "Docker container [$dockerContainerName] failed to stop."
    return 1
  fi
  ndr_logInfo "Docker container [$dockerContainerName] stopped."

  ndr_verifyDockerContainerRunning "$dockerContainerName" "$dockerContainerPort"
  return_code=$?
  if [ $return_code -eq 0 ]; then
    ndr_logWarn "Docker container [$dockerContainerName] is still running."
    return 1
  fi

  ndr_logInfo "Docker container [$dockerContainerName] successfully stopped."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainStopAllApplications ()
{
  local logSectionDesc="Stopping all applications"
  ndr_logSecStart "$logSectionDesc"

  local allApplicationsStopped=true
  while true; do
    mainStopUIApplication
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to stop UI application."
      allApplicationsStopped=false
    fi

    mainStopServiceApplication
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to stop Service application."
      allApplicationsStopped=false
    fi

    mainStopSupabaseApplication
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to stop Supabase application."
      allApplicationsStopped=false
    fi

    break
  done

  if [[ "$allApplicationsStopped" == false ]]; then
    ndr_logError "Unable to stop one or more of the required application containers."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainQueryStatusAll ()
{
  ndr_UpdateModuleInstallStatus
  ndr_UpdateModuleDockerStatus
  
  return 0
}

function mainPrintStatusAll ()
{
  echo "===================================================================="
  echo "$gCOMPANY_NAME $gPRODUCT_VERSION Software Module Management Menu"
  ndr_DisplayModuleDockerStatus
  ndr_DisplayModuleInstallStatus
  echo "===================================================================="

  return 0
}

function mainCreateLocalRegistry ()
{
  local logSectionDesc="Creating local registry"
  ndr_logSecStart "$logSectionDesc"

  ndr_LocalDockerRegistryCreate
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create Local Docker Registry."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainPopulateLocalRegistry ()
{
  local logSectionDesc="Populating local registry"
  ndr_logSecStart "$logSectionDesc"

  ndr_LocalDockerRegistryPopulate
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to populate Local Docker Registry."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainQueryLocalRegistry ()
{
  local logSectionDesc="Querying local registry"
  ndr_logSecStart "$logSectionDesc"

  ndr_LocalDockerRegistryQuery
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to query Local Docker Registry."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}



function mainRemoveLocalRegistry ()
{
  local logSectionDesc="Removing local registry"
  ndr_logSecStart "$logSectionDesc"

  ndr_LocalDockerRegistryRemove
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to remove Local Docker Registry."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainPopulateGCPRegistry ()
{
  local logSectionDesc="Populating GCP artifact registry"
  ndr_logSecStart "$logSectionDesc"

  ndr_GCPDockerRegistryPopulate
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to populate GCP Docker Artifact Registry."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainQueryGCPRegistry ()
{
  local logSectionDesc="Querying GCP artifact registry"
  ndr_logSecStart "$logSectionDesc"

  ndr_GCPDockerRegistryQuery
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to query GCP Docker Artifact Registry."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# ====================================================
# command line parsing
# ====================================================
function mainParseCommandLineArgs ()
{
  local logSectionDesc="Parsing command line arguments"
  ndr_logSecStart "$logSectionDesc"

  # Default values
  
  ndr_parseCommandLineArgs "$@"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to parse common command line args."
    return 1
  fi
  
  # Parse arguments
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --help|-h)
        ndr_logWarn "Usage: $0 --express <$EXPRESS_MENU_OPTIONS> --password <password> [--debug]."
        return 1
        ;;
      --recreate|--recreate-container)
        gNDR_RECREATE_DOCKER_CONTAINERS=true
        ndr_logInfo "Option to recreate Docker containers on module start is enabled."
        shift
        ;;
      --locregname|--privregname)
        if [[ -n "$2" && "$2" != --* ]]; then
          gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME="$2"
          ndr_logInfo "Local Docker Registry container name set to [$gNDR_DOCKER_LOCAL_REGISTRY_CONTAINER_NAME]."
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      --locregdir|--privregdir)
        if [[ -n "$2" && "$2" != --* ]]; then
          gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR="$2"
          ndr_logInfo "Local Docker Registry data dir set to [$gNDR_DOCKER_LOCAL_REGISTRY_DATA_DIR]."
          shift 2
        else
          ndr_logError "$1 requires a value."
          return 1
        fi
        ;;
      *)
        #ndr_logError "Unknown option: $1"
        shift
        ;;
    esac
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# ====================================================
# Express mode
# ====================================================
function mainExpressAdminMode ()
{
  local logSectionDesc="Executing express admin mode"
  ndr_logSecStart "$logSectionDesc"

  # Check if express mode is enabled and an option is provided
  if [ "$gEXPRESS_MODE" == false ]; then
    ndr_logError "Express mode is not enabled. Use --express to enable."
    return 1
  fi
  if [ -z "$gExpressOption" ]; then
    ndr_logError "No express option provided. Use --express <option>."
    return 1
  fi

  case "$gExpressOption" in
    startsupabase|startdb)
      mainStartSupabaseApplication
      ;;
    startservice|startsvc)
      mainStartServiceApplication
      ;;
    startui)
      mainStartUIApplication
      ;;
    startall)
      mainStartAllApplications
      ;;
    stopsupabase|stopdb)
      mainStopSupabaseApplication
      ;;
    stopservice|stopsvc)
      mainStopServiceApplication
      ;;
    stopui)
      mainStopUIApplication
      ;;
    stopall)
      mainStopAllApplications
      ;;
    status)
      mainQueryStatusAll
      mainPrintStatusAll
      ;;
    createlocalregistry|clr)
      mainCreateLocalRegistry
      ;;
    populatelocalregistry|plr)
      mainPopulateLocalRegistry
      ;;
    querylocalregistry|qlr)
      mainQueryLocalRegistry
      ;;
    removelocalregistry|rlr)
      mainRemoveLocalRegistry
      ;;
    populategcpregistry|pgcpr)
      mainPopulateGCPRegistry
      ;;
    querygcpregistry|qgcpr)
      mainQueryGCPRegistry
      ;;
    
    *)
      # print usage and exit
      ndr_logWarn "Invalid option. Please use one of the following options: $EXPRESS_MENU_OPTIONS"
      return 1
      ;;
  esac
  
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to execute selection."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# basic menu items
menuIdx=0
NDR_ADMIN_MENU_OPTION_IDX_NONE=$menuIdx
menuIdx=$((menuIdx+1))
NDR_ADMIN_MENU_OPTION_IDX_START_DB=$menuIdx
NDR_ADMIN_MENU_OPTION_DESC_START_DB="Start the $gCOMPANY_NAME Supabase database application container"
menuIdx=$((menuIdx+1))
NDR_ADMIN_MENU_OPTION_IDX_START_SERVICE=$menuIdx
NDR_ADMIN_MENU_OPTION_DESC_START_SERVICE="Start the $gCOMPANY_NAME Service application container"
menuIdx=$((menuIdx+1))
NDR_ADMIN_MENU_OPTION_IDX_START_UI=$menuIdx
NDR_ADMIN_MENU_OPTION_DESC_START_UI="Start the $gCOMPANY_NAME UI application container"
menuIdx=$((menuIdx+1))
NDR_ADMIN_MENU_OPTION_IDX_START_ALL=$menuIdx
NDR_ADMIN_MENU_OPTION_DESC_START_ALL="Start all $gCOMPANY_NAME module containers"
menuIdx=$((menuIdx+1))
NDR_ADMIN_MENU_OPTION_IDX_STOP_DB=$menuIdx
NDR_ADMIN_MENU_OPTION_DESC_STOP_DB="Stop the $gCOMPANY_NAME Supabase database application container"
menuIdx=$((menuIdx+1))
NDR_ADMIN_MENU_OPTION_IDX_STOP_SERVICE=$menuIdx
NDR_ADMIN_MENU_OPTION_DESC_STOP_SERVICE="Stop the $gCOMPANY_NAME Service application container"
menuIdx=$((menuIdx+1))
NDR_ADMIN_MENU_OPTION_IDX_STOP_UI=$menuIdx
NDR_ADMIN_MENU_OPTION_DESC_STOP_UI="Stop the $gCOMPANY_NAME UI application container"
menuIdx=$((menuIdx+1))
NDR_ADMIN_MENU_OPTION_IDX_STOP_ALL=$menuIdx
NDR_ADMIN_MENU_OPTION_DESC_STOP_ALL="Stop all $gCOMPANY_NAME module containers"
menuIdx=$((menuIdx+1))

# local docker registry items
NDR_ADMIN_MENU_OPTION_IDX_CREATE_LOCAL_REGISTRY=$menuIdx
NDR_ADMIN_MENU_OPTION_DESC_CREATE_LOCAL_REGISTRY="Create local $gCOMPANY_NAME Local Docker Registry"
menuIdx=$((menuIdx+1))
NDR_ADMIN_MENU_OPTION_IDX_POPULATE_LOCAL_REGISTRY=$menuIdx
NDR_ADMIN_MENU_OPTION_DESC_POPULATE_LOCAL_REGISTRY="Populate local $gCOMPANY_NAME Local Docker Registry with application images"
menuIdx=$((menuIdx+1))
NDR_ADMIN_MENU_OPTION_IDX_QUERY_LOCAL_REGISTRY=$menuIdx
NDR_ADMIN_MENU_OPTION_DESC_QUERY_LOCAL_REGISTRY="Query local $gCOMPANY_NAME Local Docker Registry for application images"
menuIdx=$((menuIdx+1))
NDR_ADMIN_MENU_OPTION_IDX_DELETE_LOCAL_REGISTRY_IMAGE=$menuIdx
NDR_ADMIN_MENU_OPTION_DESC_DELETE_LOCAL_REGISTRY_IMAGE="Delete an image from the local $gCOMPANY_NAME Local Docker Registry"
menuIdx=$((menuIdx+1))
NDR_ADMIN_MENU_OPTION_IDX_REMOVE_LOCAL_REGISTRY=$menuIdx
NDR_ADMIN_MENU_OPTION_DESC_REMOVE_LOCAL_REGISTRY="Remove local $gCOMPANY_NAME Local Docker Registry and its images"

# GCP/google cloud artifact registry
menuIdx=$((menuIdx+1))
NDR_ADMIN_MENU_OPTION_IDX_POPULATE_GCP_REGISTRY=$menuIdx
NDR_ADMIN_MENU_OPTION_DESC_POPULATE_GCP_REGISTRY="Populate $gCOMPANY_NAME GCP Docker Artifact Registry with application images"
menuIdx=$((menuIdx+1))
NDR_ADMIN_MENU_OPTION_IDX_QUERY_GCP_REGISTRY=$menuIdx
NDR_ADMIN_MENU_OPTION_DESC_QUERY_GCP_REGISTRY="Query $gCOMPANY_NAME GCP Docker Arifact Registry for application images"

# ====================================================
# Text based interactive menu mode
# ====================================================
function mainInteractiveMenuMode ()
{
  local logSectionDesc="Executing text based interactive menu mode"
  ndr_logSecStart "$logSectionDesc"
  
  declare -a menuItem=() # primary array to hold menu item indices and actions
  declare -A menuItemDesc=() # associative array to hold menu item descriptions

  # add basic menu items
  local menuIdx=1
  menuItem[$menuIdx]="$NDR_ADMIN_MENU_OPTION_IDX_START_DB"
  menuItemDesc[$menuIdx]="$NDR_ADMIN_MENU_OPTION_DESC_START_DB"
  menuIdx=$((menuIdx+1))
  menuItem[$menuIdx]="$NDR_ADMIN_MENU_OPTION_IDX_START_SERVICE"
  menuItemDesc[$menuIdx]="$NDR_ADMIN_MENU_OPTION_DESC_START_SERVICE"
  menuIdx=$((menuIdx+1))
  menuItem[$menuIdx]="$NDR_ADMIN_MENU_OPTION_IDX_START_UI"
  menuItemDesc[$menuIdx]="$NDR_ADMIN_MENU_OPTION_DESC_START_UI"
  menuIdx=$((menuIdx+1))
  menuItem[$menuIdx]="$NDR_ADMIN_MENU_OPTION_IDX_START_ALL"
  menuItemDesc[$menuIdx]="$NDR_ADMIN_MENU_OPTION_DESC_START_ALL"
  menuIdx=$((menuIdx+1))
  menuItem[$menuIdx]="$NDR_ADMIN_MENU_OPTION_IDX_STOP_DB"
  menuItemDesc[$menuIdx]="$NDR_ADMIN_MENU_OPTION_DESC_STOP_DB"
  menuIdx=$((menuIdx+1))
  menuItem[$menuIdx]="$NDR_ADMIN_MENU_OPTION_IDX_STOP_SERVICE"
  menuItemDesc[$menuIdx]="$NDR_ADMIN_MENU_OPTION_DESC_STOP_SERVICE"
  menuIdx=$((menuIdx+1))
  menuItem[$menuIdx]="$NDR_ADMIN_MENU_OPTION_IDX_STOP_UI"
  menuItemDesc[$menuIdx]="$NDR_ADMIN_MENU_OPTION_DESC_STOP_UI"
  menuIdx=$((menuIdx+1))
  menuItem[$menuIdx]="$NDR_ADMIN_MENU_OPTION_IDX_STOP_ALL"
  menuItemDesc[$menuIdx]="$NDR_ADMIN_MENU_OPTION_DESC_STOP_ALL"

  # add advanced menu items if advanced mode is enabled
  if [[ "$gNDR_ADVANCED_MODE" == true ]]; then
    menuIdx=$((menuIdx+1))
    menuItem[$menuIdx]="$NDR_ADMIN_MENU_OPTION_IDX_CREATE_LOCAL_REGISTRY"
    menuItemDesc[$menuIdx]="$NDR_ADMIN_MENU_OPTION_DESC_CREATE_LOCAL_REGISTRY"
    menuIdx=$((menuIdx+1))
    menuItem[$menuIdx]="$NDR_ADMIN_MENU_OPTION_IDX_POPULATE_LOCAL_REGISTRY"
    menuItemDesc[$menuIdx]="$NDR_ADMIN_MENU_OPTION_DESC_POPULATE_LOCAL_REGISTRY"
    menuIdx=$((menuIdx+1))
    menuItem[$menuIdx]="$NDR_ADMIN_MENU_OPTION_IDX_QUERY_LOCAL_REGISTRY"
    menuItemDesc[$menuIdx]="$NDR_ADMIN_MENU_OPTION_DESC_QUERY_LOCAL_REGISTRY"
    menuIdx=$((menuIdx+1))
    menuItem[$menuIdx]="$NDR_ADMIN_MENU_OPTION_IDX_DELETE_LOCAL_REGISTRY_IMAGE"
    menuItemDesc[$menuIdx]="$NDR_ADMIN_MENU_OPTION_DESC_DELETE_LOCAL_REGISTRY_IMAGE"
    menuIdx=$((menuIdx+1))
    menuItem[$menuIdx]="$NDR_ADMIN_MENU_OPTION_IDX_REMOVE_LOCAL_REGISTRY"
    menuItemDesc[$menuIdx]="$NDR_ADMIN_MENU_OPTION_DESC_REMOVE_LOCAL_REGISTRY"

    menuIdx=$((menuIdx+1))
    menuItem[$menuIdx]="$NDR_ADMIN_MENU_OPTION_IDX_POPULATE_GCP_REGISTRY"
    menuItemDesc[$menuIdx]="$NDR_ADMIN_MENU_OPTION_DESC_POPULATE_GCP_REGISTRY"
    menuIdx=$((menuIdx+1))
    menuItem[$menuIdx]="$NDR_ADMIN_MENU_OPTION_IDX_QUERY_GCP_REGISTRY"
    menuItemDesc[$menuIdx]="$NDR_ADMIN_MENU_OPTION_DESC_QUERY_GCP_REGISTRY"
  fi

  local refreshModuleStatus=true
  while true; do
    if [[ "$refreshModuleStatus" == true ]]; then
      mainQueryStatusAll
    fi
    mainPrintStatusAll
    echo "Please select an option:"
    echo ""
    for idx in "${!menuItem[@]}"; do
        echo "$idx. ${menuItemDesc[$idx]}"
      done
    echo "q. Exit"
    echo ""
    read -p "Enter your choice [1-n]: " choice

    refreshModuleStatus=false

     # check for non-numerical choice (exit, test, etc)
    if ! [[ "$choice" =~ ^[0-9]+$ ]]; then
      if [[ "$choice" == "q" || "$choice" == "Q" ]]; then
        ndr_logInfo "Exiting installer."
        break
      fi
    fi

    # translate numerical choice index to menu item index
    local action="${menuItem[$choice]}"
    local actionDesc="${menuItemDesc[$choice]}"
    ndr_logDebug "User selected menu choice [$choice] -> action [$action] : [$actionDesc]"
    if [[ "$action" -eq "$NDR_ADMIN_MENU_OPTION_IDX_NONE" ]]; then
      ndr_logWarn "Invalid selection [$choice], please try again."
      continue
    fi

    mainExecuteMenuSelection "$action" "$actionDesc"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to execute menu selection." "$NDR_LOG_POLICY_FORCE_PRINT_TERMINAL"
      continue
    fi

    refreshModuleStatus=true
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function mainExecuteMenuSelection ()
{
  local logSectionDesc="Executing menu selection"
  ndr_logSecStart "$logSectionDesc"

  # Validate argument count
  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <menu_selection> <menu_selection_description>"
    return 1
  fi

  local action="$1"
  local actionDesc="$2"
  
  ndr_logInfo "Executing menu selection: $action"

  ndr_PromptYesNo "$actionDesc. Are you sure you want to proceed?" "$NDR_PROMPT_DEFAULT_INPUT_YES"
  return_code=$?
  if [ $return_code -eq $NDR_PROMPT_RETURN_NO ]; then
    ndr_logInfo "Operation cancelled, returning to main menu."
    return 1
  elif [ $return_code -eq $NDR_PROMPT_RETURN_ERROR ]; then
    ndr_logError "Failed to get user confirmation."
    return 1
  fi

  while true; do
    case $action in
      "$NDR_ADMIN_MENU_OPTION_IDX_START_DB")
        mainStartSupabaseApplication
        ;;
      "$NDR_ADMIN_MENU_OPTION_IDX_START_SERVICE")
        mainStartServiceApplication
        ;;
      "$NDR_ADMIN_MENU_OPTION_IDX_START_UI")
        mainStartUIApplication
        ;;
      "$NDR_ADMIN_MENU_OPTION_IDX_START_ALL")
        mainStartAllApplications
        ;;
      "$NDR_ADMIN_MENU_OPTION_IDX_STOP_DB")
        mainStopSupabaseApplication
        ;;
      "$NDR_ADMIN_MENU_OPTION_IDX_STOP_SERVICE")
        mainStopServiceApplication
        ;;
      "$NDR_ADMIN_MENU_OPTION_IDX_STOP_UI")
        mainStopUIApplication
        ;;
      "$NDR_ADMIN_MENU_OPTION_IDX_STOP_ALL")
        mainStopAllApplications
        ;;
      "$NDR_ADMIN_MENU_OPTION_IDX_CREATE_LOCAL_REGISTRY")
        mainCreateLocalRegistry
        ;;
      "$NDR_ADMIN_MENU_OPTION_IDX_POPULATE_LOCAL_REGISTRY")
        mainPopulateLocalRegistry
        ;;
      "$NDR_ADMIN_MENU_OPTION_IDX_QUERY_LOCAL_REGISTRY")
        mainQueryLocalRegistry
        ;;
      "$NDR_ADMIN_MENU_OPTION_IDX_DELETE_LOCAL_REGISTRY_IMAGE")
        ndr_LocalDockerRegistryDeleteImage
        ;;
      "$NDR_ADMIN_MENU_OPTION_IDX_REMOVE_LOCAL_REGISTRY")
        mainRemoveLocalRegistry
        ;;
      "$NDR_ADMIN_MENU_OPTION_IDX_POPULATE_GCP_REGISTRY")
        mainPopulateGCPRegistry
        ;;
      "$NDR_ADMIN_MENU_OPTION_IDX_QUERY_GCP_REGISTRY")
        mainQueryGCPRegistry
        ;;
      *)
        echo "Invalid option. Please try again."
        break
        ;;
    esac
    
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to execute menu selection."
      return 1
    fi

    break
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function main ()
{
  gNDR_ADMIN_MODE=true
  ndr_SetLogPolicy $NDR_LOG_POLICY_MODE_QUIET
  
  mainParseCommandLineArgs "$@"
  return_code=$?
  if [ $return_code != 0 ]; then
    return 1
  fi

  local operation_return_code=0

  if [[ "$gEXPRESS_MODE" == true  && -n "$gExpressOption" ]]; then
    ndr_logInfo "🕓 Started at $(date)"
    ndr_logInfo "Express option selected. Skipping all prompts and running with supplied values."
    mainExpressAdminMode
    operation_return_code=$?
    ndr_logInfo "🕓 Finished at $(date)"
    return $operation_return_code
  fi

  ndr_logInfo "🕓 Started at $(date)"
  echo "Please wait, initializing current image and container inventory and installation status..."
  mainInteractiveMenuMode
  operation_return_code=$?

  ndr_logInfo "🕓 Finished at $(date)"

  return $operation_return_code
}

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  main "$@"
  return_code=$?
  exit $return_code
fi
