--
-- NextDR Supabase Database Schema 
-- NDR-SCHEMA-VERSION: 1.1.4
-- NDR-UPGRADE-FROM: 1.1.3
-- NDR-SCHEMA-TYPE: INCR
-- NDR-FULL-BASELINE-SCHEMA-SHA256: dd01f609bc8743f4a8a6ff3fc9c35c813c1ba579eae600ab93ada26ee40c3232
-- NDR-FULL-UPGRADE-SCHEMA-SHA256: 914650d0b3688fc68f9283b624d8d8e8b6b8df5a2513e13d82ff9c033dd51d5e
--

drop policy "Users can view their own SMTP settings" on "public"."smtp_settings";

drop policy "Users can view own profile" on "public"."user_profiles";

drop policy "Users can view own role" on "public"."user_profiles";

alter table "public"."smtp_settings" drop constraint "unique_user_smtp_settings";

drop index if exists "public"."unique_user_smtp_settings";

alter table "public"."smtp_settings" alter column "user_id" drop not null;

CREATE UNIQUE INDEX idx_smtp_single_system ON public.smtp_settings USING btree ((true)) WHERE (user_id IS NULL);

create policy "Authenticated users can view SMTP settings"
on "public"."smtp_settings"
as permissive
for select
to public
using ((auth.uid() IS NOT NULL));


create policy "Only admins can delete SMTP settings"
on "public"."smtp_settings"
as permissive
for delete
to public
using ((EXISTS ( SELECT 1
   FROM user_profiles
  WHERE ((user_profiles.id = auth.uid()) AND (user_profiles.role = 'admin'::text)))));


create policy "Only admins can insert SMTP settings"
on "public"."smtp_settings"
as permissive
for insert
to public
with check ((EXISTS ( SELECT 1
   FROM user_profiles
  WHERE ((user_profiles.id = auth.uid()) AND (user_profiles.role = 'admin'::text)))));


create policy "Only admins can update SMTP settings"
on "public"."smtp_settings"
as permissive
for update
to public
using ((EXISTS ( SELECT 1
   FROM user_profiles
  WHERE ((user_profiles.id = auth.uid()) AND (user_profiles.role = 'admin'::text)))))
with check ((EXISTS ( SELECT 1
   FROM user_profiles
  WHERE ((user_profiles.id = auth.uid()) AND (user_profiles.role = 'admin'::text)))));


create policy "Authenticated Users can view all users"
on "public"."user_profiles"
as permissive
for select
to authenticated
using (true);