#!/usr/bin/env python3
# returns 0 for success, 1 for usage error, 2 for diff generation error, 3 for no diff found
import sys
from sqlbag import S
from migra import Migration

def main():
    if len(sys.argv) != 4:
        print("Usage: run_diff.py <CURR_DB_URL> <UPGR_DB_URL> <OUTPUT_SQL_PATH>")
        sys.exit(1)

    curr_db = sys.argv[1]
    upgr_db = sys.argv[2]
    output_path = sys.argv[3]
    schema = "public"

    print(f"Diffing schema '{schema}' from CURRENT DB → UPGRADE DB")
    #print(f"  CURRENT DB: {curr_db}")
    #print(f"  UPGRADE DB: {upgr_db}")
    print(f"  Output path: {output_path}")

    try:
        with S(curr_db) as a, S(upgr_db) as b:
            m = Migration(a, b, schema=schema)
            m.set_safety(False)
            m.add_all_changes()
            sql = m.sql
            if sql:
                with open(output_path, "w") as f:
                    f.write(sql)
                print(f"Wrote diff SQL to: {output_path}")
            else:
                print("No differences found — empty output file will be created.")
                open(output_path, "w").close()
                sys.exit(3)
    except Exception as e:
        print(f"Error while generating diff: {e}")
        sys.exit(2)

if __name__ == "__main__":
    main()