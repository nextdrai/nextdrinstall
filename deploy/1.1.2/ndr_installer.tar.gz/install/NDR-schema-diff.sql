--
-- NextDR Supabase Database Schema 
-- NDR-SCHEMA-VERSION: 1.1.2
-- NDR-UPGRADE-FROM: 1.1.1
-- NDR-SCHEMA-TYPE: INCR
-- NDR-FULL-BASELINE-SCHEMA-SHA256: 777a6d724cc3b0d631dc9233574d47e5b3f39009e5dae01f1ae2ff125757d396
-- NDR-FULL-UPGRADE-SCHEMA-SHA256: 5d355b0c77cefda41203cff3984ff7470d135f2c29f29730dfbd0e07e13da34b
--

alter table "public"."backup_run" add column "datacentre_config" jsonb not null default '""'::jsonb;