#!/bin/bash
# ndrSupabase.sh - A Bash module providing common Supabase related functions

source "$(dirname "${BASH_SOURCE[0]}")/ndrDocker.sh"

# global variables
export gMIGRATION_TIMESTAMP=""
export gSUPABASE_MIGRATION_DIR="./supabase/migrations"
export gNDR_REFERENCE_SQL_SCHEMA_FILENAME="NDR-schema.sql"
export gNDR_REPLAY_SQL_SCHEMA_FILENAME="99-NDR-schema.sql"
export gNDR_SQL_SCHEMA_PLAYBACK_DIR="db-init-scripts"
export gNDR_INIT_AUTH_SQL_SCRIPT_FILENAME="00-NDR-init-supabase-auth.sql"
export gSUPABASE_COMPOSE_COPY_MODE=0
export gNDR_SUPABASE_DOCKER_PROJECT_NAME="ndr-supabase"
export gNDR_SUPABASE_REMOTE_HOST_URL="aws-0-us-west-1.pooler.supabase.com"

# schema files and options
export gACTIVE_NDR_SQL_SCHEMA_FILE="" # the active schema file to use for installs and upgrades.
export gNDR_SUPABASE_DB_SCHEMA_FILE="" # a user supplied schema file for db restores via --sf argument
export gNDR_SUPABASE_DB_BACKUP_FILE="" # PD_DUMP schema file produced during backup
export gNDR_POSTGRES_EXPORT_SCHEMA_ONLY=false # PG_DUMP option to export only the schema without data
export gNDR_ALLOW_SCHEMA_ERRORS=false # PSQL option to allow schema errors during playback

export gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL="" # the full schema file that represents the currently installed DB schema (typically kept in the install/home folder)
export gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL="" # the full schema file we are upgrading to
export gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF="" # the diff schema file computed from the prod schema and the upgrade schema (or explicitly provided via cmdline option)
export gNDR_SUPABASE_UPGRADE_SCHEMA_DIFF_GENERATE=true # flag to indicate if the diff schema file should be generated during the upgrade process (default is to generate, disabled with --dsf option)
export gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF_FILENAME="NDR-schema-diff_v${gPRODUCT_VERSION}_${NDR_GIT_REPO_COMMIT_HASH_SHORT}_$$.sql" # output diff file name
export gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF_FILENAME_SHORT="NDR-schema-diff.sql" # undecorated diff file name to be bundled in the installer archive.

# supabase versions
export gNDR_SUPABASE_GIT_REPO="supabase/supabase"
export gNDR_SUPABASE_GIT_VERSION_TAG="1.25.04" # default version tag to use for new installs from https://github.com/supabase/supabase/tags
export gNDR_SUPABASE_GIT_VERSION_TAG_NEXT="" # next version tag after target version tag, used for querying latest commit between the two tags.
export gNDR_SUPABASE_GIT_VERSION_COMMIT_HASH_FULL="484a264a41abf97577f9b984704b4b7ea63492ea"  # commit hash for the target version tag, used for checking out specific version of the repo.
export gNDR_SUPABASE_GIT_VERSION_COMMIT_HASH_SHORT="484a264" # short, 7 char version of the commit hash (commonly used in github and easier to embed in image names and tags)
export gNDR_SUPABASE_GIT_VERSION_ALLOW_COMMIT_HASH_UPDATE=false # option to allow install to query for commits *after* the sealed version tag (but not exceeding the next tag) and use the latest commit available for checkout/install/upgrade.
export gNDR_SUPABASE_GIT_VERSION_ALLOW_TAG_UPDATE=false # option to allow install to query for latest tag after teh sealed version tag and use this for checkout/install/upgrade.

# supabase command variables
export gSUPABASE_CLI_CMD="sudo npx supabase"
export gSUPABASE_NEXTDR_SUB="supabase_NDR"
export gSUPABASE_NEXTDR_HOME=""
export gSUPABASE_DB_BACKUP_SUB="ndr_db_backups"
export gSUPABASE_TEMPLATE_SUB="supabase_template"
export gSUPABASE_TEMPLATE_HOME=""
export gSUPABASE_REMOTE_TOKEN="" #SECRETS
export gSUPABASE_REMOTE_PROJECT_REFERENCE="" #SECRETS
export gSUPABASE_REMOTE_PASSWORD="" #SECRETS

# supabase env var entries
declare -A gSUPABASE_ENV_VARS=()

export gSUPABASE_ENV_KEY_DASHBOARD_USERNAME="DASHBOARD_USERNAME"
export gSUPABASE_ENV_VAL_DASHBOARD_USERNAME="supabase"

export gSUPABASE_ENV_KEY_DASHBOARD_PASSWORD="DASHBOARD_PASSWORD"
export gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD=""
export gSUPABASE_DASHBOARD_PASSWORD_LENGTH=16

export gSUPABASE_ENV_KEY_JWT_SECRET="JWT_SECRET"
export gSUPABASE_ENV_VAL_JWT_SECRET=""

export gSUPABASE_ENV_KEY_ANON_KEY="ANON_KEY"
export gSUPABASE_ENV_VAL_ANON_KEY=""

export gSUPABASE_ENV_KEY_SERVICE_ROLE_KEY="SERVICE_ROLE_KEY"
export gSUPABASE_ENV_VAL_SERVICE_ROLE_KEY=""

export gSUPABASE_ENV_KEY_POSTGRES_USER="POSTGRES_USER"
export gSUPABASE_ENV_VAL_POSTGRES_USER=""

export gSUPABASE_ENV_KEY_POSTGRES_PASSWORD="POSTGRES_PASSWORD"
export gSUPABASE_ENV_VAL_POSTGRES_PASSWORD=""

export gSUPABASE_ENV_KEY_POSTGRES_DB="POSTGRES_DB"
export gSUPABASE_ENV_VAL_POSTGRES_DB=""

# supabase service, image and container names (ideally read these from yml for most up to date values)
export NDR_SUPABASE_APP_SERVICE_NAME_STUDIO="studio"
export NDR_SUPABASE_APP_SERVICE_NAME_STUDIO_IMAGE_NAME="supabase/studio"
export NDR_SUPABASE_APP_SERVICE_NAME_STUDIO_CONTAINER_NAME="supabase-studio"

export NDR_SUPABASE_APP_SERVICE_NAME_KONG="kong"
export NDR_SUPABASE_APP_SERVICE_NAME_KONG_IMAGE_NAME="kong"
export NDR_SUPABASE_APP_SERVICE_NAME_KONG_CONTAINER_NAME="supabase-kong"

export NDR_SUPABASE_APP_SERVICE_NAME_AUTH="auth"
export NDR_SUPABASE_APP_SERVICE_NAME_AUTH_IMAGE_NAME="supabase/gotrue"
export NDR_SUPABASE_APP_SERVICE_NAME_AUTH_CONTAINER_NAME="supabase-auth"

export NDR_SUPABASE_APP_SERVICE_NAME_REST="rest"
export NDR_SUPABASE_APP_SERVICE_NAME_REST_IMAGE_NAME="postgrest/postgrest"
export NDR_SUPABASE_APP_SERVICE_NAME_REST_CONTAINER_NAME="supabase-rest"

export NDR_SUPABASE_APP_SERVICE_NAME_REALTIME="realtime"
export NDR_SUPABASE_APP_SERVICE_NAME_REALTIME_IMAGE_NAME="supabase/realtime"
export NDR_SUPABASE_APP_SERVICE_NAME_REALTIME_CONTAINER_NAME="realtime-dev.supabase-realtime"

export NDR_SUPABASE_APP_SERVICE_NAME_STORAGE="storage"
export NDR_SUPABASE_APP_SERVICE_NAME_STORAGE_IMAGE_NAME="supabase/storage-api"
export NDR_SUPABASE_APP_SERVICE_NAME_STORAGE_CONTAINER_NAME="supabase-storage"

export NDR_SUPABASE_APP_SERVICE_NAME_IMGPROXY="imgproxy"
export NDR_SUPABASE_APP_SERVICE_NAME_IMGPROXY_IMAGE_NAME="darthsim/imgproxy"
export NDR_SUPABASE_APP_SERVICE_NAME_IMGPROXY_CONTAINER_NAME="supabase-imgproxy"

export NDR_SUPABASE_APP_SERVICE_NAME_META="meta"
export NDR_SUPABASE_APP_SERVICE_NAME_META_IMAGE_NAME="supabase/postgres-meta"
export NDR_SUPABASE_APP_SERVICE_NAME_META_CONTAINER_NAME="supabase-meta"

export NDR_SUPABASE_APP_SERVICE_NAME_FUNCTIONS="functions"
export NDR_SUPABASE_APP_SERVICE_NAME_FUNCTIONS_IMAGE_NAME="supabase/edge-runtime"
export NDR_SUPABASE_APP_SERVICE_NAME_FUNCTIONS_CONTAINER_NAME="supabase-edge-functions"

export NDR_SUPABASE_APP_SERVICE_NAME_ANALYTICS="analytics"
export NDR_SUPABASE_APP_SERVICE_NAME_ANALYTICS_IMAGE_NAME="supabase/logflare"
export NDR_SUPABASE_APP_SERVICE_NAME_ANALYTICS_CONTAINER_NAME="supabase-analytics"

export NDR_SUPABASE_APP_SERVICE_NAME_DB="db"
export NDR_SUPABASE_APP_SERVICE_NAME_DB_IMAGE_NAME="supabase/postgres"
export NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME="supabase-db"

export NDR_SUPABASE_APP_SERVICE_NAME_VECTOR="vector"
export NDR_SUPABASE_APP_SERVICE_NAME_VECTOR_IMAGE_NAME="timberio/vector"
export NDR_SUPABASE_APP_SERVICE_NAME_VECTOR_CONTAINER_NAME="supabase-vector"

export NDR_SUPABASE_APP_SERVICE_NAME_SUPAVISOR="supavisor"
export NDR_SUPABASE_APP_SERVICE_NAME_SUPAVISOR_IMAGE_NAME="supabase/supavisor"
export NDR_SUPABASE_APP_SERVICE_NAME_SUPAVISOR_CONTAINER_NAME="supabase-pooler"

# supabase cleanup mode options
export NDR_SUPABASE_CLEANUP_OPTION_STRICT=0x1 # fail on any error, default behavior for standard uninstalls.
export NDR_SUPABASE_CLEANUP_OPTION_BEST_EFFORT=0x2 # in prepare phase, we do a best effort cleanup and dont fail on errors.
export NDR_SUPABASE_CLEANUP_OPTION_DEFAULT=$(( NDR_SUPABASE_CLEANUP_OPTION_STRICT ))

# schema headers
export gNDR_SUPABASE_SCHEMA_FILE_HEADER_DESC="-- NextDR Supabase Database Schema"
export gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION="-- NDR-SCHEMA-VERSION:" # product version of the current schema file (what will be installed or upgraded TO)
export gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL="$gPRODUCT_VERSION"
export gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM="-- NDR-UPGRADE-FROM:" # product version this schema file supports upgrading FROM
export gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL="$gINSTALLED_VERSION"
# Found in the DIFF schema file, these are the sha256 checksums of the FULL schema files that this DIFF was generated from.
# These checksums are used to validate and ensure the the DIFF file is the acutal one generated from the FULL schema files being used for the upgrade.
# if this hash matches the computed hash of the FULL baseline schema file found in the install/home folder AND the full upgrade schema supplied in the installtion package, 
# then we can confidently use this DIFF file for this upgrade and save time.
# if the hashes do not match, then the DIFF file is invalid for the FULL schema files and we must generate a new diff on the fly.
export gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH="-- NDR-FULL-BASELINE-SCHEMA-SHA256:" 
export gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH_VAL=""
export gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH="-- NDR-FULL-UPGRADE-SCHEMA-SHA256:" 
export gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL=""

export gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_FULL="FULL"
export gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_INCR="INCR"
export gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE="-- NDR-SCHEMA-TYPE:"
export gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_VAL="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_FULL"
  
# supabase db upgrade schema diff options
export NDR_SCHEMA_DIFF_WORK_DIR="/tmp/diff"
export NDR_SCHEMA_DIFF_SUPABASE_DIR="${NDR_SCHEMA_DIFF_WORK_DIR}/supabase-diff"
export NDR_SCHEMA_DIFF_SUPABASE_BASELINE_DIR="${NDR_SCHEMA_DIFF_WORK_DIR}/supabase-base"
export NDR_SCHEMA_DIFF_SUPABASE_DOCKER_SUB_DIR="docker"
export NDR_SCHEMA_DIFF_SUPABASE_PROJECT_NAME_BASELINE="ndr-supabase-base"
export NDR_SCHEMA_DIFF_SUPABASE_PROJECT_NAME_DIFF="ndr-supabase-diff"

export NDR_SCHEMA_DIFF_PYTHON_SCRIPT_FILE="run_diff.py"

declare -a NDR_SCHEMA_DIFF_DOCKER_SERVICES=($NDR_SUPABASE_APP_SERVICE_NAME_DB $NDR_SUPABASE_APP_SERVICE_NAME_AUTH $NDR_SUPABASE_APP_SERVICE_NAME_REALTIME $NDR_SUPABASE_APP_SERVICE_NAME_STORAGE) # master list of service names required for diff db
declare -A NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_TEMP=() # list of linked temp diff container names
declare -A NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_BASE=() # OPTIONAL list of linked temp baseline container names
declare -A NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_PROD=() # list of linked original container names
declare -A NDR_SCHEMA_DIFF_DOCKER_SERVICE_IMAGES_TEMP=() # list of linked temp diff container images
declare -A NDR_SCHEMA_DIFF_DOCKER_SERVICE_IMAGES_BASE=() # OPTIONAL list of linked temp baseline container images
declare -A NDR_SCHEMA_DIFF_DOCKER_SERVICE_IMAGES_PROD=() # list of linked original container images

# Supabase merge
export gNDR_SUPABASE_DB_MERGE_TEMP_PROD_DB="" # temporary DB to contain copy of production DB for diff comparison and merging.

export gNDR_SUPABASE_DB_OPS_POSTGRES_ADMIN_USER="postgres"
export gNDR_SUPABASE_DB_OPS_SUPABASE_ADMIN_USER="supabase_admin"
export gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT="$gNDR_SUPABASE_DB_OPS_POSTGRES_ADMIN_USER"
export gNDR_SUPABASE_DB_OPS_PRODUCTION_DB="postgres"

# Supabase test DB build options
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_PREPARE_FOLDERS=0x1
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CLONE_REPO=0x2
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_COPY_ENV_FILE=0x4
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODIFY_ENV_PORTS=0x8
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CONFIGURE_COMPOSE_SERVICES=0x10
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_PULL_IMAGES=0x20
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_COMPOSE_CONTAINERS=0x40
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CONTAINER_VERIFY=0x80
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_BRIDGE_NETWORKS=0x100
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_QUERY_PROD_DB_ENV=0x200
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_QUERY_BUILD_DB_ENV=0x400
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_INJECT_SCHEMA=0x800
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_VALIDATE_SCHEMA=0x1000
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_VALIDATE_BUILD_TABLES=0x2000
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_INSTALL_DIFF_UTILS=0x4000
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CLEANUP_SERVICES=0x8000
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CLEANUP_FOLDERS=0x10000

# Test DB construct mode
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_BASELINE=0x1000000000
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_UPGRADE=0x2000000000

# Baseline db build options (devops mode)
baselineDBOpts=$NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_BASELINE
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_PREPARE_FOLDERS ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CLONE_REPO ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_COPY_ENV_FILE ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODIFY_ENV_PORTS ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CONFIGURE_COMPOSE_SERVICES ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_PULL_IMAGES ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_COMPOSE_CONTAINERS ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CONTAINER_VERIFY ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_BRIDGE_NETWORKS ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_QUERY_PROD_DB_ENV ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_QUERY_BUILD_DB_ENV ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_INJECT_SCHEMA ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_VALIDATE_SCHEMA ))
#baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_VALIDATE_BUILD_TABLES ))
#baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_INSTALL_DIFF_UTILS ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CLEANUP_SERVICES ))
baselineDBOpts=$(( baselineDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CLEANUP_FOLDERS ))
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_BASELINE=$baselineDBOpts

# Upgrade test db build options
upgradeDBOpts=$NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_UPGRADE
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_PREPARE_FOLDERS ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CLONE_REPO ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_COPY_ENV_FILE ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODIFY_ENV_PORTS ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CONFIGURE_COMPOSE_SERVICES ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_PULL_IMAGES ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_COMPOSE_CONTAINERS ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CONTAINER_VERIFY ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_BRIDGE_NETWORKS ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_QUERY_PROD_DB_ENV ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_QUERY_BUILD_DB_ENV ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_INJECT_SCHEMA ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_VALIDATE_SCHEMA ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_VALIDATE_BUILD_TABLES ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_INSTALL_DIFF_UTILS ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CLEANUP_SERVICES ))
upgradeDBOpts=$(( upgradeDBOpts | NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CLEANUP_FOLDERS ))
export NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_UPGRADE=$upgradeDBOpts

# supabase application build enum
export NDR_SUPABASE_APP_BUILD_OPTIONS_NONE=0x0

# prepare phase individual options
export NDR_SUPABASE_APP_BUILD_OPTIONS_INSTALL_PREREQUISITES=0x1 # install and devops
export NDR_SUPABASE_APP_BUILD_OPTIONS_HOME_DIR_CHECK=0x2        # (install only, devops will always use the current working directory since all will be cleaned up at the end)
export NDR_SUPABASE_APP_BUILD_OPTIONS_INSTALL_PROMPTS=0x4  # devops and install
export NDR_SUPABASE_APP_BUILD_OPTIONS_CLEANUP_EXISTING_APP=0x8  # devops and install

# configure phase individual options
export NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_SUPABASE_DIRS=0x10     # devops and install
export NDR_SUPABASE_APP_BUILD_OPTIONS_GIT_CLONE_TEMPLATE=0x20       # devops and install
export NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_TEMPLATE_FILES=0x40       # devops and install, template files only.
export NDR_SUPABASE_APP_BUILD_OPTIONS_CUSTOMIZE_COMPOSE_FILE=0x80   # devops and install, note- Install will later copy precustomized file from installer archive.
export NDR_SUPABASE_APP_BUILD_OPTIONS_QUERY_COMPOSE_SERVICES=0x100  # install and devops

# build/install phase individual options
export NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_SUPABASE_APP_REGISTRY=0x1000 # install only
export NDR_SUPABASE_APP_BUILD_OPTIONS_SCHEMA_FILE_CHECK=0x2000            # devops, note- install will pull the necessary image with schema baked in
export NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_SCHEMA_FILE=0x4000             # devops, note- install will pull the necessary image with schema baked in
export NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_ENV_FILE=0x8000                # devops and install, note- install will package the env file with the installer archive
export NDR_SUPABASE_APP_BUILD_OPTIONS_PULL_SUPABASE_BASE_IMAGES=0x10000   # devops and install
export NDR_SUPABASE_APP_BUILD_OPTIONS_BACKUP_SCHEMA=0x20000               # install
export NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_BRIDGE_NETWORK=0x40000       # devops and install, note- not required by devops build, but docker compose command will fail since the entry is in the compose file.
export NDR_SUPABASE_APP_BUILD_OPTIONS_START_CONTAINERS=0x80000            # devops and install
export NDR_SUPABASE_APP_BUILD_OPTIONS_VERIFY_CONTAINERS=0x100000          # devops and install
export NDR_SUPABASE_APP_BUILD_OPTIONS_APP_INSTALL_COMPLETE_NOTIFY=0x200000 # install only
export NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_SYSTEMD=0x400000             # install only
export NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_ADMIN_ACCOUNT=0x800000       # devops and install
export NDR_SUPABASE_APP_BUILD_OPTIONS_APPLY_SCHEMA=0x1000000              # devops and install
export NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_INSTALL_FILES=0x2000000        # install only
export NDR_SUPABASE_APP_BUILD_OPTIONS_POPULATE_HOST_ADDRESS=0x4000000     # devops and install
export NDR_SUPABASE_APP_BUILD_OPTIONS_CUSTOMIZE_ENV_FILE=0x8000000        # devops and install
export NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_DASHBOARD_ACCOUNT=0x10000000 # devops and install

# Post install phase individual options
export NDR_SUPABASE_APP_BUILD_OPTIONS_STOP_CONTAINERS=0x100000000             # devops only
export NDR_SUPABASE_APP_BUILD_OPTIONS_REMOVE_SUPABASE_APP=0x400000000         # devops only
export NDR_SUPABASE_APP_BUILD_OPTIONS_CLEANUP_SUPABASE_DIRS=0x800000000       # devops and install, note- devops removes all folders, install only removes the template folder, note2- install mode essentially ends here

# build mode
export NDR_SUPABASE_APP_BUILD_OPTIONS_INSTALL_MODE=0x1000000000
export NDR_SUPABASE_APP_BUILD_OPTIONS_DEVOPS_MODE=0x2000000000

# install and devops option amalgamations.
installOpts=$NDR_SUPABASE_APP_BUILD_OPTIONS_INSTALL_MODE
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_INSTALL_PREREQUISITES ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_HOME_DIR_CHECK ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_INSTALL_PROMPTS ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_SCHEMA_FILE_CHECK ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CLEANUP_EXISTING_APP ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_SUPABASE_DIRS ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_GIT_CLONE_TEMPLATE ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_TEMPLATE_FILES ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CUSTOMIZE_COMPOSE_FILE ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_QUERY_COMPOSE_SERVICES ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_SUPABASE_APP_REGISTRY ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_SCHEMA_FILE ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_ENV_FILE ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_DASHBOARD_ACCOUNT ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CUSTOMIZE_ENV_FILE ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_PULL_SUPABASE_BASE_IMAGES ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_BRIDGE_NETWORK ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_START_CONTAINERS ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_VERIFY_CONTAINERS ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_INSTALL_FILES ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_SYSTEMD ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_APPLY_SCHEMA ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_ADMIN_ACCOUNT ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_BACKUP_SCHEMA ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_APP_INSTALL_COMPLETE_NOTIFY ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CLEANUP_SUPABASE_DIRS ))
installOpts=$(( installOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_POPULATE_HOST_ADDRESS ))
export NDR_SUPABASE_APP_BUILD_OPTIONS_INSTALL=$installOpts

devopsOpts=$NDR_SUPABASE_APP_BUILD_OPTIONS_DEVOPS_MODE
devopsOpts=$(( devopsOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_INSTALL_PREREQUISITES ))
devopsOpts=$(( devopsOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_INSTALL_PROMPTS ))
devopsOpts=$(( devopsOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_SCHEMA_FILE_CHECK ))
devopsOpts=$(( devopsOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CLEANUP_EXISTING_APP ))
devopsOpts=$(( devopsOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_SUPABASE_DIRS ))
devopsOpts=$(( devopsOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_GIT_CLONE_TEMPLATE ))
devopsOpts=$(( devopsOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_TEMPLATE_FILES ))
devopsOpts=$(( devopsOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CUSTOMIZE_COMPOSE_FILE ))
devopsOpts=$(( devopsOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_QUERY_COMPOSE_SERVICES ))
devopsOpts=$(( devopsOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_SCHEMA_FILE ))
devopsOpts=$(( devopsOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_ENV_FILE ))
devopsOpts=$(( devopsOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_DASHBOARD_ACCOUNT ))
devopsOpts=$(( devopsOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CUSTOMIZE_ENV_FILE ))
devopsOpts=$(( devopsOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_PULL_SUPABASE_BASE_IMAGES ))
devopsOpts=$(( devopsOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_BRIDGE_NETWORK ))
devopsOpts=$(( devopsOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_START_CONTAINERS ))
devopsOpts=$(( devopsOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_VERIFY_CONTAINERS ))
devopsOpts=$(( devopsOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_APPLY_SCHEMA ))
devopsOpts=$(( devopsOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_ADMIN_ACCOUNT ))
devopsOpts=$(( devopsOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_BACKUP_SCHEMA ))
devopsOpts=$(( devopsOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_APP_INSTALL_COMPLETE_NOTIFY ))
devopsOpts=$(( devopsOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_CLEANUP_SUPABASE_DIRS ))
devopsOpts=$(( devopsOpts | NDR_SUPABASE_APP_BUILD_OPTIONS_POPULATE_HOST_ADDRESS ))
export NDR_SUPABASE_APP_BUILD_OPTIONS_DEVOPS=$devopsOpts

# --- FUNCTIONS ---

ndr_version_ge() {
  # returns 0 if $1 >= $2
  # otherwise returns 1
  local v1 v2

  # split by dot and pad to 3 fields
  IFS='.' read -r -a v1 <<< "$1"
  IFS='.' read -r -a v2 <<< "$2"

  # compare major, then minor, then patch
  for i in 0 1 2; do
      local a="${v1[i]:-0}"
      local b="${v2[i]:-0}"

      if (( a > b )); then return 0; fi
      if (( a < b )); then return 1; fi
  done

  return 0  # equal
}

# 1st checks if app is installed and reads registry.
# 2nd looks for compose yml and reads from file.
# 3rd will populate from hard coded defines.
function ndr_PopulateSupabaseServiceMap ()
{
  local logSectionDesc="Populating Supabase service map"
  ndr_logSecStart "$logSectionDesc"

  local serviceListFound=false

  # 1st checks if app is installed and reads registry.
  while [ "$serviceListFound" = false ]; do
    ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
    local dbInstalled=$?
    if [[ "$dbInstalled" -ne 0 ]]; then
      break
    fi

    ndr_RegistryReadServiceEntries
    return_code=$?
    if [[ $return_code -ne 0 ]]; then
      ndr_logWarn "Could not read service entries from registry."
      break
    fi
    
    if [ ${#ndr_supabase_container_services[@]} -eq 0 ]; then
      ndr_logWarn "No service entries found in list."
      break
    fi

    ndr_logInfo "Read ${#ndr_supabase_container_services[@]} service entries from the registry."

    serviceListFound=true
  done

  while [ "$serviceListFound" = false ]; do
    local COMPOSE_FILE="${gSUPABASE_NEXTDR_HOME}/docker-compose.yml"

    if [[ ! -f $COMPOSE_FILE ]]; then
      ndr_logError "Docker compose file [$COMPOSE_FILE] not found."
      break
    fi

    # Get list of services
    mapfile -t services < <(yq eval '.services | keys | .[]' "$COMPOSE_FILE")
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to retrieve services from compose file [$COMPOSE_FILE]."
      break
    fi

    if [[ ${#services[@]} -eq 0 ]]; then
      echo "No services found in compose file."
      break
    fi

    ndr_logInfo "Read ${#services[@]} service entries from the compose file."

    # clear the arrays
    ndr_supabase_container_services=()
    ndr_supabase_container_service_container_names=()
    ndr_supabase_container_service_image_names=()
    ndr_supabase_container_service_image_tags=()

    for service_name in "${services[@]}"; do
      local container_name=$(yq eval ".services.$service_name.container_name" "$COMPOSE_FILE")
      local image=$(yq eval ".services.$service_name.image" "$COMPOSE_FILE")

      if [[ -z "$container_name" || -z "$image" ]]; then
        ndr_logError "Failed to retrieve service [$service_name] details from compose file [$COMPOSE_FILE]."
        break
      fi
    
      local image_base_name=$image
      local image_version

      if [[ "$image" == *:* ]]; then
        image_base_name="${image%%:*}"
        image_version="${image##*:}"
      fi

      ndr_AddSupabaseServiceMapEntry $service_name $container_name $image_base_name $image_version

    done

    ndr_logInfo "Added ${#ndr_supabase_container_services[@]} service entries from the compose file."

    serviceListFound=true
  done

  while [ "$serviceListFound" = false ]; do
    
    # clear the arrays
    ndr_supabase_container_services=()
    ndr_supabase_container_service_container_names=()
    ndr_supabase_container_service_image_names=()
    ndr_supabase_container_service_image_tags=()

    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_STUDIO $NDR_SUPABASE_APP_SERVICE_NAME_STUDIO_CONTAINER_NAME $NDR_SUPABASE_APP_SERVICE_NAME_STUDIO_IMAGE_NAME
    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_KONG $NDR_SUPABASE_APP_SERVICE_NAME_KONG_IMAGE_NAME $NDR_SUPABASE_APP_SERVICE_NAME_KONG_CONTAINER_NAME
    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_AUTH $NDR_SUPABASE_APP_SERVICE_NAME_AUTH_IMAGE_NAME $NDR_SUPABASE_APP_SERVICE_NAME_AUTH_CONTAINER_NAME
    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_REST $NDR_SUPABASE_APP_SERVICE_NAME_REST_IMAGE_NAME $NDR_SUPABASE_APP_SERVICE_NAME_REST_CONTAINER_NAME
    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_REALTIME $NDR_SUPABASE_APP_SERVICE_NAME_REALTIME_IMAGE_NAME $NDR_SUPABASE_APP_SERVICE_NAME_REALTIME_CONTAINER_NAME
    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_STORAGE $NDR_SUPABASE_APP_SERVICE_NAME_STORAGE_IMAGE_NAME $NDR_SUPABASE_APP_SERVICE_NAME_STORAGE_CONTAINER_NAME
    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_IMGPROXY $NDR_SUPABASE_APP_SERVICE_NAME_IMGPROXY_IMAGE_NAME $NDR_SUPABASE_APP_SERVICE_NAME_IMGPROXY_CONTAINER_NAME
    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_META $NDR_SUPABASE_APP_SERVICE_NAME_META_IMAGE_NAME $NDR_SUPABASE_APP_SERVICE_NAME_META_CONTAINER_NAME
    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_FUNCTIONS $NDR_SUPABASE_APP_SERVICE_NAME_FUNCTIONS_IMAGE_NAME $NDR_SUPABASE_APP_SERVICE_NAME_FUNCTIONS_CONTAINER_NAME
    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_ANALYTICS $NDR_SUPABASE_APP_SERVICE_NAME_ANALYTICS_IMAGE_NAME $NDR_SUPABASE_APP_SERVICE_NAME_ANALYTICS_CONTAINER_NAME
    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_DB $NDR_SUPABASE_APP_SERVICE_NAME_DB_IMAGE_NAME $NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME
    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_VECTOR $NDR_SUPABASE_APP_SERVICE_NAME_VECTOR_IMAGE_NAME $NDR_SUPABASE_APP_SERVICE_NAME_VECTOR_CONTAINER_NAME
    ndr_AddSupabaseServiceMapEntry $NDR_SUPABASE_APP_SERVICE_NAME_SUPAVISOR $NDR_SUPABASE_APP_SERVICE_NAME_SUPAVISOR_IMAGE_NAME $NDR_SUPABASE_APP_SERVICE_NAME_SUPAVISOR_CONTAINER_NAME
    
    serviceListFound=true
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# usage: function <service_name> <container_name> <image_name> <image_tag (OPTIONAL)> 
function ndr_AddSupabaseServiceMapEntry () 
{
  # Argument validation
  if [[ $# -lt 3 ]]; then
    ndr_logError "Usage: function <service_name> <container_name> <image_name> <image_tag [OPTIONAL]>"
    return 1
  fi
  
  local serviceName="$1"
  local containerName="$2"
  local imageName="$3"
  local imageTag="${4:-}"
  
  # Append to the ordered service array
  ndr_supabase_container_services+=("$serviceName")

  # Map service to its container, image and tag name
  ndr_supabase_container_service_container_names["$serviceName"]="$containerName"
  ndr_supabase_container_service_image_names["$serviceName"]="$imageName"
  ndr_supabase_container_service_image_tags["$serviceName"]="$imageTag"

  return 0
}

function ndr_SupabasePullDatabaseReferenceSchemaFileV2 ()
{
  local logSectionDesc="Executing supabase DB pull"
  ndr_logSecStart "$logSectionDesc"

  # decrypt and populate secrets.
  ndr_DecryptPopulateSecrets || { echo "Error: failed to populate secrets"; return 1; }

  local destMigrationFileName=$gNDR_REFERENCE_SQL_SCHEMA_FILENAME
  local destMigrationFileTmp="${gSCRIPT_HOME_DIR}/tmp_${destMigrationFileName}"

  # build command
  # this connects directly to the postgres db in the cloud supabase project using the IPV4 session pooler style parameter syntax.
  # it requires the remote pwd, remote proj reference and remote host url (found in the connection options for session pooler)

  cmd="env PGPASSWORD='$gSUPABASE_REMOTE_PASSWORD' pg_dump -h \"$gNDR_SUPABASE_REMOTE_HOST_URL\" -U \"postgres.$gSUPABASE_REMOTE_PROJECT_REFERENCE\" -d postgres -p 5432 --no-owner -f \"$destMigrationFileTmp\" --schema-only --schema=auth --schema=public"
  eval $cmd
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "[$cmd] failure with code [$return_code]"
    return 1
  fi

  ndr_logInfo "Successfully generated $gCOMPANY_NAME SQL schema file [$destMigrationFileTmp]"

  # check for existing migration refrence file in root project folder.
  # if one exists, backup/rename with timestamp appended.
  if [[ -f "$destMigrationFileName" ]]; then
    # Get the UNIX timestamp (modification time) of the file
    timestamp=$(stat -c %Y "$destMigrationFileName")

    # Convert timestamp to readable format: YYYYMMDD_HHMMSS
    readable_time=$(date -d @"$timestamp" +"%Y%m%d_%H%M%S")
    
    # Build the new filename with timestamp appended
    filename_base="${destMigrationFileName%.*}"
    filename_ext="${destMigrationFileName##*.}"

    if [[ "$filename_base" == "$destMigrationFileName" ]]; then
      # No extension case
      backup_filename="${filename_base}_${readable_time}"
    else
      backup_filename="${filename_base}_${readable_time}.${filename_ext}"
    fi

    # Move the file to the new filename
    mv -f "$destMigrationFileName" "$backup_filename"

    ndr_logInfo "Backing up preexisting $gCOMPANY_NAME SQL schema file [$destMigrationFileName] to [$backup_filename]"
  fi

  # move tmp file to root project folder
  local destMigrationFile="${gSCRIPT_HOME_DIR}/${destMigrationFileName}"
  mv -f $destMigrationFileTmp $destMigrationFile
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to move temp schema file [$destMigrationFileTmp] to [$destMigrationFile]"
    return 1
  fi
  ndr_logInfo "Moved migration file [$destMigrationFileTmp] to [$destMigrationFile]"

  # cache copied migration file name for potential later use
  gACTIVE_NDR_SQL_SCHEMA_FILE=$destMigrationFile
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabasePullDatabaseReferenceSchemaFile ()
{
  local logSectionDesc="Executing supabase DB pull"
  ndr_logSecStart "$logSectionDesc"

  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }

  # pre check for any existing migrations. If any exist, the DB pull may fail.
  # If this is the first time running this script, there should be no migrations present.
  # If there are migrations present, the user will need to run the migration repair command to remove the entry from the remote migration history table.
  # Set the directory to query
  
  
  # Check if the directory exists. Directory will not exist for fresh installs so skip check if not present.
  if [ ! -d "$gSUPABASE_MIGRATION_DIR" ]; then
    ndr_logInfo "Directory $gSUPABASE_MIGRATION_DIR does not exist, skipping precheck. "
    #return 1
  fi

  # Get list of regular files (excluding directories) in the directory
  FILES=("$gSUPABASE_MIGRATION_DIR"/*)
  COUNT=0
  
  # Count only regular files (skip directories and others)
  for FILE in "${FILES[@]}"; do
    if [ -f "$FILE" ]; then
      ndr_logInfo "Removing existing migration file: [$FILE]"
      # delete original migration file from migrations folder
      rm "$FILE"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logWarn "Failed to remove preexisting migration file [$FILE]. Please remove manually."
        #return 1
      fi
      
      # Extract just the filename portion (strip path)
      BASENAME=$(basename "$FILE")

      # Check if filename contains an underscore
      if [[ "$BASENAME" != *_* ]]; then
        ndr_logWarn "Invalid filename format. No underscore found in [$BASENAME], skipping."
        continue
      fi

      # Extract the timestamp value before the first underscore
      gMIGRATION_TIMESTAMP=$(echo "$BASENAME" | cut -d'_' -f1)

      if [ -z "$gMIGRATION_TIMESTAMP" ]; then
        ndr_logWarn "Failed to extract migration timestamp from filename [$BASENAME], skipping. "
        continue
      fi

      ndr_logInfo "Using migration timestamp: [$gMIGRATION_TIMESTAMP]"

      # run migration entry reset against remote db with the timestamp
      # this will remove the entry from the remote migration history table
      cmd="$gSUPABASE_CLI_CMD migration repair --status reverted $gMIGRATION_TIMESTAMP"
      if [ -n "$gSUPABASE_REMOTE_PASSWORD" ]; then
        cmd="$cmd --password '$gSUPABASE_REMOTE_PASSWORD'"
      fi    
      if [[ "$gDebugMode" -eq 1 ]]; then
        cmd="$cmd --debug"
      fi
      
      max_retries=3
      attempt=1

      while true; do
        eval "$cmd"
        
        return_code=$?

        if [[ $return_code -eq 0 ]]; then
          # success
          break
        fi

        if [[ $attempt -ge $max_retries ]]; then
          ndr_logError "Max supabase command retries reached. Exiting. "
          return 1
        fi

        ndr_logWarn "Supabase command attempt $attempt failed, retrying."
        
        
        attempt=$((attempt + 1))
        sleep 1  # Optional: wait before retrying
      done

      if [ $return_code != 0 ]; then
        ndr_logWarn "Failed to remove migration entry [$gMIGRATION_TIMESTAMP] from remote DB. Please run command to remove manually [$gSUPABASE_CLI_CMD migration repair --status reverted $gMIGRATION_TIMESTAMP]"
        #return 1
      fi

      ndr_logInfo "Removing remote migration entry for timestamp: [$gMIGRATION_TIMESTAMP]"
      
      ((COUNT++))
    fi
  done

  # Check count and respond accordingly
  if [ "$COUNT" -eq 0 ]; then
    ndr_logInfo "No preexisting migration files found in directory. Proceeding with db pull."
  else
    ndr_logInfo "Removed [$COUNT] migration files from dir [$gSUPABASE_MIGRATION_DIR]"
  fi

  # The auth and storage schemas are excluded by default. Run supabase db pull --schema auth,storage again to diff them.
  max_retries=3
  attempt=1

  cmd="$gSUPABASE_CLI_CMD db pull --linked --schema auth,public"
  if [ -n "$gSUPABASE_REMOTE_PASSWORD" ]; then
    cmd="$cmd --password '$gSUPABASE_REMOTE_PASSWORD'"
  fi
  if [[ "$gDebugMode" -eq 1 ]]; then
    cmd="$cmd --debug"
  fi
  
  while true; do
    eval "$cmd" <<< "n"
    
    return_code=$?

    if [[ $return_code -eq 0 ]]; then
      # success
      break
    fi

    if [[ $attempt -ge $max_retries ]]; then
      ndr_logError "Max supabase command retries reached. Exiting. "
      return 1
    fi

    ndr_logWarn "Supabase command attempt $attempt failed, retrying."
    
    
    attempt=$((attempt + 1))
    sleep 1  # Optional: wait before retrying
  done

  if [ $return_code != 0 ]; then
    ndr_logError "Supabase db pull failed."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# To install supabase CLI:
# https://supabase.com/docs/guides/local-development
function ndr_SupabaseCLIInstall ()
{
  local logSectionDesc="Installing supabase CLI"
  ndr_logSecStart "$logSectionDesc"

  cd "$gNEXTDR_HOME_DIR"  || { ndr_logError "Failed to cd into home dir"; return 1; }
  
  # check if supabase cli is already installed
  $gSUPABASE_CLI_CMD -v
  return_code=$?
  if [ $return_code -eq 0 ]; then
    ndr_logInfo "Supabase CLI already installed"
    return 0
  fi

  npm install supabase --save-dev
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to install supabase CLI."
    return 1
  fi
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# To begin linking to the remote instance
# eg. supabase link --project-ref <project-id> -password <password>
# You can get <project-id> from your project's dashboard URL: https://supabase.com/dashboard/project/<project-id>
# Alternatively, omitting the project ID will cause supabase to show all available remote db's to choose from.
# password is the master project password (not the supabase email account login)

function ndr_SupabaseLinkRemote ()
{
  local logSectionDesc="Executing supabase remote login"
  ndr_logSecStart "$logSectionDesc"

  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }

  # perform a remote logout in case the user is already logged in.
  ndr_SupabaseLogoutRemote

  cmd="$gSUPABASE_CLI_CMD login --token $gSUPABASE_REMOTE_TOKEN"
  if [[ "$gDebugMode" -eq 1 ]]; then
    cmd="$cmd --debug"
  fi
  $cmd
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Supabase login with token failed."
    return 1
  fi
  ndr_logSecEnd "$logSectionDesc"

  local logSectionDesc="Executing supabase init"
  ndr_logSecStart "$logSectionDesc"

  cmd="$gSUPABASE_CLI_CMD init --force"
  $cmd <<< "n"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Supabase init failed."
    return 1
  fi
  ndr_logSecEnd "$logSectionDesc"

  local logSectionDesc="Linking local supabase project to remote master"
  ndr_logSecStart "$logSectionDesc"

  # There seems to be a bug in the supbase CLI where the link command (And others) still prompts for password even when the initial login with token was successful.
  # This results in several redundant prompts for password from a number of CLI commands.
  # As a workaround, lets prompt for the password interactively here and then pass it to the link command. If link command fails, the password was incorrect and retry the prompt up to 3 times.

  cmd="$gSUPABASE_CLI_CMD link --project-ref $gSUPABASE_REMOTE_PROJECT_REFERENCE"
  if [ -n "$gSUPABASE_REMOTE_PASSWORD" ]; then
    cmd="$cmd --password '$gSUPABASE_REMOTE_PASSWORD'"
  fi
  if [[ "$gDebugMode" -eq 1 ]]; then
    cmd="$cmd --debug"
  fi
  
  max_retries=3
  attempt=1

  while true; do

    if [[ -z "$gSUPABASE_REMOTE_PASSWORD" ]]; then
      read -s -p "Enter the Supabase remote project password: " gSUPABASE_REMOTE_PASSWORD
      echo  # Print a newline after the password input
      
      if [[ -z "$gSUPABASE_REMOTE_PASSWORD" ]]; then
        ndr_logError "Supabase remote project password is required."
        continue
      else 
        cmd="$cmd --password '$gSUPABASE_REMOTE_PASSWORD'"
      fi
    fi

    eval "$cmd"
    
    return_code=$?

    if [[ $return_code -eq 0 ]]; then
      # success
      break
    fi

    if [[ $attempt -ge $max_retries ]]; then
      ndr_logError "Max supabase command retries reached. Exiting. "
      return 1
    fi

    ndr_logWarn "Supabase command attempt $attempt failed, retrying."
    
    # command failure could be due to an incoorect password so clear that to trigger a re-prompt.
    gSUPABASE_REMOTE_PASSWORD=""
    
    attempt=$((attempt + 1))
    sleep 1  # Optional: wait before retrying
  done

  if [ $return_code != 0 ]; then
    ndr_logError "Supabase link failed."
    # immediately run a supabase unlink command to remove the local link and clean up.
    $gSUPABASE_CLI_CMD unlink
    return 1
  fi
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# Capture any changes that you have made to your remote database before you went through in the process of pulling the schema.
# may prompt to update remote migration history table. select default.
# this process is lengthy and can take several minutes.

# If successful, Will output schema sql file to a folder stated in CLI output.
# supabase/migrations is now populated with a migration in <timestamp>_remote_schema.sql.
# eg. "Schema written to supabase\migrations\20250421192748_remote_schema.sql"

# query the output folder for the generated sql file. This will be under supabase/migrations.
# copy this file to the root project folder and delete the original from the migrations folder.
# parse the timestamp from the file name.
# Run the migration entry reset against the remote db with the timestamp. This will remove the entry from the remote migration history table.
# eg.  npx supabase migration repair --status reverted 20250422185759
function ndr_SupabaseProcessRemoteMigration ()
{
  local logSectionDesc="Processing supabase remote migration file"
  ndr_logSecStart "$logSectionDesc"

  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }

  # Set the directory to query
  DIR="$gSUPABASE_MIGRATION_DIR"
  
  # Check if the directory exists
  if [ ! -d "$DIR" ]; then
    ndr_logError "Directory $DIR does not exist. "
    return 1
  fi

  # Get list of regular files (excluding directories) in the directory
  FILES=("$DIR"/*)
  COUNT=0
  MIGRATION_FILENAME=""

  # Count only regular files (skip directories and others)
  for FILE in "${FILES[@]}"; do
    if [ -f "$FILE" ]; then
      ((COUNT++))
      MIGRATION_FILENAME="$FILE"
    fi
  done

  # Check count and respond accordingly
  if [ "$COUNT" -eq 0 ]; then
    ndr_logError "No migration files found in directory. "
    return 1
  elif [ "$COUNT" -gt 1 ]; then
    ndr_logError "Too many files migration found in directory. "
    return 1
  else
    ndr_logInfo "Found migration file: [$MIGRATION_FILENAME]"
    # You can now use $MIGRATION_FILENAME as needed
  fi

  # Extract just the filename portion (strip path)
  BASENAME=$(basename "$MIGRATION_FILENAME")

  # Extract the timestamp value before the first underscore
  gMIGRATION_TIMESTAMP=$(echo "$BASENAME" | cut -d'_' -f1)

  ndr_logInfo "Using migration timestamp: [$gMIGRATION_TIMESTAMP]"

  destMigrationFileName=$gNDR_REFERENCE_SQL_SCHEMA_FILENAME
  # check for existing migration refrence file in root project folder.
  # if one exists, backup/rename with timestamp appended.
  if [[ -f "$destMigrationFileName" ]]; then
    # Get the UNIX timestamp (modification time) of the file
    timestamp=$(stat -c %Y "$destMigrationFileName")

    # Convert timestamp to readable format: YYYYMMDD_HHMMSS
    readable_time=$(date -d @"$timestamp" +"%Y%m%d_%H%M%S")
    
    # Build the new filename with timestamp appended
    filename_base="${destMigrationFileName%.*}"
    filename_ext="${destMigrationFileName##*.}"

    if [[ "$filename_base" == "$destMigrationFileName" ]]; then
      # No extension case
      backup_filename="${filename_base}_${readable_time}"
    else
      backup_filename="${filename_base}_${readable_time}.${filename_ext}"
    fi

    # Move the file to the new filename
    mv -f "$destMigrationFileName" "$backup_filename"

    ndr_logInfo "Backing up preexisting $gCOMPANY_NAME SQL schema file [$destMigrationFileName] to [$backup_filename]"
  fi

  # copy migration file to root project folder
  local destMigrationFile="${gSCRIPT_HOME_DIR}/${destMigrationFileName}"
  cp -f $MIGRATION_FILENAME $destMigrationFile
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to copy migration file [$MIGRATION_FILENAME] to [$destMigrationFile]"
    return 1
  fi
  ndr_logInfo "Copied migration file [$MIGRATION_FILENAME] to [$destMigrationFile]"

  # cache copied migration file name for later use in docker container construction
  gACTIVE_NDR_SQL_SCHEMA_FILE=$destMigrationFile
  ndr_logInfo "Successfully generated $gCOMPANY_NAME SQL schema file [$destMigrationFileName]"

  # delete original migration file from migrations folder
  rm "$MIGRATION_FILENAME"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Failed to remove original migration file [$MIGRATION_FILENAME]. Please remove manually."
    #return 1
  fi

  # run migration entry reset against remote db with the timestamp
  # this will remove the entry from the remote migration history table
  cmd="$gSUPABASE_CLI_CMD migration repair --status reverted $gMIGRATION_TIMESTAMP"
  if [ -n "$gSUPABASE_REMOTE_PASSWORD" ]; then
    cmd="$cmd --password '$gSUPABASE_REMOTE_PASSWORD'"
  fi    
  if [[ "$gDebugMode" -eq 1 ]]; then
    cmd="$cmd --debug"
  fi
  
  max_retries=3
  attempt=1

  while true; do
    eval "$cmd"
    
    return_code=$?

    if [[ $return_code -eq 0 ]]; then
      # success
      break
    fi

    if [[ $attempt -ge $max_retries ]]; then
      ndr_logError "Max supabase command retries reached. Exiting. "
      return 1
    fi

    ndr_logWarn "Supabase command attempt $attempt failed, retrying."
    
    
    attempt=$((attempt + 1))
    sleep 1  # Optional: wait before retrying
  done

  if [ $return_code != 0 ]; then
    ndr_logWarn "Failed to remove migration entry [$gMIGRATION_TIMESTAMP] from remote DB. Please run command to remove manually [$gSUPABASE_CLI_CMD migration repair --status reverted $gMIGRATION_TIMESTAMP]"
    #return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseLogoutRemote ()
{
  local logSectionDesc="Unlinking local supabase project"
  ndr_logSecStart "$logSectionDesc"

  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }

  cmd="$gSUPABASE_CLI_CMD unlink"
  if [[ "$gDebugMode" -eq 1 ]]; then
    cmd="$cmd --debug"
  fi
  $cmd
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Supabase unlink failed."
    #return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  
  local logSectionDesc="Executing supabase remote logout"
  ndr_logSecStart "$logSectionDesc"

  cmd="$gSUPABASE_CLI_CMD logout"
  if [[ "$gDebugMode" -eq 1 ]]; then
    cmd="$cmd --debug"
  fi
  $cmd <<< "y"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Supabase logout failed."
    #return 1
  fi
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

# there are 2 types of objects that need to be removed:
# 1. the supabase container and its data. This can be done with the docker file and compose commands if present. Otherwise we can remove images and containers by name.
# 2. the supabase template and project directories and files.
function ndr_SupabaseContainerCleanup ()
{
  # Cleanup code snippet taken from "projectDir/reset.sh"
  # clean up supbase container
  local logSectionDesc="Cleaning up Supabase Container"
  ndr_logSecStart "$logSectionDesc"
  
  if [ "$gUPGRADE_MODE" == true ]; then
    ndr_logDebug "Upgrade mode set, skipping section."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  local cleanupOptions="${1:-$NDR_SUPABASE_CLEANUP_OPTION_DEFAULT}"
  
  if [[ -z "$gNEXTDR_HOME_DIR" ]]; then
    # read from registry if package already present.
    local homeDir=""
    homeDir=$(ndr_getHomeDirReg)
    return_code=$?
    if [[ $return_code -eq 0 && -n "$homeDir" ]]; then
      ndr_logInfo "Found existing directory [$homeDir] in registry."
      gNEXTDR_HOME_DIR="$homeDir"
    fi
  fi
  
  if [[ -n "$gNEXTDR_HOME_DIR" ]]; then
    gSUPABASE_NEXTDR_HOME="${gNEXTDR_HOME_DIR}/${gSUPABASE_NEXTDR_SUB}"
    gSUPABASE_TEMPLATE_HOME="${gNEXTDR_HOME_DIR}/${gSUPABASE_TEMPLATE_SUB}"
  fi

  if [[ -z "$gNEXTDR_HOME_DIR" || -z "$gSUPABASE_NEXTDR_HOME" ]]; then
    ndr_logError "Invalid home or project directory."
    return 1
  fi

  if [[ ! -d "$gSUPABASE_NEXTDR_HOME" ]]; then
    ndr_logInfo "Supabase project directory [$gSUPABASE_NEXTDR_HOME] does not exist. Nothing to clean up."
    return 0
  fi

  local dockerComposeFile="$gSUPABASE_NEXTDR_HOME/docker-compose.yml"
  local dockerComposeDevFile="$gSUPABASE_NEXTDR_HOME/dev/docker-compose.dev.yml"
  
  # step 1: stop and remove the supabase docker containers and images
  ndr_logInfo "Stopping and removing Supabase Docker container..."

  # if the home dir and compose file exists, we can query it for the service list and execute the compose down command.
  if [[ -f "$dockerComposeFile" ]]; then

    cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into supabase project dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }

    if [[ "$gNDR_DEVOPS_MODE" == true ]]; then
      ndr_ParseComposeFileServices "$dockerComposeFile"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "Failed to parse Docker compose file [$dockerComposeFile] service entries."
        #return 1
      fi
    fi

    docker compose -p "$gNDR_SUPABASE_DOCKER_PROJECT_NAME" -f "$dockerComposeFile" -f "$dockerComposeDevFile" down -v --remove-orphans
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logWarn "Failed to stop and remove Supabase Docker container"
      if (( cleanupOptions & NDR_SUPABASE_CLEANUP_OPTION_DEFAULT )); then
        return 1
      fi
    fi
    ndr_logInfo "Stopped and removed Supabase Docker container"

  else
    ndr_logWarn "Docker compose file [$dockerComposeFile] not found, skipping compose down command."
  fi
  
  # some modes will have registry access (install), others will only have compose file access (devops)
  if [ ${#ndr_supabase_container_services[@]} -eq 0 ]; then
    if [[ "$gNDR_INSTALL_MODE" == true ]]; then
      ndr_RegistryReadServiceEntries
      return_code=$?
      if [[ $return_code -ne 0 ]]; then
        ndr_logError "Failed to read service entries from registry."
        #return 1
      fi
    fi
  fi  

  if [ ${#ndr_supabase_container_services[@]} -eq 0 ]; then
    ndr_logError "No service entries found in compose or registry to act on."
    return 0
  fi

    
  imageFailed=0

  for service in "${ndr_supabase_container_services[@]}"; do
    if [[ "$gNDR_RETAIN_DOCKER_IMAGES" == true ]]; then
      ndr_logInfo "Global flag to retain Docker images is set, skipping delete of [$service]"
      continue
    fi

    local image_name="${ndr_supabase_container_service_image_names[$service]}"
    local image_tag="${ndr_supabase_container_service_image_tags[$service]}"

    local dockerAppManageOptions="$NDR_DOCKER_APP_MANAGE_OPTIONS_REMOVE_NO_PROMPT"
    local dockerImage="$image_name:$image_tag"

    ndr_cleanupDockerImage "$dockerImage" "$dockerAppManageOptions"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to remove Docker image [$dockerImage]."
      imageFailed=1
      continue
    fi
  done

  if [ $imageFailed -eq 1 ]; then
    ndr_logError "One or more Supabase Docker images were not removed. Please check the logs for details."
    #return 1
  else
    ndr_logInfo "All Supabase Docker images removed."
  fi
  
  # remove bridge network
  if ! docker network ls --format '{{.Name}}' | grep -q "^${NDR_DOCKER_BRIDGE_NETWORK_NAME}$"; then
    ndr_logInfo "Docker network not found [$NDR_DOCKER_BRIDGE_NETWORK_NAME]."
  else
    output=$(docker network rm "$NDR_DOCKER_BRIDGE_NETWORK_NAME" 2>&1)
    return_code=$?
    if [ $return_code != 0 ]; then
      if echo "$output" | grep -q "network .* is in use"; then
        ndr_logWarn "Cannot remove Docker network '$NDR_DOCKER_BRIDGE_NETWORK_NAME': It is currently in use by one or more containers."
      else
        ndr_logWarn "Failed to remove Docker network [$NDR_DOCKER_BRIDGE_NETWORK_NAME]."
      fi
    else
      ndr_logInfo "Removed Docker network [$NDR_DOCKER_BRIDGE_NETWORK_NAME]."
    fi
  fi

  # step 2: remove all directories and files related to the supabase project
  if [[ "$gNDR_UNINSTALL_RETAIN_SUPABASE_DB_DATA" == false ]]; then
    ndr_logInfo "Removing Supabase project directories and files..."

    ndr_logInfo "Cleaning up bind-mounted directories."
    BIND_MOUNTS=(
      "$gSUPABASE_NEXTDR_HOME/volumes/db/data"
    )

    for DIR in "${BIND_MOUNTS[@]}"; do
      if [ -d "$DIR" ]; then
        ndr_logInfo "Deleting $DIR..."
        rm -rf "$DIR"
      else
        ndr_logInfo "Directory $DIR does not exist. Skipping bind mount deletion."
      fi
    done

    ndr_logInfo "Removing Supabase project directory [$gSUPABASE_NEXTDR_HOME] and template directory [$gSUPABASE_TEMPLATE_HOME]..."
    if [ -d "$gSUPABASE_NEXTDR_HOME" ]; then
      rm --recursive --force "$gSUPABASE_NEXTDR_HOME"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "Failed to remove Supabase project directory [$gSUPABASE_NEXTDR_HOME]. Please check permissions and try again."
        #return 1
      fi
    else
      ndr_logInfo "Supabase project directory [$gSUPABASE_NEXTDR_HOME] does not exist."
    fi

    if [ -d "$gSUPABASE_TEMPLATE_HOME" ]; then
      rm --recursive --force "$gSUPABASE_TEMPLATE_HOME"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "Failed to remove Supabase template directory [$gSUPABASE_TEMPLATE_HOME]. Please check permissions and try again."
        #return 1
      fi
    else
      ndr_logInfo "Supabase template directory [$gSUPABASE_TEMPLATE_HOME] does not exist."
    fi
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseLocalSchemaFileCheck ()
{
  local logSectionDesc="Local $gCOMPANY_NAME schema file check"
  ndr_logSecStart "$logSectionDesc"
  
  #if [ "$gExpressMode" -eq 1 ]; then
  #  ndr_logInfo "Skipping local $gCOMPANY_NAME schema file check in express mode."
  #  return 0
  #fi

  # check for local NDR schema file. 
  # first check if the file is present in the home directory.
  # If not in the home folder, check if the file is present in the same folder as the script.

  # If not present, prompt user to exit and run the supabase db pull command to generate the file.
  if [ -z "$gACTIVE_NDR_SQL_SCHEMA_FILE" ]; then
    # active schema file variable not populated. populate and recheck
    if [ -f "${gNEXTDR_HOME_DIR}/${gNDR_REFERENCE_SQL_SCHEMA_FILENAME}" ]; then
      gACTIVE_NDR_SQL_SCHEMA_FILE="${gNEXTDR_HOME_DIR}/${gNDR_REFERENCE_SQL_SCHEMA_FILENAME}"
      ndr_logInfo "Found local $gCOMPANY_NAME schema file in home directory [$gACTIVE_NDR_SQL_SCHEMA_FILE]"
    elif [ -f "${PWD}/${gNDR_REFERENCE_SQL_SCHEMA_FILENAME}" ]; then
      gACTIVE_NDR_SQL_SCHEMA_FILE="$PWD/$gNDR_REFERENCE_SQL_SCHEMA_FILENAME"
      ndr_logInfo "Found local $gCOMPANY_NAME schema file in script folder [$gACTIVE_NDR_SQL_SCHEMA_FILE]"
    else
      ndr_logError "Local $gCOMPANY_NAME schema file not found in home directory or script folder."
    fi
  fi
  
  if [ ! -f "$gACTIVE_NDR_SQL_SCHEMA_FILE" ]; then
    ndr_logWarn "WARNING: Local copy of $gCOMPANY_NAME schema file [$gNDR_REFERENCE_SQL_SCHEMA_FILENAME] not found."
    ndr_logInfo "This file is required to seed the Supabase Docker container with the $gCOMPANY_NAME schema upon startup and, without it, the database would be empty and require manual injection of the SQL schema after installation."
    return 1
  fi

  # check for a schema DIFF file for upgrade scenarios.
  if [ "$gUPGRADE_MODE" = true ]; then
    while true; do
      # check for diff schema in package
      local diffSchemaFile="${gSCRIPT_HOME_DIR}/${gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF_FILENAME_SHORT}"
      if [ ! -f "$diffSchemaFile" ]; then
        ndr_logInfo "No local $gCOMPANY_NAME schema DIFF file found for upgrade. Schema diff will be regenerated on the fly."
        break
      fi
      ndr_logInfo "Found local $gCOMPANY_NAME schema DIFF file [$diffSchemaFile] for upgrades."
      
      # Check for and assign installed schema filename to baseline schema file var for checksum operations
      if [[ -z "$gNEXTDR_HOME_DIR" ]]; then
        gNEXTDR_HOME_DIR=$(ndr_getHomeDirReg)
        return_code=$?
        if [[ $return_code -ne 0 || -z "$gNEXTDR_HOME_DIR" ]]; then
          ndr_logError "Failed to retrieve home dir from registry."
          break
        fi
      fi
      gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL="$gNEXTDR_HOME_DIR/$gSUPABASE_NEXTDR_SUB/$gNDR_REFERENCE_SQL_SCHEMA_FILENAME"
      if [[ ! -f "$gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL" ]]; then
        ndr_logError "Installed schema file not found at expected location [$gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL]. Schema diff will be regenerated on the fly."
        break
      fi
      ndr_logInfo "Using installed schema file for baseline: $gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL"

      # read checksum of FULL schema file from the DIFF schema header.
      ndr_logInfo "Checking schema diff for compatibility..."
      gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL="$gACTIVE_NDR_SQL_SCHEMA_FILE"
      ndr_SupabaseSchemaDiffHeaderVerify "$diffSchemaFile"
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logWarn "Failed to validate schema diff. Schema diff will be regenerated on the fly."
        break
      fi
      
      # Diff schema is good to go, preserve values
      gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF="$diffSchemaFile"
      gNDR_SUPABASE_UPGRADE_SCHEMA_DIFF_GENERATE=false

      break
    done
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_customizeSupabaseDockerComposeFile () 
{
  local logSectionDesc="Customizing $gCOMPANY_NAME supabase docker compose file"
  ndr_logSecStart "$logSectionDesc"

  local appBuildOptions="${1:-$NDR_SUPABASE_APP_BUILD_OPTIONS_NONE}"
  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_NONE )); then
    ndr_logInfo "No build options specified."
    return 1
  fi

  ndr_customizeSupabaseDockerComposeFileAddProjectName
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to customize supabase docker compose file to add project name."
    return 1
  fi
  ndr_logInfo "Successfully customized $gCOMPANY_NAME supabase docker compose file to add project name."

  ndr_customizeSupabaseDockerComposeFileAddLogflareInfo
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to customize supabase docker compose file to add Logflare info."
    return 1
  fi
  ndr_logInfo "Successfully customized $gCOMPANY_NAME supabase docker compose file to add Logflare info."

  # customize the docker compose file to add the bridge network
  ndr_customizeSupabaseDockerComposeFileAddBridgeNetwork
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to customize supabase docker compose file to add bridge network."
    return 1
  fi
  ndr_logInfo "Successfully customized $gCOMPANY_NAME supabase docker compose file to add bridge network."
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_customizeSupabaseDockerComposeFileAddLogflareInfo () 
{
  local logSectionDesc="Customizing $gCOMPANY_NAME supabase docker compose file to add logflare info"
  ndr_logSecStart "$logSectionDesc"

  local COMPOSE_FILE="${gSUPABASE_NEXTDR_HOME}/docker-compose.yml"
  
  if [[ ! -f $COMPOSE_FILE ]]; then
    ndr_logError "Docker compose file [$COMPOSE_FILE] not found."
    return 1
  fi

  # Get list of services
  mapfile -t services < <(yq eval '.services | keys | .[]' "$COMPOSE_FILE")
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to retrieve services from compose file [$COMPOSE_FILE]."
    return 1
  fi

  if [[ ${#services[@]} -eq 0 ]]; then
    echo "No services found in compose file."
    return 1
  fi

  service_name=$NDR_SUPABASE_APP_SERVICE_NAME_VECTOR

  #yq eval 'has("services") and .services | has("vector")' $COMPOSE_FILE | grep -q true
  result=$(yq eval 'has("services") and .services | has("vector")' $COMPOSE_FILE)
  #return_code=$?
  #if [ $return_code -ne 0 ]; then
  if [ "$result" != "true" ]; then
    ndr_logError "Compose file missing .services.vector section."
    return 1
  fi

  yq eval -i ".services.\"$service_name\".environment.LOGFLARE_PUBLIC_ACCESS_TOKEN = \"\${LOGFLARE_PUBLIC_ACCESS_TOKEN}\"" "$COMPOSE_FILE"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to customize supabase docker compose file to add logflare public access token."
    return 1
  fi
  ndr_logInfo "Added logflare public access token to compose file."

  yq eval -i ".services.\"$service_name\".environment.LOGFLARE_PRIVATE_ACCESS_TOKEN = \"\${LOGFLARE_PRIVATE_ACCESS_TOKEN}\"" "$COMPOSE_FILE"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to customize supabase docker compose file to add logflare private access token."
    return 1
  fi
  ndr_logInfo "Added logflare private access token to compose file."

  ndr_logInfo "Logflare info updated successfully in compose file [$COMPOSE_FILE]."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_customizeSupabaseDockerComposeFileAddBridgeNetwork () 
{
  local logSectionDesc="Customizing $gCOMPANY_NAME supabase docker compose file to add bridge network"
  ndr_logSecStart "$logSectionDesc"

  local COMPOSE_FILE="${gSUPABASE_NEXTDR_HOME}/docker-compose.yml"
  
  ndr_CustomizeDockerComposeFileAddBridgeNetwork "$COMPOSE_FILE"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to add bridge network to compose file [$COMPOSE_FILE]."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_customizeSupabaseDockerComposeFileAddProjectName () 
{
  local logSectionDesc="Customizing $gCOMPANY_NAME supabase docker compose file to add project name"
  ndr_logSecStart "$logSectionDesc"
  
  local COMPOSE_FILE="${gSUPABASE_NEXTDR_HOME}/docker-compose.yml"
  
  if [[ ! -f $COMPOSE_FILE ]]; then
    ndr_logError "Docker compose file [$COMPOSE_FILE] not found."
    return 1
  fi

  ndr_logInfo "Customizing $gCOMPANY_NAME project Docker compose file [$COMPOSE_FILE]."

  # Replace first occurrence of 'name: supabase' with 'name: ndr-supabase'
  yq eval -i ".name = \"${gNDR_SUPABASE_DOCKER_PROJECT_NAME}\"" "$COMPOSE_FILE"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Failed to change top level container stack entry to \"$gNDR_SUPABASE_DOCKER_PROJECT_NAME\" in compose file."
    #return 1
  fi
  ndr_logInfo "Changed top level container stack entry to \"$gNDR_SUPABASE_DOCKER_PROJECT_NAME\" in compose file."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_customizeSupabaseDockerComposeFileAddSchema () 
{
  local logSectionDesc="Customizing $gCOMPANY_NAME supabase docker compose file to add schema file"
  ndr_logSecStart "$logSectionDesc"
  
  local COMPOSE_FILE="${gSUPABASE_NEXTDR_HOME}/docker-compose.yml"
  
  if [[ ! -f $COMPOSE_FILE ]]; then
    ndr_logError "Docker compose file [$COMPOSE_FILE] not found."
    return 1
  fi

  ndr_logInfo "Customizing $gCOMPANY_NAME project Docker compose file [$COMPOSE_FILE]."

  # Check if insert_line1 exists
  # line 1 is a comment line that is used to initialize the database with NDR schema.
  # yq has a limitation with adding comments to an array and it is not critical to have this line in the compose file.
  if false; then
  insert_line1="# Initialize the database with NDR schema"
  grep -qF -- "$insert_line1" "$COMPOSE_FILE"
  return_code=$?
  if [ $return_code -eq 0 ]; then
    ndr_logInfo "[$insert_line1] already exists in db volumes"
  else
    yq eval -i ".services.db.volumes += [\"$insert_line1\"]" "$COMPOSE_FILE"
    return_code=$?
    if [ $return_code -eq 0 ]; then
      ndr_logInfo "Added [$insert_line1] to db volumes"
    else
      ndr_logError "Failed to add [$insert_line1] to db volumes"
    fi    
  fi
  fi

  # init the sequence num for playback of the ndr schema file in the compose file to 99 and adjust from there.
  local ndrSequenceNum=99

  # check for jwt entry and pull its sequence number.
  # eg.       - ./volumes/db/init-scripts/99-jwt.sql:/docker-entrypoint-initdb.d/init-scripts/99-jwt.sql:Z
  local jwtSqlFileName="jwt.sql"
  local jwt_matched_line=$(grep -- "[0-9][0-9]-$jwtSqlFileName" "$COMPOSE_FILE")
  if [ -n "$jwt_matched_line" ]; then
    # Extract the sequence number (e.g., 99 from 99-jwt.sql)
    local jwt_seq_num=$(echo "$jwt_matched_line" | sed -n 's/.*\/\([0-9][0-9\-]*\)-jwt\.sql.*/\1/p' | grep -oE '^[0-9]+')
    ndr_logInfo "jwt sql file entry [$jwt_matched_line] found in compose file [$COMPOSE_FILE], sequence number: [$jwt_seq_num]"
    # Set ndrSequenceNum to jwt_seq_num + 1 if jwt_seq_num is not empty
    if [ -n "$jwt_seq_num" ]; then
      ndrSequenceNum=$((jwt_seq_num + 1))
      ndr_logInfo "Incrementing NDR schema sequence number to $ndrSequenceNum"
    fi
  else
    ndr_logWarn "jwt sql file [$jwtSqlFileName] not found in compose file [$COMPOSE_FILE]"
  fi

  # formulate ndr replay schema filename with seq number.
  gNDR_REPLAY_SQL_SCHEMA_FILENAME="$ndrSequenceNum-$gNDR_REFERENCE_SQL_SCHEMA_FILENAME"
  ndr_logInfo "Setting NDR replay schema filename [$gNDR_REPLAY_SQL_SCHEMA_FILENAME]"

  
  # Check if $gNDR_REFERENCE_SQL_SCHEMA_FILENAME exists
  local ndr_matched_line=$(grep -- "$gNDR_REFERENCE_SQL_SCHEMA_FILENAME" "$COMPOSE_FILE")
  if [ -n "$ndr_matched_line" ]; then
    # we should never already have this entry in the file because we need to modify its name to adjust playback order.
    ndr_logError "[$ndr_matched_line] already exists in db volumes"
    return 1
  fi
  
  # insert the line.
  insert_line2="./${gNDR_SQL_SCHEMA_PLAYBACK_DIR}/$gNDR_REPLAY_SQL_SCHEMA_FILENAME:/docker-entrypoint-initdb.d/migrations/$gNDR_REPLAY_SQL_SCHEMA_FILENAME:Z"
  
  yq eval -i ".services.db.volumes += [\"$insert_line2\"]" "$COMPOSE_FILE"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to add [$insert_line2] to db volumes"
    return 1
  fi
  ndr_logInfo "Added [$insert_line2] to db volumes"
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_verifySupabaseContainersExist ()
{
  local logSectionDesc="Verifying Supabase containers exist"
  ndr_logSecStart "$logSectionDesc"

  if [[ -z "$gNEXTDR_HOME_DIR" || -z "$gSUPABASE_NEXTDR_HOME" ]]; then
    ndr_logError "Invalid home or project directory."
    return 1
  fi

  if [ ${#ndr_supabase_container_services[@]} -eq 0 ]; then
    if [[ "$gNDR_INSTALL_MODE" == true ]]; then
      ndr_RegistryReadServiceEntries
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logError "Failed to read Supabase Docker service entries from registry."
        return 1
      fi
    elif [[ "$gNDR_DEVOPS_MODE" == true ]]; then
      ndr_ParseComposeFileServices "$dockerComposeFile"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "Failed to parse Docker compose file [$dockerComposeFile] service entries."
        #return 1
      fi
    else
      ndr_logWarn "Unknown install mode."
      return 1
    fi
  fi

  if [ ${#ndr_supabase_container_services[@]} -eq 0 ]; then
    ndr_logInfo "No Supabase service array entries found."
    return 1
  fi

  ndr_logInfo "Verifying ${#ndr_supabase_container_services[@]} Supabase service entries."

  local containerFailed=0

  for service in "${ndr_supabase_container_services[@]}"; do
    local container_name="${ndr_supabase_container_service_container_names[$service]}"
    local image_name="${ndr_supabase_container_service_image_names[$service]}"
    local image_tag="${ndr_supabase_container_service_image_tags[$service]}"

    # check if the supabase container exists
    local containerCheck="$container_name" #"$image_name:$image_tag"
    ndr_verifyDockerContainerExists "$containerCheck"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Supabase Docker container [$containerCheck] does not exist."
      containerFailed=1
      continue
    fi

    ndr_CheckContainerHealth "$container_name"
    return_code=$?
    if [[ $return_code -eq 0 ]]; then
      ndr_logInfo "Docker container returned healthy status [$container_name]."
      #retVal=0
    else
      ndr_logWarn "Docker container returned non-healthy status [$container_name]."
      local logs_output=$(docker logs --tail 50 "$container_name" 2>&1)
      if [[ -n "$logs_output" ]]; then
        ndr_logWarn "$logs_output"
      fi
      #retVal=1
    fi
  done

  if [ $containerFailed -eq 0 ]; then
    ndr_logInfo "All Supabase Docker containers exist."
  else
    ndr_logError "One or more Supabase Docker containers do not exist. Please check the logs for details."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

check_url() {
  curl -Is --max-time 3 "$1" >/dev/null 2>&1
}

function ndr_SupabaseInstallCompletePopulateReport ()
{
  # Populate installation report with Supabase info
  ndr_logInfo "Populating installation report with Supabase info."

  local remoteURL="http://$gNDR_SERVER_HOST_ADDRESS:8000"
  local localURL="http://localhost:8000"

  ndr_InstallationReportAddEntry "The $gCOMPANY_NAME $gPRODUCT_VERSION application suite installation has been installed successfully at [$gNEXTDR_HOME_DIR]."
  ndr_InstallationReportAddEntry "You can access the Supabase Studio through the API gateway on port 8000."
  ndr_InstallationReportAddEntry "$remoteURL, or $localURL if you are accessing Docker locally."
  if [[ -n "$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME" && -n "$gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD" ]]; then
    ndr_InstallationReportAddEntry "The Supabase Dashboard user account is: \"$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME\" password: \"$gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD\""
  fi
  if [[ -n "$gNDR_CONSOLE_ADMIN_ACCOUNT_USER" && -n "$gNDR_CONSOLE_ADMIN_ACCOUNT_PASSWORD" ]]; then
    ndr_InstallationReportAddEntry "The $gCOMPANY_NAME Admin Console user account is: \"$gNDR_CONSOLE_ADMIN_ACCOUNT_USER\" password: \"$gNDR_CONSOLE_ADMIN_ACCOUNT_PASSWORD\""
  fi
  ndr_InstallationReportAddEntry "Please check the .env file in the folder [$gSUPABASE_NEXTDR_HOME] for full dashboard configuration."
  
  return 0
}

function ndr_SupabaseInstallCompleteNotify ()
{
  # Accessing Supabase Studio
  # You can access Supabase Studio through the API gateway on port 8000. For example: http://<your-ip>:8000, or localhost:8000 if you are running Docker locally.

  # You will be prompted for a username and password. By default, the credentials are:

  # Username: supabase
  # Password: this_password_is_insecure_and_should_be_updated

  # Need to change credentials and secrets to secure values
  # Update the ./docker/.env file with your own secrets. In particular, these are required:

  # POSTGRES_PASSWORD: the password for the postgres role.
  # JWT_SECRET: used by PostgREST and GoTrue, among others.

  # Dashboard authentication
  # The Dashboard is protected with basic authentication. The default user and password MUST be updated before using Supabase in production.
  # Update the following values in the ./docker/.env file:

  # DASHBOARD_PASSWORD: The default password for the Dashboard

  local remoteURL="http://$gNDR_SERVER_HOST_ADDRESS:8000"
  local localURL="http://localhost:8000"

  ndr_PrintInstallationReport

  # Prefer remote URL if it responds
  if check_url "$remoteURL"; then
    ndr_logInfo "Remote console is available at $remoteURL. Launching browser..."
    xdg-open "$remoteURL" >/dev/null 2>&1 &
  elif check_url "$localURL"; then
    # Otherwise try local URL
    ndr_logInfo "Remote console not available. Launching local console at $localURL..."
    xdg-open "$localURL" >/dev/null 2>&1 &
  fi

  return 0
}

function ndr_CreateSupabaseFolders ()
{
   # Create your desired working directory:
  # Tree should look like this
  # .
  # ├── supabase
  # └── supabase-project
  
  local logSectionDesc="Cleaning and creating new application folders"
  ndr_logSecStart "$logSectionDesc"
  
  if [ "$gUPGRADE_MODE" == true ]; then
    ndr_logDebug "Upgrade mode set, skipping section."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  if [[ -z "$gNEXTDR_HOME_DIR" || -z "$gSUPABASE_NEXTDR_HOME" ]]; then
    ndr_logError "Invalid home or project directory."
    return 1
  fi

  rm --recursive --force "$gSUPABASE_NEXTDR_HOME"
  rm --recursive --force "$gSUPABASE_TEMPLATE_HOME"
  mkdir "$gSUPABASE_NEXTDR_HOME"
  mkdir "$gSUPABASE_TEMPLATE_HOME"
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_PullSupabaseGitTemplate ()
{
  # To pull supabase docker code from GIT
  # This is a very lengthy process and will take several minutes or more depending on connectivity speed.
  local logSectionDesc="Cloning a local supabase template from GIT"
  ndr_logSecStart "$logSectionDesc"

  if [ "$gUPGRADE_MODE" == true ]; then
    ndr_logDebug "Upgrade mode set, skipping section."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  cd "$gSUPABASE_TEMPLATE_HOME" || { ndr_logError "Failed to cd into supabase template dir [$gSUPABASE_TEMPLATE_HOME]"; return 1; }

  local checkoutTag="$gNDR_SUPABASE_GIT_VERSION_TAG"

  # first check if we can update to a more recent tag.
  if [ "$gNDR_SUPABASE_GIT_VERSION_ALLOW_TAG_UPDATE" == true ]; then
    ndr_logInfo "Option to query for latest release tag is enabled."
    ndr_SupabaseQueryLatestTag
    return_code=$?
    if [[ $return_code != 0 ]]; then
      ndr_logWarn "Failed to query latest release tag from GitHub. Will checkout base tag [$checkoutTag]"
      #return 0
    else
      checkoutTag="$gNDR_SUPABASE_GIT_VERSION_COMMIT_HASH_FULL"
    fi
  fi

  # then check if we can update to the latest commit hash for our given tag.
  if [ "$gNDR_SUPABASE_GIT_VERSION_ALLOW_COMMIT_HASH_UPDATE" == true ]; then
    ndr_logInfo "Option to query for latest granular commit after [$gNDR_SUPABASE_GIT_VERSION_TAG] is enabled."
    ndr_SupabaseQueryLatestCommit
    return_code=$?
    if [[ $return_code != 0 ]]; then
      ndr_logWarn "Failed to query latest commit hash from GitHub. Will checkout base tag [$checkoutTag]"
      #return 0
    else
      checkoutTag="$gNDR_SUPABASE_GIT_VERSION_COMMIT_HASH_FULL"
    fi
  fi

  ndr_logInfo "Cloning the Supabase template repository tag [$checkoutTag] from GitHub to [$gSUPABASE_TEMPLATE_HOME]"
  
  # advanced clone command
  git clone --filter=blob:none --no-checkout https://github.com/supabase/supabase "$gSUPABASE_TEMPLATE_HOME"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Git clone failed."
    return 1
  fi
  ndr_logInfo "Git clone for Supabase completed."

  git sparse-checkout set --cone docker
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "GIT sparse checkout for docker only folder failed."
    return 1
  fi
  ndr_logInfo "Git sparse checkout for Supabase completed."

  git checkout "$checkoutTag"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "GIT checkout for [$checkoutTag] failed."
    return 1
  fi
  ndr_logInfo "Git checkout for [$checkoutTag] completed."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_CopySupabaseTemplateFiles ()
{
  # Copy the template compose files over to your project
  local logSectionDesc="Copying the template files to project"
  ndr_logSecStart "$logSectionDesc"

  if [ "$gUPGRADE_MODE" == true ]; then
    ndr_logDebug "Upgrade mode set, skipping section."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # always need to copy the template files because there a number of files and folders other than the main yml needed here.
  cd "$gSCRIPT_HOME_DIR" || { ndr_logError "Failed to cd into install dir"; return 1; }
    
  local srcFile="$gSUPABASE_TEMPLATE_HOME/docker/*"
  local destFile="$gSUPABASE_NEXTDR_HOME"
  cp -rf $srcFile $destFile # note: DO NOT quote the args for cp command, otherwise it will not copy the files correctly with a stat failure.
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to copy Base template files [$srcFile] to [$destFile]"
    return 1
  fi
  ndr_logInfo "Base template files [$srcFile] copied to [$destFile]"
  
  # Ensure all copied files have world-readable permissions (to resolve an issue seen in makeself installation)
  local targetDir="$gSUPABASE_NEXTDR_HOME/volumes"
  if [ ! -d "$targetDir" ]; then
    ndr_logError "Target folder not found [$targetDir]"
    return 1
  fi
  
  #umask 022
  chown -R $(whoami) "$targetDir"
  
  find "$targetDir" -type f -print -exec chmod -v 644 {} +
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to change copied template file permissions recursively under [$targetDir]"
    umask
    return 1
  fi
  ndr_logInfo "Changed copied template file permissions [$targetDir]"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_CopySupabaseSchemaFile ()
{
  local logSectionDesc="Copying the $gCOMPANY_NAME schema file to project"
  ndr_logSecStart "$logSectionDesc"
  
  # Copy the NDR schema file to the project.
  # we copy the schema to the ndr supabase home loc to store as a reference for the currently installed schema. This dir already exists so no need to create.
  
  local schemaDestLocation="${gSUPABASE_NEXTDR_HOME}"
  
  local schemaSrcFile="${gACTIVE_NDR_SQL_SCHEMA_FILE}"
  if [ -z "$schemaSrcFile" ] || [ ! -f "$schemaSrcFile" ]; then
    schemaSrcFile="${gSCRIPT_HOME_DIR}/${gNDR_REFERENCE_SQL_SCHEMA_FILENAME}"
  fi

  if [ -z "$schemaSrcFile" ] || [ ! -f "$schemaSrcFile" ]; then
    ndr_logError "No active Supabase schema file [$gACTIVE_NDR_SQL_SCHEMA_FILE] found."
    return 1
  fi

  local schemaDestFile="${schemaDestLocation}/${gNDR_REFERENCE_SQL_SCHEMA_FILENAME}"

  cp -f $schemaSrcFile $schemaDestFile
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to copy Supabase schema file [$schemaSrcFile] to [$schemaDestFile]"
    return 1
  fi
  ndr_logInfo "Successfully copied Supabase schema file [$schemaSrcFile] to [$schemaDestFile]"

  gACTIVE_NDR_SQL_SCHEMA_FILE="$schemaDestFile"
  ndr_logInfo "Updating active Supabase schema file as [$gACTIVE_NDR_SQL_SCHEMA_FILE]."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_CopySupabaseEnvFile ()
{
  local logSectionDesc="Copying the Supabase template env file to project"
  ndr_logSecStart "$logSectionDesc"
  
  if [ "$gUPGRADE_MODE" == true ]; then
    ndr_logDebug "Upgrade mode set, skipping section."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # Copy the supplied template env var file to the project.
  # its important to use the supplied template file because it is maintained by supabase and 
  # contains all essential vars pertinent to the image versions it is accompanied with.
  local envSrcFile="${gSUPABASE_TEMPLATE_HOME}/docker/${gNDR_SUPABASE_ENV_TEMPLATE_VAR_FILENAME}"
  local envDestFile="${gSUPABASE_NEXTDR_HOME}/${gNDR_ENV_TARGET_FILENAME}"
  cp -f $envSrcFile $envDestFile
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to copy the Supabase template env file [$envSrcFile] to [$envDestFile]"
    return 1
  fi
  ndr_logInfo "Supabase template env file [$envSrcFile] copied to [$envDestFile]"
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_GenerateJWT () 
{
  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: <role> <jwt_secret>"
    return 1
  fi

  local role=$1
  local jwt_secret=$2
  local iat=$(date +%s)                   # current time
  local exp=1911700800                    # far future expiration (2030+)
  
  local header=$(printf '{"alg":"HS256","typ":"JWT"}' \
    | openssl base64 -e -A | tr '+/' '-_' | tr -d '=')
  local payload=$(printf '{"role":"%s","iss":"supabase","iat":%s,"exp":%s}' \
    "$role" "$iat" "$exp" \
    | openssl base64 -e -A | tr '+/' '-_' | tr -d '=')
  local signature=$(printf '%s.%s' "$header" "$payload" \
    | openssl dgst -binary -sha256 -hmac "$jwt_secret" \
    | openssl base64 -e -A | tr '+/' '-_' | tr -d '=')
  
  echo "${header}.${payload}.${signature}"

  return 0
}

function ndr_CustomizeSupabaseEnvFile ()
{
  local logSectionDesc="Customizing the Supabase env file"
  ndr_logSecStart "$logSectionDesc"

  if [ "$gUPGRADE_MODE" == true ]; then
    ndr_logDebug "Upgrade mode set, skipping section."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # decrypt and populate secrets.
  #ndr_DecryptPopulateSecrets || { echo "Error: failed to populate secrets"; return 1; }

  local envSrcFile="${gSCRIPT_HOME_DIR}/${gNDR_SUPABASE_ENV_SOURCE_VAR_FILENAME}"
  local envDestFile="${gSUPABASE_NEXTDR_HOME}/${gNDR_ENV_TARGET_FILENAME}"
  local envDestFileTmp="${envDestFile}.tmp"  # Temporary output file

  # --- Check that files exist ---
  if [ ! -f "$envSrcFile" ]; then
    ndr_logError "Source file missing [$envSrcFile]"
    return 1
  fi
  if [ ! -f "$envDestFile" ]; then
    ndr_logError "Dest file missing [$envDestFile]"
    return 1
  fi
  if [[ -z "$gNDR_SERVER_HOST_ADDRESS" || "$gNDR_SERVER_HOST_ADDRESS" == "localhost" ]]; then
    ndr_logError "Target server host address not specified."
    return 1
  fi

  # --- customize secrets and keys ---
  # Generate a secure random JWT secret (hex string)
  gSUPABASE_ENV_VAL_JWT_SECRET=$(openssl rand -hex 32)
  if [[ $? -ne 0 ]]; then
    ndr_logError "OpenSSL failed to generate JWT secret"
    return 1
  fi
  if [ -z "$gSUPABASE_ENV_VAL_JWT_SECRET" ]; then
    ndr_logError "JWT secret returned empty"
    return 1
  fi
  # todo check ret output

  # Generate anon and service role keys
  gSUPABASE_ENV_VAL_ANON_KEY=$(ndr_GenerateJWT "anon" "$gSUPABASE_ENV_VAL_JWT_SECRET")
  if [[ $? -ne 0 ]]; then
    ndr_logError "Failed to generate anon key"
    return 1
  fi
  if [ -z "$gSUPABASE_ENV_VAL_ANON_KEY" ]; then
    ndr_logError "Anon key returned empty"
    return 1
  fi

  gSUPABASE_ENV_VAL_SERVICE_ROLE_KEY=$(ndr_GenerateJWT "service_role" "$gSUPABASE_ENV_VAL_JWT_SECRET")
  if [[ $? -ne 0 ]]; then
    ndr_logError "Failed to generate service role key"
    return 1
  fi
  if [ -z "$gSUPABASE_ENV_VAL_SERVICE_ROLE_KEY" ]; then
    ndr_logError "Service role key returned empty"
    return 1
  fi

  # global vars that will override any template env values
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_JWT_SECRET"]="$gSUPABASE_ENV_VAL_JWT_SECRET"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_ANON_KEY"]="$gSUPABASE_ENV_VAL_ANON_KEY"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_SERVICE_ROLE_KEY"]="$gSUPABASE_ENV_VAL_SERVICE_ROLE_KEY"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_DASHBOARD_USERNAME"]="$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_DASHBOARD_PASSWORD"]="$gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD"

  # --- Load custom supabase overrides into associative array ---
  declare -A src_map=()
  while IFS='=' read -r key value; do
    [[ -z "$key" || "$key" == \#* ]] && continue
    src_map["$key"]="$value"
  done < "$envSrcFile"

  ndr_logInfo "Read [${#src_map[@]}] custom values from source file [$envSrcFile] to update in target file [$envDestFile]."

  # --- Read template into array ---
  mapfile -t lines < "$envDestFile"
  if [[ $? -ne 0 ]]; then
    ndr_logError "Failed to read $envDestFile"
    return 1
  fi

  local new_lines=()
  declare -A seen_keys=()  # Tracks keys that already exist in dest

  local linesUpdated=0

  # --- Process template lines ---
  for line in "${lines[@]}"; do
    if [[ "$line" =~ ^([A-Za-z_][A-Za-z0-9_]*)=(.*)$ ]]; then
      key="${BASH_REMATCH[1]}"
      value="${BASH_REMATCH[2]}"
      seen_keys["$key"]=1

      if [[ -n "${src_map[$key]+_}" ]]; then
        value="${src_map[$key]}"
        ndr_logInfo "Overriding $key with custom value from source"
        linesUpdated=$((linesUpdated += 1))
      fi

      if [[ "$value" == *"localhost"* ]]; then
        value="${value//localhost/$gNDR_SERVER_HOST_ADDRESS}"
        ndr_logInfo "Updating host address key with actual value [$key=$value]"
        linesUpdated=$((linesUpdated += 1))
      fi

      new_lines+=("$key=$value")
    else
      new_lines+=("$line")
    fi
  done

  # --- Append any source keys not in the template ---
  for key in "${!src_map[@]}"; do
    if [[ -z "${seen_keys[$key]+_}" ]]; then
      ndr_logInfo "Adding missing key from source: $key"
      value="${src_map[$key]}"
      if [[ "$value" == *"localhost"* ]]; then
        value="${value//localhost/$gNDR_SERVER_HOST_ADDRESS}"
        ndr_logInfo "Updating host address key with actual value [$key=$value]"
      fi
      linesUpdated=$((linesUpdated += 1))
      new_lines+=("$key=$value")
    fi
  done

  # --- Override any template or source keys from global vars ---
  # Loop through global gSUPABASE_ENV_VARS and update/add in new_lines
  for key in "${!gSUPABASE_ENV_VARS[@]}"; do
    local found=0
    local value="${gSUPABASE_ENV_VARS[$key]}"
    # if the value is empty, skip immediately.
    if [ -z "$value" ]; then
      ndr_LogWarn "Key [$key] had empty value, skipping..."
      continue
    fi
    for ii in "${!new_lines[@]}"; do
      local line="${new_lines[$ii]}"
      
      [[ -z "$line" || "$line" == \#* ]] && continue
      
      local line_key="${line%%=*}"
      if [[ "$line_key" == "$key" ]]; then
        new_lines[$ii]="$key=$value"
        found=1
        ndr_logInfo "Updating key [$key] with new value from env var map."
        break
      fi
    done
    if [[ $found -eq 0 ]]; then
      new_lines+=("$key=$value")
      ndr_logInfo "Adding new key [$key] from env var map."
    fi
  done
  
  # --- Open temp file for writing ---
  exec 3> "$envDestFileTmp" || {
    ndr_logError "Failed to open $envDestFileTmp for writing"
    return 1
  }

  # --- Write updated lines to temp file with error checking ---
  for l in "${new_lines[@]}"; do
    if ! printf '%s\n' "$l" >&3; then
      ndr_logError "Failed to write line to $envDestFileTmp: $l"
      exec 3>&-
      return 1
    fi
  done

  # --- Close temp file descriptor ---
  exec 3>&-

  # --- Move temp file into place ---
  if ! mv "$envDestFileTmp" "$envDestFile"; then
    ndr_logError "Failed to replace $envDestFile with updated content"
    return 1
  fi

  ndr_logInfo "Environment file [$envDestFile] successfully updated with [$linesUpdated] values"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_PullSupabaseBaseDockerImages ()
{
  local logSectionDesc="Pulling base Supabase Docker images"
  ndr_logSecStart "$logSectionDesc"
  
  # Go to the docker folder
  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into supabase project dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }
  
  # Pull all the latest images
  if [ ${#ndr_supabase_container_services[@]} -eq 0 ]; then
    ndr_logInfo "Pulling all Supabase images at once."
    docker compose pull --quiet
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Docker compose pull failed"
      return 1
    fi
  else
    ndr_logInfo "Pulling Supabase images individually."
    for service in "${ndr_supabase_container_services[@]}"; do
      local dockerImageBaseName="${ndr_supabase_container_service_image_names[$service]}"
      local dockerImageVersion="${ndr_supabase_container_service_image_tags[$service]}"
      local dockerImageName="$dockerImageBaseName:$dockerImageVersion"
      
      ndr_logInfo "Pulling Supabase image [$dockerImageName]."
      docker pull "$dockerImageName"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "Docker pull failed for image [$dockerImageName]"
        return 1
      fi
    done
  fi
  

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

export NDR_START_SUPABASE_DOCKER_CONTAINER_OPTION_NO_RECREATE="no_recreate"

# shellcheck disable=SC2120
function ndr_StartSupabaseDockerContainers ()
{
  # Start the container services (in detached mode)
  local logSectionDesc="Starting Supabase Docker Container services"
  ndr_logSecStart "$logSectionDesc"
  
  local opt_no_recreate="${1:-}"

  # Go to the docker folder
  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into supabase project dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }

  dockerProjectName="$gNDR_SUPABASE_DOCKER_PROJECT_NAME"

  if [ "$opt_no_recreate" == "$NDR_START_SUPABASE_DOCKER_CONTAINER_OPTION_NO_RECREATE" ]; then
    docker compose -p "$dockerProjectName" up -d --no-recreate
  else
    docker compose -p "$dockerProjectName" up -d
  fi
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Docker compose up failed"

    for service in "${ndr_supabase_container_services[@]}"; do
      local container_name="${ndr_supabase_container_service_container_names[$service]}"
      
      ndr_CheckContainerHealth "$container_name"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logWarn "Docker container returned non-healthy status [$container_name]."
        local logs_output=$(docker logs --tail 50 "$container_name" 2>&1)
        if [[ -n "$logs_output" ]]; then
          ndr_logWarn "$logs_output"
        fi
      else
        ndr_logInfo "Docker container returned healthy status [$container_name]."
      fi
    done

    return 1
  fi
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_CleanupSupabaseProjectDirs ()
{
  local logSectionDesc="Cleaning up Supabase Docker folders"
  ndr_logSecStart "$logSectionDesc"

  # clean up supabase folders
  if [[ -n "$gSUPABASE_TEMPLATE_HOME" && -d "$gSUPABASE_TEMPLATE_HOME" ]]; then
    ndr_logInfo "Removing Supabase template folder [$gSUPABASE_TEMPLATE_HOME]"
    rm -rf "$gSUPABASE_TEMPLATE_HOME"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to remove Supabase folder [$gSUPABASE_TEMPLATE_HOME]"
      #return 1
    fi
  fi

  if [[ "$gNDR_DEVOPS_MODE" == true ]]; then
    if [[ -n "$gSUPABASE_NEXTDR_HOME" && -d "$gSUPABASE_NEXTDR_HOME" ]]; then
      rm -rf "$gSUPABASE_NEXTDR_HOME"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "Failed to remove Supabase folder [$gSUPABASE_NEXTDR_HOME]"
        #return 1
      fi
    fi
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_StopSupabaseDockerContainers ()
{
  # bring the containers down.
  local logSectionDesc="Stopping Supabase Docker containers"
  ndr_logSecStart "$logSectionDesc"
  
  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into supabase project dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }
  
  docker compose down
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logInfo "Failed to stop Supabase Docker containers"
    return 0
  fi
  ndr_logInfo "Stopped Supabase Docker containers"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseSchemaDiffPrepare ()
{
  local logSectionDesc="Preparing Supabase Schema Diff Environment"
  ndr_logSecStart "$logSectionDesc"

  if [ "$gNDR_SUPABASE_UPGRADE_SCHEMA_DIFF_GENERATE" = false ]; then
    ndr_logInfo "Schema diff file explicitly supplied [$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF]. Skipping prepare."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  ndr_SupabaseBuildTempDatabase "$NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_UPGRADE" "$NDR_SCHEMA_DIFF_SUPABASE_DIR" "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to build Supabase temp upgrade database for schema diff."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseBuildTempDatabase ()
{
  local logSectionDesc="Building Supabase Temp Database Environment"
  ndr_logSecStart "$logSectionDesc"
  
  # Argument validation
  if [[ $# -lt 3 ]]; then
    ndr_logError "Usage: function <db_build_options> <db_build_folder> <schema_file>"
    return 1
  fi

  local buildOptions=${1:-}
  local buildDBFolder=${2:-}
  local schemaFile=${3:-}
  
  # -----------------------------
  # Configuration
  # -----------------------------
  local PROD_DB_CONTAINER="$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME"
  local checkoutTag="$gNDR_SUPABASE_GIT_VERSION_TAG"
  local DB_SERVICE="$NDR_SUPABASE_APP_SERVICE_NAME_DB"
  local supabaseDockerDir="${buildDBFolder}/${NDR_SCHEMA_DIFF_SUPABASE_DOCKER_SUB_DIR}"
  local COMPOSE_FILE="${supabaseDockerDir}/$NDR_STANDARD_DOCKER_COMPOSEFILE_FILENAME"
  local project_name="$NDR_SCHEMA_DIFF_SUPABASE_PROJECT_NAME_DIFF"
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_BASELINE )); then
    project_name="$NDR_SCHEMA_DIFF_SUPABASE_PROJECT_NAME_BASELINE"
  fi

  # -----------------------------
  # Prepare temp folders
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_PREPARE_FOLDERS )); then
    if [ ! -d "$NDR_SCHEMA_DIFF_WORK_DIR" ]; then
      ndr_logInfo "Creating schema diff work dir [$NDR_SCHEMA_DIFF_WORK_DIR]"
      sudo mkdir -p "$NDR_SCHEMA_DIFF_WORK_DIR"  
      sudo chown "$(whoami)":"$(whoami)" "$NDR_SCHEMA_DIFF_WORK_DIR"
    fi
    
    if [ ! -d "$buildDBFolder" ]; then
      ndr_logInfo "Creating supabase diff container dir [$buildDBFolder]"
      sudo mkdir -p "$buildDBFolder"  
      sudo chown "$(whoami)":"$(whoami)" "$buildDBFolder"
    fi
  fi

  # -----------------------------
  # checkout supabase repo
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CLONE_REPO )); then
    ndr_logInfo "Cloning Supabase repository into [$buildDBFolder]"

    cd "$buildDBFolder" || { ndr_logError "Failed to cd into dir [$buildDBFolder]"; return 1; }

    git clone --filter=blob:none --no-checkout https://github.com/supabase/supabase "$buildDBFolder"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Git clone failed."
      return 1
    fi
    ndr_logInfo "Git clone for Supabase completed."

    git sparse-checkout set --cone docker
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "GIT sparse checkout for docker only folder failed."
      return 1
    fi
    ndr_logInfo "Git sparse checkout for Supabase completed."

    ndr_logInfo "Checking out Supabase repository tag [$checkoutTag]"
    git checkout "$checkoutTag"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "GIT checkout for [$checkoutTag] failed."
      return 1
    fi
    ndr_logInfo "Git checkout for [$checkoutTag] completed."
  fi

  # -----------------------------
  # copy template env file
  # -----------------------------
  local envDestFile=""
  
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_COPY_ENV_FILE )); then
    local envSrcFile="${supabaseDockerDir}/${gNDR_SUPABASE_ENV_TEMPLATE_VAR_FILENAME}"
    envDestFile="${supabaseDockerDir}/${gNDR_ENV_TARGET_FILENAME}"
    cp -f $envSrcFile $envDestFile
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to copy the Supabase template env file [$envSrcFile] to [$envDestFile]"
      return 1
    fi
    ndr_logInfo "Supabase template env file [$envSrcFile] copied to [$envDestFile]"
  fi

  # -----------------------------
  # modify postgres port in env file to 5433
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODIFY_ENV_PORTS )); then
    local port="5433"
    if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_BASELINE )); then
      port="5434"
    fi
    
    sed -i "s/^POSTGRES_PORT=.*/POSTGRES_PORT=$port/" "$envDestFile"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to modify POSTGRES_PORT in env file [$envDestFile]"
      return 1
    fi
    ndr_logInfo "Modified POSTGRES_PORT to $port in env file [$envDestFile]"
  fi

  # -----------------------------
  # configure compose services
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CONFIGURE_COMPOSE_SERVICES )); then
    
    # -----------------------------
    # customize project name
    # -----------------------------
    # Replace first occurrence of 'name: supabase' with 'name: supabase-<suffix>'
    yq eval -i ".name = \"${project_name}\"" "$COMPOSE_FILE"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logWarn "Failed to change compose file project name to \"$project_name\"."
      return 1
    fi
    ndr_logInfo "Changed compose file project name to \"$project_name\"."
      
    for service in "${NDR_SCHEMA_DIFF_DOCKER_SERVICES[@]}"; do
      # -----------------------------
      # read the image name for the services in the compose file
      # -----------------------------
      local image_section=".services.$service.image"
      local temp_image_name=$(yq eval "$image_section" "$COMPOSE_FILE")
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "Failed to read $image_section from compose file."
        return 1
      fi
      ndr_logInfo "Read $image_section as [$temp_image_name] from compose file."

      # -----------------------------
      # read the container name for the services in the compose file
      # -----------------------------
      local container_name_section=".services.$service.container_name"
      local prod_container_name=$(yq eval "$container_name_section" "$COMPOSE_FILE")
      return_code=$?
      if [[ $return_code != 0 || -z "$prod_container_name" ]]; then
        ndr_logError "Failed to read $container_name_section from compose file."
        return 1
      fi

      # -----------------------------
      # get the image name of the production db container
      # -----------------------------
      local prod_image_name=$(ndr_QueryContainerImageName "$prod_container_name")
      return_code=$?
      if [[ $return_code -ne 0 || -z "$prod_image_name" ]]; then
        ndr_logWarn "Failed to retrieve image name for container [$prod_container_name]. Using image name [$temp_image_name] from compose file."
        prod_image_name="$temp_image_name"
        gNDR_RETAIN_DOCKER_IMAGES=true
      fi
      ndr_logInfo "Image name for container [$prod_container_name]: $prod_image_name"
      
      # -----------------------------
      # modify compose file container_name value to append suffix
      # -----------------------------
      local temp_container_name=""
      local temp_container_suffix="-diff"
      if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_BASELINE )); then
        temp_container_suffix="-base"
      fi
      temp_container_name="${prod_container_name}${temp_container_suffix}"
      yq eval -i "$container_name_section = \"$temp_container_name\"" "$COMPOSE_FILE"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logWarn "Failed to change $container_name_section to '$temp_container_name' in compose file."
        return 1
      fi
      ndr_logInfo "Changed $container_name_section to '$temp_container_name' in compose file."

      # -----------------------------
      # preserve values
      # -----------------------------
      NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_PROD["$service"]="$prod_container_name"
      NDR_SCHEMA_DIFF_DOCKER_SERVICE_IMAGES_PROD["$service"]="$prod_image_name"

      if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_UPGRADE )); then
        NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_TEMP["$service"]="$temp_container_name"
        NDR_SCHEMA_DIFF_DOCKER_SERVICE_IMAGES_TEMP["$service"]="$temp_image_name"
      fi
      if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_BASELINE )); then
        NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_BASE["$service"]="$temp_container_name"
        NDR_SCHEMA_DIFF_DOCKER_SERVICE_IMAGES_BASE["$service"]="$temp_image_name"
      fi
    done
  fi

  # -----------------------------
  # pull images
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_PULL_IMAGES )); then
    cd "$supabaseDockerDir" || { ndr_logError "Failed to cd into dir [$supabaseDockerDir]"; return 1; }

    for service in "${NDR_SCHEMA_DIFF_DOCKER_SERVICES[@]}"; do
      docker compose pull --quiet "$service"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "Docker compose pull failed for service [$service]"
        return 1
      fi
      ndr_logInfo "Docker compose pull completed for service [$service]"
    done
  fi

  # -----------------------------
  # compose containers
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_COMPOSE_CONTAINERS )); then
    cd "$supabaseDockerDir" || { ndr_logError "Failed to cd into dir [$supabaseDockerDir]"; return 1; }

    for service in "${NDR_SCHEMA_DIFF_DOCKER_SERVICES[@]}"; do
      docker compose -p "$project_name" -f "$COMPOSE_FILE" up -d --no-deps --force-recreate "$service"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "Docker compose up failed for service [$service]"
        return 1
      fi
      ndr_logInfo "Docker compose up completed for service [$service]"
    done
  fi

  # -----------------------------
  # wait for containers to be running/healthy
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CONTAINER_VERIFY )); then
    for service in "${NDR_SCHEMA_DIFF_DOCKER_SERVICES[@]}"; do
      local max_retries=3
      local attempt=1
      local container_name=""
      if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_UPGRADE )); then
        container_name="${NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_TEMP[$service]}"
      else
        container_name="${NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_BASE[$service]}"
      fi
        
      while true; do
        sleep 3

        ndr_verifyDockerContainerRunning "$container_name" >/dev/null
        return_code=$?
        if [ $return_code -eq 0 ]; then
          ndr_logInfo "Container is running [$container_name]"
          break
        fi
        
        if [[ $attempt -ge $max_retries ]]; then
          ndr_logError "Max container running checks reached for [$container_name]. Exiting."
          return 1
        fi

        attempt=$((attempt + 1))
      done

      # -----------------------------
      # wait for DB container to be healthy
      # -----------------------------
      attempt=1

      while true; do

        sleep 3

        ndr_CheckContainerHealth "$container_name"
        return_code=$?
        if [[ $return_code -eq 0 ]]; then
          ndr_logInfo "Docker container returned healthy status [$container_name]."
          break
        fi
          
        if [[ $attempt -ge $max_retries ]]; then
          ndr_logError "Max container health checks reached for [$container_name]. Exiting."

          ndr_logWarn "Docker container returned non-healthy status [$container_name]."
          local logs_output=$(docker logs --tail 50 "$container_name" 2>&1)
          if [[ -n "$logs_output" ]]; then
            ndr_logWarn "$logs_output"
          fi

          return 1
        fi

        attempt=$((attempt + 1))
      done
    done
  fi

  # -----------------------------
  # connect new containers to existing ndr bridge network
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_BRIDGE_NETWORKS )); then
    # create or verify the bridge network exists
    ndr_createDockerBridgeNetwork
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to create or verify docker bridge network [$NDR_DOCKER_BRIDGE_NETWORK_NAME]"
      return 1
    fi

    for service in "${NDR_SCHEMA_DIFF_DOCKER_SERVICES[@]}"; do
      local container_name=""
      if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_UPGRADE )); then
        container_name="${NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_TEMP[$service]}"
      else
        container_name="${NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_BASE[$service]}"
      fi

      docker network connect "$NDR_DOCKER_BRIDGE_NETWORK_NAME" "$container_name"
      return_code=$?
      if [ $return_code != 0 ]; then
        ndr_logError "Docker network [$NDR_DOCKER_BRIDGE_NETWORK_NAME] connect failed for [$container_name]"
        return 1
      fi
      ndr_logInfo "Docker network [$NDR_DOCKER_BRIDGE_NETWORK_NAME] connect completed for [$container_name]"
    done
  fi

  # -----------------------------
  # Detect Postgres credentials inside container
  # -----------------------------
  local PROD_POSTGRES_ENV=""
  local PROD_POSTGRES_USER=""
  local PROD_POSTGRES_PASSWORD=""
  local PROD_POSTGRES_DB=""

  local TEMP_DB_CONTAINER=""
  local TEMP_POSTGRES_ENV=""
  local TEMP_POSTGRES_USER=""
  local TEMP_POSTGRES_PASSWORD=""
  local TEMP_POSTGRES_DB=""

  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_QUERY_PROD_DB_ENV )); then
    PROD_POSTGRES_ENV=$(docker exec -i "$PROD_DB_CONTAINER" env | grep POSTGRES_)
    PROD_POSTGRES_USER=$(echo "$PROD_POSTGRES_ENV" | grep POSTGRES_USER | cut -d '=' -f2 | tr -d '\r\n')
    PROD_POSTGRES_PASSWORD=$(echo "$PROD_POSTGRES_ENV" | grep POSTGRES_PASSWORD | cut -d '=' -f2 | tr -d '\r\n')
    PROD_POSTGRES_DB=$(echo "$PROD_POSTGRES_ENV" | grep POSTGRES_DB | cut -d '=' -f2 | tr -d '\r\n')
    #local PROD_POSTGRES_PORT=$(echo "$PROD_POSTGRES_ENV" | grep POSTGRES_PORT | cut -d '=' -f2 | tr -d '\r\n')
    
    if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_UPGRADE )); then
      TEMP_DB_CONTAINER="${NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_TEMP[$DB_SERVICE]}"
    else
      TEMP_DB_CONTAINER="${NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_BASE[$DB_SERVICE]}"
    fi
    TEMP_POSTGRES_ENV=$(docker exec -i "$TEMP_DB_CONTAINER" env | grep POSTGRES_)
    TEMP_POSTGRES_USER=$(echo "$TEMP_POSTGRES_ENV" | grep POSTGRES_USER | cut -d '=' -f2 | tr -d '\r\n')
    TEMP_POSTGRES_PASSWORD=$(echo "$TEMP_POSTGRES_ENV" | grep POSTGRES_PASSWORD | cut -d '=' -f2 | tr -d '\r\n')
    TEMP_POSTGRES_DB=$(echo "$TEMP_POSTGRES_ENV" | grep POSTGRES_DB | cut -d '=' -f2 | tr -d '\r\n')
  fi
    
  # -----------------------------
  # Inject schema into temp DB
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_INJECT_SCHEMA )); then
    ndr_logInfo "Applying schema [$schemaFile] to temp container [$TEMP_DB_CONTAINER] for diff comparison..."

    # determine which user to use based on version (>=1.25.12 use supabase admin due to auth changes)
    ndr_version_ge "$gNDR_SUPABASE_GIT_VERSION_TAG" "1.25.12"
    return_code=$?
    if [ $return_code -eq 0 ]; then
      gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT="$gNDR_SUPABASE_DB_OPS_SUPABASE_ADMIN_USER"
      ndr_logDebug "Supabase version [$gNDR_SUPABASE_GIT_VERSION_TAG] >= 1.25.12, using supabase admin user [$gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT] for schema application."
    fi
    ndr_logInfo "Using schema account [$gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT] for schema application."

    # full command arg list
    # sqlOutput=$(docker compose exec -T "$DB_SERVICE" psql -U "$gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT" -d postgres -v ON_ERROR_STOP=1 < "$schemaFile")
    local psql_args=()
    psql_args+=("docker" "compose" "exec" "-T" "$DB_SERVICE" "psql" "-U" "$gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT" "-d" "$TEMP_POSTGRES_DB")

    # Conditionally add -v ON_ERROR_STOP=1
    if [[ "$gNDR_ALLOW_SCHEMA_ERRORS" != "true" ]]; then
      psql_args+=("-v" "ON_ERROR_STOP=1")
    fi

    # Execute and capture output
    local sqlOutput=$("${psql_args[@]}" < "$schemaFile")
    return_code=$?

    # Print any ERROR or WARNING lines from sqlOutput
    if [ -n "$sqlOutput" ]; then
      while IFS= read -r line; do
        if echo "$line" | grep -qE 'ERROR|WARNING'; then
          echo "$line"
        fi
      done <<< "$sqlOutput"
    fi

    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to apply upgrade schema to upgrade temp container [$TEMP_DB_CONTAINER]."
      return 1
    fi
  fi

  # -----------------------------
  # Validate schema applied by checking for a known table
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_VALIDATE_SCHEMA )); then    
    ndr_logInfo "Querying Supabase tables for schema..."
    local table_list=$(docker compose exec -T "$DB_SERVICE" psql -U "$gNDR_SUPABASE_DB_OPS_POSTGRES_ADMIN_USER" -d "$TEMP_POSTGRES_DB" -c '\dt' 2>/dev/null)
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logWarn "Failed to query schema status"
    fi
    
    local searchTable="recovery_plans"
    if [[ -n "$table_list" ]]; then
      # Search for the recovery_plans table
      if echo "$table_list" | grep -q "\b$searchTable\b"; then
        #ndr_logInfo "$table_list"
        ndr_logInfo "Table $searchTable found, schema applied."
      else
        ndr_logInfo "$table_list"
        ndr_logError "Table $searchTable not found. Schema may not have been applied."
        return 1
      fi
    else
      ndr_logError "Table list empty. Schema may not have been applied."
      return 1
    fi
  fi

  # -----------------------------
  # Compare table counts to ensure they are consistent (upgrade db count should be greater then or equal to prod db count)
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_VALIDATE_BUILD_TABLES )); then
    local prod_table_count=$(docker exec -i "$PROD_DB_CONTAINER" psql -U "$PROD_POSTGRES_USER" -d "$PROD_POSTGRES_DB" -At -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_type = 'BASE TABLE';")
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logWarn "Failed to query production table count"
    fi
    ndr_logInfo "Production table count: $prod_table_count"

    local temp_table_count=$(docker exec -i "$TEMP_DB_CONTAINER" psql -U "$TEMP_POSTGRES_USER" -d "$TEMP_POSTGRES_DB" -At -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_type = 'BASE TABLE';")
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logWarn "Failed to query upgrade table count"
    fi
    ndr_logInfo "Temp table count: $temp_table_count"

    if [[ "$temp_table_count" -lt "$prod_table_count" ]]; then
      ndr_logWarn "Temp table count ($temp_table_count) is less than production table count ($prod_table_count)."
    fi
  fi

  # -----------------------------
  # Create Python driver script on host
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_INSTALL_DIFF_UTILS )); then
    
cat > "${NDR_SCHEMA_DIFF_WORK_DIR}/$NDR_SCHEMA_DIFF_PYTHON_SCRIPT_FILE" << 'EOF'
#!/usr/bin/env python3
import sys
from sqlbag import S
from migra import Migration

def main():
    if len(sys.argv) != 4:
        print("Usage: run_diff.py <CURR_DB_URL> <UPGR_DB_URL> <OUTPUT_SQL_PATH>")
        sys.exit(1)

    curr_db = sys.argv[1]
    upgr_db = sys.argv[2]
    output_path = sys.argv[3]
    schema = "public"

    print(f"Diffing schema '{schema}' from CURRENT DB → UPGRADE DB")
    #print(f"  CURRENT DB: {curr_db}")
    #print(f"  UPGRADE DB: {upgr_db}")
    print(f"  Output path: {output_path}")

    try:
        with S(curr_db) as a, S(upgr_db) as b:
            m = Migration(a, b, schema=schema)
            m.set_safety(False)
            m.add_all_changes()
            sql = m.sql
            if sql:
                with open(output_path, "w") as f:
                    f.write(sql)
                print(f"Wrote diff SQL to: {output_path}")
            else:
                print("No differences found — output file not created.")
    except Exception as e:
        print(f"Error while generating diff: {e}")
        sys.exit(2)

if __name__ == "__main__":
    main()
EOF

    chmod +x "${NDR_SCHEMA_DIFF_WORK_DIR}/$NDR_SCHEMA_DIFF_PYTHON_SCRIPT_FILE"

    if [ ! -f "${NDR_SCHEMA_DIFF_WORK_DIR}/$NDR_SCHEMA_DIFF_PYTHON_SCRIPT_FILE" ]; then
      ndr_logError "Failed to create schema diff script [${NDR_SCHEMA_DIFF_WORK_DIR}/$NDR_SCHEMA_DIFF_PYTHON_SCRIPT_FILE]"
      return 1
    fi
  
    # -----------------------------
    # Copy Python script and repo into container /tmp
    # -----------------------------
    local src="${NDR_SCHEMA_DIFF_WORK_DIR}/$NDR_SCHEMA_DIFF_PYTHON_SCRIPT_FILE"
    local dest="$TEMP_DB_CONTAINER:/tmp/$NDR_SCHEMA_DIFF_PYTHON_SCRIPT_FILE"
    docker cp "$src" "$dest"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to copy [$src] to [$dest]."
      return 1
    fi
    ndr_logInfo "Copied schema diff script [$src] to container [$dest]."

    # -----------------------------
    # Install dependencies inside container (system-wide)
    # -----------------------------
    docker exec -i "$TEMP_DB_CONTAINER" bash -c "
    apt-get update && apt-get install -y python3-pip
    pip3 install --upgrade pip
    pip3 install psycopg2-binary sqlbag migra"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to install schema diff prerequisites inside container [$TEMP_DB_CONTAINER]."
      return 1
    fi
    ndr_logInfo "Schema diff prerequisites installed successfully inside container."
  fi

  ndr_logInfo "Supabase test database environment built successfully."

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseSchemaDiffGenerate ()
{
  local logSectionDesc="Generating Supabase Schema Diff"
  ndr_logSecStart "$logSectionDesc"

  if [ "$gNDR_SUPABASE_UPGRADE_SCHEMA_DIFF_GENERATE" = false ]; then
    ndr_logInfo "Schema diff file explicity supplied [$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF]. Skipping generation."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # -----------------------------
  # Configuration
  # -----------------------------
  local DB_SERVICE="$NDR_SUPABASE_APP_SERVICE_NAME_DB"
  local PROD_DB_CONTAINER="$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME"
  local TEMP_DB_CONTAINER="${NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_TEMP[$DB_SERVICE]}"

  ndr_SupabaseDiffTempDatabase "$PROD_DB_CONTAINER" "$TEMP_DB_CONTAINER"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to generate Supabase schema diff of [$PROD_DB_CONTAINER] and [$TEMP_DB_CONTAINER]"
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseDiffTempDatabase ()
{
  local logSectionDesc="Generating Diff of Supabase Temp Databases"
  ndr_logSecStart "$logSectionDesc"
  
  # Argument validation
  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <baseline_db> <diff_db>"
    return 1
  fi

  local baselineDB=${1:-}
  local diffDB=${2:-}
    
  # -----------------------------
  # Prepare host workspace
  # -----------------------------
  if [ ! -d "$NDR_SCHEMA_DIFF_WORK_DIR" ]; then
    ndr_logInfo "Creating schema diff work dir [$NDR_SCHEMA_DIFF_WORK_DIR]"
    sudo mkdir -p "$NDR_SCHEMA_DIFF_WORK_DIR"  
    sudo chown "$(whoami)":"$(whoami)" "$NDR_SCHEMA_DIFF_WORK_DIR"
  fi
  cd "$NDR_SCHEMA_DIFF_WORK_DIR" || { ndr_logError "Failed to cd into dir [$NDR_SCHEMA_DIFF_WORK_DIR]"; return 1; }
  
  # -----------------------------
  # Detect Postgres credentials inside container
  # -----------------------------
  local PROD_POSTGRES_ENV=$(docker exec -i "$baselineDB" env | grep POSTGRES_)
  local PROD_POSTGRES_USER=$(echo "$PROD_POSTGRES_ENV" | grep POSTGRES_USER | cut -d '=' -f2 | tr -d '\r\n')
  local PROD_POSTGRES_PASSWORD=$(echo "$PROD_POSTGRES_ENV" | grep POSTGRES_PASSWORD | cut -d '=' -f2 | tr -d '\r\n')
  local PROD_POSTGRES_DB=$(echo "$PROD_POSTGRES_ENV" | grep POSTGRES_DB | cut -d '=' -f2 | tr -d '\r\n')
  local PROD_POSTGRES_PORT=$(echo "$PROD_POSTGRES_ENV" | grep POSTGRES_PORT | cut -d '=' -f2 | tr -d '\r\n')
  
  local TEMP_POSTGRES_ENV=$(docker exec -i "$diffDB" env | grep POSTGRES_)
  local TEMP_POSTGRES_USER=$(echo "$TEMP_POSTGRES_ENV" | grep POSTGRES_USER | cut -d '=' -f2 | tr -d '\r\n')
  local TEMP_POSTGRES_PASSWORD=$(echo "$TEMP_POSTGRES_ENV" | grep POSTGRES_PASSWORD | cut -d '=' -f2 | tr -d '\r\n')
  local TEMP_POSTGRES_DB=$(echo "$TEMP_POSTGRES_ENV" | grep POSTGRES_DB | cut -d '=' -f2 | tr -d '\r\n')
  
  # To run FROM upgr unix socket and connect TO prod via bridge net
  local PROD_DB_CONN_STR="postgresql://$PROD_POSTGRES_USER:$PROD_POSTGRES_PASSWORD@$baselineDB:$PROD_POSTGRES_PORT/$PROD_POSTGRES_DB"
  local TEMP_DB_CONN_STR="postgresql://$TEMP_POSTGRES_USER:$TEMP_POSTGRES_PASSWORD@/$TEMP_POSTGRES_DB?host=/var/run/postgresql"

  # -----------------------------
  # Run the diff inside container
  # -----------------------------
  local container_schema_diff_file="/tmp/$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF_FILENAME"
  docker exec -i "$diffDB" bash -c "
  python3 /tmp/$NDR_SCHEMA_DIFF_PYTHON_SCRIPT_FILE '$PROD_DB_CONN_STR' '$TEMP_DB_CONN_STR' '$container_schema_diff_file'"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to execute schema diff script inside container [$diffDB]."
    return 1
  fi
  ndr_logInfo "Schema diff script executed successfully inside container [$diffDB]."

  ndr_logDebug "Diff cmd: [python3 /tmp/$NDR_SCHEMA_DIFF_PYTHON_SCRIPT_FILE '$PROD_DB_CONN_STR' '$TEMP_DB_CONN_STR' '$container_schema_diff_file']"
  
  # -----------------------------
  # Copy resulting diff back to host
  # -----------------------------
  local src="$diffDB:$container_schema_diff_file"
  local dest="$NDR_SCHEMA_DIFF_WORK_DIR/$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF_FILENAME"
  docker cp "$src" "$dest"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to copy diff file [$src] to [$dest]."
    return 1
  fi
  ndr_logInfo "Copied schema diff file from container [$src] to host [$dest]."

  gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF="$dest"

  # -----------------------------
  # Verify output
  # -----------------------------
  if [ ! -f "$dest" ]; then
    ndr_logError "Diff file not found [$dest]."
    return 1
  fi

  # -----------------------------
  # check file size
  # -----------------------------
  local fileSizeBytes=$(stat -c%s "$dest")
  if [ $fileSizeBytes -eq 0 ]; then
    ndr_logInfo "Diff file empty. Either no differences found between production and upgrade schemas or an error occurred generating the diff."
    rm -f "$dest"
    return 1
  fi

  # -----------------------------
  # Embed version info header
  # -----------------------------
  ndr_SupabaseSchemaHeaderWrite "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to write schema diff header to file [$dest]."
    return 1
  fi
  
  # -----------------------------
  ndr_logInfo "Generated schema diff file [$dest]."
  ndr_logDebug "Diff file contents: $(cat "$dest")"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseSchemaDiffCleanup ()
{
  local logSectionDesc="Supabase Schema Diff Cleanup"
  ndr_logSecStart "$logSectionDesc"

  if [ "$gNDR_SUPABASE_UPGRADE_SCHEMA_DIFF_GENERATE" = false ]; then
    ndr_logInfo "Schema diff file explicitly supplied [$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF]. Skipping cleanup."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  ndr_SupabaseCleanupTempDatabase "$NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_UPGRADE" "$NDR_SCHEMA_DIFF_SUPABASE_DIR"
  local return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Failed to cleanup Supabase temp upgrade database."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseCleanupTempDatabase ()
{
  local logSectionDesc="Cleanup Supabase Temp Database Environment"
  ndr_logSecStart "$logSectionDesc"
  
  # Argument validation
  if [[ $# -lt 2 ]]; then
    ndr_logError "Usage: function <db_build_options> <db_build_folder>"
    return 1
  fi

  local buildOptions=${1:-}
  local buildDBFolder=${2:-}
  
  local supabaseDockerDir="${buildDBFolder}/${NDR_SCHEMA_DIFF_SUPABASE_DOCKER_SUB_DIR}"
  local retVal=0
  
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CLEANUP_SERVICES )); then
    cd "$supabaseDockerDir" || { ndr_logError "Failed to cd into dir [$supabaseDockerDir]"; return 1; }

    for service in "${NDR_SCHEMA_DIFF_DOCKER_SERVICES[@]}"; do

      # -----------------------------
      # Gather image/container status
      # -----------------------------

      local remove_container=true
      local temp_container_name=""
      if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_UPGRADE )); then
        temp_container_name="${NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_TEMP[$service]}"
      else
        temp_container_name="${NDR_SCHEMA_DIFF_DOCKER_SERVICE_CONTAINERS_BASE[$service]}"
      fi
      
      if [ -z "$temp_container_name" ]; then
        ndr_logError "Empty container name for service [$service], skipping container removal."
        retVal=1
        remove_container=false
      fi

      if [ "$remove_container" = true ]; then
        ndr_verifyDockerContainerExists "$temp_container_name" >/dev/null
        return_code=$?
        #2-error, 1-not found, 0-found
        if [[ $return_code != 0 ]]; then
          # skip if not found
          ndr_logWarn "Docker container '$temp_container_name' not found, nothing to prune."
          remove_container=false
        fi
      fi

      local remove_image=true;
      local temp_image_name=""
      if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_MODE_UPGRADE )); then
        temp_image_name="${NDR_SCHEMA_DIFF_DOCKER_SERVICE_IMAGES_TEMP[$service]}"
      else
        temp_image_name="${NDR_SCHEMA_DIFF_DOCKER_SERVICE_IMAGES_BASE[$service]}"
      fi
      
      if [ -z "$temp_image_name" ]; then
        ndr_logError "Empty image name for service [$service], skipping image removal."
        retVal=1
        remove_image=false
      fi

      if [ "$gNDR_RETAIN_DOCKER_IMAGES" = true ]; then
        ndr_logInfo "Retain docker images flag is set, skipping image removal for [$temp_image_name]."
        remove_image=false
      fi

      # verify the tmp container image exists
      if [ "$remove_image" = true ]; then
        ndr_verifyDockerImageExists "$temp_image_name" >/dev/null
        return_code=$?
        #2-error, 1-not found, 0-found
        if [ $return_code -ne 0 ]; then
          # skip if not found
          ndr_logWarn "Docker image [$temp_image_name] not found, nothing to prune."
          remove_image=false
        fi
      fi

      # if we know both image names for the prod db container and temp diff db container, check if they are same (can't prune) or different (can prune).
      if [ "$remove_image" = true ]; then
        local prod_image_name="${NDR_SCHEMA_DIFF_DOCKER_SERVICE_IMAGES_PROD[$service]}"
        if [[ -n "$prod_image_name" && -n "$temp_image_name" && "$prod_image_name" = "$temp_image_name" ]]; then
          ndr_logInfo "Temporary diff DB image [$temp_image_name] is the same as production DB image [$prod_image_name]. Skipping image prune."
          remove_image=false
        else
          ndr_logInfo "Temporary diff DB image [$temp_image_name] is different from production DB image [$prod_image_name]. Proceeding with image prune."
        fi
      fi

      # -----------------------------
      # removal actions
      # -----------------------------

      if [ "$remove_container" = true ]; then
        ndr_logInfo "Bringing down container [$temp_container_name]..."
        docker compose down --remove-orphans "$service"
        return_code=$?
        if [ $return_code -ne 0 ]; then
          ndr_logError "Failed to bring down and remove container [$temp_container_name]."
          retVal=1
        else
          ndr_logInfo "Container [$temp_container_name] removed successfully."
        fi
      fi

      if [ "$remove_image" = true ]; then
        ndr_logInfo "Removing image [$temp_image_name]..."
        docker image rm -f "$temp_image_name"
        return_code=$?
        if [[ $return_code != 0 ]]; then
          ndr_logError "Failed to remove image [$temp_image_name]."
          retVal=1
        else
          ndr_logInfo "Docker image [$temp_image_name] removal succeeded."
        fi
      fi
    done
  fi

  # -----------------------------
  # cleanup folders
  # -----------------------------
  if (( buildOptions & NDR_SUPABASE_TEST_DB_BUILD_OPTIONS_CLEANUP_FOLDERS )); then  
    if [[ -n "$buildDBFolder" && -d "$buildDBFolder" ]]; then
      ndr_logInfo "Removing temporary schema diff work directory [$buildDBFolder]..."
      rm -rf "$buildDBFolder"
    fi

    # if no more sub-folders exist, remove parent work dir
    if [ -d "$NDR_SCHEMA_DIFF_WORK_DIR" ] && [ -z "$(ls -A "$NDR_SCHEMA_DIFF_WORK_DIR")" ]; then
      ndr_logInfo "Removing empty schema diff work directory [$NDR_SCHEMA_DIFF_WORK_DIR]..."
      rm -rf "$NDR_SCHEMA_DIFF_WORK_DIR"
    fi
  fi

  if [ "$retVal" -ne 0 ]; then
    ndr_logWarn "One or more errors occurred during Supabase schema diff container cleanup."
  fi

  ndr_logSecEnd "$logSectionDesc"

  return $retVal
}

function ndr_SupabaseRollbackSchema() 
{
  local logSectionDesc="Rolling Back to Original Supabase Schema"
  ndr_logSecStart "$logSectionDesc"
  
  local schema_file="$1"

  # check for schema file
  if [ -z "$schema_file" ] || [ ! -f "$schema_file" ]; then
    ndr_logError "No active Supabase schema file or parameter option [$schema_file]."
    return 1
  fi

  ndr_logInfo "ROLLBACK: Restoring production DB '$gNDR_SUPABASE_DB_OPS_POSTGRES_ADMIN_USER' from backup '$schema_file'"

  ndr_SupabaseApplySchema "$schema_file"
  local nRollbackError=$?

  # always perform cleanup regardless of rollback success.
  ndr_SupabaseSchemaDiffCleanup

  ndr_logSecEnd "$logSectionDesc"

  if [ $nRollbackError -ne 0 ]; then
    ndr_logError "One or more errors occurred during rollback."
    return 1
  fi
  
  return 0
}

function ndr_SupabaseSchemaHeaderWrite ()
{
  local logSectionDesc="Writing Supabase Schema Header"
  ndr_logSecStart "$logSectionDesc"

  local schema_file="$1"

  # check for schema file
  if [ -z "$schema_file" ] || [ ! -f "$schema_file" ]; then
    ndr_logError "Invalid schema file or parameter option [$schema_file]."
    return 1
  fi

  # Values to update
  #-- NDR-SCHEMA-VERSION: 1.1.0
  #-- NDR-UPGRADE-FROM: 1.0.0
  #-- NDR_SCHEMA_TYPE: INCR
  #-- NDR-FULL-BASELINE-SCHEMA-SHA256-HASH: <hash_value>
  #-- NDR-FULL-UPGRADE-SCHEMA-SHA256-HASH: <hash_value>

  gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH_VAL=""
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL=""

  # compute sha256 checksum of the FULL baseline and upgrade schema file this DIFF weas generated from.
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH_VAL=$(sha256sum "$gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL" | awk '{print $1}')
  if [ -z "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH_VAL" ]; then
    ndr_logError "Failed to compute sha256 checksum of full schema file."
    return 1
  fi
  ndr_logInfo "Computed sha256 checksum [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH_VAL] of full baseline schema file: $gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL"

  gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL=$(sha256sum "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL" | awk '{print $1}')
  if [ -z "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL" ]; then
    ndr_logError "Failed to compute sha256 checksum of full schema file."
    return 1
  fi
  ndr_logInfo "Computed sha256 checksum [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL] of full upgrade schema file: $gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL"

  # When generated from an acutal installation, the upgrade from version is the currently installed version.
  # but if run as a standalone diff generation, we would need to use the version embedded in the "from" schema file.
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL="$gINSTALLED_VERSION"
  
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL="$gPRODUCT_VERSION"
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_VAL="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_INCR"
  
  local search_pattern="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION"
  grep -q "$search_pattern" "$schema_file"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logInfo "Creating schema diff header in [$schema_file]"
    # inject initial values.
    local complete_header="--
$gNDR_SUPABASE_SCHEMA_FILE_HEADER_DESC 
$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION $gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL
$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM $gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL
$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE $gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_VAL
$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH $gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH_VAL
$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH $gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL
--"

    # Create temp file: header + original
    local tmpDiffFile="$schema_file.tmp"
    printf "%s\n\n%s" "$complete_header" "$(cat "$schema_file")" > "$tmpDiffFile"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to prepend schema version header to temp diff file [$tmpDiffFile]."
      return 1
    fi

    # Replace original file
    mv "$tmpDiffFile" "$schema_file"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to move temp diff file [$tmpDiffFile] to final diff file [$schema_file]."
      return 1
    fi

  else

    ndr_logInfo "Updating schema diff headers in [$schema_file]"

    local search_pattern="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION"
    local updated_header="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION $gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL"
    sed -i "s|.*${search_pattern}.*|${updated_header}|" "$schema_file"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to update schema version header [$search_pattern]"
      return 1
    fi

    search_pattern="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM"
    updated_header="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM $gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL"
    sed -i "s|.*${search_pattern}.*|${updated_header}|" "$schema_file"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to update schema upgrade version header [$search_pattern]"
      return 1
    fi

    search_pattern="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE"
    updated_header="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE $gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_VAL"
    sed -i "s|.*${search_pattern}.*|${updated_header}|" "$schema_file"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to update schema type header [$search_pattern]"
      return 1
    fi

    search_pattern="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH"
    updated_header="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH $gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH_VAL"
    sed -i "s|.*${search_pattern}.*|${updated_header}|" "$schema_file"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to update baseline schema hash header [$search_pattern]"
      return 1
    fi

    search_pattern="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH"
    updated_header="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH $gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL"
    sed -i "s|.*${search_pattern}.*|${updated_header}|" "$schema_file"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to update upschema version header [$search_pattern]"
      return 1
    fi
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseSchemaHeaderRead ()
{
  local logSectionDesc="Reading Supabase Schema Header"
  ndr_logSecStart "$logSectionDesc"

  local schema_file="$1"

  # check for schema file
  if [ -z "$schema_file" ] || [ ! -f "$schema_file" ]; then
    ndr_logError "Invalid schema file or parameter option [$schema_file]."
    return 1
  fi

  # Values to read
  #-- NDR-SCHEMA-VERSION: 1.1.0
  #-- NDR-UPGRADE-FROM: 1.0.0
  #-- NDR_SCHEMA_TYPE: INCR

  gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL=""
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL=""
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_VAL=""
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL=""

  #--------------------------------
  # Version

  local search_pattern="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION"
  local line=$(grep "^$search_pattern" "$schema_file")

  if [[ -z "$line" ]]; then
    ndr_logError "Schema header [$search_pattern] not found in file [$schema_file]."
    return 1
  fi

  local val="$(
    echo "$line" | cut -d':' -f2 | tr -d ' '
  )"
  ndr_logInfo "Read schema header [$search_pattern $val]"
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL="$val"
  
  #--------------------------------
  # Upgrade from version

  search_pattern="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM"
  line=$(grep "^$search_pattern" "$schema_file")

  if [[ -z "$line" ]]; then
    ndr_logError "Schema header [$search_pattern] not found in file [$schema_file]."
    return 1
  fi

  val="$(
    echo "$line" | cut -d':' -f2 | tr -d ' '
  )"
  ndr_logInfo "Read schema header [$search_pattern $val]"
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL="$val"

  #--------------------------------
  # Schema type

  search_pattern="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE"
  line=$(grep "^$search_pattern" "$schema_file")

  if [[ -z "$line" ]]; then
    ndr_logError "Schema header [$search_pattern] not found in file [$schema_file]."
    return 1
  fi

  val="$(
    echo "$line" | cut -d':' -f2 | tr -d ' '
  )"
  ndr_logInfo "Read schema header [$search_pattern $val]"
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_VAL="$val"

  #--------------------------------
  # Baseline schema sha256 hash

  search_pattern="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH"
  line=$(grep "^$search_pattern" "$schema_file")

  if [[ -z "$line" ]]; then
    ndr_logError "Schema header [$search_pattern] not found in file [$schema_file]."
    return 1
  fi

  val="$(
    echo "$line" | cut -d':' -f2 | tr -d ' '
  )"
  ndr_logInfo "Read schema header [$search_pattern $val]"
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH_VAL="$val"

  #--------------------------------
  # Upgrade schema sha256 hash

  search_pattern="$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH"
  line=$(grep "^$search_pattern" "$schema_file")

  if [[ -z "$line" ]]; then
    ndr_logError "Schema header [$search_pattern] not found in file [$schema_file]."
    return 1
  fi

  val="$(
    echo "$line" | cut -d':' -f2 | tr -d ' '
  )"
  ndr_logInfo "Read schema header [$search_pattern $val]"
  gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL="$val"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseSchemaDiffHeaderVerify ()
{
  local logSectionDesc="Verifying Supabase Schema Diff Header"
  ndr_logSecStart "$logSectionDesc"

  local schema_file="$1"

  # check for schema file
  if [ -z "$schema_file" ] || [ ! -f "$schema_file" ]; then
    ndr_logError "Invalid schema file or parameter option [$schema_file]."
    return 1
  fi

  # Values to validate
  #-- NDR-SCHEMA-VERSION: 1.1.0
  #-- NDR-UPGRADE-FROM: 1.0.0
  #-- NDR_SCHEMA_TYPE: INCR

  ndr_SupabaseSchemaHeaderRead "$schema_file"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to read schema diff header."
    return 1
  fi

  local nRet=0

  #--------------------------------
  # check basic verstion and type values

  if [ "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_VAL" != "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_INCR" ]; then
    ndr_logError "Schema diff type [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_VAL] is not incremental [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_TYPE_INCR]."
    nRet=1
  fi

  if [ "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL" != "$gINSTALLED_VERSION" ]; then
    ndr_logError "Schema diff upgrade-from version [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_UPGRADE_FROM_VAL] does not match installed version [$gINSTALLED_VERSION]."
    nRet=1
  fi

  if [ "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL" != "$gPRODUCT_VERSION" ]; then
    ndr_logWarn "Schema diff target version [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_VERSION_VAL] does not match current version [$gPRODUCT_VERSION]."
    nRet=1
  fi

  #--------------------------------
  # read and compare checksums
  while true; do
    # compute sha256 checksum of the FULL baseline schema file this DIFF was generated from.
    if [ -z "$gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL" ] || [ ! -f "$gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL" ]; then
      ndr_logError "No active Supabase full installed schema file or value [$gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL]."
      nRet=1
      break
    fi

    local fullSchemaHash=$(sha256sum "$gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL" | awk '{print $1}')
    if [ -z "$fullSchemaHash" ]; then
      ndr_logError "Failed to compute sha256 checksum of full schema file [$gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL]."
      nRet=1
      break
    fi
    ndr_logInfo "Computed sha256 checksum [$fullSchemaHash] of full schema file: $gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL"
    if [ "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH_VAL" != "$fullSchemaHash" ]; then
      ndr_logError "Schema diff full schema hash [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH_VAL] does not match computed hash [$fullSchemaHash] of full schema file [$gNDR_SUPABASE_INSTALLED_SCHEMA_FILE_FULL]."
      nRet=1
      break
    fi

    ndr_logInfo "Installed schema hash from diff header matches computed hash of installed schema file."
    gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_BASELINE_SCHEMA_SHA256_HASH_VAL="$fullSchemaHash"
    
    #--------------------------------
    # compute sha256 checksum of the FULL upgrade schema file this DIFF was generated from.
    if [ -z "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL" ] || [ ! -f "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL" ]; then
      ndr_logError "No active Supabase full upgrade schema file or value [$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL]."
      nRet=1
      break
    fi
    
    fullSchemaHash=""
    fullSchemaHash=$(sha256sum "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL" | awk '{print $1}')
    if [ -z "$fullSchemaHash" ]; then
      ndr_logError "Failed to compute sha256 checksum of full schema file [$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL]."
      nRet=1
      break
    fi
    ndr_logInfo "Computed sha256 checksum [$fullSchemaHash] of full schema file: $gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL"

    if [ "$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL" != "$fullSchemaHash" ]; then
      ndr_logError "Schema diff full schema hash [$gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL] does not match computed hash [$fullSchemaHash] of full schema file [$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL]."
      nRet=1
      break
    fi

    ndr_logInfo "Upgrade schema hash from diff header matches computed hash of upgrade schema file."
    gNDR_SUPABASE_SCHEMA_FILE_HEADER_FULL_UPGRADE_SCHEMA_SHA256_HASH_VAL="$fullSchemaHash"
    
    break
  done

  if [ $nRet -ne 0 ]; then
    ndr_logError "Schema diff header verification failed."
  else
    ndr_logInfo "Schema diff compatibility check passed."
  fi

  ndr_logSecEnd "$logSectionDesc"

  return $nRet
}


function ndr_SupabaseUpgradeSchema ()
{
  local logSectionDesc="Applying $gPRODUCT_NAME Supabase Upgrade Schema"
  ndr_logSecStart "$logSectionDesc"

  # optionally pass in a schema file to apply instead of the global one.
  gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL="${1:-$gACTIVE_NDR_SQL_SCHEMA_FILE}"
  
  # check for schema file
  if [ -z "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL" ] || [ ! -f "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL" ]; then
    ndr_logError "No active Supabase schema file or parameter option [$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_FULL]."
    return 1
  fi

  gNDR_SUPABASE_DB_MERGE_TEMP_PROD_DB="NDR-merge-tmp-db_$$"
  #gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF_FILENAME="NDR-schema-diff_v${gPRODUCT_VERSION}_${NDR_GIT_REPO_COMMIT_HASH_SHORT}_$$.sql"

  local DB_SERVICE="$NDR_SUPABASE_APP_SERVICE_NAME_DB"
  
  # determine which user to use based on version (>=1.25.12 use supabase admin due to auth changes)
  ndr_version_ge "$gNDR_SUPABASE_GIT_VERSION_TAG" "1.25.12"
  return_code=$?
  if [ $return_code -eq 0 ]; then
    gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT="$gNDR_SUPABASE_DB_OPS_SUPABASE_ADMIN_USER"
    ndr_logDebug "Supabase version [$gNDR_SUPABASE_GIT_VERSION_TAG] >= 1.25.12, using supabase admin user [$gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT] for schema application."
  fi
  ndr_logInfo "Using schema account [$gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT] for schema application."

  # ----------------------------------------------------------------
  ndr_logInfo "Setting up diff environment for schema comparison and merging..."
  ndr_SupabaseSchemaDiffPrepare
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to prepare schema diff environment."
    ndr_SupabaseSchemaDiffCleanup
    return 1
  fi

  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into supabase project dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }

  # ----------------------------------------------------------------
  ndr_logInfo "Backing up production database (schema+data)..."
  
  # For the sole purpose of rollback, we must backup public and auth with data.
  #docker compose exec -T "$DB_SERVICE" pg_dump -U "$gNDR_SUPABASE_DB_OPS_POSTGRES_ADMIN_USER" -d "$gNDR_SUPABASE_DB_OPS_PRODUCTION_DB" --no-owner --schema=auth --schema=extensions --schema=public > "$gNDR_SUPABASE_DB_BACKUP_FILE"
  ndr_BackupPostgresDB
  return_code=$?
  if [ $return_code -ne 0 ] || [ ! -s "$gNDR_SUPABASE_DB_BACKUP_FILE" ]; then
    ndr_logError "Failed to dump production database."
    ndr_SupabaseSchemaDiffCleanup
    return 1
  fi
  chmod 777 "$gNDR_SUPABASE_DB_BACKUP_FILE"

  # ----------------------------------------------------------------
  ndr_logInfo "Generating schema diff between production and upgraded temp DB's..."
  ndr_SupabaseSchemaDiffGenerate
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to generate schema diff."
    ndr_SupabaseSchemaDiffCleanup
    return 1
  fi

  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into supabase project dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }

  # ----------------------------------------------------------------
  ndr_logInfo "Checking schema diff for compatibility..."
  ndr_SupabaseSchemaDiffHeaderVerify "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to validate schema diff."
    ndr_SupabaseSchemaDiffCleanup
    return 1
  fi

  # ----------------------------------------------------------------
  # Stop select services that may re-open connections
  ndr_logInfo "Stopping Supabase Dashboard and related services..."
  docker compose stop "$NDR_SUPABASE_APP_SERVICE_NAME_REALTIME" "$NDR_SUPABASE_APP_SERVICE_NAME_REST" "$NDR_SUPABASE_APP_SERVICE_NAME_KONG" "$NDR_SUPABASE_APP_SERVICE_NAME_STUDIO"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to stop Supabase Dashboard and related services."
    ndr_SupabaseSchemaDiffCleanup
    return 1
  fi

  # ----------------------------------------------------------------
  # Drop all current db connections
  ndr_logInfo "Dropping all active connections to $gNDR_SUPABASE_DB_OPS_PRODUCTION_DB"
  docker compose exec -T db psql -U "$gNDR_SUPABASE_DB_OPS_SUPABASE_ADMIN_USER" -d "$gNDR_SUPABASE_DB_OPS_PRODUCTION_DB" -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='postgres' AND pid <> pg_backend_pid();"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to drop active production DB connections."
    ndr_SupabaseSchemaDiffCleanup
    return 1
  fi

  # ----------------------------------------------------------------
  # Apply db upgrade diff to production DB
  ndr_logInfo "Applying upgrade schema to production DB..."
  # full command arg list
  # sqlOutput=$(docker compose exec -T "$DB_SERVICE" psql -U "$gNDR_SUPABASE_DB_OPS_POSTGRES_ADMIN_USER" -d postgres -v ON_ERROR_STOP=1 < "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF")
  local psql_args=()
  psql_args+=("docker" "compose" "exec" "-T" "$DB_SERVICE" "psql" "-U" "$gNDR_SUPABASE_DB_OPS_POSTGRES_ADMIN_USER" "-d" "postgres")

  # Conditionally add -v ON_ERROR_STOP=1
  if [[ "$gNDR_ALLOW_SCHEMA_ERRORS" != "true" ]]; then
    psql_args+=("-v" "ON_ERROR_STOP=1")
  fi

  # Execute and capture output
  sqlOutput=$("${psql_args[@]}" < "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF")
  return_code=$?

  # Print any ERROR or WARNING lines from sqlOutput
  if [ -n "$sqlOutput" ]; then
    while IFS= read -r line; do
      if echo "$line" | grep -qE 'ERROR|WARNING'; then
        echo "$line"
      fi
    done <<< "$sqlOutput"
  fi

  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to apply upgrade schema to production DB."
    ndr_SupabaseRollbackSchema "$gNDR_SUPABASE_DB_BACKUP_FILE"
    return 1
  fi
  
  # ----------------------------------------------------------------
  # restart services
  docker compose start "$NDR_SUPABASE_APP_SERVICE_NAME_REALTIME" "$NDR_SUPABASE_APP_SERVICE_NAME_REST" "$NDR_SUPABASE_APP_SERVICE_NAME_KONG" "$NDR_SUPABASE_APP_SERVICE_NAME_STUDIO"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to start Supabase services."
    #return 1
  fi

  # ----------------------------------------------------------------
  # Copy diff schema to backup location for reference
  local backup_folder="${gSUPABASE_NEXTDR_HOME}/${gSUPABASE_DB_BACKUP_SUB}"
  local src="$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF"
  local dest="$backup_folder/$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF_FILENAME_SHORT"
  cp "$src" "$dest"
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logWarn "Failed to copy diff file [$src] to [$dest]."
  else
    ndr_logInfo "Copied schema diff file from [$src] to [$dest]."
  fi

  # ----------------------------------------------------------------
  ndr_logInfo "Success: Live DB upgraded."
  
  ndr_logInfo "Cleaning up temporary files..."
  
  ndr_SupabaseSchemaDiffCleanup
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseApplySchema ()
{
  local logSectionDesc="Applying $gPRODUCT_NAME Custom Supabase Schema"
  ndr_logSecStart "$logSectionDesc"

  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into supabase project dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }

  # optionally pass in a schema file to apply instead of the global one.
  local schema_file="${1:-$gACTIVE_NDR_SQL_SCHEMA_FILE}"

  # check for schema file
  if [ -z "$schema_file" ] || [ ! -f "$schema_file" ]; then
    ndr_logError "No active Supabase schema file or parameter option [$schema_file]."
    return 1
  fi

  local DB_SERVICE="$NDR_SUPABASE_APP_SERVICE_NAME_DB"
  
  # determine which user to use based on version (>=1.25.12 use supabase admin due to auth changes)
  ndr_version_ge "$gNDR_SUPABASE_GIT_VERSION_TAG" "1.25.12"
  return_code=$?
  if [ $return_code -eq 0 ]; then
    gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT="$gNDR_SUPABASE_DB_OPS_SUPABASE_ADMIN_USER"
    ndr_logDebug "Supabase version [$gNDR_SUPABASE_GIT_VERSION_TAG] >= 1.25.12, using supabase admin user [$gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT] for schema application."
  fi
  ndr_logInfo "Using schema account [$gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT] for schema application."

  # ----------------------------------------------------------------
  # Stop select services that may re-open connections
  ndr_logInfo "Stopping Supabase Dashboard and related services..."
  docker compose stop "$NDR_SUPABASE_APP_SERVICE_NAME_REALTIME" "$NDR_SUPABASE_APP_SERVICE_NAME_REST" "$NDR_SUPABASE_APP_SERVICE_NAME_KONG" "$NDR_SUPABASE_APP_SERVICE_NAME_STUDIO"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logWarn "Failed to stop Supabase Dashboard and related services."
  fi

  # ----------------------------------------------------------------
  # Drop all current db connections
  ndr_logInfo "Dropping all active connections to $gNDR_SUPABASE_DB_OPS_PRODUCTION_DB"
  docker compose exec -T "$DB_SERVICE" psql -U "$gNDR_SUPABASE_DB_OPS_SUPABASE_ADMIN_USER" -d "$gNDR_SUPABASE_DB_OPS_PRODUCTION_DB" -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='postgres' AND pid <> pg_backend_pid();"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logWarn "Failed to drop active production DB connections."
  fi

  # ----------------------------------------------------------------
  ndr_logInfo "Resetting Supabase database..."
  declare -a schema_list=("public" "auth")

  for drop_schema in "${schema_list[@]}"; do
    # Check if schema file contains 'CREATE SCHEMA $drop_schema'
    if grep -q "^CREATE SCHEMA $drop_schema" "$schema_file"; then
      ndr_logInfo "Schema file [$schema_file] contains $drop_schema schema, resetting $drop_schema schema..."
    
      local sqlOutput=$(docker compose exec -T "$DB_SERVICE" psql -U "$gNDR_SUPABASE_DB_OPS_SUPABASE_ADMIN_USER" -d "$gNDR_SUPABASE_DB_OPS_PRODUCTION_DB" -c "DROP SCHEMA IF EXISTS $drop_schema CASCADE;") # sql script will recreate schema
      return_code=$?
      if [ $return_code -ne 0 ]; then
        ndr_logWarn "Failed to reset Supabase database schema [$drop_schema]"
      fi
    else
      ndr_logInfo "Schema file [$schema_file] does not contain $drop_schema schema, skipping reset of $drop_schema schema."
    fi
  done

  # ----------------------------------------------------------------
  ndr_logInfo "Applying Supabase database schema [$schema_file]..."
  # full command arg list
  # sqlOutput=$(docker exec -i "$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME" psql -U "$gNDR_SUPABASE_DB_OPS_POSTGRES_ADMIN_USER" -d "$gNDR_SUPABASE_DB_OPS_PRODUCTION_DB" -v ON_ERROR_STOP=1 < "$schema_file") # error checking enabled
  
  psql_args=()
  psql_args+=("docker" "exec" "-i" "$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME" "psql" "-U" "$gNDR_SUPABASE_DB_OPS_SCHEMA_APPLY_ACCOUNT" "-d" "$gNDR_SUPABASE_DB_OPS_PRODUCTION_DB")
  # Conditionally add -v ON_ERROR_STOP=1
  if [[ "$gNDR_ALLOW_SCHEMA_ERRORS" != "true" ]]; then
    psql_args+=("-v" "ON_ERROR_STOP=1")
  fi

  # Execute and capture output
  sqlOutput=$("${psql_args[@]}" < "$schema_file")
  return_code=$?
  # Print any ERROR or WARNING lines from sqlOutput
  if [ -n "$sqlOutput" ]; then
    while IFS= read -r line; do
      if echo "$line" | grep -qE 'ERROR|WARNING'; then
        echo "$line"
      fi
    done <<< "$sqlOutput"
  fi
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to apply Supabase database schema [$schema_file]"
    docker compose start "$NDR_SUPABASE_APP_SERVICE_NAME_REALTIME" "$NDR_SUPABASE_APP_SERVICE_NAME_REST" "$NDR_SUPABASE_APP_SERVICE_NAME_KONG" "$NDR_SUPABASE_APP_SERVICE_NAME_STUDIO"
    return 1
  fi
  #[ "$gDebugMode" -eq 1 ] && ndr_logInfo "$schemaReplay"
  
  # ----------------------------------------------------------------
  # restart services
  docker compose start "$NDR_SUPABASE_APP_SERVICE_NAME_REALTIME" "$NDR_SUPABASE_APP_SERVICE_NAME_REST" "$NDR_SUPABASE_APP_SERVICE_NAME_KONG" "$NDR_SUPABASE_APP_SERVICE_NAME_STUDIO"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logWarn "Failed to start Supabase Dashboard and related services."
  fi

  # ----------------------------------------------------------------
  # Validate schema applied by checking for a known table
  ndr_logInfo "Querying Supabase tables for schema..."
  local table_list=$(docker exec -i "$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME" psql -U "$gNDR_SUPABASE_DB_OPS_POSTGRES_ADMIN_USER" -d "$gNDR_SUPABASE_DB_OPS_PRODUCTION_DB" -c '\dt' 2>/dev/null)
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logWarn "Failed to query schema status"
  fi
  
  local searchTable="recovery_plans"
  if [[ -n "$table_list" ]]; then
    # Search for the recovery_plans table
    if echo "$table_list" | grep -q "\b$searchTable\b"; then
      #ndr_logInfo "$table_list"
      ndr_logInfo "Table $searchTable found, schema applied."
    else
      ndr_logInfo "$table_list"
      ndr_logError "Table $searchTable not found. Schema may not have been applied."
      return 1
    fi
  else
    ndr_logError "Table list empty. Schema may not have been applied."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_PromptNDRConsoleAdminAccount ()
{
  ndr_logInfo "Prompting for $gPRODUCT_NAME Console Admin Account details."
  ndr_logSecStart "$logSectionDesc"

  if [ "$gUPGRADE_MODE" == true ]; then
    ndr_logDebug "Upgrade mode set, skipping section."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # Prompt for admin email (username)
  if [[ -z "$gNDR_CONSOLE_ADMIN_ACCOUNT_USER" ]]; then
    while true; do
      read -p "Enter the $gPRODUCT_NAME Console Admin account email address to create: " input_email
      echo >&2 # new line
      # Basic email regex
      if [[ "$input_email" =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]]; then
        read -n 1 -p "You entered: $input_email. Is this correct? (Y/n): "
        echo >&2 # new line
        if [[ $REPLY =~ ^[Nn]$ ]]; then
          continue
        fi
        gNDR_CONSOLE_ADMIN_ACCOUNT_USER="$input_email"
        break
      else
        echo "Invalid email format. Please try again."
        continue
      fi
    done
    
    ndr_logInfo "Using user entered account [$gNDR_CONSOLE_ADMIN_ACCOUNT_USER] to create."
  else
    ndr_logInfo "Using predefined account [$gNDR_CONSOLE_ADMIN_ACCOUNT_USER] to create."
  fi

  # Prompt for admin password (with confirmation)
  if [[ -z "$gNDR_CONSOLE_ADMIN_ACCOUNT_PASSWORD" ]]; then
    while true; do
      read -s -p "Enter $gPRODUCT_NAME Console Admin password: " input_pass1
      echo >&2 # new line
      if [[ -z "$input_pass1" ]]; then
        echo "Password cannot be empty. Please try again."
        continue
      fi

      read -s -p "Re-enter password: " input_pass2
      echo >&2 # new line
      if [[ -z "$input_pass2" ]]; then
        echo "Password cannot be empty. Please try again."
        continue
      fi
      
      if [[ "$input_pass1" != "$input_pass2" ]]; then
        echo "Passwords do not match. Please try again."
        continue
      fi
      
      gNDR_CONSOLE_ADMIN_ACCOUNT_PASSWORD="$input_pass1"
      break
    done
    
    ndr_logInfo "Using user entered password to create."
  else
    ndr_logInfo "Using predefined password to create."
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_CreateNDRConsoleAdminAccount ()
{
  local logSectionDesc="Creating $gPRODUCT_NAME Console Admin Account"
  ndr_logSecStart "$logSectionDesc"

  if [ "$gUPGRADE_MODE" == true ]; then
    ndr_logDebug "Upgrade mode set, skipping section."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # Prompt for account info if not already set
  if [[ -z "$gNDR_CONSOLE_ADMIN_ACCOUNT_USER" || -z "$gNDR_CONSOLE_ADMIN_ACCOUNT_PASSWORD" ]]; then
    ndr_PromptNDRConsoleAdminAccount
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to get $gPRODUCT_NAME Console Admin account info."
      return 1
    fi
  else
    ndr_logInfo "$gPRODUCT_NAME Console Admin Account user and password already populated, skipping prompt."
  fi

  # Admin account creation can be run as a separate post-install command and so the folders need to be populated.
  if [ -z "$gSUPABASE_NEXTDR_HOME" ]; then
    gSUPABASE_NEXTDR_HOME="${gNEXTDR_HOME_DIR}/${gSUPABASE_NEXTDR_SUB}"
  fi
  if [ ! -d "$gSUPABASE_NEXTDR_HOME" ]; then
    ndr_logError "Unable to determine Supabase home directory or directory doesn't exist."
    return 1
  fi

  # Inject: Read API_EXTERNAL_URL and SERVICE_ROLE_KEY from env file
  local env_file="${gSUPABASE_NEXTDR_HOME}/${gNDR_ENV_TARGET_FILENAME}"
  if [[ ! -f "$env_file" ]]; then
    ndr_logError "Env file [$env_file] not found. API_EXTERNAL_URL and SERVICE_ROLE_KEY not loaded."
    return 1
  fi
  
  #API_EXTERNAL_URL=$(grep -E '^API_EXTERNAL_URL=' "$env_file" | cut -d'=' -f2-)
  API_EXTERNAL_URL="http://localhost:8000" # todo - external ip resolving incorrectly on integration vm's, use localhost instead.
  SERVICE_ROLE_KEY=$(grep -E '^SERVICE_ROLE_KEY=' "$env_file" | cut -d'=' -f2-)
  
  if [[ -z "$API_EXTERNAL_URL" || -z "$SERVICE_ROLE_KEY" ]]; then
    ndr_logError "Could not read API_EXTERNAL_URL or SERVICE_ROLE_KEY from env file [$env_file]."
    return 1
  fi
  ndr_logInfo "Read API_EXTERNAL_URL [$API_EXTERNAL_URL] and SERVICE_ROLE_KEY from env file [$env_file]."

  if [[ -z "$gNDR_CONSOLE_ADMIN_ACCOUNT_USER" || -z "$gNDR_CONSOLE_ADMIN_ACCOUNT_PASSWORD" ]]; then
    ndr_logError "$gPRODUCT_NAME Console Admin Account user or password is not set."
    return 1
  fi
  ndr_logInfo "Creating $gPRODUCT_NAME Console Admin Account user [$gNDR_CONSOLE_ADMIN_ACCOUNT_USER]."

  local curlRespFile="/tmp/curlReqResp.json"
  max_retries=3
  attempt=1

  while true; do
    rm -f "$curlRespFile"  # clean up prior

    sleep 3  # wait before attempting since this is called right after container startup.

    create_response=$(curl -s -o "$curlRespFile" -w "%{http_code}" -X POST "$API_EXTERNAL_URL/auth/v1/admin/users" \
    -H "apikey: $SERVICE_ROLE_KEY" \
    -H "Authorization: Bearer $SERVICE_ROLE_KEY" \
    -H "Content-Type: application/json" \
    -d "{
      \"email\": \"$gNDR_CONSOLE_ADMIN_ACCOUNT_USER\",
      \"password\": \"$gNDR_CONSOLE_ADMIN_ACCOUNT_PASSWORD\",
      \"email_confirm\": true,
      \"user_metadata\": {
      \"role\": \"admin\"
      }
    }")
    return_code=$?
    ndr_logInfo "ret code: $return_code"

    # Extract response body
    response_body=$(cat "$curlRespFile")
    #todo rm -f "$curlRespFile"  # clean up


    # Check if the request was successful
    if [[ "$create_response" -eq 200 || "$create_response" -eq 201 ]]; then
      # Parse JSON response for confirmation
      user_email=$(echo "$response_body" | jq -r '.email // empty')
      user_id=$(echo "$response_body" | jq -r '.id // empty')
      user_created_at=$(echo "$response_body" | jq -r '.created_at // empty')
      ndr_logInfo "User created: email=[$user_email], id=[$user_id], created_at=[$user_created_at]"
      break
    fi
    
    ndr_logError "Failed to create user [$gNDR_CONSOLE_ADMIN_ACCOUNT_USER]. Status code: [$create_response], Response body: [$response_body]"

    if [[ $attempt -ge $max_retries ]]; then
      ndr_logError "Max user creation retries reached. Exiting."
      return 1
    fi

    attempt=$((attempt + 1))
    
  done

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_CreateSupabaseDashboardAccount ()
{
  local logSectionDesc="Creating Supabase Dashboard Account"
  ndr_logSecStart "$logSectionDesc"

  if [ "$gUPGRADE_MODE" == true ]; then
    ndr_logDebug "Upgrade mode set, skipping section."
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  if [ "$gExpressMode" -eq 1 ]; then
    # if the dashboard user/pass is not set in express mode, we can still use the standard account in the env file.
    if [[ -z "$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME" || -z "$gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD" ]]; then
      ndr_logWarn "Supabase Dashboard Admin Account user [$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME] or password is not explicitly set for express mode, using default template credentials."
    else
      ndr_logInfo "Using Supabase Dashboard Admin account user [$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME] and password for express mode."
    fi
    ndr_logSecEnd "$logSectionDesc"
    return 0
  fi

  # read default username/password from env file
  # Read DASHBOARD_USERNAME and DASHBOARD_PASSWORD from env file
  local env_file="${gSUPABASE_NEXTDR_HOME}/${gNDR_ENV_TARGET_FILENAME}"
  if [[ ! -f "$env_file" ]]; then
    ndr_logError "Env file [$env_file] not found. Supabase dashboard account cannot be read or set."
    return 1
  fi
  
  # if not already populated via cmdline param, try to pull current val from the env file.
  [[ -z "$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME" ]] && gSUPABASE_ENV_VAL_DASHBOARD_USERNAME=$(grep -E '^DASHBOARD_USERNAME=' "$env_file" | cut -d'=' -f2-)
  [[ -z "$gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD" ]] && gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD=$(grep -E '^DASHBOARD_PASSWORD=' "$env_file" | cut -d'=' -f2-)
  
  if [[ -z "$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME" || -z "$gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD" ]]; then
    ndr_logWarn "Could not prepopulate DASHBOARD_USERNAME or DASHBOARD_PASSWORD from any source."
  fi
  
  # by default, we do not prompt interactively unless in advanced mode or auto generation fails.
  local promptInteractively=false
  #if [ "$gNDR_ADVANCED_MODE" == "true" ]; then
  #  promptInteractively=true
  #fi

  if [ "$promptInteractively" == false ]; then
    gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD=$(ndr_generateSecurePassword "$gSUPABASE_DASHBOARD_PASSWORD_LENGTH" 2>/dev/null)
    #gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD="ndr"
    return_code=$?
    if [[ $return_code -ne 0 || -z "$gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD" ]]; then
      ndr_logWarn "Failed to generate Supabase Dashboard Admin Account password, forcing interactive prompt."
      promptInteractively=true
    fi
  fi
  
  if [ "$promptInteractively" == true ]; then
    # Prompt for admin email (username)
    echo -e "The Supabase Dashboard Admin Account username is currently [$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME]. Is this the username you wish to use for the Dashboard Admin Account?" >&2
    read -p "Choose YES to continue with this username or NO to be prompted to enter a new one [Y|n]" -n 1 -r
    echo >&2   # Move to a new line
    if [[ $REPLY =~ ^[Nn]$ ]]; then
      # clear it and we will prompt below to enter
      gSUPABASE_ENV_VAL_DASHBOARD_USERNAME=""
    fi
      
    if [ -z "$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME" ]; then
      while true; do
        read -p "Enter the Supabase Dashboard Admin account to create: " gSUPABASE_ENV_VAL_DASHBOARD_USERNAME
        echo >&2 # new line
    
        if [ -n "$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME" ]; then
          read -n 1 -p "You entered: $gSUPABASE_ENV_VAL_DASHBOARD_USERNAME. Is this correct? (Y/n): "
          echo >&2 # new line
          if [[ $REPLY =~ ^[Nn]$ ]]; then
            gSUPABASE_ENV_VAL_DASHBOARD_USERNAME=""
            continue
          fi
          break
        else
          echo "Invalid username. Please try again."
          continue
        fi
      done
    fi
    
    # Prompt for admin password (with confirmation)
    while true; do
      read -s -p "Enter Supabase Dashboard Admin Account password: " input_pass1
      echo >&2 # new line
      if [[ -z "$input_pass1" ]]; then
        echo "Password cannot be empty. Please try again."
        continue
      fi

      read -s -p "Re-enter password: " input_pass2
      echo >&2 # new line
      if [[ -z "$input_pass2" ]]; then
        echo "Password cannot be empty. Please try again."
        continue
      fi
      
      if [[ "$input_pass1" != "$input_pass2" ]]; then
        echo "Passwords do not match. Please try again."
        continue
      fi
      
      gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD="$input_pass1"
      break
    done
    
    if [[ -z "$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME" || -z "$gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD" ]]; then
      ndr_logError "Supabase Dashboard Admin Account user or password is not set."
      return 1
    fi
  fi

  ndr_logInfo "Creating Supabase Dashboard Admin Account user [$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME] and password."

  # update env var map entries
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_DASHBOARD_USERNAME"]="$gSUPABASE_ENV_VAL_DASHBOARD_USERNAME"
  gSUPABASE_ENV_VARS["$gSUPABASE_ENV_KEY_DASHBOARD_PASSWORD"]="$gSUPABASE_ENV_VAL_DASHBOARD_PASSWORD"
  
  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_BackupPostgresDB () 
{
  local logSectionDesc="Backing up Supabase Postgres DB"
  ndr_logSecStart "$logSectionDesc"

  local drop_conns="${1:-true}"  # default to true if not passed in.
  
  # ----------------------------------------------------------------
  # prereq module checks
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
  local dbInstalled=$?
  if [ "$dbInstalled" -ne 0 ]; then
    ndr_logError "The $gCOMPANY_NAME Supabase database module does not appear to be currently installed."
    return 1
  fi

  local containerName="$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME"
  ndr_verifyDockerContainerExists "$containerName" >/dev/null
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Container not present [$containerName]"
    return 1
  fi
    
  ndr_verifyDockerContainerRunning "$containerName" >/dev/null
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Container not running [$containerName]"
    return 1
  fi

  # ----------------------------------------------------------------
  # form local home folder paths.
  if [[ -z "$gNEXTDR_HOME_DIR" || ! -d "$gNEXTDR_HOME_DIR" ]]; then
    ndr_logInfo "Home directory is not set or does not exist. Attempting to determine home directory..."
    
    # read from registry if package already present.
    gNEXTDR_HOME_DIR=$(ndr_getHomeDirReg)
    return_code=$?
    if [[ $return_code -eq 0 && -n "$gNEXTDR_HOME_DIR" && -d "$gNEXTDR_HOME_DIR" ]]; then
      ndr_logInfo "Found home directory entry [$gNEXTDR_HOME_DIR] in registry."
    else
      ndr_logWarn "No home directory entry found in registry."
    fi
  fi

  gSUPABASE_NEXTDR_HOME="${gNEXTDR_HOME_DIR}/${gSUPABASE_NEXTDR_SUB}"
  if [[ -z "$gSUPABASE_NEXTDR_HOME" || ! -d "$gSUPABASE_NEXTDR_HOME" ]]; then
    ndr_logError "Unable to determine Supabase home directory or directory doesn't exist. Please install the local Supabase module prior to pulling the reference schema so there is a local instance to link the remote instance to."
    return 1
  fi

  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into supabase project dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }

  local backup_folder="${gSUPABASE_NEXTDR_HOME}/${gSUPABASE_DB_BACKUP_SUB}"
  if [ ! -d "$backup_folder" ]; then
    mkdir "$backup_folder"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to create db backup folder [$backup_folder]"
      return 1
    fi
    ndr_logInfo "Successfully created db backup  folder [$backup_folder]"
  else
    ndr_logInfo "DB backup folder already exists [$backup_folder]"
  fi

  if [ "$drop_conns" = true ]; then
    # ----------------------------------------------------------------
    # Stop select services that may re-open connections
    ndr_logInfo "Stopping Supabase Dashboard and related services..."
    docker compose stop "$NDR_SUPABASE_APP_SERVICE_NAME_REALTIME" "$NDR_SUPABASE_APP_SERVICE_NAME_REST" "$NDR_SUPABASE_APP_SERVICE_NAME_KONG" "$NDR_SUPABASE_APP_SERVICE_NAME_STUDIO"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logWarn "Failed to stop Supabase Dashboard and related services."
    fi

    # ----------------------------------------------------------------
    # Drop all current db connections
    ndr_logInfo "Dropping all active connections to $gNDR_SUPABASE_DB_OPS_PRODUCTION_DB"
    docker compose exec -T "$DB_SERVICE" psql -U "$gNDR_SUPABASE_DB_OPS_SUPABASE_ADMIN_USER" -d "$gNDR_SUPABASE_DB_OPS_PRODUCTION_DB" -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='postgres' AND pid <> pg_backend_pid();"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logWarn "Failed to drop active production DB connections."
    fi
  fi
  
  # ----------------------------------------------------------------
  local version_stamp=$(ndr_getModuleVersionReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME")
  return_code=$?
  if [[ $return_code -ne 0 || -n "$version_stamp" ]]; then
    version_stamp="$gPRODUCT_VERSION"
  fi

  # create backup file dump
  local timestamp
  timestamp=$(date +"%Y%m%d_%H%M%S")
  gNDR_SUPABASE_DB_BACKUP_FILE="${backup_folder}/NDR-schema-bkp_v${version_stamp}_${timestamp}.sql"

  ndr_logInfo "🔄 Starting full Postgres backup to: $gNDR_SUPABASE_DB_BACKUP_FILE"

  # build as an array to allow for easier conditional appending of options.
  local cmd=(docker compose exec -T db pg_dump -U postgres -d postgres --no-owner --schema=public)
  
  cmd+=(--schema=auth)

  if [ "$gNDR_POSTGRES_EXPORT_SCHEMA_ONLY" = true ]; then
    cmd+=(--schema-only)
  fi

  "${cmd[@]}" > "$gNDR_SUPABASE_DB_BACKUP_FILE"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Backup failed."
    return 1
  fi
  echo "Backup dump completed successfully: $gNDR_SUPABASE_DB_BACKUP_FILE"

  # ----------------------------------------------------------------
  # create tarball of the entire db folder
  local db_dir="$gSUPABASE_NEXTDR_HOME/volumes/db/data"
  local db_tar_file="${backup_folder}/NDR-db-vol-bkp_v${version_stamp}_${timestamp}.tar.gz"
  ndr_logInfo "Creating tarball of Supabase Postgres data folder: $db_dir to $db_tar_file"
  tar -czf "$db_tar_file" -C "$db_dir" .
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Failed to create archive $db_tar_file from $db_dir"
    return 1
  fi
  ndr_logInfo "Created archive $db_tar_file from $db_dir"

  if [ "$drop_conns" = true ]; then
    # ----------------------------------------------------------------
    # restart containers after backup
    docker compose start "$NDR_SUPABASE_APP_SERVICE_NAME_REALTIME" "$NDR_SUPABASE_APP_SERVICE_NAME_REST" "$NDR_SUPABASE_APP_SERVICE_NAME_KONG" "$NDR_SUPABASE_APP_SERVICE_NAME_STUDIO"
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to start Supabase Dashboard and related services."
      #return 1
    fi
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_RestorePostgresDB () 
{
  local logSectionDesc="Restoring Supabase Postgres DB"
  ndr_logSecStart "$logSectionDesc"

  local databaseApplyOption="$1"

  # prereq module check
  ndr_isModuleInstalledReg "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
  local dbInstalled=$?
  if [[ "$dbInstalled" -ne 0 ]]; then
    ndr_logError "The $gCOMPANY_NAME Supabase database module does not appear to be currently installed."
    return 1
  fi

  local containerName="$NDR_SUPABASE_APP_SERVICE_NAME_DB_CONTAINER_NAME"
  ndr_verifyDockerContainerExists "$containerName" >/dev/null
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Container not present [$containerName]"
    return 1
  fi
    
  ndr_verifyDockerContainerRunning "$containerName" >/dev/null
  return_code=$?
  if [ $return_code != 0 ]; then
    ndr_logError "Container not running [$containerName]"
    return 1
  fi

  # form local hoome folder paths.
  if [[ -z "$gNEXTDR_HOME_DIR" || ! -d "$gNEXTDR_HOME_DIR" ]]; then
    ndr_logInfo "Home directory is not set or does not exist. Attempting to determine home directory..."
    
    # read from registry if package already present.
    gNEXTDR_HOME_DIR=$(ndr_getHomeDirReg)
    return_code=$?
    if [[ $return_code -eq 0 && -n "$gNEXTDR_HOME_DIR" && -d "$gNEXTDR_HOME_DIR" ]]; then
      ndr_logInfo "Found home directory entry [$gNEXTDR_HOME_DIR] in registry."
    else
      ndr_logWarn "No home directory entry found in registry."
    fi
  fi

  gSUPABASE_NEXTDR_HOME="${gNEXTDR_HOME_DIR}/${gSUPABASE_NEXTDR_SUB}"
  if [[ -z "$gSUPABASE_NEXTDR_HOME" || ! -d "$gSUPABASE_NEXTDR_HOME" ]]; then
    ndr_logError "Unable to determine Supabase home directory or directory doesn't exist. Please install the local Supabase module prior to pulling the reference schema so there is a local instance to link the remote instance to."
    return 1
  fi

  cd "$gSUPABASE_NEXTDR_HOME" || { ndr_logError "Failed to cd into supabase project dir [$gSUPABASE_NEXTDR_HOME]"; return 1; }

  local schema_found=false
  if [ "$schema_found" == false ]; then
    if [ "$databaseApplyOption" == "upgrade" ]; then
      # for upgrades, if a diff schema file was explicitly supplied, we can use that, skip the diff process, skip the full schema file validation and immdiately apply the diff file.
      if [[ -n "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF" && -f "$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF" ]]; then
        ndr_logInfo "Using explicitly supplied upgrade diff schema file [$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF] to apply upgrade."
        gNDR_SUPABASE_DB_SCHEMA_FILE="$gNDR_SUPABASE_UPGRADE_SCHEMA_FILE_DIFF"
        schema_found=true
      fi
    fi
  fi

  if [ "$schema_found" == false ]; then
    # if schema file not already populated or doesn't exist, prompt for it
    if [[ -z "$gNDR_SUPABASE_DB_SCHEMA_FILE" || ! -f "$gNDR_SUPABASE_DB_SCHEMA_FILE" ]]; then
      while true; do
        read -p "Enter the Supabase schema file you wish to restore: " input_file
        echo >&2 # new line
        read -n 1 -p "You entered: [$input_file]. Is this correct? (Y/n/a): "
        echo >&2 # new line
        if [[ $REPLY =~ ^[Nn]$ ]]; then
          continue
        fi
        if [[ $REPLY =~ ^[Aa]$ ]]; then
          ndr_logInfo "Aborting."
          return 1
        fi
        if [[ -z "$input_file" || ! -f "$input_file" ]]; then
          ndr_logWarn "Invalid filename or file does not exist, please enter again [$input_file]"
          continue
        fi
        gNDR_SUPABASE_DB_SCHEMA_FILE="$input_file"
        break
      done
    fi
  fi
  ndr_logInfo "Using file [$gNDR_SUPABASE_DB_SCHEMA_FILE] to restore."

  gACTIVE_NDR_SQL_SCHEMA_FILE=$gNDR_SUPABASE_DB_SCHEMA_FILE

  if [ "$databaseApplyOption" == "upgrade" ]; then
    ndr_SupabaseUpgradeSchema "$gACTIVE_NDR_SQL_SCHEMA_FILE"
  else
    ndr_SupabaseApplySchema "$gACTIVE_NDR_SQL_SCHEMA_FILE"
  fi
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Restore of schema [$gACTIVE_NDR_SQL_SCHEMA_FILE] failed."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseQueryLatestTag ()
{
  local logSectionDesc="Querying Latest Supabase Repo Tag"
  ndr_logSecStart "$logSectionDesc"

  local repo="$gNDR_SUPABASE_GIT_REPO"
  local startTag="$gNDR_SUPABASE_GIT_VERSION_TAG"

  # Normalize the input tag (remove 'v' prefix if present)
  cleanStartTag=$(echo "$startTag" | sed 's/^v//')

  # Fetch and normalize all tags
  ndr_logInfo "Fetching and sorting tags from $repo..."
  tag_list=$(
    curl -s "https://api.github.com/repos/$repo/tags?per_page=100" |
    jq -r '.[].name' |
    awk '{ orig=$0; clean=$0; gsub(/^v/, "", clean); print clean "\t" orig }' |
    sort -V -k1,1
  )

  # Print tag list for visibility (optional)
  #echo "Sorted tags:"
  #echo "$tag_list" | awk '{print NR " → " $2 " (clean=" $1 ")"}'

  # Get the last/latest entry
  latest_tag=$(echo "$tag_list" | tail -n 1 | awk '{print $2}')

  ndr_logInfo "Latest tag detected: ${latest_tag:-none}"
  if [ -z "$latest_tag" ]; then
    ndr_logWarn "Unable to find latest tag beyond [$startTag]"
    return 1
  fi

  if [ "$latest_tag" == "$cleanStartTag" ]; then
    ndr_logInfo "Tag [$cleanStartTag] is already latest/up to date for repo."
    return 0
  fi

  # query for hash for this tag
  local commit=$(curl -s "https://api.github.com/repos/$repo/git/ref/tags/$latest_tag" | jq -r '.object.sha')

  if [ -z "$commit" ] || [ "$commit" == "null" ]; then
    ndr_logWarn "No commit found for tag $latest_tag."
    return 1
  fi

  gNDR_SUPABASE_GIT_VERSION_COMMIT_HASH_FULL="$commit"
  gNDR_SUPABASE_GIT_VERSION_COMMIT_HASH_SHORT=$(echo "$commit" | cut -c1-7)
  gNDR_SUPABASE_GIT_VERSION_TAG="$latest_tag"

  ndr_logInfo "Updating to latest Supabase tag [$gNDR_SUPABASE_GIT_VERSION_TAG], commit [$gNDR_SUPABASE_GIT_VERSION_COMMIT_HASH_FULL ($gNDR_SUPABASE_GIT_VERSION_COMMIT_HASH_SHORT)]"

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_SupabaseQueryLatestCommit ()
{
  local logSectionDesc="Querying Latest Supabase Repo Commit"
  ndr_logSecStart "$logSectionDesc"

  local repo="$gNDR_SUPABASE_GIT_REPO"
  local startTag="$gNDR_SUPABASE_GIT_VERSION_TAG"

  #if [[ -n "$gNDR_SUPABASE_GIT_VERSION_TAG_NEXT" && -n "$gNDR_SUPABASE_GIT_VERSION_COMMIT_HASH_FULL" ]]; then
  #  ndr_logInfo "Supabase repo version info already populated. Skipping."
  #  ndr_logSecEnd "$logSectionDesc"
  #  return 0
  #fi

  # Normalize the input tag (remove 'v' prefix if present)
  local cleanStartTag=$(echo "$startTag" | sed 's/^v//')

  # Fetch and normalize all tags
  ndr_logInfo "Fetching and sorting tags from $repo..."
  tag_list=$(
    curl -s "https://api.github.com/repos/$repo/tags?per_page=100" |
    jq -r '.[].name' |
    awk '{ orig=$0; clean=$0; gsub(/^v/, "", clean); print clean "\t" orig }' |
    sort -V -k1,1
  )

  # Print tag list for visibility (optional)
  #echo "Sorted tags:"
  #echo "$tag_list" | awk '{print NR " → " $2 " (clean=" $1 ")"}'

  # Find next tag after the given one
  local nextTag=$(echo "$tag_list" | awk -v target="$cleanStartTag" '
    found { print $2; exit }   # print the next tag after the match
    $1 == target { found=1 }   # mark when we find the current tag
  ')

  echo "Matched cleanStartTag: $cleanStartTag"
  echo "Next tag detected: ${nextTag:-none}"

  if [ -z "$nextTag" ]; then
    nextTag="master"
  fi
  gNDR_SUPABASE_GIT_VERSION_TAG_NEXT="$nextTag"
  
  # all commits between startTag and nextTag
  #local commits=$(curl -s "https://api.github.com/repos/$repo/compare/$startTag...$nextTag" | jq -r '.commits[].sha')

  # only latest commit between startTag and nextTag
  local commit=$(curl -s "https://api.github.com/repos/$repo/compare/$startTag...$nextTag" | jq -r '.commits[-1].sha')
  if [ -z "$commit" ] || [ "$commit" == "null" ]; then
    ndr_logWarn "No commits found between $startTag and $nextTag."
    return 1
  fi

  gNDR_SUPABASE_GIT_VERSION_COMMIT_HASH_FULL="$commit"
  gNDR_SUPABASE_GIT_VERSION_COMMIT_HASH_SHORT=$(echo "$commit" | cut -c1-7)
  ndr_logInfo "Latest commit between $startTag and $nextTag: $commit ($gNDR_SUPABASE_GIT_VERSION_COMMIT_HASH_SHORT)"
  

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_BuildSupabaseApplication ()
{
  local logSectionDesc="Building and Installing Supabase Docker application"
  ndr_logSecStart "$logSectionDesc"

  local appBuildOptions="${1:-$NDR_SUPABASE_APP_BUILD_OPTIONS_NONE}"
  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_NONE )); then
    ndr_logError "No build options specified."
    return 1
  fi

  ndr_PrepareSupabaseInstallation "$appBuildOptions"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Supabase prepare step failed."
    return 1
  fi

  ndr_ConfigureSupabaseInstallation "$appBuildOptions"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Supabase configure step failed."
    return 1
  fi
  
  ndr_InstallSupabaseApplication "$appBuildOptions"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Supabase install step failed."
    return 1
  fi
  
  ndr_PostInstallSupabaseApplication "$appBuildOptions"
  return_code=$?
  if [ $return_code -ne 0 ]; then
    ndr_logError "Supabase post install step failed."
    return 1
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_PrepareSupabaseInstallation ()
{
  local logSectionDesc="Prepare Supabase Application"
  ndr_logSecStart "$logSectionDesc"

  local appBuildOptions="${1:-$NDR_SUPABASE_APP_BUILD_OPTIONS_NONE}"
  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_NONE )); then
    ndr_logError "No build options specified."
    return 1
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_INSTALL_PREREQUISITES )); then
    ndr_packagePrereqCheck
    return_code=$?
    if [ $return_code -ne 0 ]; then
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_HOME_DIR_CHECK )); then
    if [[ "$gNDR_DEVOPS_MODE" == true ]]; then
      gNEXTDR_HOME_DIR="$PWD"
    else
      ndr_InstallHomeCheck
      return_code=$?
      if [ $return_code -ne 0 ]; then
        return 1
      fi
    fi

    gSUPABASE_NEXTDR_HOME="${gNEXTDR_HOME_DIR}/${gSUPABASE_NEXTDR_SUB}"
    gSUPABASE_TEMPLATE_HOME="${gNEXTDR_HOME_DIR}/${gSUPABASE_TEMPLATE_SUB}"
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_INSTALL_PROMPTS )); then
    ndr_PromptHostAddress
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to prompt for host address."
      return 1
    fi

    ndr_PromptNDRConsoleAdminAccount
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to prompt for Supabase dashboard account details."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_CLEANUP_EXISTING_APP )); then
    local cleanupOptions=$NDR_SUPABASE_CLEANUP_OPTION_BEST_EFFORT
    ndr_SupabaseContainerCleanup $cleanupOptions
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to clean up Supabase containers."
      return 1
    fi
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_ConfigureSupabaseInstallation ()
{
  local logSectionDesc="Configuring Supabase Installation"
  ndr_logSecStart "$logSectionDesc"

  local appBuildOptions="${1:-$NDR_SUPABASE_APP_BUILD_OPTIONS_NONE}"
  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_NONE )); then
    ndr_logError "No build options specified."
    return 1
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_SUPABASE_DIRS )); then
    ndr_CreateSupabaseFolders
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to create Supabase folders."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_GIT_CLONE_TEMPLATE )); then
    ndr_PullSupabaseGitTemplate
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to pull Supabase git template."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_TEMPLATE_FILES )); then
    ndr_CopySupabaseTemplateFiles
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to copy Supabase template files."
      return 1
    fi
  fi
  
  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_CUSTOMIZE_COMPOSE_FILE )); then
    ndr_customizeSupabaseDockerComposeFile "$appBuildOptions"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to customize $gCOMPANY_NAME Docker compose file."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_QUERY_COMPOSE_SERVICES )); then
    local dockerComposeFile="$gSUPABASE_NEXTDR_HOME/docker-compose.yml"
    ndr_ParseComposeFileServices "$dockerComposeFile"
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to parse Docker compose file [$dockerComposeFile] service entries."
      return 1
    fi
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_InstallSupabaseApplication ()
{
  local logSectionDesc="Installing Supabase Application"
  ndr_logSecStart "$logSectionDesc"

  local appBuildOptions="${1:-$NDR_SUPABASE_APP_BUILD_OPTIONS_NONE}"
  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_NONE )); then
    ndr_logError "No build options specified."
    return 1
  fi

  if [ "$gUPGRADE_MODE" == false ]; then
    if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_SUPABASE_APP_REGISTRY )); then
      ndr_RegistryCreate "$gPRODUCT_VERSION" "$gNEXTDR_HOME_DIR" "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
      return_code=$?
      if [ $return_code -ne 0 ]; then
        return 1
      fi
      ndr_logInfo "Successfully created registry."
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_POPULATE_HOST_ADDRESS )); then
    ndr_PopulateHostAddress
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to populate hostname/ip address for remote host resolution."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_SCHEMA_FILE_CHECK )); then
    ndr_SupabaseLocalSchemaFileCheck
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "No active Supabase schema file found."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_ENV_FILE )); then
    ndr_CopySupabaseEnvFile
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to copy $gCOMPANY_NAME Supabase env file."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_DASHBOARD_ACCOUNT )); then
    ndr_CreateSupabaseDashboardAccount
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to create Supabase Dashboard account."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_CUSTOMIZE_ENV_FILE )); then
    ndr_CustomizeSupabaseEnvFile
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to customize $gCOMPANY_NAME Supabase env file."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_PULL_SUPABASE_BASE_IMAGES )); then
    ndr_PullSupabaseBaseDockerImages
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to pull Supabase base Docker images."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_BRIDGE_NETWORK )); then
    # create the bridge network if it does not exist
    ndr_createDockerBridgeNetwork
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to create Docker bridge network."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_START_CONTAINERS )); then
    ndr_StartSupabaseDockerContainers
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to start Supabase $gCOMPANY_NAME Docker containers."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_VERIFY_CONTAINERS )); then
    # check if the newly built Docker containers exist
    ndr_verifySupabaseContainersExist
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Docker container verification failed."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_SUPABASE_APP_REGISTRY )); then
    ndr_RegistryAddKeyServiceEntries
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to add Docker service entries to registry"
      return 1
    fi
    ndr_logInfo "Successfully added Docker compose file service entries to registry."
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_APPLY_SCHEMA )); then
    if [ "$gUPGRADE_MODE" == true ]; then
      ndr_SupabaseUpgradeSchema "$gACTIVE_NDR_SQL_SCHEMA_FILE"
    else
      ndr_SupabaseApplySchema "$gACTIVE_NDR_SQL_SCHEMA_FILE"
    fi
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Application of custom schema failed."
      return 1
    fi
  fi

  if [ "$gUPGRADE_MODE" == true ]; then
    if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_SUPABASE_APP_REGISTRY )); then
      ndr_RegistryCreate "$gPRODUCT_VERSION" "$gNEXTDR_HOME_DIR" "$gREGISTRY_ENTRY_MODULE_STATUS_SUPABASE_NAME"
      return_code=$?
      if [ $return_code -ne 0 ]; then
        return 1
      fi
      ndr_logInfo "Successfully updated registry."
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_ADMIN_ACCOUNT )); then
    ndr_CreateNDRConsoleAdminAccount
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Admin account creation failed."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_BACKUP_SCHEMA )); then
    ndr_BackupPostgresDB
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "DB backup failed."
      #return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_INSTALL_FILES )); then
    ndr_CopyInstallHomeFiles
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to copy install home files"
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_COPY_SCHEMA_FILE )); then
    ndr_CopySupabaseSchemaFile
    return_code=$?
    if [ $return_code != 0 ]; then
      ndr_logError "Failed to copy $gCOMPANY_NAME Supabase schema file."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_CREATE_SYSTEMD )); then
    ndr_InstallSystemdUnit_Supabase
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to create systemd service unit for Supabase"
      return 1
    fi
  fi
  
  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_APP_INSTALL_COMPLETE_NOTIFY )); then
    ndr_SupabaseInstallCompletePopulateReport
    ndr_SupabaseInstallCompleteNotify
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

function ndr_PostInstallSupabaseApplication ()
{
  local logSectionDesc="Post install Supabase Application"
  ndr_logSecStart "$logSectionDesc"

  local appBuildOptions="${1:-$NDR_SUPABASE_APP_BUILD_OPTIONS_NONE}"
  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_NONE )); then
    ndr_logError "No build options specified."
    return 1
  fi

  # in devops mode only if we have previously stopped the containers, offer to restart.
  if [[ "$gNDR_DEVOPS_MODE" == true ]]; then
    if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_STOP_CONTAINERS )); then
      echo "Supabase application build is now complete. Would you like to keep and start the application or continue to remove and clean up?"
      read -p "Yes to keep and start or No to remove and clean up [Y|n]" -n 1 -r
      echo    # Move to a new line
      if [[ $REPLY =~ ^[Nn]$ ]]; then
        ndr_logInfo "Cleanup chosen, proceeding to remove application."
      else
        ndr_logInfo "Keep application chosen, proceeding to restart application."

        ndr_StartSupabaseDockerContainers
        return_code=$?
        if [ $return_code != 0 ]; then
          ndr_logError "Failed to start Supabase $gCOMPANY_NAME Docker containers."
          return 1
        fi

        # exit here before any further cleanup.
        return 0
      fi
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_REMOVE_SUPABASE_APP )); then
    ndr_SupabaseContainerCleanup
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to clean up Supabase containers."
      return 1
    fi
  fi

  if (( appBuildOptions & NDR_SUPABASE_APP_BUILD_OPTIONS_CLEANUP_SUPABASE_DIRS )); then
    ndr_CleanupSupabaseProjectDirs
    return_code=$?
    if [ $return_code -ne 0 ]; then
      ndr_logError "Failed to clean up Supabase Docker folders."
      return 1
    fi
  fi

  ndr_logSecEnd "$logSectionDesc"

  return 0
}

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  ndr_logWarn "This is a bash module--there is no direct execution capabilities in this file."
  exit 0
fi
