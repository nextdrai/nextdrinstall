#!/bin/bash
# ndrVersion.sh - A Bash module providing package versioning information.

export gPRODUCT_VERSION_MAJOR="1"
export gPRODUCT_VERSION_MINOR="1"
export gPRODUCT_VERSION_PATCH="0"
export gPRODUCT_VERSION="${gPRODUCT_VERSION_MAJOR}.${gPRODUCT_VERSION_MINOR}.${gPRODUCT_VERSION_PATCH}"
