--
-- NextDR Supabase Database Schema 
-- NDR-SCHEMA-VERSION: 1.1.0
-- NDR-UPGRADE-FROM: 1.0.0
-- NDR-SCHEMA-TYPE: INCR
-- NDR-FULL-BASELINE-SCHEMA-SHA256: 89c8598ca67fbada3c6a984264bb0494773e2711cc8a5a06804f2258f42ac16c
-- NDR-FULL-UPGRADE-SCHEMA-SHA256: d16af6fecf6988710962f5aa94366e6fa438e1b4def81d1ec3eab979ae1465a6
--

alter table "public"."recovery_plan_progress" drop constraint "recovery_plan_progress_status_check";

alter table "public"."recovery_plans_new" drop constraint "recovery_plans_new_execution_status_check";

alter table "public"."application_groups" add column "minimum_backup_count" integer default 0;

alter table "public"."backup_run" add column "project_config" jsonb not null default '{}'::jsonb;

alter table "public"."backup_run" add column "retention_period" bigint default '7'::bigint;

alter table "public"."datacenters2" add column "is_control_plane" boolean default false;

alter table "public"."recovery_plan_progress" add constraint "recovery_plan_progress_status_check" CHECK ((status = ANY (ARRAY['pending'::text, 'in_progress'::text, 'completed'::text, 'failed'::text, 'stopped'::text, 'awaiting_approval'::text, 'approved'::text, 'rejected'::text]))) not valid;

alter table "public"."recovery_plan_progress" validate constraint "recovery_plan_progress_status_check";

alter table "public"."recovery_plans_new" add constraint "recovery_plans_new_execution_status_check" CHECK ((execution_status = ANY (ARRAY['not_started'::text, 'in_progress'::text, 'paused'::text, 'completed'::text, 'stopped'::text, 'failed'::text]))) not valid;

alter table "public"."recovery_plans_new" validate constraint "recovery_plans_new_execution_status_check";

create policy "Edit"
on "public"."datacenters2"
as permissive
for update
to authenticated
using (true)
with check (true);

alter publication supabase_realtime add table public.recovery_step_execution;
alter publication supabase_realtime add table public.recovery_plan_execution;