--
-- NextDR Supabase Database Schema 
-- NDR-SCHEMA-VERSION: 1.1.3
-- NDR-UPGRADE-FROM: 1.1.2
-- NDR-SCHEMA-TYPE: INCR
-- NDR-FULL-BASELINE-SCHEMA-SHA256: 5d355b0c77cefda41203cff3984ff7470d135f2c29f29730dfbd0e07e13da34b
-- NDR-FULL-UPGRADE-SCHEMA-SHA256: dd01f609bc8743f4a8a6ff3fc9c35c813c1ba579eae600ab93ada26ee40c3232
--

alter table "public"."resource_backup" alter column "completed_at" drop default;

alter table "public"."resource_backup" alter column "started_at" drop default;